
/* =========================================================================
   8º E 9º ANO — dicas ("Como fazer") e descritores do Paebes (acrescentado)
   Só acrescenta chaves em DICA, DESCRITORES e DESC_DE. Nada é reescrito.
========================================================================= */
Object.assign(DESCRITORES, {
  D029: 'Cálculos com valores aproximados de radicais', D049: 'Relações métricas no triângulo retângulo',
  D063: 'Listas e tabelas com os gráficos que as representam', D077: 'Sistema de equações que representa um problema',
  D087: 'Problemas com equação do 2º grau', D154: 'Sistema de equações: forma algébrica e gráfica',
});
Object.assign(DESC_DE, {
  pot8: ['D010'], raiz8: ['D029', 'D010'], probRac8: ['D024'], seq8: ['D081'], alg8: ['D018', 'D081'], porc8: ['D038'], classes8: ['D064', 'D153'],
  grafAdeq8: ['D063', 'D064'], medidas8: ['D064'], contagem8: ['D042'], prob8: ['D065'], propTipo8: ['D039'], regra3_8: ['D039'], retaEq8: ['D043', 'D154'],
  sistema8: ['D077', 'D154'], quadProp8: ['D117'], area8: ['D058'], vol8: ['D062', 'D060'], eq2_8: ['D120'], geo8: ['D118'],
  pot9: ['D010', 'D029'], cient9: ['D010'], porcSuc9: ['D038'], razao9: ['D039'], escala9: ['D039'], paral9: ['D144'], tales9: ['D039'],
  graf9: ['D064'], prob9: ['D065'], prodNot9: ['D018'], fator9: ['D018'], eq2g9: ['D087'], semelh9: ['D113', 'D116'], pitag9: ['D049'],
  circ9: ['D121'], irrac9: ['D009', 'D013'], vistas9: ['D111'], volPC9: ['D062', 'D058'], funcao9: ['D018', 'D043'],
});
Object.assign(DICA, {
  // 8º ano
  pot8: m => m.tipo === 'prop' ? 'Mesma base: na multiplicação SOMA os expoentes; na divisão SUBTRAI; potência de potência MULTIPLICA.' : m.tipo === 'ida' ? 'Ponha a vírgula depois do 1º algarismo e conte quantas casas ela andou: para a esquerda o expoente é positivo; para a direita, negativo.' : m.tipo === 'volta' ? 'Expoente positivo: ande com a vírgula para a DIREITA; negativo: para a ESQUERDA. Complete com zeros.' : 'Expoente negativo: inverta a base (2⁻³ = 1/2³). Base negativa entre parênteses: expoente par dá +, ímpar dá −. Sem parênteses, o − fica de fora.',
  raiz8: m => m.modo === 'entre' || m.modo === 'prox' ? 'Liste os quadrados perfeitos (1, 4, 9, 16, 25, 36…) e veja entre quais o número está.' : m.tipo === 'radical' ? 'O denominador do expoente vira o índice da raiz e o numerador vira o expoente: 5^(2/3) = ∛(5²).' : 'Pense: que número vezes ele mesmo dá o valor de dentro? Com vírgula: √0,49 = 0,7 (7 × 7 = 49).',
  probRac8: () => 'Escreva a conta em etapas. "Do que sobrou" quer dizer: primeiro tire a 1ª parte, depois calcule a fração do resto.',
  seq8: m => m.modo === 'termo' ? `Troque n pela posição pedida e faça a conta (primeiro a multiplicação).` : m.modo === 'lei' ? 'Veja quanto aumenta de um termo para o outro: esse é o número que multiplica o n. Depois ajuste para acertar o 1º termo.' : 'Calcule termo a termo, a partir dos que você já tem.',
  alg8: m => m.modo === 'vn' ? 'Troque cada letra pelo número entre parênteses: (−3)² = +9, mas −3² = −9.' : m.modo === 'poli' ? 'Soma: junte só os números e mantenha a letra e o expoente. Produto: multiplique os números e SOME os expoentes.' : 'Ache o maior número (e a letra) que divide os dois termos. Divida cada termo por ele e escreva o resto dentro do parêntese.',
  porc8: () => '10% = dividir por 10; 1% = dividir por 100. Desconto de p%: você paga (100 − p)% do preço. Para achar o preço antigo, divida o que pagou pela parte que pagou.',
  classes8: () => 'a ⊢ b inclui o a e NÃO inclui o b (o b vai para a próxima classe). Risque cada número à medida que conta.',
  grafAdeq8: () => 'Partes de um todo (%): setores. Mudança no tempo: linhas. Comparar categorias: colunas. Comparar dois grupos em cada categoria: colunas duplas.',
  medidas8: m => ({ moda: 'Moda = o valor que mais se repete.', amplitude: 'Amplitude = maior valor − menor valor.', mediana: 'Coloque em ordem. Mediana = o do meio (se forem dois no meio, faça a média deles).', media: 'Média = soma de todos ÷ quantidade de valores.' })[m.pergunta] || '',
  contagem8: () => 'Princípio multiplicativo: quantas escolhas para a 1ª posição × quantas para a 2ª × … (se não pode repetir, cada posição tem uma a menos).',
  prob8: () => 'Monte todos os resultados possíveis (árvore): moeda e dado = 2 × 6 = 12. Chance = resultados que servem ÷ total. As chances de tudo somam 1 (100%).',
  propTipo8: () => 'Divida y por x em cada coluna: sempre igual → direta. Multiplique x por y: sempre igual → inversa. Nenhum dos dois → não proporcionais.',
  regra3_8: () => 'Primeiro pense: se uma aumenta, a outra aumenta (direta) ou diminui (inversa)? Na composta, analise cada grandeza separado com a que se quer achar.',
  retaEq8: m => m.modo === 'graf' ? 'Veja onde a reta corta o eixo y (número somado) e quanto ela sobe (ou desce) para cada 1 que anda para a direita (número que multiplica x).' : 'Troque x e y pelos números do ponto: se a igualdade der certo, o ponto está na reta.',
  sistema8: () => 'Some as equações para sumir com o y (ou isole uma letra e substitua na outra). No problema: dê nome às duas quantidades e escreva as duas informações.',
  quadProp8: () => 'Quadrado = retângulo + losango. Retângulo: 4 ângulos retos, diagonais iguais. Losango: 4 lados iguais, diagonais perpendiculares. Trapézio: só 1 par de lados paralelos.',
  area8: () => 'Triângulo: base × altura ÷ 2. Paralelogramo: base × altura (não o lado inclinado). Trapézio: (B + b) × h ÷ 2. Losango: D × d ÷ 2. Círculo: π × r².',
  vol8: () => 'Volume = comprimento × largura × altura. 1 m³ = 1000 L; 1 dm³ = 1 L; 1000 cm³ = 1 L.',
  eq2_8: () => 'Deixe o x² sozinho e tire a raiz. Na equação, x pode ser positivo OU negativo; numa medida, só o positivo serve.',
  geo8: m => m.modo === 'lugar' ? 'Mediatriz: mesma distância de dois PONTOS. Bissetriz: mesma distância de duas RETAS (divide o ângulo ao meio). Circunferência: mesma distância de UM ponto.' : 'Diagonais = n · (n − 3) ÷ 2. A bissetriz divide o ângulo em duas partes iguais; ponto da mediatriz fica à mesma distância de A e B.',
  // 9º ano
  pot9: m => m.modo === 'simp' ? 'Procure o maior quadrado perfeito que divide o número (4, 9, 16, 25, 36, 49…): √72 = √(36 · 2) = 6√2.' : 'Expoente negativo inverte a base. Expoente fracionário: o de baixo é o índice da raiz, o de cima é a potência. √a · √b = √(a · b).',
  cient9: () => 'Multiplique (ou divida) os números da frente e SOME (ou subtraia) os expoentes do 10. Se o da frente passar de 10, ajuste: 12 × 10³ = 1,2 × 10⁴.',
  porcSuc9: () => 'Cada aumento de p% é multiplicar por (1 + p/100); cada desconto, por (1 − p/100). O segundo é sobre o preço NOVO, então não dá para somar as porcentagens.',
  razao9: () => 'Velocidade = distância ÷ tempo. Densidade demográfica = habitantes ÷ área. Densidade = massa ÷ volume. Consumo = km ÷ litros.',
  escala9: m => m.esc ? 'Multiplique a medida do mapa pelo número da escala (dá em cm) e converta: 100 cm = 1 m; 100 000 cm = 1 km.' : 'Some as partes para saber quantas partes há ao todo. Divida o total por isso (valor de 1 parte) e multiplique pela parte da pessoa.',
  paral9: () => 'Com paralelas, os ângulos "do mesmo tipo" (agudo com agudo, obtuso com obtuso) são iguais; um agudo e um obtuso somam 180°.',
  tales9: () => 'Os segmentos de uma transversal são proporcionais aos da outra: a/b = c/d. Multiplique em cruz.',
  graf9: () => 'Leia o topo de cada coluna na escala. Média = soma ÷ quantidade. Porcentagem = parte ÷ total × 100.',
  prob9: () => 'Multiplique a chance da 1ª retirada pela da 2ª. Se a bola NÃO volta, a urna fica com uma bola a menos (e, se foi da mesma cor, uma a menos daquela cor).',
  prodNot9: () => '(a + b)² = a² + 2ab + b². (a − b)² = a² − 2ab + b². (a + b)(a − b) = a² − b².',
  fator9: () => 'x² − a² = (x + a)(x − a). x² + 2ax + a² = (x + a)². Trinômio x² + Sx + P: ache dois números que somam S e multiplicam P.',
  eq2g9: m => m.delta ? 'Δ = b² − 4ac. Δ > 0: duas raízes; Δ = 0: uma; Δ < 0: nenhuma real.' : 'Coloque x em evidência quando não tem termo sem x. Senão, use soma e produto (ou Bhaskara: x = (−b ± √Δ) ÷ 2a).',
  semelh9: () => 'Descubra a razão: lado do grande ÷ lado correspondente do pequeno. Multiplique o lado do pequeno por ela.',
  pitag9: () => 'Hipotenusa² = cateto² + cateto². Para achar um cateto: hipotenusa² − outro cateto². Depois tire a raiz.',
  circ9: () => 'O ângulo inscrito vale a METADE do central (e do arco) que ele enxerga. Inscrito numa semicircunferência vale 90°.',
  irrac9: () => 'Irracional: decimal infinito que não se repete (√2, √3, π…). Raiz exata, fração e dízima periódica são racionais. Diagonal do quadrado = lado · √2.',
  vistas9: () => 'Imagine-se olhando de frente (ou de cima, ou do lado): conte a pilha mais alta de cada coluna que você enxerga.',
  volPC9: () => 'Volume do prisma ou do cilindro = área da base × altura. Cilindro: π · r² · h. 1000 cm³ = 1 L.',
  funcao9: m => m.modo === 'zeros' ? 'Os zeros são os valores de x onde o gráfico toca o eixo x.' : m.modo === 'graf' ? 'Onde a reta corta o eixo y é o número somado; quanto sobe para cada 1 à direita é o número que multiplica x.' : 'Troque x pelo número entre parênteses e faça a conta (primeiro a potência, depois a multiplicação).',
});
