
/* =========================================================================
   CONTROLE DOS ALUNOS E LIMPAR TURMA (acrescentado)
   · Botão "👥 Alunos" fixo no canto da tela do professor (sala de espera e
     partida, na Corrida e no Treino): abre os cartões de cada aluno
     (🔴 errando · 🎲 chutando · 🟡 parado · 📡 offline · 🟢 respondendo).
     Clique no aluno: pedir troca de nome, plano, ficha, remover.
     Com lista de nomes: marca quem está com apelido (fora da lista) e
     pede a troca de todos de uma vez.
   · "🧹 Limpar tudo (outra turma)": apaga alunos, progresso, lista de nomes,
     foco e nome da turma (pode salvar o arquivo antes). Mostra também os
     alunos guardados, para apagar apelidos um a um.
   Funções originais intactas: só embrulho em montarCartao.
========================================================================= */
const ehApelido = p => !!(estado.cfg.lista && (estado.cfg.nomes || []).length && !(estado.cfg.nomes || []).some(n => normNome(n) === normNome(p.name)));
function controleHTML(){
  const ap = app.host.players.filter(p => !p.isBot && ehApelido(p));
  const topo = ap.length ? `<div class="ct-apel">⚠️ ${ap.length} com nome fora da lista: <b>${ap.map(p => esc(p.name)).join(', ')}</b>
      <button class="primary" data-trocatodos="1">✏️ Pedir troca de nome a todos eles</button></div>` : '';
  return topo + acompanharHTML();
}
function abrirControle(){
  let box = $('ctBox'); if(box){ box.remove(); clearInterval(estado.ctT); }
  box = document.createElement('div'); box.id = 'ctBox'; box.className = 'cat-fundo';
  const desenha = () => { const c = $('ctCorpo'); if(c) c.innerHTML = controleHTML(); const q = $('ctQtd'); if(q) q.textContent = `(${app.host.players.filter(p => !p.isBot).length})`; };
  box.innerHTML = `<div class="cat-topo"><h2>👥 Alunos na sala <span id="ctQtd"></span></h2><div class="dir"><button class="ab" data-fechar="1">✕ Fechar</button></div></div><div id="ctCorpo" style="margin-top:12px"></div>`;
  document.body.appendChild(box);
  desenha();
  estado.ctT = setInterval(() => { if(!$('ctBox')) return clearInterval(estado.ctT); if(!$('acMenu') && !$('plBox')) desenha(); }, 3000);
  box.onclick = e => {
    if(e.target.closest('[data-fechar]')){ box.remove(); clearInterval(estado.ctT); return; }
    if(e.target.closest('[data-trocatodos]')){
      const ap = app.host.players.filter(p => !p.isBot && ehApelido(p) && !p._trocando);
      if(!ap.length || !confirm(`Pedir para ${ap.length} aluno${ap.length === 1 ? '' : 's'} trocar o nome?\nO celular de cada um fica parado até ele escolher o nome dele na lista.`)) return;
      ap.forEach(p => { p._trocando = true; enviarPedidoNome(p, 'Use o seu nome de verdade (toque nele na lista).'); });
      app.toast(`✏️ Pedido enviado para ${ap.length} aluno${ap.length === 1 ? '' : 's'}`, 'info'); desenha(); return;
    }
    const c = e.target.closest('[data-aluno]'); if(c) abrirMenuAluno(c.dataset.aluno);
  };
}
/* turma: limpar tudo / apagar apelidos guardados */
function turmaVazia(){ return { tipo: 'corrida-trilha-turma', versao: 1, nome: '', criado: new Date().toISOString(), alunos: {} }; }
function limparTudo(){
  estado.turma = turmaVazia();
  Object.assign(estado.cfg, { nomes: [], lista: false, foco: { ids: [], freq: (estado.cfg.foco && estado.cfg.foco.freq) || 0.25, stamp: Date.now() } });
  estado.snap = {}; estado.alertas = {}; estado.hoje = {};
  ['cgm_treino_hoje', 'cgm_partida_prof'].forEach(k => { try{ localStorage.removeItem(k); }catch(e){} });
  lsSet(LS_TURMA, estado.turma); salvarCfg();
  const card = $('trilhaCard'); if(card) card.remove();
  montarCartao();
  app.toast('🧹 Tudo limpo: pronto para outra turma', 'success');
}
function abrirLimpar(){
  let box = $('lmBox'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'lmBox'; box.className = 'cat-fundo';
  const desenha = () => {
    const al = Object.values(estado.turma.alunos || {}).filter(r => r && r.nome).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
    const lista = (estado.cfg.nomes || []).map(normNome);
    box.innerHTML = `<div class="cat-topo"><h2>🧹 Turma ${esc(estado.turma.nome || '(sem nome)')}</h2><div class="dir"><button class="ab" data-fechar="1">✕ Fechar</button></div></div>
      <div class="lm-sec"><h3>Começar com outra turma</h3>
        <div class="lm-txt">Apaga os alunos e o progresso, a lista de nomes, o foco da aula e o nome da turma. O tipo de sala, o ano e o tempo continuam como estão.</div>
        <div class="lm-bts"><button class="primary" data-limpar="salvar">💾 Salvar o arquivo desta turma e limpar</button><button class="ghost" data-limpar="direto" style="color:#fca5a5">🧹 Limpar sem salvar</button></div></div>
      <div class="lm-sec"><h3>Alunos guardados nesta turma (${al.length})</h3>
        <div class="lm-txt">Apague aqui os apelidos e os nomes errados. ${lista.length ? 'Os que não estão na lista de nomes aparecem em amarelo.' : ''}</div>
        <div class="lm-grade">${al.map(r => { const dom = Object.values(r.deg || {}).filter(d => d.dom).length, fora = lista.length && !lista.includes(normNome(r.nome));
          return `<div class="lm-al ${fora ? 'fora' : ''}"><div><b>${esc(r.nome)}</b><span>${dom} degrau${dom === 1 ? '' : 's'} · ${r.resp || 0} resp.${fora ? ' · fora da lista' : ''}</span></div><button class="ghost" data-apaga="${esc(r.chave || normNome(r.nome))}" title="Apagar">🗑</button></div>`; }).join('') || '<div style="color:var(--muted)">Nenhum aluno guardado.</div>'}</div>
        ${lista.length && al.some(r => !lista.includes(normNome(r.nome))) ? '<button class="ghost" data-apagafora="1" style="margin-top:10px">🗑 Apagar todos os que estão fora da lista</button>' : ''}</div>`;
  };
  desenha(); document.body.appendChild(box);
  box.onclick = e => {
    const t = e.target;
    if(t.closest('[data-fechar]')){ box.remove(); return; }
    const lp = t.closest('[data-limpar]');
    if(lp){
      if(lp.dataset.limpar === 'salvar'){ baixarTurma(); setTimeout(() => { limparTudo(); box.remove(); }, 600); return; }
      if(!confirm('Apagar TUDO desta turma sem salvar? Não dá para desfazer.')) return;
      limparTudo(); box.remove(); return;
    }
    const ap = t.closest('[data-apaga]');
    if(ap){ const r = estado.turma.alunos[ap.dataset.apaga]; if(!r || !confirm(`Apagar "${r.nome}" e o progresso dele desta turma?`)) return; delete estado.turma.alunos[ap.dataset.apaga]; lsSet(LS_TURMA, estado.turma); atualizarStatus(); desenha(); return; }
    if(t.closest('[data-apagafora]')){
      const lista = (estado.cfg.nomes || []).map(normNome), fora = Object.keys(estado.turma.alunos).filter(k => !lista.includes(normNome(estado.turma.alunos[k].nome)));
      if(!confirm(`Apagar ${fora.length} aluno${fora.length === 1 ? '' : 's'} que não estão na lista (${fora.map(k => estado.turma.alunos[k].nome).join(', ')})?`)) return;
      fora.forEach(k => delete estado.turma.alunos[k]); lsSet(LS_TURMA, estado.turma); atualizarStatus(); desenha();
    }
  };
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  #ctBtn{position:fixed;left:12px;bottom:12px;z-index:450;width:auto;padding:10px 16px;border-radius:14px;font-size:16px;font-weight:900;background:#1d4ed8;color:#fff;border:2px solid #93c5fd;box-shadow:0 6px 20px rgba(0,0,0,.45);cursor:pointer}
  #ctBtn.alerta{background:#b91c1c;border-color:#fca5a5}
  .ct-apel{background:rgba(245,158,11,.12);border:2px solid #f59e0b;border-radius:12px;padding:10px 12px;margin-bottom:12px;font-weight:800;display:flex;flex-wrap:wrap;gap:10px;align-items:center}
  .ct-apel button{width:auto;padding:8px 14px}
  .lm-sec{background:var(--panel);border:2px solid var(--line);border-radius:14px;padding:14px;margin-top:12px}
  .lm-sec h3{margin:0 0 6px}
  .lm-txt{color:var(--muted);font-size:14px;margin-bottom:10px}
  .lm-bts{display:flex;gap:10px;flex-wrap:wrap}.lm-bts button{width:auto}
  .lm-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px}
  .lm-al{display:flex;align-items:center;justify-content:space-between;gap:8px;background:var(--panel2);border:2px solid var(--line);border-radius:10px;padding:8px 10px}
  .lm-al.fora{border-color:#f59e0b;background:rgba(245,158,11,.1)}
  .lm-al span{display:block;color:var(--muted);font-size:12px}
  .lm-al button{width:auto;padding:6px 10px}
  /* pista: nunca espremida por outras caixas da tela (altura mínima e faixas que não encolhem) */
  #hostGame .hg-middle{min-height:min(360px,62vh)}
  #hPlayers{justify-content:safe center}
  #hPlayers .race-lane{flex:none}`;
  document.head.appendChild(st);
  const bt = document.createElement('button'); bt.id = 'ctBtn'; bt.className = 'hidden'; bt.onclick = abrirControle;
  document.body.appendChild(bt);
  const vis = id => { const e = $(id); return e && !e.classList.contains('hidden'); };
  setInterval(() => {
    const mostra = app.mode === 'teacher' && !app.host.isDemo && (vis('hostLobby') || vis('hostGame'));
    bt.classList.toggle('hidden', !mostra);
    if(!mostra) return;
    const ps = app.host.players.filter(p => !p.isBot);
    let atencao = 0; try{ atencao = ps.filter(p => ['erro', 'chute', 'parado', 'off'].includes(situacaoAluno(p).st) || ehApelido(p)).length; }catch(e){}
    bt.textContent = `👥 Alunos (${ps.length})${atencao ? ` · ⚠️ ${atencao}` : ''}`;
    bt.classList.toggle('alerta', atencao > 0);
  }, 1000);
  document.addEventListener('keydown', e => { if(e.key === 'Escape'){ const b = $('ctBox') || $('lmBox'); if(b && !$('acMenu')){ b.remove(); clearInterval(estado.ctT); } } });
  // cartão da Trilha: "Nova turma" vira "Limpar tudo"
  const ajusta = () => { const b = $('trNova'); if(!b) return; b.textContent = '🧹 Limpar tudo (outra turma)'; b.onclick = abrirLimpar; };
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); ajusta(); return r; };
  ajusta();
})();
