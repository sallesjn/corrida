
/* =========================================================================
   MODO TREINO (acrescentado) — dentro de uma sala, só com a Trilha ligada
   · O professor escolhe "Treino" no cartão da Trilha, cria a sala e começa.
   · Aluno: sem cronômetro da questão, sem relógio da partida, sem pontos,
     sem equipe. Sobe de degrau com os mesmos critérios (7 de 10 no difícil),
     só que o tempo de resposta não conta. Tem as 3 ajudas por degrau.
   · Professor: no lugar da pista, um painel do treino — com ranking por
     degraus conquistados na aula OU sem ranking (só o total da turma).
   · Quem chega atrasado entra no treino já começado.
   · O progresso vai para o arquivo da turma igual à corrida.
   Como a sala sabe que é treino: a duração da partida fica num valor
   especial (TREINO_MS), que já viaja para o aluno e é salvo pela proteção.
   Funções originais intactas: só embrulhos (createRoom, startGame,
   startMatchTimer, endGame, hostPlayerJoin, startContinuousPlay,
   startQuestionTimer, updatePlayerStatsUI, finishPlayerMatch).
========================================================================= */
const TREINO_MS = 5 * 3600 * 1000 + 7;                 // 5 h: "marca" da sala de treino
const LS_HOJE = 'cgm_treino_hoje';
const ehTreino = ms => typeof ms === 'number' && ms % 60000 === 7;      // duração do treino = minutos inteiros + 7 ms (a "marca")
const treinoProf = () => app.mode === 'teacher' && ehTreino(app.host.matchDurationMs) && !app.host.isDemo;
const treinoAluno = () => app.mode !== 'teacher' && ehTreino(app.player.matchTotalMs);

if(typeof window !== 'undefined') (() => {
  if(!estado.cfg.modo) estado.cfg.modo = 'corrida';
  if(estado.cfg.rank === undefined) estado.cfg.rank = 0;
  if(estado.cfg.treinoMin === undefined) estado.cfg.treinoMin = 30;

  const st = document.createElement('style');
  st.textContent = `
  body.cgm-treino #ppTime, body.cgm-treino #ppQuestionCard .qtimer, body.cgm-treino #ppTeam,
  body.cgm-treino .pp-stats .item.score, body.cgm-treino #pTeamBadgeWrap, body.cgm-treino #pTeamLabel, body.cgm-treino #pdTeamLabel{display:none!important}
  .tr-treino-tag{font-weight:900;color:#fbbf24;font-size:16px}
  body.cgm-treino-prof #hostGame .hg-players, body.cgm-treino-prof #hostGame .hg-rank,
  body.cgm-treino-prof #hostGame .hg-match-timer, body.cgm-treino-prof #hPhaseBadge, body.cgm-treino-prof #hPodium{display:none!important}
  .tt-painel{flex:1;min-width:0;overflow:auto;background:var(--panel);border:2px solid var(--line);border-radius:16px;padding:16px 18px}
  .tt-cab{display:flex;flex-wrap:wrap;gap:10px 22px;align-items:baseline;margin-bottom:12px}
  .tt-cab h3{font-size:22px}
  .tt-cab .m{color:var(--muted);font-weight:800}
  .tt-total{font-size:clamp(30px,6vw,64px);font-weight:900;text-align:center;color:#fbbf24;margin:10px 0 4px}
  .tt-sub{text-align:center;color:var(--muted);font-weight:800;margin-bottom:14px}
  .tt-nomes{display:flex;flex-wrap:wrap;gap:8px;justify-content:center}
  .tt-nomes span{background:var(--panel2);border:2px solid var(--line);border-radius:999px;padding:6px 14px;font-weight:900}
  .tt-clic{cursor:pointer}
  .tt-clic:hover{text-decoration:underline;color:#fbbf24}
  .tt-trocando{color:#fbbf24 !important}
  .tt-rank{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px}
  .tt-lin{display:flex;align-items:center;gap:10px;background:var(--panel2);border:2px solid var(--line);border-radius:12px;padding:8px 12px;position:relative;overflow:hidden}
  .tt-lin .bar{position:absolute;left:0;top:0;bottom:0;background:rgba(251,191,36,.18);z-index:0}
  .tt-lin > *:not(.bar){position:relative;z-index:1}
  .tt-lin .pos{font-weight:900;width:34px;text-align:center;font-size:18px}
  .tt-lin .nm{font-weight:900;font-size:18px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .tt-lin .dg{font-weight:900;color:#fbbf24;font-size:18px;white-space:nowrap}
  .tt-lin.top1{border-color:#fbbf24}
  .tt-det{margin-top:16px}
  .tt-det .tr-tab td,.tt-det .tr-tab th{font-size:13px}
  `;
  document.head.appendChild(st);

  /* ---------- cartão da Trilha: tipo de sala ---------- */
  function controles(){
    const opts = $('trOpts');
    if(!opts || $('trModo')) return;
    const c = estado.cfg;
    const box = document.createElement('div');
    box.id = 'trModoBox';
    box.style.cssText = 'margin-bottom:14px;padding:12px;border:2px solid #f59e0b;border-radius:14px;background:rgba(245,158,11,.07)';
    box.innerHTML = `<label>Tipo de sala</label>
      ${segHTML('trModo', [['corrida', '🏁 Corrida'], ['treino', '🎯 Treino']], c.modo)}
      <div id="trModoInfo" style="color:var(--muted);font-size:12px;margin-top:6px;line-height:1.5"></div>
      <div id="trRankBox" style="margin-top:10px" class="${c.modo === 'treino' ? '' : 'hidden'}"><label>No telão, durante o treino</label>
        ${segHTML('trRank', [[0, '🙈 Sem ranking'], [1, '🏆 Ranking por degraus']], c.rank ? 1 : 0)}
        <label style="margin-top:10px">Tempo do treino (o aluno não vê o relógio)</label>
        ${segHTML('trTempo', [[20, '20 min'], [30, '30 min'], [40, '40 min'], [50, '50 min'], [0, 'Sem limite']], c.treinoMin)}</div>`;
    opts.prepend(box);
    const info = () => { $('trModoInfo').innerHTML = c.modo === 'treino'
      ? `Sem tempo por questão, sem pontos e sem carrinhos. O aluno sobe de degrau acertando 7 de 10 no difícil (o tempo de resposta não conta). Pode entrar atrasado. O progresso vai para o arquivo da turma, igual à corrida. ${c.treinoMin ? `O treino termina sozinho em <b>${c.treinoMin} min</b> (só você vê o relógio).` : 'Termine com <b>🏁 Encerrar partida</b>.'}`
      : 'Disputa por equipes com tempo (como sempre).'; };
    const seg = (id, fn) => { $(id).onclick = e => { const b = e.target.closest('button[data-v]'); if(!b) return; [...$(id).children].forEach(x => x.classList.toggle('on', x === b)); fn(b.dataset.v); salvarCfg(); info(); }; };
    seg('trModo', v => { c.modo = v; $('trRankBox').classList.toggle('hidden', v !== 'treino'); });
    seg('trRank', v => { c.rank = +v; });
    seg('trTempo', v => { c.treinoMin = +v; });
    info();
  }
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); controles(); return r; };
  controles();

  const querTreino = () => estado.cfg.on && estado.cfg.modo === 'treino';
  const doBotao = (sel, attr, pad) => { const b = document.querySelector(`#${sel} button.on`); return b ? b.dataset[attr] : pad; };
  function voltarDuracaoNormal(){                  // depois de um treino, a corrida volta a usar o que está marcado na tela
    const h = app.host;
    if(!ehTreino(h.matchDurationMs)) return;
    h.matchDurationMs = (+doBotao('durationSel', 'min', 15) || 15) * 60 * 1000;
    const sp = doBotao('sprintSel', 'sprint', null); if(sp !== null) h.sprintEnabled = sp === '1';
  }

  /* ---------- professor ---------- */
  const createRoom0 = app.createRoom;
  app.createRoom = function(isDemo){
    voltarDuracaoNormal();
    document.body.classList.remove('cgm-treino-prof');
    const r = createRoom0.apply(this, arguments);
    if(!isDemo && querTreino() && this.room){
      $('hModeLabel').innerHTML = `<span style="color:#fbbf24">🎯 TREINO ${estado.cfg.ano}º${(estado.cfg.anoMax || 9) < 9 ? ` · até ${estado.cfg.anoMax}º` : ''}</span>`;
      // treino começa sozinho: o aluno já joga assim que entra (sem esperar o professor dar início)
      setTimeout(() => { if(this.host.phase === 'lobby' && querTreino()) this.startGame(); }, 300);
    }
    return r;
  };
  const startGame0 = app.startGame;
  app.startGame = function(){
    const treino = !this.host.isDemo && querTreino();
    if(treino){
      this.host.matchDurationMs = (estado.cfg.treinoMin ? estado.cfg.treinoMin * 60000 : TREINO_MS - 7) + 7;   // tempo definido pelo professor (o aluno não vê)
      this.host.sprintEnabled = false;
      estado.hoje = {};
      estado.treinoIni = Date.now();
    } else voltarDuracaoNormal();
    const r = startGame0.apply(this, arguments);
    if(treino) $('hMsg').innerHTML = '🎯 <b>TREINO EM ANDAMENTO</b> — sem tempo, sem pressão';
    return r;
  };
  const startMatchTimer0 = app.startMatchTimer;       // também roda quando a partida é retomada
  app.startMatchTimer = function(){
    const r = startMatchTimer0.apply(this, arguments);
    if(treinoProf()){
      document.body.classList.add('cgm-treino-prof');
      if(!estado.treinoIni){                    // partida retomada depois de recarregar: recupera a contagem da aula
        estado.treinoIni = this.host.matchEndTime - this.host.matchDurationMs;
        const g = lsGet(LS_HOJE, null); if(g && g.room === app.room && g.hoje) estado.hoje = g.hoje;
      }
      if(/PARTIDA EM ANDAMENTO/.test($('hMsg').innerHTML)) $('hMsg').innerHTML = '🎯 <b>TREINO EM ANDAMENTO</b> — sem tempo, sem pressão';
      painel();
      clearInterval(estado.treinoT);
      estado.treinoT = setInterval(() => { if(app.host.phase === 'playing' && treinoProf()){ painel(); lsSet(LS_HOJE, { room: app.room, hoje: estado.hoje }); } else clearInterval(estado.treinoT); }, 3000);
    }
    return r;
  };
  const endGame0 = app.endGame;
  app.endGame = function(){
    const treino = treinoProf() && this.host.phase !== 'end';
    clearInterval(estado.treinoT);
    const r = endGame0.apply(this, arguments);
    if(treino){
      const tot = Object.values(estado.hoje).reduce((s, n) => s + n, 0);
      const min = Math.max(1, Math.round((Date.now() - (estado.treinoIni || Date.now())) / 60000));
      $('hEndSub').innerHTML = `🎯 Fim do treino · ${min} min · a turma conquistou <b style="color:#fbbf24">${tot} degrau${tot === 1 ? '' : 's'}</b>`;
      voltarDuracaoNormal();
    }
    estado.treinoIni = 0;
    return r;
  };
  const renderLobby0 = app.renderLobby;
  app.renderLobby = function(){               // treino: pode começar com qualquer número de alunos (os outros entram depois)
    const r = renderLobby0.apply(this, arguments);
    const bt = $('startGameBtn');
    if(bt && !this.host.isDemo && querTreino()){ bt.disabled = false; bt.textContent = 'Começar treino 🎯'; }
    else if(bt && bt.textContent !== 'Começar partida 🏁') bt.textContent = 'Começar partida 🏁';
    return r;
  };
  const hostPlayerJoin0 = app.hostPlayerJoin;
  app.hostPlayerJoin = function(msg){
    // treino já começado: quem chega atrasado entra (na corrida continua sendo recusado)
    if(treinoProf() && this.host.phase === 'playing' && msg && !this.host.players.find(p => p.id === msg.id)){
      const check = checkName(msg.name);
      if(!check.ok){ this.pub(`${BASE}/${this.room}/to/${msg.id}`, { type: 'kick', reason: check.reason }); this.notifyHost(msg.name || '(sem nome)', check.reason, 'kick'); return; }
      const p = { id: msg.id, name: msg.name, team: this.chooseBalancedTeam(), score: 0, correct: 0, wrong: 0, timeouts: 0,
        level: 1, totalAnswers: 0, isBot: false, byType: {}, totalMsCorrect: 0 };
      this.host.players.push(p);
      const rec = registroDe(p.name);
      estado.snap[normNome(p.name)] = rec ? CAT.filter(d => rec.deg[d.id] && rec.deg[d.id].dom).length : 0;
      enviarTrilha(p); publicarNomes();
      sndJoin();
      this.broadcastState();
      painel();
      app.toast(`👋 <b>${esc(p.name)}</b> entrou no treino`, 'info');
      return;
    }
    return hostPlayerJoin0.apply(this, arguments);
  };

  function linhasTreino(){
    return app.host.players.filter(p => !p.isBot).map(p => {
      const r = estado.turma.alunos[normNome(p.name)];
      const at = r && r.atual ? POR_ID[r.atual] : null;
      const rs = r ? resumo(r) : null;
      const tot = (p.correct || 0) + (p.wrong || 0) + (p.timeouts || 0);
      return { id: p.id, nome: p.name + (p._trocando ? ' ✏️…' : ''), hoje: estado.hoje[p.id] || 0, resp: tot, ac: p.correct || 0,
        degrau: at ? `${at.ano}º · ${at.nome}` : (r ? 'trilha concluída' : '—'), nivel: rs && rs.nivel ? ['', 'fácil', 'médio', 'difícil'][rs.nivel] : '—', trav: !!(r && r.trav) };
    });
  }
  function painel(){
    if(app.host.phase !== 'playing' || !treinoProf()) return;
    const meio = document.querySelector('#hostGame .hg-middle'); if(!meio) return;
    let box = $('ttPainel');
    if(!box){
      box = document.createElement('div'); box.id = 'ttPainel'; box.className = 'tt-painel';
      meio.appendChild(box);
      box.onclick = e => {
        if(e.target.closest('[data-det]')){ estado.treinoDet = !estado.treinoDet; painel(); return; }
        const tn = e.target.closest('[data-troca]'); if(tn){ pedirTrocaNome(tn.dataset.troca); painel(); return; }
        const rm = e.target.closest('[data-rem]'); if(rm){ app.kickPlayer(rm.dataset.rem); painel(); return; }
        const al = e.target.closest('[data-aluno]'); if(al){ abrirMenuAluno(al.dataset.aluno); return; }
      };
    }
    const L = linhasTreino();
    const tot = L.reduce((s, l) => s + l.hoje, 0);
    const min = Math.max(0, Math.floor((Date.now() - (estado.treinoIni || Date.now())) / 60000));
    let corpo;
    if(estado.cfg.rank){
      const ord = [...L].sort((a, b) => b.hoje - a.hoje || b.ac - a.ac || a.nome.localeCompare(b.nome, 'pt-BR'));
      const max = Math.max(1, ...ord.map(l => l.hoje));
      const med = ['🥇', '🥈', '🥉'];
      corpo = `<div class="tt-sub">🏆 Degraus conquistados nesta aula</div><div class="tt-rank">` + ord.map((l, i) => `<div class="tt-lin ${i === 0 && l.hoje ? 'top1' : ''}">
          <div class="bar" style="width:${Math.round(l.hoje / max * 100)}%"></div>
          <span class="pos">${l.hoje && med[i] ? med[i] : i + 1 + 'º'}</span><span class="nm tt-clic" data-troca="${esc(l.id)}" title="Clique para o aluno trocar o nome">${esc(l.nome)}</span><span class="dg">🏅 ${l.hoje}</span></div>`).join('') + `</div>`;
    } else {
      corpo = `<div class="tt-total">🏅 ${tot}</div><div class="tt-sub">degrau${tot === 1 ? '' : 's'} conquistado${tot === 1 ? '' : 's'} pela turma nesta aula</div>
        <div class="tt-nomes">${[...L].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')).map(l => `<span class="tt-clic" data-troca="${esc(l.id)}" title="Clique para o aluno trocar o nome">${esc(l.nome)}</span>`).join('')}</div>`;
    }
    const det = estado.treinoDet ? acompanharHTML() : '';                  // tela de acompanhamento (só para o professor)
    if(estado.treinoDet) corpo = '';
    box.innerHTML = `<div class="tt-cab"><h3>🎯 Treino</h3><span class="m">⏱️ ${min} min</span>${app.host.matchDurationMs < 4 * 3600000 ? `<span class="m" style="color:#fbbf24">⏳ faltam ${fmtTime(Math.max(0, app.host.matchEndTime - Date.now()))}</span>` : ''}<span class="m">👥 ${L.length} aluno${L.length === 1 ? '' : 's'}</span>
        <button class="ghost" data-det="1" style="margin-left:auto;width:auto;padding:6px 12px;font-size:13px">${estado.treinoDet ? '📺 Voltar ao telão' : '👁️ Acompanhar alunos'}</button></div>` + corpo + det;
  }

  /* ---------- aluno ---------- */
  const startContinuousPlay0 = app.startContinuousPlay;
  app.startContinuousPlay = function(state){
    const treino = state && ehTreino(state.totalMs);
    document.body.classList.toggle('cgm-treino', !!treino);
    const r = startContinuousPlay0.apply(this, arguments);
    if(treino){
      let tag = $('ppTreinoTag');
      if(!tag){ tag = document.createElement('span'); tag.id = 'ppTreinoTag'; tag.className = 'tr-treino-tag'; $('ppTime').after(tag); }
      tag.textContent = '🎯 Treino';
    } else { const tag = $('ppTreinoTag'); if(tag) tag.remove(); }
    return r;
  };
  const startQuestionTimer0 = app.startQuestionTimer;
  app.startQuestionTimer = function(){
    if(treinoAluno()){ cancelAnimationFrame(this.player.questionRAF); return; }   // treino: a questão não tem cronômetro
    return startQuestionTimer0.apply(this, arguments);
  };
  const updatePlayerStatsUI0 = app.updatePlayerStatsUI;
  app.updatePlayerStatsUI = function(){
    const r = updatePlayerStatsUI0.apply(this, arguments);
    const pt = this.player.trilha;
    const tag = $('ppTreinoTag');
    if(tag && treinoAluno() && pt && pt.rec){
      const at = pt.rec.atual ? POR_ID[pt.rec.atual] : null;
      tag.textContent = '🎯 Treino';                         // o aluno não vê de que ano é a atividade
    }
    return r;
  };
  const finishPlayerMatch0 = app.finishPlayerMatch;
  app.finishPlayerMatch = function(){
    const treino = treinoAluno() && this.player.phase !== 'done';
    const r = finishPlayerMatch0.apply(this, arguments);
    if(treino && $('pdSub')){
      $('pdSub').innerHTML = '🎯 Treino encerrado! Seu progresso foi guardado.';
      const em = document.querySelector('#playerDone .em'); if(em) em.textContent = '🎯';
    }
    return r;
  };
})();
