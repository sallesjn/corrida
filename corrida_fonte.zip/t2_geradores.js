
/* =========================================================================
   GERADORES DOS DEGRAUS — 1º e 2º ano
   Cada gerador(nivel 1..3) devolve:
   { text, fala, image?, optImgs?, options[4], correct, erros[4], answer, meta, chave }
   conferir(meta) recalcula a resposta por outro caminho (usado no teste).
========================================================================= */
const COR_A = '#ef4444', COR_B = '#3b82f6';
const G = {};      // geradores
const C = {};      // conferência independente (teste)

/* 1 ─ Soma com resultado até 10 (EF01MA06, EF01MA08) */
G.soma10 = n => {
  const [a, b] = sortearAte(() => [rnd(n === 1 ? 1 : 0, n === 1 ? 5 : 9), rnd(1, n === 1 ? 5 : 9)],
    ([x, y]) => x + y <= (n === 1 ? 7 : 10) && x + y >= 2 && (n === 1 || x > 0) && (n < 3 || x + y >= 5));
  const s = a + b;
  const erradas = [{ v: s + 1, erro: 'contou um a mais' }, { v: s - 1, erro: 'contou um a menos' },
    { v: Math.abs(a - b), erro: 'subtraiu em vez de somar' }, { v: Math.max(a, b), erro: 'contou só um grupo' }];
  const o = alternativas(s, erradas, String, { max: 19 });
  let image, text, fala;
  if(n === 1){
    const tipo = pick(OBJETOS);
    const g1 = grupoIcones(tipo, a, 10, 10, 52), g2 = grupoIcones(tipo, b, g1.w + 70, 10, 52);
    const H = Math.max(g1.h, g2.h) + 20;
    image = svgURI(SVG(g1.w + g2.w + 80, H, g1.svg + T(g1.w + 40, H / 2 + 14, '+', { fs: 46 }) + g2.svg));
    text = `Quantas ${plural(tipo, 2)} ao todo?`;
    fala = `${a} ${plural(tipo, a)} mais ${b} ${plural(tipo, b)}. Quantas ${plural(tipo, 2)} ao todo?`;
    if(genero(tipo) === 'm'){ text = `Quantos ${plural(tipo, 2)} ao todo?`; fala = fala.replace('Quantas', 'Quantos'); }
  } else if(n === 2){
    image = svgURI(SVG(290, 130, quadroDez(20, 12, 50, [...Array(a).fill(COR_A), ...Array(b).fill(COR_B)])));
    text = `${a} + ${b} = ?`;
    fala = `Quanto é ${a} mais ${b}?`;
  } else {
    text = `${a} + ${b} = ?`;
    fala = `Quanto é ${a} mais ${b}?`;
  }
  return { ...o, text, fala, image, meta: { a, b }, chave: `${a}+${b}` };
};
C.soma10 = m => String(m.a + m.b);

/* 2 ─ Subtração até 10 (EF01MA08) */
G.sub10 = n => {
  const [a, b] = sortearAte(() => [rnd(2, n === 1 ? 6 : 10), rnd(1, 9)], ([x, y]) => y < x && (n < 3 || y >= 2));
  const r = a - b;
  const erradas = [{ v: a + b, erro: 'somou em vez de subtrair' }, { v: r + 1, erro: 'contou um a mais' },
    { v: r - 1, erro: 'contou um a menos' }, { v: b, erro: 'respondeu o que foi tirado' }, { v: a, erro: 'não tirou nada' }];
  const o = alternativas(r, erradas, String, { max: 20 });
  let image, text, fala;
  if(n === 1){
    const tipo = pick(OBJETOS);
    const g = grupoIcones(tipo, a, 10, 10, 56, 6, b);
    image = svgURI(SVG(g.w + 20, g.h + 20, g.svg));
    const qt = genero(tipo) === 'm' ? 'Quantos' : 'Quantas';
    text = `${qt} sobraram?`;
    const risc = genero(tipo) === 'm' ? 'riscado' : 'riscada';
    fala = `Tinha ${a} ${plural(tipo, a)}. ${b} ${b === 1 ? 'foi ' + risc : 'foram ' + risc + 's'}. ${qt} sobraram?`;
  } else if(n === 2){
    image = svgURI(SVG(290, 130, quadroDez(20, 12, 50, Array(a).fill(COR_B), b)));
    text = `${a} − ${b} = ?`; fala = `Quanto é ${a} menos ${b}?`;
  } else { text = `${a} − ${b} = ?`; fala = `Quanto é ${a} menos ${b}?`; }
  return { ...o, text, fala, image, meta: { a, b }, chave: `${a}-${b}` };
};
C.sub10 = m => String(m.a - m.b);

/* 3 ─ Quanto falta para 10 — amigos do 10 (EF01MA06) */
G.faz10 = n => {
  const k = rnd(n === 3 ? 1 : 2, 9), falta = 10 - k;
  const erradas = [{ v: k, erro: 'respondeu o que já tem' }, { v: falta + 1, erro: 'contou um a mais' },
    { v: falta - 1, erro: 'contou um a menos' }, { v: 10 + k, erro: 'somou com 10' }];
  const o = alternativas(falta, erradas, String, { min: 0, max: 20 });
  let image, text, fala;
  if(n === 1){
    image = svgURI(SVG(290, 130, quadroDez(20, 12, 50, Array(k).fill(COR_A))));
    text = 'Quantos faltam para 10?'; fala = `O quadro tem ${k}. Quantos faltam para completar 10?`;
  } else if(n === 2){
    image = svgURI(SVG(290, 130, quadroDez(20, 12, 50, Array(k).fill(COR_A))));
    text = `${k} + ? = 10`; fala = `${k} mais quanto dá 10?`;
  } else {
    const ordem = rnd(0, 1);
    text = ordem ? `? + ${k} = 10` : `${k} + ? = 10`; fala = ordem ? `Quanto mais ${k} dá 10?` : `${k} mais quanto dá 10?`;
  }
  return { ...o, text, fala, image, meta: { k }, chave: `f${k}${n}` };
};
C.faz10 = m => String(10 - m.k);

/* 4 ─ Contar e comparar até 20 (EF01MA01, EF01MA02, EF01MA03) */
G.cont20 = n => {
  if(n === 1){
    const tipo = pick(OBJETOS), q = rnd(6, 20);
    const g = grupoIcones(tipo, q, 10, 10, 40, 10);
    const erradas = [{ v: q + 1, erro: 'contou um a mais' }, { v: q - 1, erro: 'contou um a menos' },
      { v: q + 10, erro: 'contou uma fileira a mais' }, { v: q - 10, erro: 'esqueceu uma fileira' }, { v: q + 2, erro: 'contou algum duas vezes' }];
    const o = alternativas(q, erradas, String, { min: 1, max: 30 });
    const qt = genero(tipo) === 'm' ? 'Quantos' : 'Quantas';
    return { ...o, text: `${qt} ${plural(tipo, 2)}?`, fala: `Conte. ${qt} ${plural(tipo, 2)} há na figura?`,
      image: svgURI(SVG(g.w + 20, g.h + 20, g.svg)), meta: { itens: Array(q).fill(tipo) }, chave: `c${q}${tipo}` };
  }
  // n 2 e 3: 4 caixas; qual tem MAIS (ou MENOS)?
  const mais = n === 2 ? rnd(0, 3) > 0 : rnd(0, 1) === 1;
  const qs = sortearAte(() => shuffle([...Array(n === 2 ? 15 : 12)].map((_, i) => i + (n === 2 ? 2 : 3))).slice(0, 4),
    v => new Set(v).size === 4 && (n === 3 || Math.max(...v) - Math.min(...v) >= 4));
  const alvo = mais ? Math.max(...qs) : Math.min(...qs);
  const tipo = pick(OBJETOS);
  // nível 3: a caixa com MENOS figuras tem as figuras MAIORES (engana pelo tamanho)
  const tams = qs.map(q => n === 3 ? Math.round(56 - (q - 3) * 2.4) : 32);
  const letras = ['A', 'B', 'C', 'D'];
  let o = '';
  qs.forEach((q, i) => {            // caixas em 2 × 2 (cabe melhor na tela do celular)
    const bx = 10 + (i % 2) * 230, by = 10 + Math.floor(i / 2) * 190, s = tams[i], porL = Math.max(2, Math.floor(200 / s));
    o += `<rect x="${bx}" y="${by}" width="220" height="180" rx="12" fill="#f8fafc" stroke="#111" stroke-width="3"/>`;
    o += T(bx + 22, by + 34, letras[i], { fs: 30 });
    const lin = Math.ceil(q / porL);
    o += grupoIcones(tipo, q, bx + (220 - Math.min(q, porL) * s) / 2 + 8, by + (180 - lin * s) / 2 + 6, s, porL).svg;
  });
  const idxAlvo = qs.indexOf(alvo);
  const idxOposto = qs.indexOf(mais ? Math.min(...qs) : Math.max(...qs));
  const areaVisual = qs.map((q, i) => q * tams[i] * tams[i]);
  const idxVisual = areaVisual.indexOf(Math.max(...areaVisual));
  const erradas = letras.map((l, i) => i === idxAlvo ? null : {
    v: l, erro: i === idxOposto ? (mais ? 'escolheu a que tem menos' : 'escolheu a que tem mais')
      : (n === 3 && i === idxVisual && mais ? 'foi pelo tamanho das figuras' : 'contou errado') });
  const r = alternativas(letras[idxAlvo], erradas, String);
  // deixa as alternativas na ordem A B C D (mais fácil para o 1º ano)
  const ord = [0, 1, 2, 3].map(i => r.options.indexOf(letras[i]));
  const res = { options: letras.slice(), correct: idxAlvo, erros: ord.map(j => r.erros[j]), answer: letras[idxAlvo] };
  const palavra = mais ? 'MAIS' : 'MENOS';
  return { ...res, text: `Qual caixa tem ${palavra} ${plural(tipo, 2)}?`,
    fala: `Qual caixa tem ${mais ? 'mais' : 'menos'} ${plural(tipo, 2)}? A, B, C ou D?`,
    image: svgURI(SVG(470, 390, o)), meta: { qs, mais }, chave: qs.join(',') + palavra };
};
C.cont20 = m => m.itens ? String(m.itens.length) : 'ABCD'[m.qs.reduce((best, q, i) => (m.mais ? q > m.qs[best] : q < m.qs[best]) ? i : best, 0)];

/* 5 ─ Antes, depois e entre (até 20; até 100 no nível 3) (EF01MA04, EF01MA05) */
G.seq20 = n => {
  const lim = n === 1 ? 10 : n === 2 ? 20 : 99;
  const modo = n === 1 ? 'depois' : pick(n === 2 ? ['depois', 'antes'] : ['antes', 'entre', 'depois']);
  const x = rnd(2, lim - 1);
  const resp = modo === 'depois' ? x + 1 : modo === 'antes' ? x - 1 : x;
  const inv = v => v >= 10 && v < 100 && v % 10 !== Math.floor(v / 10) && v % 10 !== 0 ? +String(v).split('').reverse().join('') : null;
  const erradas = [
    { v: modo === 'depois' ? x - 1 : x + 1, erro: modo === 'depois' ? 'pensou no que vem antes' : 'pensou no que vem depois' },
    { v: modo === 'entre' ? x + 2 : x, erro: modo === 'entre' ? 'pulou um número' : 'repetiu o número' },
    { v: modo === 'depois' ? x + 2 : x - 2, erro: 'pulou um número' },
    { v: inv(resp), erro: 'inverteu os algarismos' }];
  const o = alternativas(resp, erradas, String, { min: 0, max: 100 });
  let text, fala, vals, ini;
  if(modo === 'entre'){ text = `Qual número está entre ${x - 1} e ${x + 1}?`; fala = `Qual número está entre ${x - 1} e ${x + 1}?`; }
  else { text = `Que número vem ${modo.toUpperCase()} do ${x}?`; fala = `Que número vem ${modo} do ${x}?`; }
  ini = Math.max(0, Math.min(resp - rnd(1, 3), lim - 5));
  vals = [...Array(6)].map((_, i) => ini + i);
  const mostrar = vals.map(v => v === resp ? null : v);
  const image = n < 3 ? svgURI(faixaNumerica(mostrar, vals.indexOf(x))) : undefined;
  return { ...o, text, fala, image, meta: { x, modo }, chave: modo + x };
};
C.seq20 = m => String(m.modo === 'depois' ? m.x + 1 : m.modo === 'antes' ? m.x - 1 : m.x);

/* 6 ─ Padrões com figuras e cores (EF01MA10) — alternativas desenhadas */
G.padrao = n => {
  const moldes = { 1: ['AB', 'AAB', 'ABB'], 2: ['AABB', 'ABBA', 'ABC'], 3: ['ABC', 'ABCD', 'ABAC'] }[n];
  const molde = pick(moldes);
  const formas = shuffle(['circulo', 'quadrado', 'triangulo', 'losango', 'pentagono', 'hexagono']);
  const cores = shuffle([['#ef4444', 'vermelho'], ['#3b82f6', 'azul'], ['#22c55e', 'verde'], ['#facc15', 'amarelo'], ['#a855f7', 'roxo']]);
  const letrasMolde = [...new Set(molde)];
  const el = {};
  letrasMolde.forEach((L, i) => {
    // nível 1: muda só a cor (mesma forma); níveis 2–3: muda forma e cor
    el[L] = n === 1 ? { f: formas[0], c: cores[i] } : { f: formas[i], c: cores[i] };
  });
  const tamSeq = molde.length * 2 + (n === 3 ? 1 : 0);
  const seq = [...Array(tamSeq + 1)].map((_, i) => molde[i % molde.length]);
  const alvoL = seq[tamSeq];
  const certo = el[alvoL];
  const nomeForma = { circulo: 'círculo', quadrado: 'quadrado', triangulo: 'triângulo', losango: 'losango', pentagono: 'pentágono', hexagono: 'hexágono' };
  const desc = e => `${nomeForma[e.f]} ${e.c[1]}`;
  const ultimo = el[seq[tamSeq - 1]];
  const outrasL = letrasMolde.filter(L => L !== alvoL);
  const erradas = [];
  if(desc(ultimo) !== desc(certo)) erradas.push({ v: desc(ultimo), erro: 'repetiu a última figura', e: ultimo });
  outrasL.forEach(L => erradas.push({ v: desc(el[L]), erro: 'pulou uma figura do padrão', e: el[L] }));
  const coresLivres = cores.filter(c => !letrasMolde.some(L => el[L].c === c));
  const formasLivres = formas.filter(f => !letrasMolde.some(L => el[L].f === f));
  coresLivres.slice(0, 2).forEach(c => { const e = { f: certo.f, c }; erradas.push({ v: desc(e), erro: 'forma certa, cor errada', e }); });
  formasLivres.slice(0, 2).forEach(f => { const e = { f, c: certo.c }; erradas.push({ v: desc(e), erro: 'cor certa, forma errada', e }); });
  const o = alternativas(desc(certo), erradas, String);
  const porDesc = {}; [{ v: desc(certo), e: certo }, ...erradas].forEach(x => porDesc[x.v] = x.e);
  const optImgs = o.options.map(d => svgURI(formaSVG(porDesc[d].f, porDesc[d].c[0], 0, 110)));
  const s = 64, W = (tamSeq + 1) * (s + 8) + 20;
  let fig = '';
  seq.forEach((L, i) => {
    const x = 10 + i * (s + 8);
    if(i === tamSeq){ fig += `<rect x="${x}" y="10" width="${s}" height="${s}" rx="10" fill="#fde68a" stroke="#111" stroke-width="3" stroke-dasharray="7,5"/>` + T(x + s / 2, 10 + s / 2 + 12, '?', { fs: 36 }); return; }
    const e = el[L]; fig += `<g transform="translate(${x} 10) scale(${s / 120})">${formaSVG(e.f, e.c[0], 0, 120).replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '').replace(/<rect width="120" height="120" fill="#ffffff"\/>/, '')}</g>`;
  });
  return { ...o, optImgs, text: 'Qual figura vem no lugar do ?', fala: 'Observe a sequência. Qual figura vem no lugar do ponto de interrogação?',
    image: svgURI(SVG(W, s + 20, fig)), meta: { molde, seq: seq.map(L => desc(el[L])) }, chave: molde + desc(certo) + tamSeq };
};
C.padrao = m => m.seq[m.seq.length - 1];

/* 7 ─ Soma até 20 (EF01MA08, EF02MA05) */
G.soma20 = n => {
  let a, b;
  if(n === 1){ if(rnd(0, 1)){ a = 10; b = rnd(1, 9); } else { a = rnd(2, 9); b = a; } }   // 10 + unidade ou dobro
  else [a, b] = sortearAte(() => [rnd(2, 9), rnd(2, 9)], ([x, y]) => x + y > 10 && x + y <= 18);
  const s = a + b;
  const erradas = [{ v: s % 10, erro: 'esqueceu a dezena' }, { v: s + 1, erro: 'contou um a mais' }, { v: s - 1, erro: 'contou um a menos' },
    { v: Math.abs(a - b), erro: 'subtraiu em vez de somar' }, { v: s + 10, erro: 'contou uma dezena a mais' }];
  const o = alternativas(s, erradas, String, { min: 1, max: 30 });
  let image;
  if(n < 3){
    const cores = [...Array(a).fill(COR_A), ...Array(b).fill(COR_B)];
    image = svgURI(SVG(580, 130, quadroDez(20, 12, 50, cores.slice(0, 10)) + quadroDez(300, 12, 50, cores.slice(10))));
  }
  return { ...o, text: `${a} + ${b} = ?`, fala: a === b ? `Quanto é ${a} mais ${b}? É um dobro!` : `Quanto é ${a} mais ${b}?`, image, meta: { a, b }, chave: `${a}+${b}` };
};
C.soma20 = m => String(m.a + m.b);

/* 8 ─ Subtração até 20 (EF01MA08, EF02MA05) */
G.sub20 = n => {
  const [a, b] = n === 1
    ? sortearAte(() => [rnd(11, 19), rnd(1, 8)], ([x, y]) => x % 10 >= y)          // sem "emprestar": 17 − 4
    : sortearAte(() => [rnd(11, 18), rnd(2, 9)], ([x, y]) => x % 10 < y && x - y > 0); // passando pelo 10: 13 − 5
  const r = a - b;
  const erradas = [{ v: subtracaoMenorDoMaior(a, b), erro: 'tirou o menor do maior na unidade' }, { v: a + b, erro: 'somou em vez de subtrair' },
    { v: r + 1, erro: 'contou um a mais' }, { v: r - 1, erro: 'contou um a menos' }, { v: r + 10, erro: 'não tirou a dezena' }];
  const o = alternativas(r, erradas, String, { min: 0, max: 30 });
  let image;
  if(n < 3){ const cores = Array(a).fill(COR_B); image = svgURI(SVG(580, 130, quadroDez(20, 12, 50, cores.slice(0, 10), Math.max(0, b - (a - 10))) + quadroDez(300, 12, 50, cores.slice(10), Math.min(b, a - 10)))); }
  return { ...o, text: `${a} − ${b} = ?`, fala: `Quanto é ${a} menos ${b}?`, image, meta: { a, b }, chave: `${a}-${b}` };
};
C.sub20 = m => String(m.a - m.b);

/* 9 ─ Cédulas e moedas: quanto dinheiro? (EF01MA19) */
G.cedulas = n => {
  const pool = n === 1 ? ['n2', 'n5', 'n10', 'm1'] : n === 2 ? ['n2', 'n5', 'n10', 'n20'] : ['n2', 'n5', 'n10', 'n20', 'm1', 'm1'];
  const qtd = n === 1 ? rnd(2, 4) : rnd(2, 4) + (n === 3 ? 1 : 0);
  const itens = sortearAte(() => [...Array(qtd)].map(() => pick(pool)), it => { const t = it.reduce((s, k) => s + VAL[k], 0); return t <= (n === 1 ? 20 : 50) && new Set(it).size > 1; });
  itens.sort((x, y) => VAL[y] - VAL[x] || (x[0] === 'n' ? -1 : 1));
  const tot = itens.reduce((s, k) => s + VAL[k], 0);
  const maior = Math.max(...itens.map(k => VAL[k]));
  const erradas = [{ v: itens.length, erro: 'contou as peças, não o valor' }, { v: tot - maior, erro: 'esqueceu uma cédula' },
    { v: tot + maior, erro: 'contou uma cédula duas vezes' }, { v: tot + 5, erro: 'errou a soma' }, { v: tot - 1, erro: 'errou a soma' }];
  const o = alternativas(tot, erradas, reais, { min: 1, max: 99 });
  return { ...o, text: 'Quanto dinheiro tem aqui?', fala: 'Quanto dinheiro tem aqui? Some as cédulas e as moedas.',
    image: svgURI(dinheiro(itens)), meta: { itens }, chave: itens.join(',') };
};
const VAL = { n2: 2, n5: 5, n10: 10, n20: 20, n50: 50, n100: 100, m1: 1 };
C.cedulas = m => reais(m.itens.reduce((s, k) => s + ({ n2: 2, n5: 5, n10: 10, n20: 20, n50: 50, n100: 100, m1: 1 })[k], 0));

/* 10 ─ Dias da semana e meses (EF01MA17) */
const DIAS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const DIAS_C = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'];
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
G.semana = n => {
  if(n === 3 && rnd(0, 1)){
    const i = rnd(0, 11), depois = rnd(0, 1) === 1, r = (i + (depois ? 1 : 11)) % 12;
    const erradas = [{ v: MESES[(i + (depois ? 11 : 1)) % 12], erro: depois ? 'contou para trás' : 'contou para frente' },
      { v: MESES[(i + (depois ? 2 : 10)) % 12], erro: 'pulou um mês' }, { v: MESES[i], erro: 'ficou no mesmo mês' }];
    const o = alternativas(MESES[r], erradas, String);
    return { ...o, text: `Que mês vem ${depois ? 'DEPOIS' : 'ANTES'} de ${MESES[i]}?`, fala: `Que mês vem ${depois ? 'depois' : 'antes'} de ${MESES[i]}?`,
      meta: { mes: i, desloc: depois ? 1 : -1 }, chave: 'm' + i + depois };
  }
  const hoje = rnd(0, 6);
  const tipos = n === 1 ? [[1, 'amanhã']] : n === 2 ? [[1, 'amanhã'], [-1, 'ontem'], [2, 'depois de amanhã']] : [[-2, 'anteontem'], [2, 'depois de amanhã'], [3, 'daqui a 3 dias']];
  const [d, nome] = pick(tipos);
  const r = (hoje + d + 7) % 7;
  const erradas = [{ v: DIAS[(hoje - d + 7) % 7], erro: d > 0 ? 'contou para trás' : 'contou para frente' },
    { v: DIAS[hoje], erro: 'ficou no mesmo dia' }, { v: DIAS[(hoje + d + (d > 0 ? 1 : -1) + 14) % 7], erro: 'contou um dia a mais' },
    { v: DIAS[(hoje + d + (d > 0 ? -1 : 1) + 14) % 7], erro: 'contou um dia a menos' }];
  const o = alternativas(DIAS[r], erradas, String);
  let fig = '';
  DIAS_C.forEach((dc, i) => {
    const x = 10 + i * 88;
    fig += `<rect x="${x}" y="30" width="80" height="64" rx="10" fill="${i === hoje ? '#fde68a' : '#f1f5f9'}" stroke="#111" stroke-width="${i === hoje ? 4 : 2.5}"/>` + T(x + 40, 72, dc, { fs: 22 });
    if(i === hoje) fig += T(x + 40, 22, 'HOJE', { fs: 18, cor: '#b45309' });
  });
  const verbo = d < 0 ? 'foi' : 'será';
  return { ...o, text: `Hoje é ${DIAS[hoje]}. ${nome[0].toUpperCase() + nome.slice(1)} ${verbo}:`,
    fala: `Hoje é ${DIAS[hoje]}. Que dia ${verbo} ${nome}?`, image: n < 3 ? svgURI(SVG(636, 104, fig)) : undefined,
    meta: { hoje, d }, chave: `d${hoje}${d}` };
};
C.semana = m => m.mes !== undefined ? MESES[(m.mes + m.desloc + 12) % 12] : DIAS[(m.hoje + m.d + 7) % 7];

/* 11 ─ Figuras planas (EF01MA14) */
const FORMAS_NOME = { circulo: 'círculo', quadrado: 'quadrado', triangulo: 'triângulo', retangulo: 'retângulo', pentagono: 'pentágono', hexagono: 'hexágono', losango: 'losango' };
const LADOS = { triangulo: 3, quadrado: 4, retangulo: 4, losango: 4, pentagono: 5, hexagono: 6, octogono: 8 };
G.formas = n => {
  if(n === 3){
    const f = pick(['triangulo', 'quadrado', 'retangulo', 'pentagono', 'hexagono', 'losango', 'octogono']);
    const L = LADOS[f];
    const erradas = [{ v: L + 1, erro: 'contou um lado a mais' }, { v: L - 1, erro: 'contou um lado a menos' }, { v: L * 2, erro: 'contou lados e cantos juntos' }];
    const o = alternativas(L, erradas, String, { min: 2, max: 16 });
    return { ...o, text: 'Quantos lados tem esta figura?', fala: 'Quantos lados tem esta figura?',
      image: svgURI(formaSVG(f, pick(['#60a5fa', '#f472b6', '#34d399', '#fbbf24']), n === 3 ? rnd(0, 40) : 0, 200)), meta: { f }, chave: 'l' + f };
  }
  const base = ['circulo', 'quadrado', 'triangulo', 'retangulo'];
  const alvo = pick(base);
  const confusao = { circulo: 'quadrado', quadrado: 'retangulo', retangulo: 'quadrado', triangulo: 'quadrado' };
  const outras = base.filter(f => f !== alvo);
  const erradas = outras.map(f => ({ v: FORMAS_NOME[f], erro: f === confusao[alvo] ? `confundiu com ${FORMAS_NOME[f]}` : `escolheu ${FORMAS_NOME[f]}` }));
  const o = alternativas(FORMAS_NOME[alvo], erradas, String);
  const nomeParaF = Object.fromEntries(Object.entries(FORMAS_NOME).map(([k, v]) => [v, k]));
  const cor = n === 1 ? '#60a5fa' : null;
  const optImgs = o.options.map(nome => svgURI(formaSVG(nomeParaF[nome], cor || pick(['#60a5fa', '#f472b6', '#34d399', '#fbbf24', '#a78bfa']), n === 2 ? pick([0, 15, 30, 45]) : 0, 110)));
  return { ...o, optImgs, text: `Toque no ${FORMAS_NOME[alvo].toUpperCase()}`, fala: `Toque no ${FORMAS_NOME[alvo]}.`, meta: { alvo }, chave: 'f' + alvo + n };
};
C.formas = m => m.f ? String(LADOS[m.f]) : FORMAS_NOME[m.alvo];

/* 12 ─ Pictograma e gráfico simples (EF01MA21) */
function pictograma(cats, vals, porIcone = 1){
  const s = 44, W = 140 + Math.max(...vals.map(v => v / porIcone)) * (s + 4) + 20, H = cats.length * (s + 12) + 20;
  let o = '';
  cats.forEach((c, i) => {
    const y = 10 + i * (s + 12);
    o += `<rect x="6" y="${y - 2}" width="${W - 12}" height="${s + 8}" rx="8" fill="${i % 2 ? '#f8fafc' : '#eef2ff'}"/>`;
    o += ICONES[c](40, y + s / 2 + 2, s) + `<line x1="80" y1="${y}" x2="80" y2="${y + s + 4}" stroke="#94a3b8" stroke-width="2"/>`;
    for(let k = 0; k < vals[i] / porIcone; k++) o += ICONES[c](140 + s / 2 + k * (s + 4), y + s / 2 + 2, s * .92);
  });
  return SVG(W, H, o);
}
function graficoColunas(cats, vals, escala = 1, maxV){
  // eixo com números grandes (pedido do professor): gráfico mais alto e fonte de até 28
  const top = maxV || Math.max(...vals) + escala, H = 400, base = 340, alt = 300, cw = 90, X0 = 80, W = X0 + 20 + cats.length * (cw + 20);
  const Y = v => base - v / top * alt;
  const fs = Math.min(28, Math.floor(alt / (top / escala) * 0.95));
  let o = '';
  for(let v = 0; v <= top; v += escala){
    o += `<line x1="${X0}" y1="${Y(v)}" x2="${W - 10}" y2="${Y(v)}" stroke="#d4d4d8" stroke-width="1.5"/>` + T(X0 - 8, Y(v) + fs * 0.36, v, { fs, anc: 'end' });
  }
  o += `<line x1="${X0}" y1="${base}" x2="${W - 10}" y2="${base}" stroke="#111" stroke-width="3"/><line x1="${X0}" y1="${base}" x2="${X0}" y2="${Y(top)}" stroke="#111" stroke-width="3"/>`;
  const coresB = { banana: '#facc15', uva: '#7e22ce', laranja: '#f97316', morango: '#fb7185', maca: '#b91c1c' };   // coluna com a cor da fruta
  cats.forEach((c, i) => {
    const x = X0 + 20 + i * (cw + 20);
    o += `<rect x="${x}" y="${Y(vals[i])}" width="${cw}" height="${base - Y(vals[i])}" fill="${coresB[c] || '#3b82f6'}" stroke="#111" stroke-width="2"/>`;
    o += ICONES[c](x + cw / 2, base + 30, 42);
  });
  return SVG(W, H + 10, o);
}
G.pictograma = n => {
  const k = n === 3 ? 4 : n === 2 ? 4 : 3;
  const cats = shuffle(FRUTAS).slice(0, k);
  const vals = sortearAte(() => cats.map(() => rnd(1, n === 1 ? 6 : 8)), v => new Set(v).size === v.length);
  if(n === 1){
    const i = rnd(0, k - 1), v = vals[i];
    const outro = vals.find((x, j) => j !== i);
    const erradas = [{ v: outro, erro: 'leu a linha de outra fruta' }, { v: v + 1, erro: 'contou um a mais' }, { v: v - 1, erro: 'contou um a menos' }, { v: vals.reduce((a, b) => a + b, 0), erro: 'somou tudo' }];
    const o = alternativas(v, erradas, String, { min: 1, max: 40 });
    return { ...o, text: `Quantas crianças escolheram ${NOME_ICONE[cats[i]][0]}?`, fala: `Cada desenho é uma criança. Quantas crianças escolheram ${NOME_ICONE[cats[i]][0]}?`,
      image: svgURI(pictograma(cats, vals)), meta: { cats, vals, per: 'val', i }, chave: vals.join(',') + i };
  }
  if(n === 2){
    const mais = rnd(0, 1) === 1;
    const iAlvo = vals.indexOf(mais ? Math.max(...vals) : Math.min(...vals)), iOp = vals.indexOf(mais ? Math.min(...vals) : Math.max(...vals));
    const erradas = cats.map((c, i) => i === iAlvo ? null : { v: NOME_ICONE[c][0], erro: i === iOp ? (mais ? 'escolheu a que teve menos' : 'escolheu a que teve mais') : 'comparou errado' });
    const o = alternativas(NOME_ICONE[cats[iAlvo]][0], erradas, String);
    const porNome = Object.fromEntries(cats.map(c => [NOME_ICONE[c][0], c]));
    return { ...o, optImgs: o.options.map(nm => svgURI(iconeSVG(porNome[nm]))),
      text: `Qual fruta teve ${mais ? 'MAIS' : 'MENOS'} votos?`, fala: `Qual fruta teve ${mais ? 'mais' : 'menos'} votos?`,
      image: svgURI(pictograma(cats, vals)), meta: { cats, vals, per: mais ? 'max' : 'min' }, chave: vals.join(',') + mais };
  }
  const [i, j] = sortearAte(() => [rnd(0, k - 1), rnd(0, k - 1)], ([a, b]) => vals[a] > vals[b]);
  const dif = vals[i] - vals[j];
  const erradas = [{ v: vals[i] + vals[j], erro: 'somou em vez de comparar' }, { v: vals[i], erro: 'respondeu só uma coluna' }, { v: dif + 1, erro: 'contou um a mais' }, { v: dif - 1, erro: 'contou um a menos' }];
  const o = alternativas(dif, erradas, String, { min: 0, max: 40 });
  const art = c => (genero(c) === 'm' ? 'o ' : 'a ') + NOME_ICONE[c][0];
  return { ...o, text: `Quantos votos ${art(cats[i])} teve a mais que ${art(cats[j])}?`,
    fala: `Quantos votos ${art(cats[i])} teve a mais que ${art(cats[j])}?`,
    image: svgURI(graficoColunas(cats, vals, 1, 9)), meta: { cats, vals, per: 'dif', i, j }, chave: vals.join(',') + i + j };
};
C.pictograma = m => m.per === 'val' ? String(m.vals[m.i]) : m.per === 'dif' ? String(m.vals[m.i] - m.vals[m.j])
  : NOME_ICONE[m.cats[m.vals.indexOf(m.per === 'max' ? Math.max(...m.vals) : Math.min(...m.vals))]][0];

const qtdPal = (n, pal) => `${n} ${pal}${n === 1 ? '' : 's'}`;
/* 13 ─ Dezenas e unidades até 100 (EF02MA01, EF02MA04) */
G.dezenas = n => {
  if(n === 3){
    const d = rnd(1, 9), u = rnd(1, 9);
    if(d === u) return G.dezenas(3);
    const forma = rnd(0, 2);
    if(forma === 0){
      const v = d * 10 + u;
      const erradas = [{ v: d, erro: 'disse o algarismo, não o valor' }, { v: u, erro: 'olhou o algarismo errado' }, { v, erro: 'disse o número inteiro' }, { v: d * 100, erro: 'pôs zero a mais' }];
      const o = alternativas(d * 10, erradas, String);
      return { ...o, text: `Quanto vale o ${d} em ${v}?`, fala: `No número ${v}, quanto vale o algarismo ${d}?`, meta: { d, u, pergunta: 'valorD' }, chave: `v${v}` };
    }
    const erradas = [{ v: u * 10 + d, erro: 'trocou dezena e unidade' }, { v: d + u, erro: 'somou os algarismos' }, { v: d * 100 + u, erro: 'escreveu com zero no meio' }, { v: d * 10 + u + 10, erro: 'uma dezena a mais' }];
    const o = alternativas(d * 10 + u, erradas, String);
    return forma === 1
      ? { ...o, text: `${qtdPal(d, 'dezena')} e ${qtdPal(u, 'unidade')} = ?`, fala: `${qtdPal(d, 'dezena')} e ${qtdPal(u, 'unidade')}. Que número é esse?`, meta: { d, u }, chave: `du${d}${u}` }
      : { ...o, text: `${d * 10} + ${u} = ?`, fala: `Quanto é ${d * 10} mais ${u}?`, meta: { d, u }, chave: `mu${d}${u}` };
  }
  const d = rnd(1, n === 1 ? 5 : 4), u = n === 1 ? rnd(0, 9) : rnd(10, 16);
  const v = d * 10 + u;
  const erradas = n === 1
    ? [{ v: u * 10 + d, erro: 'trocou dezena e unidade' }, { v: d + u, erro: 'contou barras como unidades' }, { v: v + 10, erro: 'contou uma barra a mais' }, { v: v - 10, erro: 'contou uma barra a menos' }]
    : [{ v: +(String(d) + String(u)), erro: 'escreveu as quantidades lado a lado' }, { v: d + u, erro: 'contou barras como unidades' }, { v: d * 10 + u - 10, erro: 'ignorou a dezena dos cubinhos soltos' }, { v: v + 1, erro: 'contou um cubinho a mais' }];
  const o = alternativas(v, erradas, String, { min: 1, max: 999 });
  return { ...o, text: 'Que número está representado?', fala: `Cada barra vale 10 e cada cubinho vale 1. Que número está representado?`,
    image: svgURI(materialDourado(0, d, u)), meta: { d, u }, chave: `md${d}.${u}` };
};
C.dezenas = m => String(m.pergunta === 'valorD' ? m.d * 10 : m.d * 10 + m.u);

/* 14 ─ Adição até 100 (EF02MA05, EF02MA06) */
const NOMES = ['Ana', 'Beto', 'Caio', 'Duda', 'Enzo', 'Lia', 'Theo', 'Malu', 'Davi', 'Sofia'];
G.soma100 = n => {
  const querVai = n >= 2;
  const [a, b] = sortearAte(() => [rnd(11, 68), rnd(n === 1 ? 2 : 5, 39)], ([x, y]) => temVaiUm(x, y) === querVai && x + y < 100 && y % 10 !== 0);
  const s = a + b;
  const erradas = [{ v: somaSemVaiUm(a, b), erro: 'esqueceu o vai-um' }, { v: s + 10, erro: 'somou uma dezena a mais' }, { v: s - 10, erro: 'somou uma dezena a menos' },
    { v: Math.abs(a - b), erro: 'subtraiu em vez de somar' }, { v: s + 1, erro: 'errou a unidade' }];
  const o = alternativas(s, erradas, String, { min: 1, max: 199 });
  if(n === 3){
    const nm = pick(NOMES), obj = pick(['figurinhas', 'bolinhas de gude', 'adesivos', 'livros']);
    return { ...o, text: `${nm} tinha ${a} ${obj} e ganhou ${b}. Quantas tem agora?`.replace('Quantas', obj === 'livros' || obj === 'adesivos' ? 'Quantos' : 'Quantas'),
      fala: `${nm} tinha ${a} ${obj} e ganhou mais ${b}. Com quantos ficou?`.replace('quantos', obj === 'livros' || obj === 'adesivos' ? 'quantos' : 'quantas'), meta: { a, b }, chave: `p${a}+${b}` };
  }
  return { ...o, text: `${a} + ${b} = ?`, fala: `Quanto é ${a} mais ${b}?`, meta: { a, b }, chave: `${a}+${b}` };
};
C.soma100 = m => String(m.a + m.b);

/* 15 ─ Subtração até 100 (EF02MA05, EF02MA06) */
G.sub100 = n => {
  const querEmp = n >= 2;
  const [a, b] = sortearAte(() => { const x = rnd(21, 99); return [x, rnd(5, x - 5)]; }, ([x, y]) => temEmpresta(x, y) === querEmp && y % 10 !== 0 && x - y >= 3);
  const r = a - b;
  const erradas = [{ v: subtracaoMenorDoMaior(a, b), erro: 'tirou o menor do maior na unidade' }, { v: a + b, erro: 'somou em vez de subtrair' },
    { v: r + 10, erro: 'esqueceu de emprestar a dezena' }, { v: r - 10, erro: 'tirou uma dezena a mais' }, { v: r + 1, erro: 'errou a unidade' }];
  const o = alternativas(r, erradas, String, { min: 0, max: 199 });
  if(n === 3){
    const obj = pick(['balas', 'figurinhas', 'bolinhas', 'folhas']);
    return { ...o, text: `Havia ${a} ${obj}. Usaram ${b}. Quantas sobraram?`, fala: `Havia ${a} ${obj}. Usaram ${b}. Quantas sobraram?`, meta: { a, b }, chave: `p${a}-${b}` };
  }
  return { ...o, text: `${a} − ${b} = ?`, fala: `Quanto é ${a} menos ${b}?`, meta: { a, b }, chave: `${a}-${b}` };
};
C.sub100 = m => String(m.a - m.b);

/* 16 ─ Dobro, metade, triplo e terça parte (EF02MA07, EF02MA08) */
G.dobro = n => {
  const ops = n === 1 ? ['dobro', 'metade'] : n === 2 ? ['dobro', 'metade', 'triplo'] : ['triplo', 'terça parte', 'metade', 'dobro'];
  const op = pick(ops);
  const lim = { 1: 10, 2: 25, 3: 30 }[n];
  let x, r;
  if(op === 'dobro'){ x = rnd(2, lim); r = 2 * x; }
  else if(op === 'triplo'){ x = rnd(2, n === 2 ? 10 : 20); r = 3 * x; }
  else if(op === 'metade'){ r = rnd(2, lim); x = 2 * r; }
  else { r = rnd(2, 15); x = 3 * r; }
  const erradas = [
    { v: op === 'dobro' ? x / 2 : op === 'metade' ? 2 * x : op === 'triplo' ? 2 * x : x / 2, erro: op === 'dobro' ? 'fez a metade' : op === 'metade' ? 'fez o dobro' : op === 'triplo' ? 'fez o dobro' : 'fez a metade' },
    { v: x + 2, erro: 'somou 2' }, { v: op === 'triplo' ? x + 3 : op === 'terça parte' ? x - 3 : r + 1, erro: op === 'triplo' ? 'somou 3' : op === 'terça parte' ? 'tirou 3' : 'um a mais' },
    { v: x, erro: 'repetiu o número' }, { v: op === 'terça parte' ? 3 * x : r - 1, erro: op === 'terça parte' ? 'fez o triplo' : 'um a menos' }];
  const o = alternativas(r, erradas.filter(e => Number.isInteger(e.v)), String, { min: 1, max: 200 });
  let image;
  if(n === 1){
    const tipo = pick(OBJETOS);
    if(op === 'dobro'){ const g1 = grupoIcones(tipo, x, 10, 10, 40), g2 = grupoIcones(tipo, x, 10, g1.h + 30, 40); image = svgURI(SVG(g1.w + 20, g1.h * 2 + 40, g1.svg + `<line x1="10" y1="${g1.h + 20}" x2="${g1.w + 10}" y2="${g1.h + 20}" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6,4"/>` + g2.svg)); }
    else { const g = grupoIcones(tipo, x, 10, 10, 40, 10); image = svgURI(SVG(g.w + 20, g.h + 20, g.svg)); }
  }
  const txt = op === 'terça parte' ? `A terça parte de ${x}` : `${op[0].toUpperCase() + op.slice(1)} de ${x}`;
  return { ...o, text: txt + ' = ?', fala: `Qual é ${op === 'terça parte' ? 'a terça parte' : op === 'metade' ? 'a metade' : 'o ' + op} de ${x}?`, image, meta: { op, x }, chave: op + x };
};
C.dobro = m => String({ dobro: m.x * 2, triplo: m.x * 3, metade: m.x / 2, 'terça parte': m.x / 3 }[m.op]);

/* 17 ─ Saltos: de 2 em 2, 5 em 5, 10 em 10 (EF02MA09, EF02MA10, EF02MA11) */
G.saltos = n => {
  const passo = n === 1 ? pick([2, 10]) : n === 2 ? pick([2, 5, 10]) : pick([2, 3, 5, 10]);
  const desc = n === 3 && rnd(0, 1) === 1;
  const ini = n === 1 ? passo * rnd(0, 4) : rnd(1, 30);
  let vals = [...Array(6)].map((_, i) => ini + i * passo);
  if(desc) vals = vals.reverse();
  const pos = n === 1 ? 5 : rnd(2, 5);
  const resp = vals[pos];
  const erradas = [{ v: vals[pos - 1] + (desc ? -1 : 1), erro: 'contou de 1 em 1' }, { v: resp + (desc ? -passo : passo), erro: 'pulou um salto' },
    { v: resp + (desc ? passo : -passo), erro: 'repetiu o anterior' }, { v: resp + 10, erro: 'errou a dezena' }];
  const o = alternativas(resp, erradas, String, { min: 0, max: 200 });
  const mostrar = vals.map((v, i) => i === pos ? null : v);
  return { ...o, text: 'Qual número está faltando?', fala: `Os números estão ${desc ? 'diminuindo' : 'aumentando'} sempre do mesmo jeito. Qual número está faltando?`,
    image: svgURI(faixaNumerica(mostrar)), meta: { vals, pos }, chave: vals.join(',') + pos };
};
C.saltos = m => String(m.vals[m.pos - 1] + (m.vals[1] - m.vals[0]));

/* 18 ─ Centenas; comparar até 1000 (EF02MA01, EF02MA02, EF02MA04) */
G.centenas = n => {
  if(n === 2){
    const mais = rnd(0, 1) === 1;
    const ds = sortearAte(() => [rnd(1, 9), rnd(1, 9), rnd(0, 9)], v => new Set(v).size === 3);
    const perm = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]].map(p => p.map(i => ds[i])).filter(p => p[0] !== 0).map(p => +p.join(''));
    const nums = shuffle(perm).slice(0, 4);
    const alvo = mais ? Math.max(...nums) : Math.min(...nums);
    const unid = nums.filter(x => x !== alvo).sort((a, b) => (b % 10) - (a % 10));
    const erradas = nums.filter(x => x !== alvo).map(x => ({ v: x, erro: x === (mais ? unid[0] : unid[unid.length - 1]) ? 'olhou as unidades, não as centenas' : 'comparou errado' }));
    const o = alternativas(alvo, erradas, String);
    return { ...o, text: `Qual é o ${mais ? 'MAIOR' : 'MENOR'} número?`, fala: `Qual é o ${mais ? 'maior' : 'menor'} número?`, meta: { nums, mais }, chave: nums.join(',') + mais };
  }
  const c = rnd(1, n === 1 ? 3 : 5), d = n === 3 ? pick([0, rnd(1, 9)]) : rnd(0, 5), u = n === 3 ? rnd(1, 9) : rnd(0, 9);
  const v = c * 100 + d * 10 + u;
  const erradas = [d === 0 ? { v: c * 10 + u, erro: 'esqueceu o zero' } : { v: c * 100 + u * 10 + d, erro: 'trocou dezena e unidade' },
    { v: c + d + u, erro: 'somou as peças' }, { v: u * 100 + d * 10 + c, erro: 'inverteu a ordem' },
    { v: v + 100, erro: 'uma centena a mais' }, { v: v + 10, erro: 'uma dezena a mais' }];
  const o = alternativas(v, erradas, String, { min: 1, max: 999 });
  if(n === 3){ const t = `${qtdPal(c, 'centena')}, ${qtdPal(d, 'dezena')} e ${qtdPal(u, 'unidade')}`;
    return { ...o, text: `${t} = ?`, fala: `${t}. Que número é?`, meta: { c, d, u }, chave: `cdu${v}` }; }
  return { ...o, text: 'Que número está representado?', fala: 'Cada placa vale 100, cada barra vale 10 e cada cubinho vale 1. Que número é?', image: svgURI(materialDourado(c, d, u)), meta: { c, d, u }, chave: `md${v}` };
};
C.centenas = m => m.nums ? String(m.mais ? Math.max(...m.nums) : Math.min(...m.nums)) : String(m.c * 100 + m.d * 10 + m.u);

/* 19 ─ Horas no relógio (EF02MA18, EF02MA19) */
const fmtH = (h, m) => `${h}:${String(m).padStart(2, '0')}`;
G.relogio = n => {
  const h = rnd(1, 12);
  const m = n === 1 ? 0 : n === 2 ? pick([0, 30, 30]) : pick([15, 45, 5, 10, 20, 25, 35, 40, 50, 55]);
  const prox = h % 12 + 1, ant = (h + 10) % 12 + 1;
  const erradas = [
    { v: fmtH(m === 0 ? 12 : Math.round(m / 5) || 12, (h % 12) * 5), erro: 'trocou os ponteiros' },
    { v: fmtH(m >= 30 ? prox : ant, m), erro: m >= 30 ? 'leu a hora seguinte' : 'leu a hora anterior' },
    { v: fmtH(h, m === 0 ? 30 : m / 5 >= 1 ? m / 5 : 0), erro: m === 0 ? 'errou os minutos' : 'leu o número, não os minutos' },
    { v: fmtH(prox, m), erro: 'leu a hora seguinte' }, { v: fmtH(ant, m), erro: 'leu a hora anterior' },
    { v: fmtH(h, (m + 15) % 60), erro: 'errou os minutos' }, { v: fmtH(h, (m + 30) % 60), erro: 'errou os minutos' }];
  const o = alternativas(fmtH(h, m), erradas.filter(e => /^\d{1,2}:\d{2}$/.test(e.v) && +e.v.split(':')[0] >= 1 && +e.v.split(':')[0] <= 12 && +e.v.split(':')[1] < 60), String);
  return { ...o, text: 'Que horas são?', fala: 'O ponteiro curto marca as horas e o comprido marca os minutos. Que horas são?',
    image: svgURI(relogio(h, m)), meta: { h, m }, chave: fmtH(h, m) };
};
C.relogio = m => fmtH(m.h, m.m);

/* 20 ─ Medir com régua em centímetros (EF02MA16) */
G.regua = n => {
  const max = 12;
  if(n === 3){
    const [a, b] = sortearAte(() => [rnd(3, 11), rnd(2, 10)], ([x, y]) => x > y);
    const erradas = [{ v: a + b, erro: 'somou em vez de comparar' }, { v: a, erro: 'respondeu só uma medida' }, { v: a - b + 1, erro: 'contou um a mais' }, { v: b, erro: 'respondeu a menor' }];
    const o = alternativas(a - b, erradas, v => v + ' cm', { min: 1, max: 30 });
    return { ...o, text: 'Quantos cm a fita A é maior que a B?', fala: 'Meça as duas fitas. Quantos centímetros a fita A é maior que a fita B?',
      image: svgURI(regua(max, [{ ini: 0, fim: a, cor: '#22c55e', rot: 'A' }, { ini: 0, fim: b, cor: '#f97316', rot: 'B' }])), meta: { a, b, tipo: 'dif' }, chave: `d${a}${b}` };
  }
  const ini = n === 1 ? 0 : rnd(1, 5), comp = rnd(2, max - ini - 1), fim = ini + comp;
  const erradas = n === 1
    ? [{ v: comp + 1, erro: 'contou os tracinhos, não os espaços' }, { v: comp - 1, erro: 'contou um a menos' }, { v: comp * 2, erro: 'contou meios centímetros' }]
    : [{ v: fim, erro: 'leu só onde termina' }, { v: ini, erro: 'leu onde começa' }, { v: comp + 1, erro: 'contou os tracinhos' }, { v: fim + ini, erro: 'somou começo e fim' }];
  const o = alternativas(comp, erradas, v => v + ' cm', { min: 1, max: 30 });
  return { ...o, text: 'Quanto mede a fita?', fala: n === 1 ? 'Quanto mede a fita verde?' : 'A fita não começa no zero. Quanto ela mede?',
    image: svgURI(regua(max, [{ ini, fim, cor: '#22c55e' }])), meta: { ini, fim }, chave: `r${ini}.${fim}` };
};
C.regua = m => (m.tipo === 'dif' ? m.a - m.b : m.fim - m.ini) + ' cm';

/* 21 ─ Dinheiro: somar, completar, troco (EF02MA20) */
G.dinheiro = n => {
  if(n === 3){
    const pago = pick([10, 20, 50]), preco = rnd(Math.max(2, pago / 2), pago - 1);
    const troco = pago - preco;
    const erradas = [{ v: pago + preco, erro: 'somou em vez de subtrair' }, { v: preco, erro: 'respondeu o preço' }, { v: troco + 1, erro: 'errou a conta' }, { v: troco - 1, erro: 'errou a conta' }, { v: troco + 10, erro: 'errou a dezena' }];
    const o = alternativas(troco, erradas, reais, { min: 1, max: 99 });
    return { ...o, text: `Comprei um brinquedo de R$ ${preco} e paguei com esta cédula. Qual é o troco?`, fala: `Comprei um brinquedo de ${preco} reais e paguei com uma cédula de ${pago} reais. Qual é o troco?`,
      image: svgURI(dinheiro(['n' + pago])), meta: { pago, preco }, chave: `t${pago}.${preco}` };
  }
  const pool = ['n2', 'n5', 'n10', 'n20', 'n50', 'm1'];
  const itens = sortearAte(() => [...Array(rnd(3, 5))].map(() => pick(pool)), it => { const t = it.reduce((s, k) => s + VAL[k], 0); return t < (n === 1 ? 100 : 50) && new Set(it).size > 2; });
  itens.sort((x, y) => VAL[y] - VAL[x]);
  const tot = itens.reduce((s, k) => s + VAL[k], 0);
  if(n === 2){
    const meta = [20, 50, 100].find(v => v > tot + 2) || 100;
    const falta = meta - tot;
    const erradas = [{ v: tot, erro: 'respondeu quanto já tem' }, { v: meta + tot, erro: 'somou em vez de completar' }, { v: falta + 1, erro: 'errou a conta' }, { v: falta - 1, erro: 'errou a conta' }, { v: falta + 10, erro: 'errou a dezena' }];
    const o = alternativas(falta, erradas, reais, { min: 1, max: 199 });
    return { ...o, text: `Quanto falta para ter R$ ${meta}?`, fala: `Quanto falta para ter ${meta} reais?`, image: svgURI(dinheiro(itens)), meta: { itens, alvo: meta }, chave: itens.join(',') + meta };
  }
  const maior = VAL[itens[0]];
  const erradas = [{ v: itens.length, erro: 'contou as peças, não o valor' }, { v: tot - VAL[itens[itens.length - 1]], erro: 'esqueceu uma peça' }, { v: tot + maior, erro: 'contou uma cédula duas vezes' }, { v: tot + 10, erro: 'errou a soma' }, { v: tot - 5, erro: 'errou a soma' }];
  const o = alternativas(tot, erradas, reais, { min: 1, max: 199 });
  return { ...o, text: 'Quanto dinheiro tem aqui?', fala: 'Quanto dinheiro tem aqui?', image: svgURI(dinheiro(itens)), meta: { itens }, chave: itens.join(',') };
};
C.dinheiro = m => {
  if(m.pago) return reais(m.pago - m.preco);
  const t = m.itens.reduce((s, k) => s + (k[0] === 'm' ? +k.slice(1) : +k.slice(1)), 0);
  return reais(m.alvo ? m.alvo - t : t);
};

/* 22 ─ Tabelas e gráficos de colunas (EF02MA22, EF02MA23) */
G.colunas = n => {
  const cats = shuffle(FRUTAS).slice(0, 4);
  const esc = n === 1 ? 1 : 2;   // escala do eixo (de 1 em 1 ou de 2 em 2)
  const vals = sortearAte(() => cats.map(() => esc * rnd(1, 9)), v => new Set(v).size === 4);
  const img = svgURI(graficoColunas(cats, vals, esc, Math.max(...vals) + esc));
  if(n < 3){
    const i = rnd(0, 3), v = vals[i];
    const erradas = [{ v: v / esc, erro: 'contou os quadradinhos, não a escala' }, { v: v + esc, erro: 'leu a linha de cima' }, { v: v - esc, erro: 'leu a linha de baixo' }, { v: vals[(i + 1) % 4], erro: 'leu outra coluna' }];
    const o = alternativas(v, erradas, String, { min: 1, max: 40 });
    return { ...o, text: `Quantos votos teve ${genero(cats[i]) === 'm' ? 'o' : 'a'} ${NOME_ICONE[cats[i]][0]}?`,
      fala: `No gráfico, quantos votos teve ${genero(cats[i]) === 'm' ? 'o' : 'a'} ${NOME_ICONE[cats[i]][0]}?`, image: img, meta: { vals, i }, chave: vals.join(',') + i };
  }
  const tot = vals.reduce((a, b) => a + b, 0);
  const erradas = [{ v: tot - vals[3], erro: 'esqueceu uma coluna' }, { v: Math.max(...vals), erro: 'respondeu a maior coluna' }, { v: tot + esc, erro: 'errou a soma' }, { v: tot / esc, erro: 'ignorou a escala' }];
  const o = alternativas(tot, erradas.filter(e => Number.isInteger(e.v)), String, { min: 1, max: 99 });
  return { ...o, text: 'Quantos votos ao todo?', fala: 'Quantas crianças votaram ao todo? Some todas as colunas.', image: img, meta: { vals, tot: true }, chave: vals.join(',') + 't' };
};
C.colunas = m => String(m.tot ? m.vals.reduce((a, b) => a + b, 0) : m.vals[m.i]);
