
/* =========================================================================
   PROTEÇÃO DA PARTIDA (acrescentado)
   1. Professor: clicar em "Sou Aluno" com sala aberta agora pede confirmação
      (antes fechava a sala sem perguntar).
   2. Professor e aluno: sair/recarregar/voltar (inclusive o gesto de voltar do
      Chromebook) com partida aberta pede confirmação do navegador.
   3. Professor: a partida fica salva no navegador; se a página fechar, ao abrir
      de novo aparece "Retomar partida" com a mesma sala, equipes e pontos.
   4. Aluno: se a página recarregar, volta sozinho para a mesma sala, com o
      mesmo nome e os pontos que já tinha.
   Funções originais intactas: só embrulhos (switchMode, playerJoin,
   startContinuousPlay, playerGotKicked, finishPlayerMatch, endGame).
========================================================================= */
(() => {
  const LS_HOST = 'cgm_partida_prof', SS_ALUNO = 'cgm_partida_aluno';
  const ls = { get(k){ try{ return JSON.parse(localStorage.getItem(k) || 'null'); }catch(e){ return null; } }, set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }, del(k){ try{ localStorage.removeItem(k); }catch(e){} } };
  const ss = { get(k){ try{ return JSON.parse(sessionStorage.getItem(k) || 'null'); }catch(e){ return null; } }, set(k, v){ try{ sessionStorage.setItem(k, JSON.stringify(v)); }catch(e){} }, del(k){ try{ sessionStorage.removeItem(k); }catch(e){} } };

  // o id do aluno precisa sobreviver ao recarregar (antes só era salvo ao trocar de modo)
  try{ sessionStorage.setItem('cgm_pid', app.playerId); }catch(e){}

  const salaAbertaProf = () => app.mode === 'teacher' && app.room && !app.host.isDemo && (app.host.phase === 'lobby' || app.host.phase === 'playing');
  const emPartidaAluno = () => app.mode === 'student' && app.room && app.playerName && app.player.phase !== 'done';

  /* 1 ─ troca de modo */
  const switchMode0 = app.switchMode;
  app.switchMode = function(m){
    if(m === 'student' && this.mode === 'teacher' && this.room && (this.host.phase === 'lobby' || this.host.phase === 'playing')){
      if(!confirm('A sala ' + this.room + ' está aberta. Trocar para "Sou Aluno" fecha a sala para todos.\n\nTrocar mesmo assim?')) return;
      ls.del(LS_HOST);
    }
    return switchMode0.call(this, m);
  };

  /* 2 ─ sair / recarregar / voltar */
  window.addEventListener('beforeunload', e => {
    if(salaAbertaProf() || emPartidaAluno()){ e.preventDefault(); e.returnValue = ''; return ''; }
  });

  /* 3 ─ professor: salva a partida a cada 2 s */
  const salvarProf = () => {
    if(!salaAbertaProf()) return;
    const h = app.host;
    ls.set(LS_HOST, { salvo: Date.now(), room: app.room, phase: h.phase, teams: h.teams, teamCount: h.teamCount,
      players: h.players.filter(p => !p.isBot).map(p => ({ id: p.id, name: p.name, team: p.team, score: p.score, correct: p.correct, wrong: p.wrong, timeouts: p.timeouts, level: p.level, totalAnswers: p.totalAnswers, byType: p.byType, totalMsCorrect: p.totalMsCorrect, isBot: false })),
      matchEndTime: h.matchEndTime, matchDurationMs: h.matchDurationMs, questionTime: h.questionTime, sprintEnabled: h.sprintEnabled,
      questionBank: h.questionBank, cfg: h.cfg, totalAnswers: h.totalAnswers, modo: $('hModeLabel') ? $('hModeLabel').innerHTML : '' });
  };
  setInterval(salvarProf, 2000);
  const endGame0 = app.endGame;
  app.endGame = function(){ ls.del(LS_HOST); return endGame0.apply(this, arguments); };

  function retomar(sn){
    app.switchMode('teacher');
    const h = app.host;
    Object.assign(h, { teams: sn.teams, teamCount: sn.teamCount, players: sn.players, matchEndTime: sn.matchEndTime, matchDurationMs: sn.matchDurationMs,
      questionTime: sn.questionTime, sprintEnabled: sn.sprintEnabled, questionBank: sn.questionBank || [], cfg: sn.cfg, totalAnswers: sn.totalAnswers || 0,
      isDemo: false, lastPositions: {}, movingTimeouts: {}, raceBuilt: false, demoTimeouts: [], phase: sn.phase });
    app.room = sn.room;
    $('roomCodeDisplay').textContent = sn.room;
    $('hRoomCode').textContent = sn.room;
    $('hModeLabel').innerHTML = sn.modo || 'AUTO';
    if(sn.phase === 'lobby'){
      app.showTeacherScreen('lobby');
      app.renderLobby();
    } else {
      app.showTeacherScreen('game');
      $('hPlayers').innerHTML = '';
      app.buildRaceTrackStructure();
      app.renderRaceTrack();
      app.renderRankLive();
      $('hMsg').innerHTML = '🏁 <b>PARTIDA EM ANDAMENTO</b> (retomada)';
      app.startMatchTimer();
      app.startBroadcastLoop();
    }
    app.connectMQTT();                  // ao conectar, reenvia o estado para os alunos
    app.toast('✅ Partida retomada: sala <b>' + esc(sn.room) + '</b>', 'success');
  }
  function oferecerRetomada(){
    const sn = ls.get(LS_HOST);
    if(!sn || !sn.room) return;
    const vivo = sn.phase === 'playing' ? sn.matchEndTime > Date.now() + 5000 : Date.now() - sn.salvo < 3 * 3600 * 1000;
    if(!vivo){ ls.del(LS_HOST); return; }
    const falta = sn.phase === 'playing' ? ` · faltam ${fmtTime(sn.matchEndTime - Date.now())}` : ' · sala aguardando início';
    const box = document.createElement('div');
    box.id = 'retomarBox';
    box.style.cssText = 'position:fixed;left:50%;top:70px;transform:translateX(-50%);z-index:400;background:#1e293b;border:2px solid #fbbf24;border-radius:16px;padding:16px 20px;box-shadow:0 12px 40px rgba(0,0,0,.6);max-width:92vw;text-align:center';
    box.innerHTML = `<div style="font-weight:900;font-size:18px;margin-bottom:6px">⚠️ Há uma partida aberta</div>
      <div style="color:var(--muted);font-size:14px;margin-bottom:12px">Sala <b style="color:#60a5fa">${esc(sn.room)}</b> · ${sn.players.length} aluno${sn.players.length === 1 ? '' : 's'}${falta}</div>
      <div class="row" style="justify-content:center"><button class="primary" id="retomarSim">▶ Retomar partida</button><button class="ghost" id="retomarNao">Descartar</button></div>`;
    document.body.appendChild(box);
    $('retomarSim').onclick = () => { box.remove(); retomar(sn); };
    $('retomarNao').onclick = () => { if(confirm('Descartar a partida da sala ' + sn.room + '?')){ ls.del(LS_HOST); box.remove(); } };
  }

  /* 4 ─ aluno: lembra sala e nome; volta sozinho depois de recarregar */
  const playerJoin0 = app.playerJoin;
  app.playerJoin = function(){
    const r = playerJoin0.apply(this, arguments);
    if(this.room && this.playerName) ss.set(SS_ALUNO, { room: this.room, name: this.playerName, t: Date.now() });
    return r;
  };
  const startContinuousPlay0 = app.startContinuousPlay;
  app.startContinuousPlay = function(state){
    const r = startContinuousPlay0.call(this, state);
    const me = (state.players || []).find(p => p.id === this.playerId);
    if(me && me.score > 0){ this.player.stats.score = me.score; this.updatePlayerStatsUI(); }   // voltou no meio: mantém os pontos
    return r;
  };
  const playerGotKicked0 = app.playerGotKicked;
  app.playerGotKicked = function(){ ss.del(SS_ALUNO); return playerGotKicked0.apply(this, arguments); };
  const finishPlayerMatch1 = app.finishPlayerMatch;
  app.finishPlayerMatch = function(){ ss.del(SS_ALUNO); return finishPlayerMatch1.apply(this, arguments); };

  function voltarAluno(){
    const s = ss.get(SS_ALUNO);
    if(!s || !s.room || Date.now() - s.t > 3 * 3600 * 1000) return;
    $('joinRoom').value = s.room;
    $('joinName').value = s.name;
    app.toast('🔄 Voltando para a sala ' + esc(s.room) + '…', 'info');
    setTimeout(() => { if(app.mode === 'student' && !app.room) app.playerJoin(); }, 300);
  }

  setTimeout(() => { oferecerRetomada(); voltarAluno(); }, 400);
})();
