
/* =========================================================================
   8º E 9º ANO (acrescentado) — entram no fim do catálogo, na ordem dos
   trimestres do Currículo SEDU/ES 2026. Nada do 1º ao 7º muda de lugar.
========================================================================= */
const CAT89 = [
  // 8º ano — 1º trimestre
  { id: 'pot8', ano: 8, un: 'Números', bncc: 'EF08MA01', nome: 'Potências (expoente inteiro) e notação científica', t: 1.5 },
  { id: 'raiz8', ano: 8, un: 'Números', bncc: 'EF08MA02', nome: 'Raízes: exata, aproximada e expoente fracionário', t: 1.5 },
  { id: 'probRac8', ano: 8, un: 'Números', bncc: 'EF07MA12/ES', nome: 'Problemas com frações e decimais', t: 1.7 },
  { id: 'seq8', ano: 8, un: 'Álgebra', bncc: 'EF08MA10 · EF08MA11/ES', nome: 'Sequências: termo geral e recursiva', t: 1.6 },
  { id: 'alg8', ano: 8, un: 'Álgebra', bncc: 'EF08MA06/ES', nome: 'Valor numérico, monômios e fator comum', t: 1.6 },
  // 8º ano — 2º trimestre
  { id: 'porc8', ano: 8, un: 'Números', bncc: 'EF08MA04/ES', nome: 'Porcentagem: quanto é, que % é, desconto', t: 1.6 },
  { id: 'classes8', ano: 8, un: 'Probabilidade e estatística', bncc: 'EF08MA24', nome: 'Tabela de frequência com classes', t: 1.8 },
  { id: 'grafAdeq8', ano: 8, un: 'Probabilidade e estatística', bncc: 'EF08MA23', nome: 'Qual gráfico usar', t: 1.4 },
  { id: 'medidas8', ano: 8, un: 'Probabilidade e estatística', bncc: 'EF08MA25', nome: 'Média, moda, mediana e amplitude', t: 1.7 },
  { id: 'contagem8', ano: 8, un: 'Números', bncc: 'EF08MA03', nome: 'Princípio multiplicativo', t: 1.5 },
  { id: 'prob8', ano: 8, un: 'Probabilidade e estatística', bncc: 'EF08MA22', nome: 'Probabilidade com espaço amostral', t: 1.6 },
  { id: 'propTipo8', ano: 8, un: 'Álgebra', bncc: 'EF08MA12/ES', nome: 'Direta, inversa ou não proporcional', t: 1.6 },
  { id: 'regra3_8', ano: 8, un: 'Álgebra', bncc: 'EF08MA13/ES', nome: 'Regra de três simples e composta', t: 1.7 },
  { id: 'retaEq8', ano: 8, un: 'Álgebra', bncc: 'EF08MA07', nome: 'Equação com duas incógnitas e a reta', t: 1.7 },
  { id: 'sistema8', ano: 8, un: 'Álgebra', bncc: 'EF08MA08', nome: 'Sistemas de equações do 1º grau', t: 1.8 },
  // 8º ano — 3º trimestre
  { id: 'quadProp8', ano: 8, un: 'Geometria', bncc: 'EF08MA14', nome: 'Quadriláteros e congruência de triângulos', t: 1.5 },
  { id: 'area8', ano: 8, un: 'Grandezas e medidas', bncc: 'EF08MA19', nome: 'Área de triângulos, quadriláteros e círculo', t: 1.7 },
  { id: 'vol8', ano: 8, un: 'Grandezas e medidas', bncc: 'EF08MA20 · EF08MA21', nome: 'Volume do bloco e litros', t: 1.7 },
  { id: 'eq2_8', ano: 8, un: 'Álgebra', bncc: 'EF08MA09', nome: 'Equação do tipo ax² = b', t: 1.5 },
  { id: 'geo8', ano: 8, un: 'Geometria', bncc: 'EF08MA15 · EF08MA17/ES', nome: 'Diagonais, mediatriz e bissetriz', t: 1.5 },
  // 9º ano — 1º trimestre
  { id: 'pot9', ano: 9, un: 'Números', bncc: 'EF09MA03/ES', nome: 'Potências de expoente negativo e fracionário; radicais', t: 1.6 },
  { id: 'cient9', ano: 9, un: 'Números', bncc: 'EF09MA04', nome: 'Notação científica em contas e problemas', t: 1.7 },
  { id: 'porcSuc9', ano: 9, un: 'Números', bncc: 'EF09MA05/ES', nome: 'Porcentagens sucessivas e juros compostos', t: 1.8 },
  { id: 'razao9', ano: 9, un: 'Grandezas e medidas', bncc: 'EF09MA07', nome: 'Velocidade, consumo e densidade', t: 1.6 },
  { id: 'escala9', ano: 9, un: 'Números', bncc: 'EF09MA08', nome: 'Escala e divisão em partes proporcionais', t: 1.7 },
  { id: 'paral9', ano: 9, un: 'Geometria', bncc: 'EF09MA10', nome: 'Ângulos entre paralelas e transversal', t: 1.6 },
  { id: 'tales9', ano: 9, un: 'Geometria', bncc: 'EF09MA14/ES', nome: 'Teorema de Tales', t: 1.7 },
  // 9º ano — 2º trimestre
  { id: 'graf9', ano: 9, un: 'Probabilidade e estatística', bncc: 'EF09MA22 · EF09MA23', nome: 'Gráfico: leitura, média e porcentagem', t: 1.7 },
  { id: 'prob9', ano: 9, un: 'Probabilidade e estatística', bncc: 'EF09MA20', nome: 'Eventos dependentes e independentes', t: 1.7 },
  { id: 'prodNot9', ano: 9, un: 'Álgebra', bncc: 'EF08MA06/ES', nome: 'Produtos notáveis', t: 1.6 },
  { id: 'fator9', ano: 9, un: 'Álgebra', bncc: 'EF09MA09', nome: 'Fatoração', t: 1.7 },
  { id: 'eq2g9', ano: 9, un: 'Álgebra', bncc: 'EF09MA26/ES', nome: 'Equação do 2º grau', t: 1.8 },
  { id: 'semelh9', ano: 9, un: 'Geometria', bncc: 'EF09MA12', nome: 'Semelhança de triângulos', t: 1.7 },
  { id: 'pitag9', ano: 9, un: 'Geometria', bncc: 'EF09MA13', nome: 'Teorema de Pitágoras', t: 1.7 },
  // 9º ano — 3º trimestre
  { id: 'circ9', ano: 9, un: 'Geometria', bncc: 'EF07MA22 · EF09MA11', nome: 'Ângulo central e ângulo inscrito', t: 1.5 },
  { id: 'irrac9', ano: 9, un: 'Números', bncc: 'EF09MA01 · EF09MA02', nome: 'Números irracionais e a reta', t: 1.6 },
  { id: 'vistas9', ano: 9, un: 'Geometria', bncc: 'EF09MA17', nome: 'Vistas ortogonais', t: 1.7 },
  { id: 'volPC9', ano: 9, un: 'Grandezas e medidas', bncc: 'EF09MA19', nome: 'Volume de prisma e cilindro', t: 1.7 },
  { id: 'funcao9', ano: 9, un: 'Álgebra', bncc: 'EF09MA06', nome: 'Função afim e quadrática', t: 1.7 },
];
CAT89.filter(d => typeof G[d.id] === 'function').forEach(d => {
  d.ordem = CAT.length; d.i = CAT.length; d.anoOrig = d.ano; d.prov = false;
  CAT.push(d); POR_ID[d.id] = d;
  TYPE_LABELS[d.id] = `${d.ano}º · ${d.nome}`; TYPE_TIME_FACTOR[d.id] = d.t;
});
