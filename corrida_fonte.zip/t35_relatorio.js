/* =========================================================================
   RELATÓRIO C / NC / NA DA TURMA
   · Abre pelo ✏️ Editar turma → "📊 Relatório C/NC/NA".
   · Visões: por atividade (degrau), por habilidade da BNCC ou por descritor do Paebes.
   · Anos: do 1º até o ano da turma, ou só o ano da turma.
   · C  = consolidado, verificado no jogo (dominou jogando ou no treino)
     C* = consolidado presumido (o diagnóstico pulou porque o aluno acertou coisa mais avançada)
     NC = não consolidado (já respondeu, ainda não domina)
     NA = não aplicado (ainda não respondeu)
   · Mostra a tabela colorida na tela e baixa a planilha (.csv, abre no Excel e no Google Planilhas).
   · Linha "Turma" com % C / % NC por coluna; ordem da trilha ou "mais críticas primeiro";
     "só o que já foi aplicado"; aba 👥 Grupos de reforço (quem está em NC em cada
     habilidade + erro mais comum de cada um); 🖨️ Imprimir.
   · Também: 🔎 Refazer diagnóstico no ⋯ do aluno na gaveta (com a sala aberta).
   Bloco novo: uma janela e dois botões.
========================================================================= */
function statusDegrau(r, d){
  const x = r && r.deg && r.deg[d.id];
  if(!x || (!x.tot && !x.dom)) return 'NA';
  if(x.dom) return (x.domPor === 'diag' || x.domPor === 'ano') ? 'C*' : 'C';
  return 'NC';
}
function juntarStatus(lista){
  if(!lista.length) return '';
  if(lista.every(s => s === 'NA')) return 'NA';
  if(lista.every(s => s === 'C' || s === 'C*')) return lista.includes('C') ? 'C' : 'C*';
  return 'NC';
}
function relatorioTurma(visao, soAno, opts = {}){
  const ano = Math.min(estado.cfg.ano || 7, LIMITE.anoMax || 9);
  let degs = CAT.filter(d => ativo(d) && (soAno ? d.ano === ano : d.ano <= ano));
  const codsDe = d => String(d.bncc || '').split(/[·,]/).map(s => s.trim().replace(/\/ES$/, '')).filter(Boolean);
  const filtro = opts.codigos && opts.codigos.length ? new Set(opts.codigos) : null;   // recorte: trimestre do currículo ou "meu plano"
  if(filtro) degs = CAT.filter(d => ativo(d) && d.ano <= ano && codsDe(d).some(c => filtro.has(c)));
  const A = estado.turma.alunos || {}, reais = estado.turma.reais || {};
  const alunos = (estado.cfg.nomes || []).map(n => ({ nome: reais[n] || n, r: A[normNome(n)] || null })).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
  let cols = [];
  if(visao === 'atividade') cols = degs.map(d => ({ cab: `${d.ano}º · ${d.nome}`, sub: d.bncc, degs: [d] }));
  if(visao === 'bncc'){
    const mapa = {};
    degs.forEach(d => String(d.bncc || '').split(/[·,]/).map(s => s.trim()).filter(Boolean).forEach(c => { const k = c.replace(/\/ES$/, ''); (mapa[k] || (mapa[k] = [])).push(d); }));
    cols = Object.keys(mapa).filter(k => !filtro || filtro.has(k)).sort().map(k => ({ cab: k, sub: [...new Set(mapa[k].map(d => d.nome))].join(' / '), degs: mapa[k] }));
  }
  if(visao === 'descritor' && typeof DESCRITORES !== 'undefined'){
    Object.keys(DESCRITORES).forEach(code => { const ds = degs.filter(d => (DESC_DE[d.id] || []).includes(code)); if(ds.length) cols.push({ cab: code, sub: DESCRITORES[code], degs: ds }); });
  }
  // valor de cada aluno em cada coluna
  const M = alunos.map(a => cols.map(c => juntarStatus(c.degs.map(d => statusDegrau(a.r, d)))));
  // estatística da turma por coluna
  cols.forEach((c, j) => {
    const n = alunos.length || 1, k = v => M.filter(l => l[j] === v).length;
    c.st = { c: k('C'), cp: k('C*'), nc: k('NC'), na: k('NA') };
    c.pc = Math.round((c.st.c + c.st.cp) / n * 100); c.pnc = Math.round(c.st.nc / n * 100); c.pna = Math.round(c.st.na / n * 100);
    c.idx = j;
  });
  let ordem = cols.slice();
  if(opts.soAplicados) ordem = ordem.filter(c => c.st.na < alunos.length);
  if(opts.ordem === 'critica') ordem.sort((x, y) => y.st.nc - x.st.nc || x.pc - y.pc);
  const linhas = alunos.map((a, i) => {
    const vals = ordem.map(c => M[i][c.idx]);
    const cont = k => vals.filter(v => v === k).length;
    return { nome: a.nome, r: a.r, vals, c: cont('C'), cp: cont('C*'), nc: cont('NC'), na: cont('NA') };
  });
  const semJogo = filtro ? [...filtro].filter(c => !CAT.some(d => ativo(d) && codsDe(d).includes(c))) : [];
  return { ano, cols: ordem, linhas, total: cols.length, semJogo };
}
/* grupos de reforço: para cada coluna com NC, quem precisa (e o erro mais comum de cada um) */
function gruposReforco(R){
  return R.cols.map((c, j) => {
    const quem = R.linhas.filter(l => l.vals[j] === 'NC').map(l => {
      let erro = '', n = 0;
      c.degs.forEach(d => { const x = l.r && l.r.deg[d.id]; if(x && x.err) Object.entries(x.err).forEach(([e, k]) => { if(k > n){ n = k; erro = e; } }); });
      return { nome: l.nome, erro, n };
    });
    return { c, quem };
  }).filter(g => g.quem.length).sort((a, b) => b.quem.length - a.quem.length);
}
estado.relatorioTurma = relatorioTurma;
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  #relBox{z-index:660}
  .rel-op{display:flex;gap:8px;flex-wrap:wrap;margin:10px 4px}
  .rel-op .ab{padding:8px 12px;border-radius:10px;background:var(--panel2);border:2px solid var(--line);color:var(--text);font-weight:900;cursor:pointer;width:auto}
  .rel-op .ab.on{background:#3b82f6;border-color:#3b82f6}
  .rel-leg{color:var(--muted);font-size:13px;margin:4px}
  .rel-leg b{padding:1px 6px;border-radius:6px}
  .rel-wrap{overflow:auto;max-height:70vh;border:1px solid var(--line);border-radius:12px;margin-top:8px}
  .rel-tab{border-collapse:collapse;font-size:12px}
  .rel-tab th,.rel-tab td{border:1px solid #1e293b;padding:4px 6px;text-align:center;white-space:nowrap}
  .rel-tab thead th{position:sticky;top:0;background:#0f172a;z-index:1;font-weight:800;color:#cbd5e1;max-width:120px;white-space:normal;vertical-align:bottom}
  .rel-tab thead th small{display:block;font-weight:600;color:#64748b;font-size:10px;max-height:42px;overflow:hidden}
  .rel-tab td.nm,.rel-tab th.nm{position:sticky;left:0;background:#0f172a;text-align:left;font-weight:800;z-index:2;color:#e2e8f0}
  .rel-tab td.C{background:#166534;color:#fff;font-weight:900}
  .rel-tab td.Cp{background:#3f6212;color:#ecfccb}
  .rel-tab td.NC{background:#92400e;color:#fff;font-weight:900}
  .rel-tab td.NA{background:#1e293b;color:#64748b}
  .rel-tab td.tot{background:#0b1220;color:#e2e8f0;font-weight:800}
  .rel-tab tfoot td{position:sticky;bottom:0;background:#0f172a;font-weight:900;font-size:11px;line-height:1.25;z-index:1}
  .rel-tab tfoot td.nm{z-index:3}
  .rel-tab tfoot td span{display:block;font-weight:700;color:#94a3b8}
  .rel-op label{display:flex;align-items:center;gap:6px;color:var(--muted);font-weight:800;font-size:13px;cursor:pointer}
  .rel-op label input{width:auto;margin:0}
  .rg-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:10px;margin-top:10px}
  .rg-card{background:var(--panel2);border:2px solid #92400e;border-radius:12px;padding:10px 12px}
  .rg-card h4{margin:0 0 2px;font-size:15px}
  .rg-card .rg-sub{color:var(--muted);font-size:12px;margin-bottom:6px}
  .rg-card li{font-size:14px;margin:2px 0}
  .rg-card li small{color:#fca5a5}
  @media print{
    body.rel-imprimindo > *:not(#relBox){display:none !important}
    body.rel-imprimindo, html{background:#fff !important}
    body.rel-imprimindo #relBox{position:static;overflow:visible;background:#fff;color:#000;padding:0}
    body.rel-imprimindo .rel-nao-imprime{display:none !important}
    body.rel-imprimindo .rg-card{background:#fff;border-color:#999;break-inside:avoid;color:#000}
    body.rel-imprimindo .rg-card .rg-sub{color:#333}
    body.rel-imprimindo .rel-wrap{max-height:none;overflow:visible}
  }`;
  document.head.appendChild(st);
  const cls = v => v === 'C*' ? 'Cp' : v;
  function abrir(){
    let box = $('relBox'); if(box) box.remove();
    box = document.createElement('div'); box.id = 'relBox'; box.className = 'cat-fundo';
    document.body.appendChild(box);
    const est = { visao: 'atividade', soAno: false, ordem: 'trilha', soAplicados: true, aba: 'tabela', tri: 0, codigos: null };
    const anoT = Math.min(estado.cfg.ano || 7, LIMITE.anoMax || 9);
    const codigosDe = t => t === 'plano' ? (estado.turma.planoCodigos || []) : t ? (((typeof TRI_ES !== 'undefined' && TRI_ES[anoT]) || {})[t] || []) : null;
    const desenha = () => {
      const R = relatorioTurma(est.visao, est.soAno, est);
      const tot = R.linhas.reduce((s, l) => s + l.c + l.cp + l.nc + l.na, 0) || 1;
      const soma = k => R.linhas.reduce((s, l) => s + l[k], 0);
      box.innerHTML = `<div class="cat-topo"><h2>📊 Relatório C / NC / NA · ${esc(estado.turma.nome || '')}</h2>
          <div class="dir rel-nao-imprime"><button class="ab" data-imprimir="1">🖨️ Imprimir</button><button class="ab" data-baixar="1" style="background:#16a34a;border-color:#16a34a">⬇️ Baixar planilha</button><button class="ab" data-fechar="1">✕ Fechar</button></div></div>
        <div class="rel-op">${[['atividade', 'Por atividade'], ['bncc', 'Por habilidade BNCC'], ['descritor', 'Por descritor Paebes']].map(([v, t]) => `<button class="ab ${est.visao === v ? 'on' : ''}" data-visao="${v}">${t}</button>`).join('')}
          <span style="width:12px"></span>
          <button class="ab ${!est.soAno ? 'on' : ''}" data-ano="0">1º ao ${R.ano}º ano</button><button class="ab ${est.soAno ? 'on' : ''}" data-ano="1">Só o ${R.ano}º ano</button></div>
        <div class="rel-op rel-nao-imprime"><button class="ab ${est.aba === 'tabela' ? 'on' : ''}" data-aba="tabela">📋 Tabela</button><button class="ab ${est.aba === 'grupos' ? 'on' : ''}" data-aba="grupos">👥 Grupos de reforço</button>
          <span style="width:12px"></span>
          <button class="ab ${est.ordem === 'trilha' ? 'on' : ''}" data-ordem="trilha">Ordem da trilha</button><button class="ab ${est.ordem === 'critica' ? 'on' : ''}" data-ordem="critica">Mais críticas primeiro</button>
          <label><input type="checkbox" data-soapl="1" ${est.soAplicados ? 'checked' : ''}> só o que já foi aplicado (${R.cols.length} de ${R.total})</label></div>
        <div class="rel-op rel-nao-imprime"><span style="color:var(--muted);font-weight:800;font-size:13px">Habilidades:</span>
          ${[[0, 'Todas'], [1, '1º trimestre'], [2, '2º trimestre'], [3, '3º trimestre'], ['plano', '📌 Meu plano']].map(([v, t]) => `<button class="ab ${String(est.tri) === String(v) ? 'on' : ''}" data-tri="${v}" ${v && v !== 'plano' ? `title="Currículo ES 2026 · ${anoT}º ano · ${v}º trimestre: ${esc(codigosDe(v).join(', '))}"` : ''}>${t}</button>`).join('')}
          ${est.tri === 'plano' ? '<button class="ab" data-editplano="1">✏️ editar meu plano</button>' : ''}</div>
        ${est.tri && R.semJogo && R.semJogo.length ? `<div class="rel-leg">ℹ️ Sem atividade no jogo (não entram no relatório): ${esc(R.semJogo.join(', '))}</div>` : ''}
        <div class="rel-leg"><b style="background:#166534;color:#fff">C</b> consolidado (verificado no jogo) · <b style="background:#3f6212;color:#ecfccb">C*</b> consolidado presumido pelo diagnóstico · <b style="background:#92400e;color:#fff">NC</b> não consolidado · <b style="background:#1e293b;color:#94a3b8">NA</b> não aplicado
          &nbsp;·&nbsp; Turma: <b>${Math.round((soma('c') + soma('cp')) / tot * 100)}%</b> C/C* · <b>${Math.round(soma('nc') / tot * 100)}%</b> NC · <b>${Math.round(soma('na') / tot * 100)}%</b> NA</div>
        ${est.aba === 'grupos' ? gruposHTML(R) : R.cols.length && R.linhas.length ? `<div class="rel-wrap"><table class="rel-tab"><thead><tr><th class="nm">Aluno</th><th>C</th><th>C*</th><th>NC</th><th>NA</th>${R.cols.map(c => `<th title="${esc(c.sub || '')}">${esc(c.cab)}<small>${esc(c.sub || '')}</small></th>`).join('')}</tr></thead>
          <tbody>${R.linhas.map(l => `<tr><td class="nm">${esc(l.nome)}</td><td class="tot">${l.c}</td><td class="tot">${l.cp}</td><td class="tot">${l.nc}</td><td class="tot">${l.na}</td>${l.vals.map(v => `<td class="${cls(v)}">${v}</td>`).join('')}</tr>`).join('')}</tbody>
          <tfoot><tr><td class="nm">Turma</td><td class="tot" colspan="4"></td>${R.cols.map(c => `<td style="background:rgba(146,64,14,${(c.pnc / 100 * 0.9 + 0.05).toFixed(2)})" title="${c.st.c} C · ${c.st.cp} C* · ${c.st.nc} NC · ${c.st.na} NA">${c.pc}% C<span>${c.pnc}% NC</span></td>`).join('')}</tr></tfoot></table></div>`
          : '<div class="rel-leg" style="padding:20px">Sem alunos ou sem atividades para mostrar.</div>'}`;
    };
    box.onclick = e => {
      const t = e.target;
      if(t.closest('[data-fechar]')){ box.remove(); return; }
      const v = t.closest('[data-visao]'); if(v){ est.visao = v.dataset.visao; desenha(); return; }
      const a = t.closest('[data-ano]'); if(a){ est.soAno = a.dataset.ano === '1'; desenha(); return; }
      const ab = t.closest('[data-aba]'); if(ab){ est.aba = ab.dataset.aba; desenha(); return; }
      const o = t.closest('[data-ordem]'); if(o){ est.ordem = o.dataset.ordem; desenha(); return; }
      const tr = t.closest('[data-tri]');
      if(tr){
        const v = tr.dataset.tri === 'plano' ? 'plano' : +tr.dataset.tri;
        if(v === 'plano' && !(estado.turma.planoCodigos || []).length){ if(!editarPlano()) return; }
        est.tri = v; est.codigos = codigosDe(v); desenha(); return;
      }
      if(t.closest('[data-editplano]')){ if(editarPlano()){ est.codigos = codigosDe('plano'); desenha(); } return; }
      if(t.closest('[data-soapl]')){ est.soAplicados = t.closest('[data-soapl]').checked; desenha(); return; }
      if(t.closest('[data-imprimir]')){ document.body.classList.add('rel-imprimindo'); setTimeout(() => { window.print(); document.body.classList.remove('rel-imprimindo'); }, 50); return; }
      if(t.closest('[data-baixar]')) baixar(est);
    };
    desenha();
  }
  function editarPlano(){
    const atual = (estado.turma.planoCodigos || []).join(' ');
    const txt = prompt('Cole as habilidades do seu plano de ensino (os códigos, ex.: EF07MA02 EF07MA17 …).\nPode colar o texto do plano inteiro: eu pego só os códigos.', atual);
    if(txt === null) return false;
    const cods = [...new Set((txt.match(/EF0\dMA\d\d/gi) || []).map(c => c.toUpperCase()))];
    estado.turma.planoCodigos = cods; salvarTurmaLocal();
    app.toast(`📌 Meu plano: ${cods.length} habilidade(s)`, 'success');
    return true;
  }
  function gruposHTML(R){
    const G = gruposReforco(R);
    if(!G.length) return '<div class="rel-leg" style="padding:20px">Ninguém com NC nas colunas mostradas. 🎉</div>';
    return `<div class="rel-leg">Para cada ${R.cols[0] && R.cols[0].degs.length === 1 ? 'atividade' : 'habilidade'} com alunos em NC: quem precisa de reforço e o erro mais comum de cada um. Das mais urgentes (mais alunos) para as menos.</div>
      <div class="rg-grade">${G.map(g => `<div class="rg-card"><h4>${esc(g.c.cab)} · ${g.quem.length} aluno${g.quem.length === 1 ? '' : 's'}</h4><div class="rg-sub">${esc(g.c.sub || '')} · turma: ${g.c.pc}% C · ${g.c.pnc}% NC</div>
        <ul style="margin:0;padding-left:18px">${g.quem.map(q => `<li>${esc(q.nome)}${q.erro ? ` <small>❌ ${esc(q.erro)}${q.n > 1 ? ` (${q.n}×)` : ''}</small>` : ''}</li>`).join('')}</ul></div>`).join('')}</div>`;
  }
  function baixar(est){
    const R = relatorioTurma(est.visao, est.soAno, est);
    const q = s => { s = String(s == null ? '' : s); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const linhas = [];
    linhas.push([`Turma ${estado.turma.nome || ''} · ${R.ano}º ano · ${new Date().toLocaleDateString('pt-BR')}${est.tri ? ' · ' + (est.tri === 'plano' ? 'meu plano' : est.tri + 'º trimestre (currículo ES)') : ''}`].map(q).join(';'));
    linhas.push(['Aluno', 'C', 'C*', 'NC', 'NA', ...R.cols.map(c => c.cab)].map(q).join(';'));
    linhas.push(['', '', '', '', '', ...R.cols.map(c => c.sub || '')].map(q).join(';'));
    R.linhas.forEach(l => linhas.push([l.nome, l.c, l.cp, l.nc, l.na, ...l.vals].map(q).join(';')));
    linhas.push(['Turma: % C+C*', '', '', '', '', ...R.cols.map(c => c.pc + '%')].map(q).join(';'));
    linhas.push(['Turma: % NC', '', '', '', '', ...R.cols.map(c => c.pnc + '%')].map(q).join(';'));
    linhas.push(['Turma: % NA', '', '', '', '', ...R.cols.map(c => c.pna + '%')].map(q).join(';'));
    linhas.push('');
    linhas.push(q('C = consolidado (verificado no jogo) · C* = consolidado presumido pelo diagnóstico · NC = não consolidado · NA = não aplicado'));
    const blob = new Blob(['﻿' + linhas.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    const nm = (estado.turma.nome || 'turma').replace(/[^\w\-]+/g, '_');
    a.href = url; a.download = `relatorio-${nm}-${{ atividade: 'atividades', bncc: 'bncc', descritor: 'paebes' }[est.visao]}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
    app.toast('⬇️ Planilha baixada', 'success');
  }
  estado.abrirRelatorio = abrir;
  /* gaveta (sala aberta): ⋯ do aluno → 🔎 Refazer diagnóstico */
  const abrirMenuAluno0 = abrirMenuAluno;
  abrirMenuAluno = function(pid){
    const r = abrirMenuAluno0.apply(this, arguments);
    const jan = document.querySelector('#acMenu .ac-janela'), p = app.host.players.find(x => x.id === pid);
    if(jan && p && estado.refazerDiagnostico && (estado.turma.alunos || {})[normNome(p.name)]){
      const b = document.createElement('button'); b.className = 'ghost'; b.textContent = '🔎 Refazer diagnóstico';
      b.onclick = e => { e.stopPropagation(); const m = $('acMenu'); if(m) m.remove();
        if(confirm(`Refazer o diagnóstico de ${p.name}?\nEle responde algumas perguntas agora para achar o degrau certo. O que conquistou jogando continua.`)){ estado.refazerDiagnostico(normNome(p.name)); app.toast(`🔎 ${esc(p.name)} vai refazer o diagnóstico`, 'info'); } };
      const ref = jan.querySelector('[data-a="ficha"]'); if(ref) ref.after(b); else jan.appendChild(b);
    }
    return r;
  };
  /* botão no ✏️ Editar turma */
  setInterval(() => {
    const topo = document.querySelector('#teBox .te-topo'); if(!topo || $('teRelBt')) return;
    const b = document.createElement('button'); b.id = 'teRelBt'; b.className = 'ghost'; b.textContent = '📊 Relatório C/NC/NA';
    b.style.cssText = 'width:auto;padding:8px 12px';
    b.onclick = e => { e.stopPropagation(); abrir(); };
    const pronto = topo.querySelector('[data-tfecha]'); if(pronto) pronto.before(b); else topo.appendChild(b);
  }, 400);
})();
