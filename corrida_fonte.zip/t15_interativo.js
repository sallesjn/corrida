
/* =========================================================================
   PERGUNTAS DE ARRASTAR (acrescentado) — por enquanto: "Abra o ângulo".
   Quando a pergunta tem q.interativo, o celular esconde as 4 alternativas e
   mostra a peça: o aluno arrasta a bolinha vermelha (ou usa os botões −5 −1
   +1 +5) e toca em "Confirmar". A conferência escolhe a alternativa certa ou
   uma errada e chama o localAnswer original — pontos, trilha, ajudas e
   relatório funcionam como em qualquer outra pergunta.
   Funções originais intactas: só embrulho em renderPlayerQuestion.
========================================================================= */
function alternativaDoAngulo(q, g){
  if(confereAbertura(q.meta, g)) return q.correct;
  const erradas = q.options.map((o, i) => i).filter(i => i !== q.correct);
  if(q.meta.graus){                                        // a errada mais perto do que ele abriu
    return erradas.sort((a, b) => Math.abs(parseInt(q.options[a], 10) - g) - Math.abs(parseInt(q.options[b], 10) - g))[0];
  }
  const tipo = g >= 180 - ABRE_TOL ? 'raso' : Math.abs(g - 90) <= ABRE_TOL ? 'reto' : g < 90 ? 'agudo' : 'obtuso';
  const i = q.options.indexOf(tipo);
  return i >= 0 && i !== q.correct ? i : erradas[0];
}
function montarAbrir(q){
  const iv = q.interativo;
  const box = document.createElement('div'); box.id = 'ivBox'; box.className = 'iv-box';
  box.innerHTML = `<div class="iv-svg"></div>
    <div class="iv-bts"><button data-d="-5">−5°</button><button data-d="-1">−1°</button><button data-d="1">+1°</button><button data-d="5">+5°</button></div>
    <button class="primary iv-ok">✔ Confirmar</button>
    <div class="iv-dica">Arraste a bolinha vermelha para abrir o ângulo</div>`;
  $('ppOptions').after(box);
  let g = 0, feito = false;
  const area = box.querySelector('.iv-svg');
  const desenhar = certo => {
    const svg = abreSVG(g, iv, certo);
    area.innerHTML = svg;
  };
  desenhar();
  const angDoPonto = ev => {
    const el = area.querySelector('svg'); if(!el) return g;
    const rc = el.getBoundingClientRect(), vb = el.viewBox && el.viewBox.baseVal && el.viewBox.baseVal.width ? el.viewBox.baseVal : { width: +el.getAttribute('width'), height: +el.getAttribute('height') };
    const x = (ev.clientX - rc.left) * vb.width / rc.width, y = (ev.clientY - rc.top) * vb.height / rc.height;
    const cx = 230, cy = iv.transferidor ? 230 : 205;
    let a = Math.atan2(cy - y, x - cx) * 180 / Math.PI;
    if(a < 0) a = a < -90 ? 180 : 0;
    return Math.max(0, Math.min(180, Math.round(a)));
  };
  let arrastando = false;
  area.onpointerdown = ev => { if(feito) return; arrastando = true; try{ area.setPointerCapture(ev.pointerId); }catch(e){} g = angDoPonto(ev); desenhar(); ev.preventDefault(); };
  area.onpointermove = ev => { if(!arrastando || feito) return; g = angDoPonto(ev); desenhar(); ev.preventDefault(); };
  area.onpointerup = area.onpointercancel = () => { arrastando = false; };
  box.querySelector('.iv-bts').onclick = e => { const b = e.target.closest('button[data-d]'); if(!b || feito) return; g = Math.max(0, Math.min(180, g + +b.dataset.d)); desenhar(); };
  box.querySelector('.iv-ok').onclick = () => {
    if(feito || app.player.questionBlocked) return;
    feito = true;
    const idx = alternativaDoAngulo(q, g), certo = idx === q.correct;
    box.classList.add(certo ? 'certo' : 'errado');
    const alvo = q.meta.graus || { agudo: 45, reto: 90, obtuso: 135, raso: 180 }[q.meta.alvo];
    if(!certo) desenhar(alvo);
    box.querySelector('.iv-dica').innerHTML = certo ? `✅ Isso! Você abriu ${g}°` : `❌ Você abriu ${g}°. ${q.meta.graus ? 'O certo era ' + q.meta.graus + '° (linha verde).' : 'Um ângulo ' + q.meta.alvo + ' seria como a linha verde.'}`;
    box.querySelectorAll('button').forEach(b => b.disabled = true);
    app.localAnswer(idx);
  };
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .iv-box{background:var(--panel);border:2px solid var(--line);border-radius:16px;padding:10px;text-align:center;margin-top:10px}
  .iv-svg{background:#fff;border-radius:12px;touch-action:none;user-select:none;cursor:pointer}
  .iv-svg svg{width:100%;height:auto;max-height:44vh;display:block;margin:0 auto}
  .iv-bts{display:flex;gap:8px;justify-content:center;margin-top:8px}
  .iv-bts button{width:auto;min-width:64px;padding:10px 12px;font-size:18px;font-weight:900;border-radius:12px;background:var(--panel2);border:2px solid var(--line);color:var(--text)}
  .iv-ok{margin-top:8px;width:100%;font-size:20px;padding:14px}
  .iv-dica{margin-top:6px;font-weight:800;color:var(--muted)}
  .iv-box.certo{border-color:#16a34a;background:rgba(34,197,94,.1)}
  .iv-box.errado{border-color:#dc2626;background:rgba(239,68,68,.08)}`;
  document.head.appendChild(st);
  const renderPlayerQuestion0 = app.renderPlayerQuestion;
  app.renderPlayerQuestion = function(q){
    const r = renderPlayerQuestion0.apply(this, arguments);
    const velho = $('ivBox'); if(velho) velho.remove();
    const opts = $('ppOptions');
    if(q && q.interativo && q.interativo.tipo === 'abrir'){
      opts.style.display = 'none';
      $('ppQImage').classList.add('hidden');                // a figura vira a peça de arrastar
      try{ montarAbrir(q); }catch(e){ console.warn('[interativo]', e); opts.style.display = ''; }
    } else opts.style.display = '';
    return r;
  };
})();
