
/* =========================================================================
   GAVETA DOS ALUNOS NA CORRIDA + DESAFIOS (acrescentado)
   · O botão "👥 Alunos" abre uma GAVETA do lado direito (não cobre a pista):
     nome (toque = pedir troca de nome, como no treino), situação, acertos
     recentes, desafios, ⋯ (plano, ficha, últimas questões) e ✕ remover.
     Toque de novo no botão para recolher.
   · DESAFIO: quem está indo bem (acerta X% das últimas 10) recebe, de vez em
     quando, uma questão mais adiantada na trilha (3 a 12 degraus à frente).
     Errar o desafio não atrapalha: não conta para o apoio nem para o degrau.
     O professor escolhe no cartão da Trilha: Não · 70% · 80% (padrão).
   Funções originais intactas: só embrulhos (escolherFonte, registrar,
   extrasPergunta, app.pub, playerReceiveState, getNextQuestion, montarCartao).
========================================================================= */
const DESAFIO = { espaco: 7, chance: 0.35, ini: 3, fim: 12 };
if(estado.cfg.desafio === undefined) estado.cfg.desafio = 0.8;

/* motor: de vez em quando, um desafio para quem está indo bem */
const escolherFonteSemDesafio = escolherFonte;
escolherFonte = function(rec, sorte){
  const f = escolherFonteSemDesafio(rec, sorte);
  const lim = estado.desafioAluno;
  if(!lim || !rec || !rec.atual || rec.apoio || rec.plano || (rec.diag && typeof rec.diag === 'object') || f.tipo === 'diag' || f.tipo === 'foco') return f;
  const u = rec.ultOk || []; if(u.length < 8 || u.reduce((a, b) => a + b, 0) / u.length < lim) return f;
  if((rec.resp || 0) - (rec.desUlt || -99) < DESAFIO.espaco || Math.random() >= DESAFIO.chance) return f;
  const at = POR_ID[rec.atual]; if(!at) return f;
  const cands = CAT.slice(at.i + DESAFIO.ini, at.i + DESAFIO.fim + 1).filter(d => ativo(d) && !(rec.deg[d.id] && rec.deg[d.id].dom));
  if(!cands.length) return f;
  return { tipo: 'desafio', id: pick(cands).id, nivel: 2 };
};
const registrarSemDesafio = registrar;
registrar = function(rec, fonte, q, idx, ok, frac){
  if(!fonte || fonte.tipo !== 'desafio') return registrarSemDesafio.apply(this, arguments);
  const ult = (rec.ultOk || []).slice(), apoio = rec.apoio ? JSON.parse(JSON.stringify(rec.apoio)) : null;
  const ev = registrarSemDesafio.call(this, rec, Object.assign({}, fonte, { tipo: 'previa' }), q, idx, ok, frac);
  rec.ultOk = ult; rec.apoio = apoio;                         // o desafio não pesa no apoio
  const ds = rec.desafios || (rec.desafios = { ok: 0, tot: 0 }); ds.tot++; if(ok) ds.ok++;
  rec.desUlt = rec.resp || 0;
  if(ev) ev.desafio = ok ? 'venceu' : 'tentou';
  try{ if(typeof document !== 'undefined' && app.mode !== 'teacher') aviso(ok ? '⭐ Desafio vencido!<br>Você já sabe coisa lá da frente!' : '⭐ Era um desafio de mais à frente.<br>Boa tentativa!', 2200); }catch(e){}
  return ev;
};

/* gaveta do professor */
function gavetaHTML(){
  const ps = app.host.players.filter(p => !p.isBot).map(p => ({ p, s: situacaoAluno(p), r: estado.turma.alunos[normNome(p.name)] }));
  ps.sort((a, b) => a.s.ordem - b.s.ordem || a.p.name.localeCompare(b.p.name, 'pt-BR'));
  const cont = k => ps.filter(x => x.s.st === k).length;
  const ap = ps.filter(x => ehApelido(x.p));
  return `<div class="gv-topo"><b>👥 Alunos (${ps.length})</b><span>🔴 ${cont('erro')} · 🎲 ${cont('chute')} · 🟡 ${cont('parado')} · 📡 ${cont('off')} · 🟢 ${cont('ok')}</span></div>
    <div class="gv-dica">Toque no nome para pedir a troca. ⋯ abre mais opções.</div>
    ${ap.length ? `<button class="primary gv-todos" data-trocatodos="1">✏️ Trocar nome dos ${ap.length} fora da lista</button>` : ''}
    <div class="gv-lista">${ps.map(({ p, s, r }) => { const ds = r && r.desafios; return `<div class="gv-lin ${s.st}">
      <button class="gv-nome" data-troca="${esc(p.id)}" title="Pedir para trocar o nome">${esc(p.name)}${p._trocando ? ' ✏️…' : ''}${ehApelido(p) ? ' ⚠️' : ''}</button>
      <span class="gv-st">${s.txt}</span>
      <span class="gv-num">${s.n10 ? `${s.ac10}/${s.n10}` : '—'}${ds && ds.tot ? ` · ⭐${ds.ok}/${ds.tot}` : ''}${r && r.med && Object.keys(r.med.g || {}).length ? ` · 🏅${Object.keys(r.med.g).length}` : ''}</span>
      <button class="gv-mais" data-aluno="${esc(p.id)}" title="Plano, ficha, últimas questões">⋯</button>
      <button class="gv-rem" data-rem="${esc(p.id)}" title="Remover da sala">✕</button></div>`; }).join('') || '<div style="color:var(--muted);padding:10px">Ninguém na sala ainda.</div>'}</div>`;
}
function gaveta(abrir){
  let g = $('gvBox');
  if(abrir === false || (abrir === undefined && g)){ if(g) g.remove(); clearInterval(estado.gvT); document.body.classList.remove('gv-aberta'); return; }
  document.body.classList.add('gv-aberta');
  if(!g){
    g = document.createElement('div'); g.id = 'gvBox'; document.body.appendChild(g);
    g.onclick = e => {
      const t = e.target;
      if(t.closest('[data-fechar]')){ gaveta(false); return; }
      if(t.closest('[data-trocatodos]')){ const ap = app.host.players.filter(p => !p.isBot && ehApelido(p) && !p._trocando); if(ap.length && confirm(`Pedir para ${ap.length} aluno(s) trocar o nome?`)){ ap.forEach(p => { p._trocando = true; enviarPedidoNome(p, 'Use o seu nome de verdade (toque nele na lista).'); }); } desenha(); return; }
      const tn = t.closest('[data-troca]'); if(tn){ pedirTrocaNome(tn.dataset.troca); desenha(); return; }
      const rm = t.closest('[data-rem]'); if(rm){ const p = app.host.players.find(x => x.id === rm.dataset.rem); if(p && confirm(`Remover ${p.name} da sala?`)){ app.kickPlayer(p.id); } desenha(); return; }
      const al = t.closest('[data-aluno]'); if(al) abrirMenuAluno(al.dataset.aluno);
    };
  }
  const desenha = () => { const b = $('gvBox'); if(b) b.innerHTML = `<button class="gv-x" data-fechar="1" title="Recolher">▸</button>` + gavetaHTML(); };
  desenha();
  clearInterval(estado.gvT); estado.gvT = setInterval(() => { if(!$('gvBox')) return clearInterval(estado.gvT); desenha(); }, 3000);
}

if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  body.gv-aberta #hostGame{padding-right:calc(min(360px,40vw) + 22px)}
  body.gv-aberta #hostGame .hg-rank{display:none}
  #hostGame .hg-rank{width:min(300px,24vw)}
  #hPlayers .race-lane{grid-template-columns:minmax(110px,190px) minmax(170px,1fr) minmax(60px,90px) minmax(56px,80px)}
  #gvBox{position:fixed;top:70px;right:10px;max-height:calc(100vh - 140px);width:min(360px,40vw);z-index:440;background:rgba(15,23,42,.97);border:2px solid #3b82f6;border-radius:16px;padding:10px 12px;overflow:auto;box-shadow:0 10px 40px rgba(0,0,0,.6)}
  .gv-x{position:absolute;top:8px;right:8px;width:auto;padding:4px 10px;font-size:18px;background:var(--panel2);border:1px solid var(--line);color:var(--text);border-radius:8px}
  .gv-topo{display:flex;flex-direction:column;gap:2px;padding-right:40px}.gv-topo span{color:var(--muted);font-size:13px}
  .gv-dica{color:var(--muted);font-size:12px;margin:4px 0 8px}
  .gv-todos{width:100%;margin-bottom:8px;padding:8px;font-size:14px}
  .gv-lista{display:flex;flex-direction:column;gap:6px}
  .gv-lin{display:grid;grid-template-columns:1fr auto auto auto;grid-template-areas:"nome num mais rem" "st st st st";gap:2px 6px;align-items:center;background:var(--panel2);border:2px solid var(--line);border-left-width:6px;border-radius:10px;padding:6px 8px}
  .gv-lin.erro,.gv-lin.chute{border-left-color:#ef4444}.gv-lin.parado{border-left-color:#f59e0b}.gv-lin.off{border-left-color:#64748b}.gv-lin.ok{border-left-color:#22c55e}
  .gv-nome{grid-area:nome;text-align:left;background:none;border:none;color:var(--text);font-weight:900;font-size:16px;padding:2px 0;width:auto;cursor:pointer;text-decoration:underline dotted #64748b}
  .gv-st{grid-area:st;color:var(--muted);font-size:12px}.gv-num{grid-area:num;font-size:12px;font-weight:800;color:#cbd5e1}
  .gv-mais,.gv-rem{width:auto;padding:2px 9px;font-size:15px;background:transparent;border:1px solid var(--line);border-radius:8px;color:var(--text)}
  .gv-mais{grid-area:mais}.gv-rem{grid-area:rem;color:#fca5a5}
  .tr-info.desafio{background:linear-gradient(90deg,#f59e0b,#fbbf24);color:#1a1300!important;border-radius:999px;padding:3px 12px;font-weight:900}
  .tr-info.desafio b,.tr-info.desafio{color:#1a1300!important}
  #ppQuestionCard.desafio{box-shadow:0 0 0 3px #fbbf24,0 0 26px rgba(251,191,36,.5)}`;
  document.head.appendChild(st);

  // o botão 👥 passa a abrir/recolher a gaveta
  const bt = $('ctBtn'); if(bt) bt.onclick = () => gaveta();
  document.addEventListener('keydown', e => { if(e.key === 'Escape' && $('gvBox') && !$('acMenu')) gaveta(false); });
  setInterval(() => { const b = $('ctBtn'); if($('gvBox') && b && b.classList.contains('hidden')) gaveta(false); }, 1500);   // saiu da partida: recolhe

  // cartão da Trilha: escolher os desafios
  const ajusta = () => {
    const ref = $('trRev'); if(!ref || $('trDesafio')) return;
    const c = estado.cfg, div = document.createElement('div'); div.style.marginTop = '12px';
    div.innerHTML = `<label>⭐ Desafios (questão mais adiantada para quem está indo bem)</label>${segHTML('trDesafio', [['0', 'Não'], ['0.7', 'Quem acerta 70%'], ['0.8', 'Quem acerta 80%']], String(c.desafio || 0))}
      <div style="color:var(--muted);font-size:12px;margin-top:4px">Mais ou menos 1 a cada 10 perguntas, de 3 a 12 degraus à frente. Errar o desafio não atrapalha o aluno.</div>`;
    ref.parentElement.after(div);
    $('trDesafio').onclick = e => { const b = e.target.closest('button[data-v]'); if(!b) return; [...$('trDesafio').children].forEach(x => x.classList.toggle('on', x === b)); c.desafio = +b.dataset.v; salvarCfg(); };
  };
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); ajusta(); return r; };
  ajusta();

  // professor → aluno: o limite de desafio vai junto com o estado da sala
  const pub0 = app.pub;
  app.pub = function(topic, obj, retain){
    if(this.mode === 'teacher' && obj && obj.type === 'state' && /\/tostate$/.test(topic)) obj = Object.assign({}, obj, { desafio: estado.cfg.on ? +(estado.cfg.desafio || 0) : 0 });
    return pub0.call(this, topic, obj, retain);
  };
  const playerReceiveState0 = app.playerReceiveState;
  app.playerReceiveState = function(state){ estado.desafioSala = state && state.desafio ? +state.desafio : 0; return playerReceiveState0.apply(this, arguments); };
  const getNextQuestion0 = app.getNextQuestion;
  app.getNextQuestion = function(){
    estado.desafioAluno = this.mode !== 'teacher' ? estado.desafioSala : 0;
    try{ return getNextQuestion0.apply(this, arguments); } finally { estado.desafioAluno = 0; }
  };
  // aluno: rótulo dourado no desafio
  const extras0 = extrasPergunta;
  extrasPergunta = function(q){
    const r = extras0.apply(this, arguments);
    const card = $('ppQuestionCard'), info = $('ppTrilhaInfo');
    const des = q && q.fonte && q.fonte.tipo === 'desafio';
    if(card) card.classList.toggle('desafio', !!des);
    if(info){ info.classList.toggle('desafio', !!des); if(des) info.innerHTML = info.innerHTML.replace(/^🧗 /, '⭐ <b>DESAFIO</b> · '); }
    return r;
  };
})();
