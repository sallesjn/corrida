
/* =========================================================================
   GERADORES COM FIGURA — 3º ao 6º ano
========================================================================= */
const fmtR = c => 'R$ ' + Math.floor(c / 100) + ',' + String(c % 100).padStart(2, '0');   // centavos → "R$ 7,35"


/* alternativas de fração: as 4 com VALORES diferentes (1/2 e 2/4 nunca juntas) e nenhuma igual à certa */
function altFrac(certa, erradas, d){
  const v = f => { const [a, b] = String(f).split('/').map(Number); return a / b; };
  const itens = [{ v: certa, erro: null }], vals = [v(certa)];
  const add = e => { if(itens.length >= 4 || !e) return; const [a, b] = String(e.v).split('/').map(Number);
    if(!(a > 0 && b > 0 && Number.isInteger(a) && Number.isInteger(b))) return; const x = a / b; if(vals.some(y => Math.abs(y - x) < 1e-9)) return; vals.push(x); itens.push({ v: `${a}/${b}`, erro: e.erro || 'outro valor' }); };
  shuffle(erradas.filter(Boolean)).forEach(add);
  for(let k = 1; itens.length < 4 && k < d * 3; k++) add({ v: `${k}/${d}`, erro: 'contou errado' });
  for(let k = 1; itens.length < 4 && k < 40; k++) add({ v: `${k}/${d + k}`, erro: 'outro valor' });
  const sh = shuffle(itens);
  return { options: sh.map(i => i.v), correct: sh.findIndex(i => i.erro === null), erros: sh.map(i => i.erro), answer: certa };
}

/* ---------- desenhos extras ---------- */
// dá 30 px de folga dos lados para o último número (ex.: 1000) não ser cortado
const retaFolga = svg => svg.replace(/viewBox="0 0 (\d+(?:\.\d+)?) (\d+(?:\.\d+)?)" width="(\d+(?:\.\d+)?)"/, (m, w, h) => `viewBox="-30 0 ${+w + 60} ${h}" width="${+w + 60}"`).replace('<rect width=', '<rect x="-30" width=').replace(/(<rect x="-30" width=")(\d+(?:\.\d+)?)/, (m, a, w) => a + (+w + 60));
function abacoSVG(dig){          // dig = [UM, C, D, U] (null = pino ausente)
  const rot = ['UM', 'C', 'D', 'U'], cores = ['#8b5cf6', '#ef4444', '#3b82f6', '#22c55e'];
  let o = `<rect x="10" y="228" width="380" height="26" rx="6" fill="#92400e"/>`;
  dig.forEach((n, i) => {
    const x = 60 + i * 93;
    o += `<rect x="${x - 4}" y="40" width="8" height="190" fill="#78716c"/>` + T(x, 278, rot[i], { fs: 22 });
    for(let k = 0; k < n; k++) o += `<ellipse cx="${x}" cy="${216 - k * 19}" rx="30" ry="9.5" fill="${cores[i]}" stroke="#111" stroke-width="2"/>`;
  });
  return SVG(400, 290, o);
}
function pontosSVG(r, c, cor = '#ef4444'){
  const s = Math.min(40, Math.floor(420 / c)), W = c * s + 20, H = r * s + 20;
  let o = '';
  for(let i = 0; i < r; i++) for(let j = 0; j < c; j++) o += `<circle cx="${10 + s / 2 + j * s}" cy="${10 + s / 2 + i * s}" r="${s * .34}" fill="${cor}" stroke="#111" stroke-width="1.5"/>`;
  return SVG(W, H, o);
}
function pratosSVG(n, k, tipo){
  let o = '';
  const g = grupoIcones(tipo, n, 10, 10, 36, 10);
  o += g.svg;
  const y0 = g.h + 40, pw = Math.min(130, Math.floor(560 / k));
  for(let i = 0; i < k; i++){ const cx = 10 + pw / 2 + i * pw; o += `<ellipse cx="${cx}" cy="${y0 + 30}" rx="${pw * .42}" ry="24" fill="#e0f2fe" stroke="#0369a1" stroke-width="3"/><ellipse cx="${cx}" cy="${y0 + 26}" rx="${pw * .28}" ry="13" fill="#bae6fd"/>`; }
  return SVG(Math.max(g.w + 20, k * pw + 20), y0 + 66, o);
}
function fracaoFigura(forma, d, pint, cor = '#f59e0b'){   // pint = índices pintados
  let o = '';
  if(forma === 'pizza'){
    const cx = 110, cy = 110, R = 95;
    for(let i = 0; i < d; i++){
      const a0 = (-90 + 360 / d * i) * Math.PI / 180, a1 = (-90 + 360 / d * (i + 1)) * Math.PI / 180;
      o += d === 1 ? `<circle cx="${cx}" cy="${cy}" r="${R}" fill="${pint.includes(i) ? cor : '#fff'}" stroke="#111" stroke-width="3"/>`
        : `<path d="M${cx} ${cy} L${(cx + R * Math.cos(a0)).toFixed(1)} ${(cy + R * Math.sin(a0)).toFixed(1)} A${R} ${R} 0 ${360 / d > 180 ? 1 : 0} 1 ${(cx + R * Math.cos(a1)).toFixed(1)} ${(cy + R * Math.sin(a1)).toFixed(1)} Z" fill="${pint.includes(i) ? cor : '#fff'}" stroke="#111" stroke-width="3" stroke-linejoin="round"/>`;
    }
    return SVG(220, 220, o);
  }
  if(forma === 'barra'){
    const w = Math.min(70, Math.floor(480 / d));
    for(let i = 0; i < d; i++) o += `<rect x="${10 + i * w}" y="10" width="${w}" height="70" fill="${pint.includes(i) ? cor : '#fff'}" stroke="#111" stroke-width="3"/>`;
    return SVG(d * w + 20, 90, o);
  }
  // retângulo em 2 linhas
  const cols = d / 2, w = Math.min(64, Math.floor(420 / cols));
  for(let i = 0; i < d; i++){ const c = i % cols, l = Math.floor(i / cols); o += `<rect x="${10 + c * w}" y="${10 + l * w}" width="${w}" height="${w}" fill="${pint.includes(i) ? cor : '#fff'}" stroke="#111" stroke-width="3"/>`; }
  return SVG(cols * w + 20, 2 * w + 20, o);
}
function relogioG(h, m, cx, cy, R){
  let o = `<circle cx="${cx}" cy="${cy}" r="${R}" fill="#fff" stroke="#111" stroke-width="5"/>`;
  for(let i = 0; i < 60; i++){ const a = i * 6 * Math.PI / 180, g = i % 5 === 0; o += `<line x1="${cx + (R - (g ? 12 : 6)) * Math.sin(a)}" y1="${cy - (R - (g ? 12 : 6)) * Math.cos(a)}" x2="${cx + (R - 2) * Math.sin(a)}" y2="${cy - (R - 2) * Math.cos(a)}" stroke="#111" stroke-width="${g ? 3 : 1.2}"/>`; }
  for(let n = 1; n <= 12; n++){ const a = n * 30 * Math.PI / 180; o += T(cx + (R - 25) * Math.sin(a), cy - (R - 25) * Math.cos(a) + 7, n, { fs: 19 }); }
  const ah = ((h % 12) * 30 + m * .5) * Math.PI / 180, am = m * 6 * Math.PI / 180;
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + R * .5 * Math.sin(ah)}" y2="${cy - R * .5 * Math.cos(ah)}" stroke="#1d4ed8" stroke-width="8" stroke-linecap="round"/>`;
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + R * .8 * Math.sin(am)}" y2="${cy - R * .8 * Math.cos(am)}" stroke="#dc2626" stroke-width="5" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="6" fill="#111"/>`;
  return o;
}
function jarraSVG(max, passo, rotulo, vol){
  const x0 = 120, yTopo = 30, yBase = 290, alt = yBase - yTopo, Y = v => yBase - v / max * alt;
  let o = `<rect x="${x0}" y="${Y(vol)}" width="130" height="${yBase - Y(vol)}" fill="#7dd3fc"/>`;
  o += `<path d="M${x0} ${yTopo - 10} L${x0} ${yBase} Q${x0} ${yBase + 12} ${x0 + 12} ${yBase + 12} L${x0 + 118} ${yBase + 12} Q${x0 + 130} ${yBase + 12} ${x0 + 130} ${yBase} L${x0 + 130} ${yTopo - 10}" fill="none" stroke="#111" stroke-width="4"/>`;
  o += `<path d="M${x0 + 130} ${yTopo + 30} q40 0 40 50 q0 50 -40 50" fill="none" stroke="#111" stroke-width="5"/>`;
  for(let v = passo; v <= max + 1e-9; v += passo){
    const r = Math.abs(v / rotulo - Math.round(v / rotulo)) < 1e-9;
    o += `<line x1="${x0}" y1="${Y(v)}" x2="${x0 + (r ? 34 : 18)}" y2="${Y(v)}" stroke="#111" stroke-width="${r ? 3 : 2}"/>`;
    if(r) o += T(x0 - 8, Y(v) + 7, v + ' mL', { fs: 18, anc: 'end' });
  }
  return SVG(310, 316, o);
}
/* sólidos geométricos em perspectiva simples */
function solidoSVG(tipo, tam = 150, cor = '#93c5fd'){
  const st = `fill="${cor}" stroke="#111" stroke-width="3" stroke-linejoin="round"`, tr = 'stroke="#111" stroke-width="2" stroke-dasharray="6,5" fill="none"';
  const lados = `fill="#60a5fa" stroke="#111" stroke-width="3" stroke-linejoin="round"`, topo = `fill="#bfdbfe" stroke="#111" stroke-width="3" stroke-linejoin="round"`;
  let o;
  const caixa = (w, h, d) => {       // paralelepípedo: frente w×h, profundidade d (oblíqua)
    const x = 20, y = 40 + d * .5, dx = d * .7, dy = d * .5;
    return `<polyline points="${x + dx},${y - dy} ${x + dx},${y - dy + h} ${x},${y + h}" ${tr}/><line x1="${x + dx}" y1="${y - dy + h}" x2="${x + w + dx}" y2="${y - dy + h}" ${tr}/>` +
      `<rect x="${x}" y="${y}" width="${w}" height="${h}" ${st}/><polygon points="${x},${y} ${x + dx},${y - dy} ${x + w + dx},${y - dy} ${x + w},${y}" ${topo}/>` +
      `<polygon points="${x + w},${y} ${x + w + dx},${y - dy} ${x + w + dx},${y - dy + h} ${x + w},${y + h}" ${lados}/>`;
  };
  if(tipo === 'cubo') o = caixa(90, 90, 60);
  else if(tipo === 'paralelepipedo') o = caixa(130, 70, 50);
  else if(tipo === 'piramide'){      // base quadrada
    o = `<line x1="40" y1="150" x2="80" y2="118" ${tr}/><line x1="80" y1="118" x2="150" y2="118" ${tr}/><line x1="80" y1="118" x2="95" y2="20" ${tr}/>` +
      `<polygon points="40,150 110,150 95,20" ${st}/><polygon points="110,150 150,118 95,20" ${lados}/>`;
  } else if(tipo === 'piramideTri'){
    o = `<line x1="30" y1="148" x2="130" y2="148" ${tr}/><polygon points="30,148 88,122 80,20" ${st}/><polygon points="88,122 130,148 80,20" ${lados}/>`;
  } else if(tipo === 'prismaTri'){
    o = `<polyline points="80,120 120,52 160,120" ${tr}/><line x1="80" y1="120" x2="160" y2="120" ${tr}/>` +
      `<polygon points="20,150 60,82 100,150" ${st}/><polygon points="60,82 120,52 160,120 100,150" ${lados}/><line x1="100" y1="150" x2="160" y2="120" stroke="#111" stroke-width="3"/>`;
  } else if(tipo === 'cilindro'){
    o = `<rect x="35" y="35" width="100" height="100" fill="${cor}"/><line x1="35" y1="35" x2="35" y2="135" stroke="#111" stroke-width="3"/><line x1="135" y1="35" x2="135" y2="135" stroke="#111" stroke-width="3"/>` +
      `<path d="M35 135 A50 16 0 0 0 135 135" ${st}/><path d="M35 135 A50 16 0 0 1 135 135" ${tr}/><ellipse cx="85" cy="35" rx="50" ry="16" ${topo}/>`;
  } else if(tipo === 'cone'){
    o = `<polygon points="85,15 35,130 135,130" fill="${cor}"/><line x1="85" y1="15" x2="35" y2="130" stroke="#111" stroke-width="3"/><line x1="85" y1="15" x2="135" y2="130" stroke="#111" stroke-width="3"/>` +
      `<path d="M35 130 A50 16 0 0 0 135 130" ${st}/><path d="M35 130 A50 16 0 0 1 135 130" ${tr}/>`;
  } else {                            // esfera
    o = `<circle cx="85" cy="85" r="62" ${st}/><path d="M23 85 A62 18 0 0 0 147 85" fill="none" stroke="#111" stroke-width="2"/><path d="M23 85 A62 18 0 0 1 147 85" ${tr}/><ellipse cx="62" cy="60" rx="14" ry="9" fill="#dbeafe"/>`;
  }
  return SVG(tam + 30, tam + 20, `<g transform="scale(${(tam + 20) / 180})">${o}</g>`);
}
const SOLIDO_NOME = { cubo: 'cubo', paralelepipedo: 'paralelepípedo', piramide: 'pirâmide', piramideTri: 'pirâmide de base triangular', prismaTri: 'prisma de base triangular', cilindro: 'cilindro', cone: 'cone', esfera: 'esfera' };
const POLIEDRO = { cubo: [6, 8, 12], paralelepipedo: [6, 8, 12], piramide: [5, 5, 8], piramideTri: [4, 4, 6], prismaTri: [5, 6, 9] };   // faces, vértices, arestas

function malhaSVG(celulas, L, C, cor = '#34d399', s = 34){
  const set = new Set(celulas.map(([r, c]) => r + ',' + c));
  let o = '';
  for(let r = 0; r < L; r++) for(let c = 0; c < C; c++) o += `<rect x="${10 + c * s}" y="${10 + r * s}" width="${s}" height="${s}" fill="${set.has(r + ',' + c) ? cor : '#fff'}" stroke="#94a3b8" stroke-width="1.5"/>`;
  // contorno da figura mais grosso
  celulas.forEach(([r, c]) => {
    const x = 10 + c * s, y = 10 + r * s;
    if(!set.has((r - 1) + ',' + c)) o += `<line x1="${x}" y1="${y}" x2="${x + s}" y2="${y}" stroke="#111" stroke-width="3.5"/>`;
    if(!set.has((r + 1) + ',' + c)) o += `<line x1="${x}" y1="${y + s}" x2="${x + s}" y2="${y + s}" stroke="#111" stroke-width="3.5"/>`;
    if(!set.has(r + ',' + (c - 1))) o += `<line x1="${x}" y1="${y}" x2="${x}" y2="${y + s}" stroke="#111" stroke-width="3.5"/>`;
    if(!set.has(r + ',' + (c + 1))) o += `<line x1="${x + s}" y1="${y}" x2="${x + s}" y2="${y + s}" stroke="#111" stroke-width="3.5"/>`;
  });
  return SVG(C * s + 20, L * s + 20, o);
}
function poliomino(n, L, C){      // figura conexa com n quadradinhos
  const cel = [[Math.floor(L / 2), Math.floor(C / 2)]], set = new Set([cel[0].join(',')]);
  while(cel.length < n){
    const [r, c] = pick(cel), [dr, dc] = pick([[1, 0], [-1, 0], [0, 1], [0, -1]]);
    const nr = r + dr, nc = c + dc;
    if(nr < 0 || nc < 0 || nr >= L || nc >= C || set.has(nr + ',' + nc)) continue;
    set.add(nr + ',' + nc); cel.push([nr, nc]);
  }
  return cel;
}
const perimetroCel = cel => { const s = new Set(cel.map(x => x.join(','))); let p = 0; cel.forEach(([r, c]) => [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([a, b]) => { if(!s.has((r + a) + ',' + (c + b))) p++; })); return p; };

function termometroSVG(min, max, passo, rotulo, t){
  const x = 150, y0 = 330, y1 = 30, Y = v => y0 - (v - min) / (max - min) * (y0 - y1);
  let o = `<rect x="${x - 14}" y="${y1 - 14}" width="28" height="${y0 - y1 + 30}" rx="14" fill="#fff" stroke="#111" stroke-width="3"/>`;
  o += `<rect x="${x - 7}" y="${Y(t)}" width="14" height="${y0 + 10 - Y(t)}" fill="#ef4444"/><circle cx="${x}" cy="${y0 + 30}" r="24" fill="#ef4444" stroke="#111" stroke-width="3"/>`;
  for(let v = min; v <= max + 1e-9; v += passo){
    const r = Math.abs(v / rotulo - Math.round(v / rotulo)) < 1e-9;
    o += `<line x1="${x + 16}" y1="${Y(v)}" x2="${x + (r ? 40 : 28)}" y2="${Y(v)}" stroke="#111" stroke-width="${r ? 3 : 1.5}"/>`;
    if(r) o += T(x + 46, Y(v) + 8, (v < 0 ? '−' + Math.abs(v) : v) + '°C', { fs: 24, anc: 'start' });
  }
  return SVG(290, 380, o);
}
function grade100SVG(p, cor = '#a855f7'){
  let o = '';
  for(let i = 0; i < 100; i++){ const r = Math.floor(i / 10), c = i % 10; o += `<rect x="${10 + c * 26}" y="${10 + r * 26}" width="26" height="26" fill="${i < p ? cor : '#fff'}" stroke="#475569" stroke-width="1.5"/>`; }
  return SVG(280, 280, o + `<rect x="10" y="10" width="260" height="260" fill="none" stroke="#111" stroke-width="3"/>`);
}
function blocoCubos(a, b, c){      // bloco a (largura) × b (profundidade) × c (altura), isométrico: só as 3 faces visíveis, com a grade
  const s = 34, cx = Math.cos(Math.PI / 6) * s, sy = Math.sin(Math.PI / 6) * s;
  const W = (a + b) * cx + 20, H = (a + b) * sy + c * s + 20, ox = 10 + b * cx, oy = 10 + c * s;
  const P = (i, j, k) => [ox + (i - j) * cx, oy + (i + j) * sy - k * s];
  const pts = arr => arr.map(p => p.map(n => n.toFixed(1)).join(',')).join(' ');
  const face = (q, cor) => `<polygon points="${pts(q)}" fill="${cor}" stroke="#1e3a8a" stroke-width="2.5" stroke-linejoin="round"/>`;
  const lin = (p, q) => `<line x1="${p[0].toFixed(1)}" y1="${p[1].toFixed(1)}" x2="${q[0].toFixed(1)}" y2="${q[1].toFixed(1)}" stroke="#1e3a8a" stroke-width="1.6"/>`;
  let o = face([P(0, 0, c), P(a, 0, c), P(a, b, c), P(0, b, c)], '#bfdbfe')          // topo
        + face([P(0, b, 0), P(a, b, 0), P(a, b, c), P(0, b, c)], '#60a5fa')          // frente (largura a)
        + face([P(a, 0, 0), P(a, b, 0), P(a, b, c), P(a, 0, c)], '#3b82f6');         // lado (profundidade b)
  for(let i = 1; i < a; i++){ o += lin(P(i, 0, c), P(i, b, c)) + lin(P(i, b, 0), P(i, b, c)); }
  for(let j = 1; j < b; j++){ o += lin(P(0, j, c), P(a, j, c)) + lin(P(a, j, 0), P(a, j, c)); }
  for(let k = 1; k < c; k++){ o += lin(P(0, b, k), P(a, b, k)) + lin(P(a, 0, k), P(a, b, k)); }
  o += face([P(0, 0, c), P(a, 0, c), P(a, b, c), P(0, b, c)], 'none').replace('stroke-width="2.5"', 'stroke-width="3"');
  return SVG(W, H, o);
}
function transferidorSVG(a){
  const cx = 230, cy = 230, R = 200;
  let o = `<path d="M${cx - R} ${cy} A${R} ${R} 0 0 1 ${cx + R} ${cy} Z" fill="#fef9c3" stroke="#a16207" stroke-width="3"/>`;
  for(let g = 0; g <= 180; g += 5){
    const t = g * Math.PI / 180, L = g % 10 === 0 ? 18 : 10;
    o += `<line x1="${cx + R * Math.cos(t)}" y1="${cy - R * Math.sin(t)}" x2="${cx + (R - L) * Math.cos(t)}" y2="${cy - (R - L) * Math.sin(t)}" stroke="#713f12" stroke-width="${g % 10 ? 1.2 : 2.2}"/>`;
    if(g % 10 === 0){
      o += T(cx + (R - 36) * Math.cos(t), cy - (R - 36) * Math.sin(t) + 6, g, { fs: 14 });                      // escala de dentro (0 à direita)
      o += T(cx + (R - 62) * Math.cos(t), cy - (R - 62) * Math.sin(t) + 5, 180 - g, { fs: 12, cor: '#b45309', fw: 'normal' });   // escala de fora
    }
  }
  const t = a * Math.PI / 180;
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + (R + 15)}" y2="${cy}" stroke="#dc2626" stroke-width="5"/>`;
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + (R + 15) * Math.cos(t)}" y2="${cy - (R + 15) * Math.sin(t)}" stroke="#dc2626" stroke-width="5"/>`;
  o += `<path d="M${cx + 45} ${cy} A45 45 0 0 0 ${cx + 45 * Math.cos(t)} ${cy - 45 * Math.sin(t)}" fill="none" stroke="#2563eb" stroke-width="4"/><circle cx="${cx}" cy="${cy}" r="5" fill="#111"/>`;
  return SVG(460, 250, o);
}
function poligonoIrreg(n, cor){
  const pts = [];
  for(let i = 0; i < n; i++){ const a = (-90 + 360 / n * i + rnd(-12, 12)) * Math.PI / 180, R = 80 + rnd(-18, 12); pts.push(`${(110 + R * Math.cos(a)).toFixed(1)},${(105 + R * Math.sin(a)).toFixed(1)}`); }
  return SVG(220, 210, `<polygon points="${pts.join(' ')}" fill="${cor}" stroke="#111" stroke-width="4" stroke-linejoin="round"/>`);
}

/* ============================ 3º ANO ============================ */
G.abaco = n => {
  const d = n === 1 ? [0, rnd(1, 9), rnd(1, 9), rnd(1, 9)] : n === 2 ? [0, rnd(1, 9), rnd(0, 9), rnd(0, 9)] : [rnd(1, 9), rnd(0, 9), rnd(0, 9), rnd(0, 9)];
  if(n > 1 && !d.slice(1).includes(0)) d[rnd(2, 3)] = 0;
  const v = +d.join('');
  const semZero = +d.filter((x, i) => x || i < d.findIndex(y => y)).join('').replace(/0/g, '') || 0;
  const erradas = [{ v: +d.slice().reverse().join(''), erro: 'leu os pinos ao contrário' }, { v: d.reduce((a, b) => a + b, 0), erro: 'contou as contas' },
    { v: semZero, erro: 'esqueceu o zero do pino vazio' }, { v: v + (n === 3 ? 1000 : 100), erro: n === 3 ? 'uma unidade de milhar a mais' : 'uma centena a mais' }, { v: v + 10, erro: 'uma dezena a mais' }];
  const o = alternativas(v, erradas, String, { min: 1, max: 99999 });
  return { ...o, text: 'Que número está no ábaco?', image: svgURI(abacoSVG(d)), meta: { d }, chave: 'ab' + v };
};
C.abaco = m => String(+m.d.join(''));

G.disposicao = n => {
  const [r, c] = n === 1 ? [rnd(2, 3), rnd(2, 5)] : n === 2 ? [rnd(2, 5), rnd(3, 6)] : [rnd(3, 6), rnd(4, 9)];
  const t = r * c;
  const erradas = [{ v: r + c, erro: 'somou fileiras e colunas' }, { v: t + c, erro: 'contou uma fileira a mais' }, { v: t - c, erro: 'contou uma fileira a menos' }, { v: t + r, erro: 'contou uma coluna a mais' }, { v: t - r, erro: 'contou uma coluna a menos' }];
  const o = alternativas(t, erradas, String, { min: 1 });
  return { ...o, text: n === 3 ? `${r} fileiras de ${c}. Quantas bolinhas ao todo?` : 'Quantas bolinhas ao todo?', image: svgURI(pontosSVG(r, c, pick(['#ef4444', '#3b82f6', '#22c55e', '#f59e0b']))), meta: { r, c }, chave: `${r}x${c}` };
};
C.disposicao = m => String(m.r * m.c);

G.pratos = n => {
  const k = n === 1 ? rnd(2, 3) : n === 2 ? rnd(2, 5) : rnd(3, 6), q = rnd(2, n === 1 ? 5 : n === 2 ? 6 : 8), tot = k * q, tipo = pick(['morango', 'laranja', 'maca', 'estrela', 'bola']);
  const erradas = [{ v: tot - k, erro: 'subtraiu em vez de dividir' }, { v: k, erro: 'respondeu o número de pratos' }, { v: q + 1, erro: 'dividiu errado' }, { v: q - 1, erro: 'dividiu errado' }, { v: tot, erro: 'respondeu o total' }];
  const o = alternativas(q, erradas, String, { min: 1 });
  const nm = NOME_ICONE[tipo][1];
  return { ...o, text: `${tot} ${nm} repartid${genero(tipo) === 'm' ? 'o' : 'a'}s igualmente em ${k} pratos. Quant${genero(tipo) === 'm' ? 'o' : 'a'}s em cada prato?`,
    image: svgURI(pratosSVG(tot, k, tipo)), meta: { tot, k }, chave: `${tot}/${k}` };
};
C.pratos = m => String(m.tot / m.k);

G.reta3 = n => {
  const [min, max, passo, rot] = n === 1 ? [0, 20, 1, 5] : n === 2 ? pick([[0, 100, 5, 10], [0, 100, 10, 50]]) : pick([[0, 1000, 50, 100], [200, 500, 10, 50], [0, 1000, 100, 500]]);
  const v = sortearAte(() => min + passo * rnd(1, (max - min) / passo - 1), x => x % rot !== 0);
  const erradas = [{ v: v + passo, erro: 'contou um tracinho a mais' }, { v: v - passo, erro: 'contou um tracinho a menos' },
    { v: min + (v - min) / passo, erro: 'contou os tracinhos de 1 em 1' }, { v: v - v % rot, erro: 'leu o número marcado mais perto' }, { v: v + rot, erro: 'errou o intervalo' }];
  const o = alternativas(v, erradas, String, { min: 0, max: 2000 });
  return { ...o, text: 'Que número está no lugar da letra A?', image: svgURI(retaFolga(svgReta(min, max, passo, rot, [[v, 'A']]))), meta: { v }, chave: `r${min}.${passo}.${v}` };
};
C.reta3 = m => String(m.v);

const PARTE = { 2: 'metade', 3: 'terça parte', 4: 'quarta parte', 5: 'quinta parte', 10: 'décima parte' };
G.partes = n => {
  if(n === 3){
    const k = pick([2, 3, 4, 5]), q = rnd(2, 5), tot = k * q, tipo = pick(OBJETOS);
    const erradas = [{ v: tot - k, erro: 'tirou em vez de dividir' }, { v: k, erro: 'respondeu em quantas partes' }, { v: tot / 2 === q ? null : tot / 2, erro: 'fez a metade' }, { v: q + 1, erro: 'dividiu errado' }, { v: q * 2, erro: 'dividiu errado' }];
    const o = alternativas(q, erradas.filter(e => Number.isInteger(e.v)), String, { min: 1 });
    const g = grupoIcones(tipo, tot, 10, 10, 40, 10);
    return { ...o, text: `Quanto é a ${PARTE[k]} de ${tot}?`, image: svgURI(SVG(g.w + 20, g.h + 20, g.svg)), meta: { tot, k }, chave: `pq${tot}${k}` };
  }
  const k = pick(n === 1 ? [2, 4] : [2, 3, 4, 5, 10]);
  const forma = k === 10 || k === 5 ? 'barra' : pick(n === 1 ? ['pizza', 'barra'] : ['pizza', 'barra']);
  const pint = [rnd(0, k - 1)];
  const nomes = Object.entries(PARTE);
  const erradas = nomes.filter(([d]) => +d !== k).map(([d, nome]) => ({ v: nome, erro: +d === k - 1 ? 'contou as partes sem pintar' : +d === k + 1 || +d === k * 2 ? 'contou as partes errado' : 'confundiu as partes' }));
  const o = alternativas(PARTE[k], erradas, String);
  return { ...o, text: 'Que parte da figura está pintada?', image: svgURI(fracaoFigura(forma, k, pint, pick(['#f59e0b', '#22c55e', '#ec4899']))), meta: { k }, chave: `pt${k}${forma}${pint}` };
};
C.partes = m => m.tot ? String(m.tot / m.k) : PARTE[m.k];

const fmtDur = min => min < 60 ? `${min} min` : `${Math.floor(min / 60)} h` + (min % 60 ? ` ${min % 60} min` : '');
G.duracao = n => {
  const passo = n === 1 ? 60 : n === 2 ? 30 : 15;
  const h0 = rnd(1, 9), m0 = n === 1 ? 0 : n === 2 ? pick([0, 30]) : pick([0, 15, 30, 45]);
  const dur = passo * rnd(1, n === 1 ? 3 : 6);
  const fimMin = h0 * 60 + m0 + dur, h1 = Math.floor(fimMin / 60), m1 = fimMin % 60;
  const erradas = [{ v: dur + 30, erro: 'contou meia hora a mais' }, { v: dur - 30 > 0 ? dur - 30 : null, erro: 'contou meia hora a menos' }, { v: dur + 60, erro: 'contou uma hora a mais' },
    { v: dur - 60 > 0 ? dur - 60 : null, erro: 'contou uma hora a menos' }, { v: dur + 15, erro: 'errou os minutos' }, { v: dur - 15 > 0 ? dur - 15 : null, erro: 'errou os minutos' }];
  const o = alternativas(dur, erradas, fmtDur, { min: 15 });
  const img = SVG(520, 260, relogioG(h0, m0, 125, 125, 105) + relogioG(h1, m1, 395, 125, 105) + T(125, 254, 'COMEÇOU', { fs: 18 }) + T(395, 254, 'TERMINOU', { fs: 18 }) + T(260, 132, '→', { fs: 40 }));
  return { ...o, text: 'Quanto tempo durou?', image: svgURI(img), meta: { h0, m0, h1, m1 }, chave: `du${h0}${m0}${dur}` };
};
C.duracao = m => fmtDur((m.h1 * 60 + m.m1) - (m.h0 * 60 + m.m0));

G.jarra = n => {
  const [max, passo, rotulo] = n === 1 ? [1000, 100, 200] : n === 2 ? [500, 50, 100] : pick([[2000, 250, 500], [1000, 50, 200]]);
  const vol = sortearAte(() => passo * rnd(1, max / passo - 1), v => v % rotulo !== 0 || n === 1);
  const erradas = [{ v: vol + passo, erro: 'leu o tracinho de cima' }, { v: vol - passo, erro: 'leu o tracinho de baixo' }, { v: vol - vol % rotulo || null, erro: 'leu só o número escrito mais perto' },
    { v: vol / passo, erro: 'contou os tracinhos, não os mL' }, { v: vol + rotulo, erro: 'errou a escala' }];
  const o = alternativas(vol, erradas, v => v + ' mL', { min: 1 });
  return { ...o, text: 'Quanto líquido tem na jarra?', image: svgURI(jarraSVG(max, passo, rotulo, vol)), meta: { vol }, chave: `j${max}.${vol}` };
};
C.jarra = m => m.vol + ' mL';

G.solidos = n => {
  const pool = n === 1 ? ['cubo', 'esfera', 'cilindro', 'cone'] : n === 2 ? ['cubo', 'esfera', 'cilindro', 'cone', 'piramide', 'paralelepipedo'] : ['cubo', 'paralelepipedo', 'piramide', 'piramideTri', 'prismaTri', 'cilindro'];
  const conj = shuffle(pool).slice(0, 4), alvo = conj[0];
  const parecido = { cubo: 'paralelepipedo', paralelepipedo: 'cubo', cilindro: 'cone', cone: 'piramide', piramide: 'cone', esfera: 'cilindro', piramideTri: 'piramide', prismaTri: 'piramideTri' };
  const erradas = conj.slice(1).map(s => ({ v: SOLIDO_NOME[s], erro: s === parecido[alvo] ? `confundiu com ${SOLIDO_NOME[s]}` : `escolheu ${SOLIDO_NOME[s]}` }));
  const o = alternativas(SOLIDO_NOME[alvo], erradas, String);
  const porNome = Object.fromEntries(Object.entries(SOLIDO_NOME).map(([k, v]) => [v, k]));
  return { ...o, image: svgURI(solidoSVG(alvo, 200)), text: 'Qual é o nome deste sólido geométrico?', meta: { alvo }, chave: 'so' + alvo + n };
};
C.solidos = m => SOLIDO_NOME[m.alvo];

G.barras = n => {
  const cats = shuffle(FRUTAS).slice(0, 4), esc = n === 1 ? 5 : 10;
  const vals = sortearAte(() => cats.map(() => esc * rnd(1, 8)), v => new Set(v).size === 4);
  const img = svgURI(graficoColunas(cats, vals, esc, Math.max(...vals) + esc));
  const art = c => (genero(c) === 'm' ? 'o ' : 'a ') + NOME_ICONE[c][0];
  if(n < 3){
    const [i, j] = n === 1 ? [rnd(0, 3), -1] : sortearAte(() => [rnd(0, 3), rnd(0, 3)], ([a, b]) => vals[a] > vals[b]);
    const r = j < 0 ? vals[i] : vals[i] - vals[j];
    const erradas = j < 0 ? [{ v: vals[i] / esc, erro: 'contou as linhas, não a escala' }, { v: vals[i] + esc, erro: 'leu a linha de cima' }, { v: vals[i] - esc, erro: 'leu a linha de baixo' }, { v: vals[(i + 1) % 4], erro: 'leu outra coluna' }]
      : [{ v: vals[i] + vals[j], erro: 'somou em vez de comparar' }, { v: vals[i], erro: 'respondeu só uma coluna' }, { v: r + esc, erro: 'errou a escala' }, { v: r - esc || null, erro: 'errou a escala' }];
    const o = alternativas(r, erradas, String, { min: 1, passo: esc });
    return { ...o, text: j < 0 ? `Quantos votos teve ${art(cats[i])}?` : `Quantos votos ${art(cats[i])} teve a mais que ${art(cats[j])}?`, image: img, meta: { vals, i, j }, chave: vals.join(',') + i + j };
  }
  const tot = vals.reduce((a, b) => a + b, 0);
  const erradas = [{ v: tot - vals[0], erro: 'esqueceu uma coluna' }, { v: tot / esc, erro: 'ignorou a escala' }, { v: tot + esc, erro: 'errou a soma' }, { v: Math.max(...vals), erro: 'respondeu a maior coluna' }];
  const o = alternativas(tot, erradas, String, { min: 1, passo: esc });
  return { ...o, text: 'Quantos votos ao todo?', image: img, meta: { vals, tot: 1 }, chave: vals.join(',') + 't' };
};
C.barras = m => String(m.tot ? m.vals.reduce((a, b) => a + b, 0) : m.j < 0 ? m.vals[m.i] : m.vals[m.i] - m.vals[m.j]);

/* ============================ 4º ANO ============================ */
G.fracfig = n => {
  const d = n === 1 ? pick([3, 4, 5, 6]) : n === 2 ? pick([5, 6, 7, 8]) : pick([6, 8, 10, 12]);
  const p = sortearAte(() => rnd(1, d - 1), x => 2 * x !== d && (n > 1 || x < d));
  const forma = n === 3 ? 'ret' : 'barra';      // pizza ficou num degrau próprio
  const pint = n === 3 ? shuffle([...Array(d).keys()]).slice(0, p) : [...Array(p).keys()];
  const erradas = [{ v: `${d - p}/${d}`, erro: 'contou as partes sem pintar' }, { v: `${p}/${d - p}`, erro: 'comparou pintadas com não pintadas' }, { v: `${d}/${p}`, erro: 'inverteu numerador e denominador' },
    { v: `${p + 1}/${d}`, erro: 'contou uma parte a mais' }, { v: `${p - 1}/${d}`, erro: 'contou uma parte a menos' }];
  const val = f => { const [a, b] = f.split('/').map(Number); return a / b; };
  const certa = `${p}/${d}`;
  const o = altFrac(certa, erradas, d);
  return { ...o, text: 'Que fração da figura está pintada?', image: svgURI(fracaoFigura(forma, d, pint, pick(['#f59e0b', '#22c55e', '#ec4899', '#3b82f6']))), meta: { p, d }, chave: `ff${p}/${d}${forma}` };
};
C.fracfig = m => `${m.p}/${m.d}`;

const VALC = { n2: 200, n5: 500, n10: 1000, n20: 2000, m1: 100, m50: 50, m25: 25, m10: 10, m5: 5 };
G.centavos = n => {
  const pool = n === 1 ? ['m50', 'm25', 'm10', 'm1'] : n === 2 ? ['n2', 'n5', 'm1', 'm50', 'm25', 'm10'] : ['n2', 'n5', 'n10', 'm1', 'm50', 'm25', 'm10', 'm5'];
  const itens = sortearAte(() => [...Array(rnd(3, n === 1 ? 5 : 6))].map(() => pick(pool)), it => it.some(k => VALC[k] < 100) && new Set(it).size > 2);
  itens.sort((a, b) => VALC[b] - VALC[a]);
  const tot = itens.reduce((s, k) => s + VALC[k], 0), cent = itens.filter(k => VALC[k] < 100).reduce((s, k) => s + VALC[k], 0), reaisInt = tot - cent;
  const erradas = [{ v: reaisInt + cent * 100 > 99999 ? null : reaisInt + cent * 100, erro: 'contou centavos como reais' }, { v: tot - VALC[itens[itens.length - 1]], erro: 'esqueceu uma moeda' },
    { v: tot + 10, erro: 'errou os centavos' }, { v: tot - 10, erro: 'errou os centavos' }, { v: tot + 100, erro: 'errou os reais' }];
  const o = alternativas(tot, erradas, fmtR, { min: 1 });
  return { ...o, text: 'Quanto dinheiro tem aqui?', image: svgURI(dinheiro(itens)), meta: { itens }, chave: itens.join(',') };
};
C.centavos = m => fmtR(m.itens.reduce((s, k) => s + ({ n2: 200, n5: 500, n10: 1000, n20: 2000, m1: 100, m50: 50, m25: 25, m10: 10, m5: 5 })[k], 0));

G.areaMalha = n => {
  let cel;
  if(n === 1){ const a = rnd(2, 4), b = rnd(2, 6); cel = []; for(let r = 0; r < a; r++) for(let c = 0; c < b; c++) cel.push([r + 1, c + 1]); }
  else if(n === 2){ const a = rnd(3, 5), b = rnd(3, 6), ca = rnd(1, a - 1), cb = rnd(1, b - 1); cel = []; for(let r = 0; r < a; r++) for(let c = 0; c < b; c++) if(!(r < ca && c < cb)) cel.push([r + 1, c + 1]); }
  else cel = poliomino(rnd(8, 15), 7, 9);
  const A = cel.length, P = perimetroCel(cel);
  const erradas = [{ v: P, erro: 'contou o contorno (perímetro)' }, { v: A + 1, erro: 'contou um a mais' }, { v: A - 1, erro: 'contou um a menos' }, { v: A + 2, erro: 'contou algum duas vezes' }];
  const o = alternativas(A, erradas, v => v + ' quadradinhos', { min: 1 });
  return { ...o, text: 'Qual é a área da figura?', image: svgURI(malhaSVG(cel, 7, 9, '#34d399')), meta: { cel }, chave: cel.map(x => x.join('.')).sort().join('|') };
};
C.areaMalha = m => m.cel.length + ' quadradinhos';

G.perimMalha = n => {
  let cel;
  if(n === 1){ const a = rnd(1, 3), b = rnd(2, 5); cel = []; for(let r = 0; r < a; r++) for(let c = 0; c < b; c++) cel.push([r + 1, c + 1]); }
  else if(n === 2){ const a = rnd(3, 4), b = rnd(3, 5), ca = rnd(1, a - 1), cb = rnd(1, b - 1); cel = []; for(let r = 0; r < a; r++) for(let c = 0; c < b; c++) if(!(r < ca && c < cb)) cel.push([r + 1, c + 1]); }
  else cel = poliomino(rnd(6, 11), 7, 9);
  const P = perimetroCel(cel), A = cel.length;
  const erradas = [{ v: A, erro: 'contou os quadradinhos (área)' }, { v: P - 2, erro: 'esqueceu lados' }, { v: P + 2, erro: 'contou lados a mais' }, { v: P / 2, erro: 'contou só metade do contorno' }];
  const o = alternativas(P, erradas, v => v + ' cm', { min: 1 });
  return { ...o, text: 'Cada lado do quadradinho mede 1 cm. Qual é o perímetro da figura?', image: svgURI(malhaSVG(cel, 7, 9, '#fbbf24')), meta: { cel }, chave: cel.map(x => x.join('.')).sort().join('|') };
};
C.perimMalha = m => perimetroCel(m.cel) + ' cm';

G.simetria4 = n => {
  const L = 6, Cm = 3;                           // metade esquerda: 6 linhas × 3 colunas
  const qtd = n === 1 ? rnd(3, 5) : n === 2 ? rnd(5, 8) : rnd(7, 11);
  let cel = sortearAte(() => shuffle([...Array(L * Cm).keys()]).slice(0, qtd).map(i => [Math.floor(i / Cm), i % Cm]),
    c => { const s = new Set(c.map(x => x.join(','))); const espelhoV = c.every(([r, cc]) => s.has((L - 1 - r) + ',' + cc)); const igualEsp = c.every(([r, cc]) => s.has(r + ',' + (Cm - 1 - cc))); return !espelhoV && !igualEsp; });
  const certa = cel.map(([r, c]) => [r, Cm - 1 - c]);                 // espelhado no eixo vertical
  const copiada = cel.map(([r, c]) => [r, c]);                         // só copiou
  const cabeca = cel.map(([r, c]) => [L - 1 - r, Cm - 1 - c]);         // espelhou e virou
  const umErro = sortearAte(() => { const x = certa.map(y => y.slice()); const i = rnd(0, x.length - 1); x[i] = [rnd(0, L - 1), rnd(0, Cm - 1)]; return x; }, x => new Set(x.map(y => y.join(','))).size === x.length && x.map(y => y.join(',')).sort().join() !== certa.map(y => y.join(',')).sort().join());
  const chaveC = x => x.map(y => y.join('.')).sort().join('|');
  const figuraCompleta = (dir) => {
    let o = '';
    const s = 30;
    for(let r = 0; r < L; r++) for(let c = 0; c < Cm * 2; c++){
      const esq = c < Cm, set = esq ? cel : dir, cc = esq ? c : c - Cm;
      const on = set && set.some(([a, b]) => a === r && b === cc);
      o += `<rect x="${10 + c * s}" y="${10 + r * s}" width="${s}" height="${s}" fill="${on ? (esq ? '#6366f1' : '#f97316') : '#fff'}" stroke="#94a3b8" stroke-width="1.5"/>`;
    }
    o += `<line x1="${10 + Cm * s}" y1="2" x2="${10 + Cm * s}" y2="${18 + L * s}" stroke="#dc2626" stroke-width="4" stroke-dasharray="8,5"/>`;
    return SVG(Cm * 2 * s + 20, L * s + 20, o);
  };
  const lado = (dir) => { let o = ''; const s = 26; for(let r = 0; r < L; r++) for(let c = 0; c < Cm; c++){ const on = dir.some(([a, b]) => a === r && b === c); o += `<rect x="${6 + c * s}" y="${6 + r * s}" width="${s}" height="${s}" fill="${on ? '#f97316' : '#fff'}" stroke="#94a3b8" stroke-width="1.5"/>`; } return SVG(Cm * s + 12, L * s + 12, o); };
  const cands = [['espelhada no eixo', certa], ['só copiada, sem espelhar', copiada], ['espelhada e de cabeça para baixo', cabeca], ['com um quadradinho no lugar errado', umErro]];
  const erradas = cands.slice(1).filter(([, x]) => chaveC(x) !== chaveC(certa)).map(([t, x]) => ({ v: t, erro: t === 'só copiada, sem espelhar' ? 'copiou sem espelhar' : t.startsWith('espelhada e') ? 'espelhou e virou de cabeça para baixo' : 'errou um quadradinho' }));
  const o = alternativas('espelhada no eixo', erradas, String);
  const mapa = Object.fromEntries(cands);
  const opcoes = o.options.map(t => mapa[t]), letras = ['A', 'B', 'C', 'D'];
  // o texto da alternativa é só a letra (o nome "espelhada" entregaria a resposta)
  return { ...o, options: letras, answer: letras[o.correct], optImgs: opcoes.map(x => svgURI(lado(x))), text: 'Qual lado completa a figura simétrica em relação à linha vermelha?',
    image: svgURI(figuraCompleta(null)), meta: { cel, opcoes }, chave: chaveC(cel) };
};
C.simetria4 = m => {          // confere refazendo o espelho e procurando qual opção é igual
  const k = x => x.map(y => y.join('.')).sort().join('|'), esp = k(m.cel.map(([r, c]) => [r, 2 - c]));
  return 'ABCD'[m.opcoes.findIndex(x => k(x) === esp)];
};

G.termometro = n => {
  const [min, max, passo, rot] = n === 1 ? [0, 40, 2, 10] : n === 2 ? [0, 50, 2, 10] : [-10, 40, 1, 5];
  const t = sortearAte(() => min + passo * rnd(1, (max - min) / passo - 1), x => x % rot !== 0 && (n < 3 || x < 5 ? true : Math.random() < .5));
  const erradas = [{ v: t + passo, erro: 'leu o tracinho de cima' }, { v: t - passo, erro: 'leu o tracinho de baixo' }, { v: t - ((t % rot) + rot) % rot, erro: 'leu só o número escrito mais perto' },
    { v: min + (t - min) / passo, erro: 'contou os tracinhos, não os graus' }, { v: -t || null, erro: 'errou o sinal' }];
  const o = alternativas(t, erradas, v => (v < 0 ? '−' + Math.abs(v) : v) + ' °C', { negativo: n === 3, min: n === 3 ? -20 : 0 });
  return { ...o, text: 'Qual é a temperatura?', image: svgURI(termometroSVG(min, max, passo, rot, t)), meta: { t }, chave: `t${min}.${t}` };
};
C.termometro = m => (m.t < 0 ? '−' + Math.abs(m.t) : m.t) + ' °C';

G.faces = n => {
  const tipo = pick(Object.keys(POLIEDRO)), [F, V, A] = POLIEDRO[tipo];
  const qual = n === 1 ? 0 : n === 2 ? 1 : 2, nome = ['faces', 'vértices', 'arestas'][qual], r = [F, V, A][qual];
  const erradas = [{ v: [F, V, A][(qual + 1) % 3], erro: `contou ${['faces', 'vértices', 'arestas'][(qual + 1) % 3]}` }, { v: [F, V, A][(qual + 2) % 3], erro: `contou ${['faces', 'vértices', 'arestas'][(qual + 2) % 3]}` },
    { v: r - 1, erro: 'esqueceu uma escondida' }, { v: r - 2, erro: 'contou só as que aparecem' }, { v: r + 1, erro: 'contou uma a mais' }];
  const o = alternativas(r, erradas, String, { min: 1 });
  return { ...o, text: `Quantos(as) ${nome} tem este sólido? (${SOLIDO_NOME[tipo]})`, image: svgURI(solidoSVG(tipo, 200)), meta: { tipo, qual }, chave: tipo + qual };
};
C.faces = m => String(POLIEDRO[m.tipo][m.qual]);

/* ============================ 5º ANO ============================ */
G.fracEquiv = n => {
  const d1 = pick(n === 1 ? [2, 3, 4] : [2, 3, 4, 5]), p1 = rnd(1, d1 - 1), k = n === 1 ? 2 : rnd(2, n === 2 ? 3 : 4), d2 = d1 * k, r = p1 * k;
  // as duas barras têm o MESMO comprimento (a mesma peça), só muda o número de divisões
  const barraIgual = (y, dd, pp) => { let o = ''; for(let i = 0; i < dd; i++) o += `<rect x="${(10 + i * 480 / dd).toFixed(2)}" y="${y}" width="${(480 / dd).toFixed(2)}" height="70" fill="${i < pp ? '#22c55e' : '#fff'}" stroke="#111" stroke-width="3"/>`; return o; };
  const img = SVG(500, 190, barraIgual(10, d1, p1) + barraIgual(105, d2, 0));
  const erradas = [{ v: p1, erro: 'repetiu o número de partes de cima' }, { v: p1 + k, erro: 'somou em vez de multiplicar' }, { v: d2 - r, erro: 'contou as que ficam sem pintar' }, { v: r + 1, erro: 'uma parte a mais' }, { v: r - 1, erro: 'uma parte a menos' }];
  const o = alternativas(r, erradas, String, { min: 1, max: d2 });
  return { ...o, text: `Quantas partes da barra de baixo preciso pintar para ter a mesma fração (${p1}/${d1})?`, image: svgURI(img), meta: { p1, d1, k }, chave: `fe${p1}/${d1}x${k}` };
};
C.fracEquiv = m => String(m.p1 * m.k);

G.porcMalha = n => {
  const p = n === 1 ? 10 * rnd(1, 9) : n === 2 ? 5 * sortearAte(() => rnd(1, 19), x => x % 2) : sortearAte(() => rnd(3, 97), x => x % 5 !== 0);
  const erradas = [{ v: 100 - p, erro: 'contou os quadradinhos sem pintar' }, { v: p + 10, erro: 'contou uma fileira a mais' }, { v: p - 10, erro: 'contou uma fileira a menos' }, { v: Math.round(p / 10), erro: 'contou as fileiras, não os quadradinhos' }, { v: p + 1, erro: 'contou um a mais' }];
  const o = alternativas(p, erradas, v => v + '%', { min: 1, max: 99 });
  return { ...o, text: 'Que porcentagem do quadrado está pintada?', image: svgURI(grade100SVG(p, pick(['#a855f7', '#22c55e', '#f97316']))), meta: { p }, chave: 'pm' + p };
};
C.porcMalha = m => m.p + '%';

G.decReta = n => {
  let min, max, passo, rot, v;
  if(n === 1){ min = 0; max = 1; passo = .1; rot = 1; v = rnd(1, 9) / 10; }
  else if(n === 2){ min = rnd(1, 6); max = min + 1; passo = .1; rot = .5; v = sortearAte(() => min + rnd(1, 9) / 10, x => Math.abs(x - min - .5) > 1e-9); }
  else { const a = rnd(10, 59) / 10; min = a; max = Math.round((a + .1) * 10) / 10; passo = .01; rot = .05; v = sortearAte(() => Math.round((a + rnd(1, 9) / 100) * 100) / 100, x => Math.abs((x - a) * 100 - 5) > 1e-6); }
  v = Math.round(v * 1000) / 1000;
  const f = x => fmtDec(Math.round(x * 1000) / 1000);
  const erradas = [{ v: v + passo, erro: 'contou um tracinho a mais' }, { v: v - passo, erro: 'contou um tracinho a menos' },
    { v: n === 3 ? Math.floor(v) + (Math.round(v * 100) % 10) / 10 : v + 1, erro: n === 3 ? 'confundiu décimos com centésimos' : 'errou a parte inteira' }, { v: v + passo * 2, erro: 'contou dois tracinhos a mais' },
    { v: n === 1 ? Math.round(v * 10) : v - 1, erro: n === 1 ? 'esqueceu a vírgula' : 'errou a parte inteira' }];
  const o = opcoesDecimaisTR(v, erradas, f);
  return { ...o, text: 'Que número decimal está no lugar da letra A?', image: svgURI(retaFolga(svgReta(min, max, passo, rot, [[v, 'A']]))), meta: { v }, chave: 'dr' + v };
};
function opcoesDecimaisTR(v, erradas, f){      // alternativas decimais com erro típico (compara pelo valor)
  const itens = [{ v, erro: null }], vistos = new Set([f(v)]);
  shuffle(erradas).forEach(e => { if(itens.length < 4 && e && Number.isFinite(e.v) && e.v > 0 && !vistos.has(f(e.v)) && Math.abs(e.v - v) > 1e-9){ vistos.add(f(e.v)); itens.push({ v: e.v, erro: e.erro }); } });
  for(let k = 3; itens.length < 4; k++){ const x = v + k * .1; if(!vistos.has(f(x))){ vistos.add(f(x)); itens.push({ v: x, erro: 'outro valor' }); } }
  const sh = shuffle(itens);
  return { options: sh.map(i => f(i.v)), correct: sh.findIndex(i => i.erro === null), erros: sh.map(i => i.erro), answer: f(v) };
}
C.decReta = m => fmtDec(Math.round(m.v * 1000) / 1000);

G.plano = n => {
  const max = n === 1 ? 5 : n === 2 ? 8 : 10;
  const [x, y] = sortearAte(() => [rnd(n === 3 ? 0 : 1, max), rnd(n === 3 ? 0 : 1, max)], ([a, b]) => a !== b);
  const f = ([a, b]) => `(${a}, ${b})`;
  const erradas = [{ v: [y, x], erro: 'trocou x e y' }, { v: [x + 1, y], erro: 'errou o x' }, { v: [x, y + 1], erro: 'errou o y' }, { v: [x - 1, y], erro: 'errou o x' }, { v: [x, y - 1], erro: 'errou o y' }]
    .filter(e => e.v.every(k => k >= 0 && k <= max)).map(e => ({ v: f(e.v), erro: e.erro }));
  const o = alternativas(f([x, y]), erradas, String);
  return { ...o, text: 'Quais são as coordenadas do ponto A? (x, y)', image: svgURI(svgPlano(0, max, [[x, y, 'A', '#dc2626']], null, false)), meta: { x, y }, chave: `p${x}.${y}` };
};
C.plano = m => `(${m.x}, ${m.y})`;

G.cubinhos = n => {
  const [a, b, c] = n === 1 ? [rnd(2, 3), rnd(1, 2), rnd(1, 2)] : n === 2 ? [rnd(2, 4), rnd(2, 3), rnd(2, 3)] : [rnd(3, 5), rnd(2, 4), rnd(2, 4)];
  const V = a * b * c, visiveis = V - (a - 1) * (b - 1) * (c - 1);
  const erradas = [{ v: a * b, erro: 'contou só a camada de cima' }, { v: visiveis, erro: 'contou só os que aparecem' }, { v: a + b + c, erro: 'somou as medidas' }, { v: V + a * b, erro: 'uma camada a mais' }, { v: V - a * b, erro: 'uma camada a menos' }];
  const o = alternativas(V, erradas, v => v + ' cubinhos', { min: 1 });
  return { ...o, text: 'Quantos cubinhos formam o bloco?', image: svgURI(blocoCubos(a, b, c)), meta: { a, b, c }, chave: `${a}x${b}x${c}` };
};
C.cubinhos = m => (m.a * m.b * m.c) + ' cubinhos';

G.chance = n => {
  const cores = shuffle(CORES_BOLAS).slice(0, n === 1 ? 2 : 3);
  const qs = sortearAte(() => cores.map(() => rnd(1, n === 1 ? 7 : 5)), v => new Set(v).size === v.length);      // até 15 bolas: cabem no pote
  const bolas = shuffle(cores.flatMap(([, h], i) => Array(qs[i]).fill(h)));
  const tot = qs.reduce((a, b) => a + b, 0);
  if(n < 3){
    const mais = rnd(0, 1) === 1, iA = qs.indexOf(mais ? Math.max(...qs) : Math.min(...qs)), iO = qs.indexOf(mais ? Math.min(...qs) : Math.max(...qs));
    const extras = n === 1 ? [{ v: 'as duas cores têm a mesma chance', erro: 'achou que é igual' }] : [];
    const erradas = [...cores.map(([nm], i) => i === iA ? null : { v: nm, erro: i === iO ? (mais ? 'escolheu a que tem menos' : 'escolheu a que tem mais') : 'comparou errado' }), ...extras, { v: 'não dá para saber', erro: 'achou que não dá para saber' }];
    const o = alternativas(cores[iA][0], erradas, String);
    return { ...o, text: `Sorteando uma bola sem olhar, qual cor tem ${mais ? 'MAIS' : 'MENOS'} chance de sair?`, image: svgURI(SVG(170, 222, poteSVG(10, '', bolas))), meta: { qs, cores: cores.map(c => c[0]), mais }, chave: qs.join(',') + mais };
  }
  const i = rnd(0, cores.length - 1), k = qs[i];
  const erradas = [{ v: `${k}/${tot - k}`, erro: 'comparou com as outras cores' }, { v: `${tot - k}/${tot}`, erro: 'contou as outras cores' }, { v: `1/${cores.length}`, erro: 'pensou só no número de cores' }, { v: `${k}/${tot + 1}`, erro: 'contou o total errado' }, { v: `${tot}/${k}`, erro: 'inverteu a fração' }]
    .filter(e => { const [a, b] = e.v.split('/').map(Number); return b > 0 && Math.abs(a / b - k / tot) > 1e-9; });
  const o = altFrac(`${k}/${tot}`, erradas, tot);
  return { ...o, text: `Qual a chance de sortear uma bola ${cores[i][0]}?`, image: svgURI(SVG(170, 222, poteSVG(10, '', bolas))), meta: { qs, i }, chave: qs.join(',') + 'f' + i };
};
C.chance = m => m.i !== undefined ? `${m.qs[m.i]}/${m.qs.reduce((a, b) => a + b, 0)}` : m.cores[m.qs.indexOf(m.mais ? Math.max(...m.qs) : Math.min(...m.qs))];

G.ampliacao = n => {
  const [w, h] = n === 1 ? [rnd(1, 3), rnd(1, 3)] : n === 2 ? [rnd(1, 4), rnd(1, 3)] : [rnd(1, 3), rnd(1, 3)];
  const k = n === 3 ? pick([2, 3]) : 2;
  if(w === h && n === 1) return G.ampliacao(n);
  const cands = [[`${w * k} × ${h * k}`, w * k, h * k, null], [`${w * k} × ${h}`, w * k, h, 'aumentou só um lado'], [`${w + k} × ${h + k}`, w + k, h + k, `somou ${k} em vez de multiplicar`], [`${w * (k + 1)} × ${h * (k + 1)}`, w * (k + 1), h * (k + 1), 'ampliou demais'], [`${w} × ${h * k}`, w, h * k, 'aumentou só um lado']];
  // todas as figuras na MESMA malha e no mesmo tamanho de quadradinho, para dar para comparar
  const GW = Math.max(...cands.map(c => c[1])) + 1, GH = Math.max(...cands.map(c => c[2])) + 1;
  const ret = (ww, hh) => { const cel = []; for(let r = 0; r < hh; r++) for(let c = 0; c < ww; c++) cel.push([r + 1, c + 1]); return svgURI(malhaSVG(cel, GH + 1, GW + 1, '#60a5fa', 22)); };
  const erradas = cands.slice(1).filter(c => !(c[1] === w * k && c[2] === h * k)).map(c => ({ v: c[0], erro: c[3] }));
  const o = alternativas(cands[0][0], erradas, String);
  const mapa = Object.fromEntries(cands.map(c => [c[0], c]));
  return { ...o, optImgs: o.options.map(t => ret(mapa[t][1], mapa[t][2])), text: `Qual figura é a original ampliada ${k} vezes (lados ${k} vezes maiores)?`,
    image: ret(w, h), meta: { w, h, k }, chave: `am${w}${h}${k}` };
};
C.ampliacao = m => `${m.w * m.k} × ${m.h * m.k}`;

/* ============================ 6º ANO ============================ */
G.transferidor = n => {
  const a = n === 1 ? pick([30, 45, 60, 90, 120, 150]) : n === 2 ? 10 * rnd(1, 17) : 5 * sortearAte(() => rnd(2, 35), x => x % 2 === 1);
  const erradas = [{ v: 180 - a, erro: 'leu a escala de fora' }, { v: a + 10, erro: 'leu um tracinho grande a mais' }, { v: a - 10, erro: 'leu um tracinho grande a menos' }, { v: a + 5, erro: 'errou os tracinhos pequenos' }, { v: 90, erro: 'achou que é reto' }]
    .filter(e => e.v !== a && e.v > 0 && e.v < 180);
  const o = alternativas(a, erradas, v => v + '°', { min: 1, max: 179, passo: 5 });
  return { ...o, text: 'Quanto mede o ângulo marcado em azul?', image: svgURI(transferidorSVG(a)), meta: { a }, chave: 'tf' + a };
};
C.transferidor = m => m.a + '°';

const POLI_NOME = { 3: 'triângulo', 4: 'quadrilátero', 5: 'pentágono', 6: 'hexágono', 7: 'heptágono', 8: 'octógono', 9: 'eneágono', 10: 'decágono' };
G.poligonos = n => {
  const L = pick(n === 1 ? [3, 4, 5, 6] : n === 2 ? [4, 5, 6, 7, 8] : [5, 6, 7, 8, 9, 10]);
  const cor = pick(['#93c5fd', '#fda4af', '#86efac', '#fde68a', '#c4b5fd']);
  const img = n === 1 ? svgURI(SVG(220, 210, `<polygon points="${poligonoPts(L, 110, 105, 90)}" fill="${cor}" stroke="#111" stroke-width="4" stroke-linejoin="round"/>`)) : svgURI(poligonoIrreg(L, cor));
  const erradas = Object.entries(POLI_NOME).filter(([k]) => +k !== L).map(([k, nm]) => ({ v: nm, erro: +k === L + 1 ? 'contou um lado a mais' : +k === L - 1 ? 'contou um lado a menos' : 'confundiu os nomes' }))
    .sort((a, b) => Math.abs(+Object.keys(POLI_NOME).find(k => POLI_NOME[k] === a.v) - L) - Math.abs(+Object.keys(POLI_NOME).find(k => POLI_NOME[k] === b.v) - L)).slice(0, 4);
  const o = alternativas(POLI_NOME[L], erradas, String);
  return { ...o, text: n === 1 ? 'Qual é o nome deste polígono?' : 'Conte os lados. Qual é o nome deste polígono?', image: img, meta: { L }, chave: 'pl' + L + n };
};
C.poligonos = m => POLI_NOME[m.L];

/* ========= PIZZA (desenho inspirado em "atividade gerador de frações com pizza") ========= */
function pizzaSVG(d, pint){
  const cx = 130, cy = 130, R = 100, P = Math.PI;
  const ang = i => -P / 2 + i * 2 * P / d, pt = (a, r) => `${(cx + r * Math.cos(a)).toFixed(1)} ${(cy + r * Math.sin(a)).toFixed(1)}`;
  let o = `<circle cx="${cx}" cy="${cy}" r="${R + 14}" fill="#fff" stroke="#000" stroke-width="5"/><circle cx="${cx}" cy="${cy}" r="${R + 5}" fill="none" stroke="#444" stroke-width="3"/>`;
  for(let i = 0; i < d; i++){
    const a0 = ang(i), a1 = ang(i + 1), grande = 2 * P / d > P ? 1 : 0;
    const fatia = `M${cx} ${cy} L${pt(a0, R)} A${R} ${R} 0 ${grande} 1 ${pt(a1, R)} Z`;
    if(!pint.includes(i)){ o += `<path d="${fatia}" fill="#ddd" stroke="#bbb" stroke-width="1.5"/>`; continue; }
    o += `<path d="${fatia}" fill="#e0a81d"/><path d="M${pt(a0, R - 6)} A${R - 6} ${R - 6} 0 ${grande} 1 ${pt(a1, R - 6)}" fill="none" stroke="#c0660a" stroke-width="13"/>`;
    const meio = (a0 + a1) / 2, larg = a1 - a0;
    for(let k = 0; k < 8; k++){ const a = a0 + larg * (.15 + .7 * Math.random()), r = 22 + Math.random() * (R - 45); o += `<circle cx="${(cx + r * Math.cos(a)).toFixed(1)}" cy="${(cy + r * Math.sin(a)).toFixed(1)}" r="1.8" fill="rgba(100,60,10,.5)"/>`; }
    const rp = Math.max(7, Math.min(14, R * Math.sin(larg / 2) * .42));      // pepperoni cabe na fatia
    const nPep = d <= 6 ? 2 : 1;
    for(let k = 0; k < nPep; k++){
      const r = nPep === 1 ? R * .62 : [R * .42, R * .72][k], a = meio + (nPep === 1 ? 0 : (k ? -1 : 1) * larg * .12);
      const x = cx + r * Math.cos(a), y = cy + r * Math.sin(a);
      o += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rp.toFixed(1)}" fill="#b0301d" stroke="#801d0f" stroke-width="2.5"/><circle cx="${(x - rp * .3).toFixed(1)}" cy="${(y - rp * .25).toFixed(1)}" r="1.8" fill="rgba(255,230,190,.8)"/><circle cx="${(x + rp * .3).toFixed(1)}" cy="${(y + rp * .2).toFixed(1)}" r="1.8" fill="rgba(255,230,190,.8)"/>`;
    }
  }
  for(let i = 0; i < d; i++) o += `<line x1="${cx}" y1="${cy}" x2="${(cx + R * Math.cos(ang(i))).toFixed(1)}" y2="${(cy + R * Math.sin(ang(i))).toFixed(1)}" stroke="#000" stroke-width="3.5"/>`;
  o += `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="#000" stroke-width="3.5"/>`;
  return SVG(260, 260, o);
}
const fracVal = f => { const [a, b] = f.split('/').map(Number); return a / b; };
G.pizza = n => {
  const d = n === 1 ? pick([3, 4, 6, 8]) : pick([4, 6, 8, 10, 12]);
  const p = sortearAte(() => rnd(1, d - 1), x => n === 1 || 2 * x !== d);
  const pint = n === 1 ? [...Array(p).keys()] : shuffle([...Array(d).keys()]).slice(0, p);
  const comida = n === 3;                       // difícil: pergunta a parte que já foi comida (fatias cinzentas)
  const certaN = comida ? d - p : p, outraN = comida ? p : d - p;
  const certa = `${certaN}/${d}`;
  const erradas = [{ v: `${outraN}/${d}`, erro: comida ? 'contou as fatias que sobraram' : 'contou as fatias que já foram comidas' }, { v: `${certaN}/${outraN}`, erro: 'comparou uma parte com a outra' },
    { v: `${d}/${certaN}`, erro: 'inverteu numerador e denominador' }, { v: `${certaN + 1}/${d}`, erro: 'contou uma fatia a mais' }, { v: `${certaN - 1}/${d}`, erro: 'contou uma fatia a menos' }, { v: `${certaN}/${d + 1}`, erro: 'contou as divisões erradas' }];
  const o = altFrac(certa, erradas, d);
  return { ...o, text: comida ? 'As fatias cinzas já foram comidas. Que fração da pizza já foi comida?' : 'Que fração da pizza ainda está no prato (fatias com recheio)?',
    image: svgURI(pizzaSVG(d, pint)), meta: { p, d, comida }, chave: `pz${p}/${d}${comida ? 'c' : ''}` };
};
C.pizza = m => `${m.comida ? m.d - m.p : m.p}/${m.d}`;

/* ========= FRAÇÕES EQUIVALENTES COM LACUNA (como em "Frações equivalentes.html") ========= */
function fracLacunaSVG(f, barras){      // f = [ln, ld, rn, rd] com null na lacuna
  const W = 460, H = barras ? 300 : 190;
  const num = (x, y, v) => v === null ? `<rect x="${x - 30}" y="${y - 40}" width="60" height="52" rx="8" fill="#fef9c3" stroke="#ca8a04" stroke-width="4"/>${T(x, y, '?', { fs: 40, cor: '#a16207' })}` : T(x, y, v, { fs: 48 });
  let o = num(120, 70, f[0]) + `<line x1="70" y1="92" x2="170" y2="92" stroke="#111" stroke-width="5"/>` + num(120, 150, f[1]) + T(230, 110, '=', { fs: 56 }) +
    num(340, 70, f[2]) + `<line x1="290" y1="92" x2="390" y2="92" stroke="#111" stroke-width="5"/>` + num(340, 150, f[3]);
  if(barras){
    const barra = (x0, y0, w, dd, pp, cor) => { let s = ''; for(let i = 0; i < dd; i++) s += `<rect x="${(x0 + i * w / dd).toFixed(1)}" y="${y0}" width="${(w / dd).toFixed(1)}" height="46" fill="${i < pp ? cor : '#fff'}" stroke="#111" stroke-width="2.5"/>`; return s; };
    if(f[0] !== null && f[1] !== null) o += barra(20, 200, 200, f[1], f[0], '#22c55e');
    if(f[3] !== null) o += barra(240, 200, 200, f[3], f[2] === null ? 0 : f[2], '#3b82f6');
    o += T(230, 285, 'as duas barras têm o mesmo tamanho', { fs: 17, fw: 'normal', cor: '#475569' });
  }
  return SVG(W, H, o);
}
G.fracLacuna = n => {
  const d = pick(n === 1 ? [2, 3, 4] : n === 2 ? [2, 3, 4, 5, 6] : [3, 4, 5, 6, 7, 8]);
  const a = sortearAte(() => rnd(1, d - 1), x => { let p = x, q = d; while(q){ [p, q] = [q, p % q]; } return p === 1; });
  const k = n === 1 ? pick([2, 3]) : n === 2 ? rnd(2, 4) : rnd(2, 6);
  let f = [a, d, a * k, d * k];
  if(Math.random() < (n === 3 ? .4 : .25)) f = [f[2], f[3], f[0], f[1]];       // às vezes a fração maior vem na frente
  const lac = n === 1 ? 2 : n === 2 ? pick([2, 3]) : pick([0, 1, 2, 3]);
  const certa = f[lac];
  const vis = f.map((v, i) => i === lac ? null : v);
  const [x0, x1, y0, y1] = f, outroLado = lac < 2 ? [y0, y1] : [x0, x1];
  const mesmaPos = outroLado[lac % 2];                       // repetir o número que está na mesma posição
  const par = lac % 2 ? f[lac - 1] : f[lac + 1], parOut = lac % 2 ? outroLado[0] : outroLado[1];
  const erradas = [{ v: mesmaPos, erro: 'repetiu o número da outra fração' }, { v: mesmaPos + Math.abs(par - parOut), erro: 'somou em vez de multiplicar' },
    { v: Math.abs(mesmaPos - Math.abs(par - parOut)), erro: 'subtraiu em vez de dividir' }, { v: certa + 1, erro: 'um a mais' }, { v: certa - 1, erro: 'um a menos' }, { v: mesmaPos * par, erro: 'multiplicou os números errados' }];
  const o = alternativas(certa, erradas, String, { min: 1, max: 200 });
  return { ...o, text: 'Qual número completa as frações equivalentes?', image: svgURI(fracLacunaSVG(vis, n < 3)), meta: { f, lac }, chave: `fl${f.join(',')}l${lac}` };
};
C.fracLacuna = m => { const [a, b, c, d] = m.f; return String([b * c / d, a * d / c, a * d / b, b * c / a][m.lac]); };
