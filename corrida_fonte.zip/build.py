import json,re
parts=[open(f).read() for f in ['t1_helpers.js','t2_geradores.js','t2b_geradores3a6.js','t2c_probcontagem.js','t2d_lote3.js','t2e_anos1a3.js','t2f_anos4a5.js','t2g_anos6a7.js','t2h_curriculo2.js','t2i_prova.js','t2j_aula.js','t2k_ano8.js','t2l_ano9.js','t3_motor.js','t3a_anos89.js','t3b_ajudas.js','t4_integracao.js','t5_teste.js','t6_placar.js','t7_protecao.js','t11_rede.js']]
t8=open('t8_treino.js').read()+'\n'+open('t9_festa.js').read()+'\n'+open('t10_descritores.js').read()+'\n'+open('t12_gestao.js').read()+'\n'+open('t13_acompanhar.js').read()+'\n'+open('t14_aula.js').read()+'\n'+open('t15_interativo.js').read()+'\n'+open('t16_ficha.js').read()+'\n'+open('t17_anos89.js').read()+'\n'+open('t18_controle.js').read()+'\n'+open('t19_chama.js').read()+'\n'+open('t20_historico.js').read()+'\n'+open('t21_correcoes.js').read()+'\n'+open('t22_desafio.js').read()+'\n'+open('t23_icones_data.js').read()+'\n'+open('t23_visual.js').read()+'\n'+open('t24_engaja.js').read()+'\n'+open('t25_tema.js').read()+'\n'+open('t26_nuvem.js').read()+'\n'+open('t27_entrada.js').read()+'\n'+open('t28_organiza.js').read()
i=[k for k,f in enumerate(parts) if 'return { CAT, POR_ID' in f][0]
parts[i]=parts[i].replace('return { CAT, POR_ID', t8+'\nreturn { CAT, POR_ID',1)
js='\n'.join(parts)
imgs=json.load(open('imgs.json'))
mapa={'nota-2':'n2','nota-5':'n5','nota-10':'n10','nota-20':'n20','nota-50':'n50','nota-100':'n100','moeda-1':'m1','moeda-5':'m5','moeda-10':'m10','moeda-25':'m25','moeda-50':'m50'}
linhas=['/* miniaturas WebP (~5 KB cada) feitas a partir de Desktop\\\\escola\\\\imagens */']
for k,v in mapa.items():
    linhas.append(f"IMG.{v} = 'data:image/webp;base64,{imgs[k]['b64']}';")
js=js.replace("const IMG = {};","const IMG = {};\n"+'\n'.join(linhas),1)
open('trilha_bloco.js','w').write(js)
html=open('orig.html').read()
assert html.count('</body>')==1
novo=html.replace('</body>','<script>\n'+js+'\n</script>\n</body>')
open('work.html','w').write(novo)
print(len(html),len(novo))
