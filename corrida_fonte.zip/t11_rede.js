
/* =========================================================================
   REDE MAIS FIRME (acrescentado)
   1. Conexão mais tolerante: "keepalive" de 60 s (o Chrome atrasa os relógios
      de abas em segundo plano e o servidor achava que a aba tinha caído) e
      nova tentativa a cada 1,5 s.
   2. Três servidores: o principal (EMQX, porta 8084) e dois reservas
      (HiveMQ, porta 8884; shiftr.io, porta 443 — a mesma dos sites comuns).
      O professor fica ligado aos três e manda tudo para os três. O aluno
      tenta o principal; se não conectar em 8 s, tenta TAMBÉM o próximo
      (sem largar o primeiro) e fica com o que conectar antes.
   3. Selo de conexão do professor: "online" se qualquer servidor estiver ligado.
   Funções originais intactas: só embrulhos (connectMQTT, pub) e as opções
   passadas ao mqtt.connect.
========================================================================= */
(() => {
  if(typeof mqtt === 'undefined' || !mqtt.connect) return;
  const SERVIDORES = [
    { nome: 'servidor 1', url: BROKER },
    { nome: 'servidor 2', url: 'wss://broker.hivemq.com:8884/mqtt' },
    { nome: 'servidor 3', url: 'wss://public.cloud.shiftr.io', username: 'public', password: 'public' },
  ];
  const connect0 = mqtt.connect.bind(mqtt);
  const conectar = (url, opts) => { const s = SERVIDORES.find(x => x.url === url) || {};
    return connect0(url, Object.assign({}, opts, { keepalive: 60, reconnectPeriod: 1500, connectTimeout: 8000 }, s.username ? { username: s.username, password: s.password } : {})); };
  try{ mqtt.connect = conectar; }catch(e){}

  const selo = (txt, cls) => [$('mqttStatus'), $('netStatus')].forEach(el => { if(!el) return; el.textContent = txt; el.className = 'status-badge ' + cls; if(el === $('netStatus')) el.classList.remove('hidden'); });
  const ligado = c => !!(c && c.connected);
  const aoReceber = cli => cli.on('message', (topic, payload) => { let msg; try{ msg = JSON.parse(payload.toString()); }catch(e){ return; } app.onMessage(topic, msg); });
  const algumExtra = () => (app._extras || []).some(ligado);
  /* o selo mostra a situação REAL a cada segundo (antes, o aviso "offline" de uma conexão já
     descartada podia ficar na tela mesmo com o aluno ligado por outro servidor) */
  let seloAtual = '';
  function seloVerdadeiro(){
    let txt, cls;
    if(app.mode === 'teacher'){
      const n = [app.mqtt, ...(app._extras || [])].filter(ligado).length;
      if(!app.room) return;
      txt = n ? 'online' : 'offline'; cls = n ? 'on' : 'off';
    } else {
      if(!app.room) return;
      const idx = app._srv || 0;
      if(ligado(app.mqtt)){ txt = idx ? 'online (' + SERVIDORES[idx].nome + ')' : 'online'; cls = 'on'; }
      else { txt = '📡 sem conexão — tentando…'; cls = 'wait'; }
    }
    const el = $('netStatus') || $('mqttStatus');
    if(seloAtual !== txt || (el && el.textContent !== txt)){ seloAtual = txt; selo(txt, cls); }
  }
  setInterval(() => { if(app.mode === 'teacher' && app.room && !app.host.isDemo) seloVerdadeiro(); }, 1000);
  // corrige na hora quando um aviso velho escreve por cima (sem piscar)
  try{ const mo = new MutationObserver(() => { if(app.room && !(app.mode === 'teacher' && app.host.isDemo)) seloVerdadeiro(); });
    ['netStatus', 'mqttStatus'].forEach(id => { const el = $(id); if(el) mo.observe(el, { childList: true, characterData: true, subtree: true }); }); }catch(e){}

  /* ---------- professor: liga também nos reservas e publica em todos ---------- */
  function reservasProfessor(){
    (app._extras || []).forEach(c => { try{ c.end(true); }catch(e){} });
    const sala = app.room;
    app._extras = SERVIDORES.slice(1).map(s => {
      const cli = conectar(s.url, { clientId: 'cgm_r_' + uid(), clean: true });
      cli.on('connect', () => { cli.subscribe(`${BASE}/${sala}/tohost`, { qos: 0 }); if(!ligado(app.mqtt)) selo('online', 'on'); setTimeout(() => { try{ app.broadcastState(); }catch(e){} }, 300); });
      cli.on('close', () => { if(!ligado(app.mqtt) && !algumExtra()) selo('offline', 'off'); });
      aoReceber(cli);
      return cli;
    });
    const c = app.mqtt;                                  // o principal caiu mas um reserva está ligado: continua "online"
    if(c){ ['close', 'reconnect', 'error'].forEach(ev => c.on(ev, () => setTimeout(() => { if(!ligado(app.mqtt) && algumExtra()) selo('online', 'on'); }, 0))); }
  }

  /* ---------- aluno: começa pelo principal; sem conexão em 8 s, tenta TAMBÉM o próximo (sem largar o
     que já está tentando). O primeiro que conectar fica; os outros são desligados. ---------- */
  const tentativas = [];
  function adotar(cli, idx){
    tentativas.splice(0).forEach(t => { if(t.cli !== cli){ try{ t.cli.end(true); }catch(e){} } });
    if(app.mqtt && app.mqtt !== cli){ try{ app.mqtt.end(true); }catch(e){} }
    app.mqtt = cli; app._srv = idx;
    tentativas.push({ cli, idx });
  }
  function montarAluno(cli, idx){
    const sala = app.room, pid = app.playerId;
    cli.on('connect', () => {
      if(app.mqtt !== cli) adotar(cli, idx);
      selo(idx ? 'online (' + SERVIDORES[idx].nome + ')' : 'online', 'on');
      cli.subscribe(`${BASE}/${sala}/tostate`, { qos: 0 });
      cli.subscribe(`${BASE}/${sala}/to/${pid}`, { qos: 0 });
      try{ sessionStorage.setItem('cgm_srv', String(idx)); }catch(e){}
    });
    cli.on('reconnect', () => { if(app.mqtt === cli) selo('reconectando…', 'wait'); });
    cli.on('close', () => { if(app.mqtt === cli) selo('offline', 'off'); });
    aoReceber(cli);
    return cli;
  }
  function tentarTambem(idx){
    if(tentativas.some(t => t.idx === idx)) return;
    selo('tentando ' + SERVIDORES[idx].nome + '…', 'wait');
    tentativas.push({ idx, cli: montarAluno(conectar(SERVIDORES[idx].url, { clientId: 'cgm_' + uid(), clean: true }), idx) });
  }
  function vigiarAluno(){
    clearInterval(app._vigia);
    let semRede = 0, semTrilha = 0;
    app._vigia = setInterval(() => {
      if(app.mode !== 'student' || !app.room || !app.mqtt){ clearInterval(app._vigia); tentativas.splice(0).forEach(t => { if(t.cli !== app.mqtt){ try{ t.cli.end(true); }catch(e){} } }); return; }   // saiu da sala ou foi removido
      seloVerdadeiro();
      if(!ligado(app.mqtt)){
        semTrilha = 0;
        if(++semRede % 8 === 0){                          // a cada 8 s sem conexão, soma mais um servidor à disputa
          const prox = SERVIDORES.findIndex((_, k) => k !== app._srv && !tentativas.some(t => t.idx === k));
          if(prox >= 0) tentarTambem(prox);
          else if(semRede >= 40){ semRede = 0; tentativas.splice(0).forEach(t => { if(t.cli !== app.mqtt){ try{ t.cli.end(true); }catch(e){} } }); }   // nada deu certo em 40 s: recomeça a disputa
        }
        return;
      }
      semRede = 0;
      // jogando sem ter recebido a trilha (a mensagem se perdeu): pede de novo ao professor
      const pt = app.player.trilha;
      if(app.player.phase === 'playing' && (!pt || !pt.rec)){
        if(++semTrilha % 4 === 0) app.pub(`${BASE}/${app.room}/tohost`, { type: 'trilhaPede', id: app.playerId });
      } else semTrilha = 0;
    }, 1000);
  }

  const connectMQTT0 = app.connectMQTT;
  app.connectMQTT = function(){
    if(this.mode !== 'teacher'){
      let pref = 0; try{ pref = +(sessionStorage.getItem('cgm_srv') || 0) || 0; }catch(e){}
      tentativas.splice(0).forEach(t => { try{ t.cli.end(true); }catch(e){} });
      if(pref > 0 && pref < SERVIDORES.length){            // já funcionou por um reserva nesta aba: começa por ele
        if(this.mqtt){ try{ this.mqtt.end(true); }catch(e){} }
        selo('conectando…', 'wait');
        const cli = montarAluno(conectar(SERVIDORES[pref].url, { clientId: 'cgm_' + uid(), clean: true }), pref);
        this.mqtt = cli; this._srv = pref; tentativas.push({ cli, idx: pref });
        vigiarAluno();
        return;
      }
      const r = connectMQTT0.apply(this, arguments);
      this._srv = 0; tentativas.push({ cli: this.mqtt, idx: 0 });
      vigiarAluno();
      return r;
    }
    const r = connectMQTT0.apply(this, arguments);
    if(this.room && !this.host.isDemo) reservasProfessor();
    return r;
  };
  const pub0 = app.pub;
  app.pub = function(topic, obj, retain = false){
    const r = pub0.apply(this, arguments);
    if(this.mode === 'teacher') (this._extras || []).forEach(c => { if(ligado(c)){ try{ c.publish(topic, JSON.stringify(obj), { qos: 0, retain }); }catch(e){} } });
    return r;
  };
  window.__rede = { SERVIDORES };
})();
