
/* =========================================================================
   CATÁLOGO DA TRILHA (ordem = ordem de subida)
   1º e 2º ano: geradores próprios (acima).
   3º ao 7º: degraus PROVISÓRIOS que usam os geradores que a Corrida já tem
   (níveis internos 1-2-3 → níveis do gerador antigo). Serão trocados por
   geradores próprios nas próximas etapas.
========================================================================= */
const CAT = [
  { id: 'soma10',     ano: 1, un: 'Números', bncc: 'EF01MA06 · EF01MA08', nome: 'Soma com resultado até 10', t: 1.3 },
  { id: 'sub10',      ano: 1, un: 'Números', bncc: 'EF01MA08', nome: 'Subtração até 10', t: 1.3 },
  { id: 'faz10',      ano: 1, un: 'Números', bncc: 'EF01MA06', nome: 'Quanto falta para 10', t: 1.3 },
  { id: 'contar100', ano: 1, un: 'Números', bncc: 'EF01MA04', nome: 'Contar até 100 com montinhos de 10', t: 1.4 },
  { id: 'cont20',     ano: 1, un: 'Números', bncc: 'EF01MA01 · EF01MA02 · EF01MA03', nome: 'Contar e comparar até 20', t: 1.5 },
  { id: 'seq20',      ano: 1, un: 'Números', bncc: 'EF01MA04 · EF01MA05', nome: 'Antes, depois e entre', t: 1.3 },
  { id: 'padrao',     ano: 1, un: 'Álgebra', bncc: 'EF01MA09 · EF01MA10', nome: 'Padrões de figuras e cores', t: 1.4 },
  { id: 'soma20',     ano: 1, un: 'Números', bncc: 'EF01MA08 · EF02MA05', nome: 'Soma até 20', t: 1.3 },
  { id: 'sub20',      ano: 1, un: 'Números', bncc: 'EF01MA08 · EF02MA05', nome: 'Subtração até 20', t: 1.3 },
  { id: 'grupos1', ano: 1, un: 'Números', bncc: 'EF01MA23', nome: 'Grupos iguais (pratos)', t: 1.4 },
  { id: 'cedulas',    ano: 1, un: 'Grandezas e medidas', bncc: 'EF01MA19', nome: 'Cédulas e moedas', t: 1.5 },
  { id: 'semana',     ano: 1, un: 'Grandezas e medidas', bncc: 'EF01MA16 · EF01MA17', nome: 'Dias da semana e meses', t: 1.4 },
  { id: 'relDigital', ano: 1, un: 'Grandezas e medidas', bncc: 'EF01MA25', nome: 'Relógio digital e de ponteiros', t: 1.5 },
  { id: 'compara1', ano: 1, un: 'Grandezas e medidas', bncc: 'EF01MA15', nome: 'Mais comprido, mais alto, mais pesado', t: 1.3 },
  { id: 'formas',     ano: 1, un: 'Geometria', bncc: 'EF01MA13 · EF01MA14', nome: 'Figuras planas', t: 1.2 },
  { id: 'posicao1', ano: 1, un: 'Geometria', bncc: 'EF01MA11', nome: 'Direita, esquerda, em cima, embaixo', t: 1.3, retirada: 1 },
  { id: 'posicaoRef1', ano: 1, un: 'Geometria', bncc: 'EF01MA12', nome: 'Direita e esquerda de outra pessoa', t: 1.3, retirada: 1 },
  { id: 'pictograma', ano: 1, un: 'Probabilidade e estatística', bncc: 'EF01MA21', nome: 'Pictograma e gráfico simples', t: 1.5 },
  { id: 'acaso1', ano: 1, un: 'Probabilidade e estatística', bncc: 'EF01MA20', nome: 'Certeza, talvez ou impossível', t: 1.4 },
  { id: 'dezenas',    ano: 2, un: 'Números', bncc: 'EF02MA01 · EF02MA04', nome: 'Dezenas e unidades', t: 1.4 },
  { id: 'soma100',    ano: 2, un: 'Números', bncc: 'EF02MA05 · EF02MA06', nome: 'Adição até 100', t: 1.4 },
  { id: 'sub100',     ano: 2, un: 'Números', bncc: 'EF02MA05 · EF02MA06', nome: 'Subtração até 100', t: 1.4 },
  { id: 'dobro',      ano: 2, un: 'Números', bncc: 'EF02MA07 · EF02MA08', nome: 'Dobro, metade, triplo e terça parte', t: 1.3 },
  { id: 'vezes2', ano: 2, un: 'Números', bncc: 'EF02MA24', nome: 'Multiplicação e repartição (2, 3, 4, 5 e 10)', t: 1.4 },
  { id: 'saltos',     ano: 2, un: 'Álgebra', bncc: 'EF02MA09 · EF02MA10 · EF02MA11', nome: 'Saltos de 2, 5 e 10', t: 1.3 },
  { id: 'centenas',   ano: 2, un: 'Números', bncc: 'EF02MA01 · EF02MA02 · EF02MA04', nome: 'Centenas e comparação até 1000', t: 1.4 },
  { id: 'setas2', ano: 2, un: 'Geometria', bncc: 'EF02MA12', nome: 'Caminho na malha com setas', t: 1.6 },
  { id: 'mapa2', ano: 2, un: 'Geometria', bncc: 'EF02MA13', nome: 'Mapa do bairro com caminho', t: 1.6 },
  { id: 'relogio',    ano: 2, un: 'Grandezas e medidas', bncc: 'EF02MA18 · EF02MA19', nome: 'Horas no relógio', t: 1.4 },
  { id: 'regua',      ano: 2, un: 'Grandezas e medidas', bncc: 'EF02MA16', nome: 'Medir com régua (cm)', t: 1.4 },
  { id: 'medidas2', ano: 2, un: 'Grandezas e medidas', bncc: 'EF02MA17', nome: 'Qual unidade de medida usar', t: 1.2 },
  { id: 'calendario2', ano: 2, un: 'Grandezas e medidas', bncc: 'EF02MA18', nome: 'Calendário: dias da semana e dias que faltam', t: 1.5 },
  { id: 'dinheiro',   ano: 2, un: 'Grandezas e medidas', bncc: 'EF02MA20', nome: 'Dinheiro: somar, completar e troco', t: 1.5 },
  { id: 'probTexto2', ano: 2, un: 'Números', bncc: 'EF02MA06', nome: 'Problemas de texto: juntar, tirar, comparar, completar', t: 2.0 },
  { id: 'colunas',    ano: 2, un: 'Probabilidade e estatística', bncc: 'EF02MA22 · EF02MA23', nome: 'Gráfico de colunas', t: 1.5 },
  { id: 'tabelaDupla', ano: 2, un: 'Probabilidade e estatística', bncc: 'EF02MA22', nome: 'Tabela de dupla entrada', t: 1.5 },
  { id: 'provavel2', ano: 2, un: 'Probabilidade e estatística', bncc: 'EF02MA21', nome: 'Roleta: muito provável, pouco provável, impossível', t: 1.4 },
  // ---- provisórios (geradores antigos da Corrida) ----
  { id: 'abaco',      ano: 3, un: 'Números', bncc: 'EF03MA01 · EF03MA02', nome: 'Ábaco: ler números até 9999', t: 1.4 },
  { id: 'p3_soma',    ano: 3, un: 'Números', bncc: 'EF03MA05 · EF03MA06', nome: 'Adição até 1000', tipo: 'add', niv: [2, 3, 4] },
  { id: 'p3_sub',     ano: 3, un: 'Números', bncc: 'EF03MA05 · EF03MA06', nome: 'Subtração até 1000', tipo: 'sub', niv: [2, 3, 4] },
  { id: 'reta3',      ano: 3, un: 'Números', bncc: 'EF03MA04', nome: 'Números na reta numérica', t: 1.4 },
  { id: 'disposicao', ano: 3, un: 'Números', bncc: 'EF03MA07', nome: 'Multiplicação em fileiras (disposição retangular)', t: 1.4 },
  { id: 'p3_tab',     ano: 3, un: 'Números', bncc: 'EF03MA03 · EF03MA07', nome: 'Tabuada', tipo: 'mult', niv: [1, 2, 3] },
  { id: 'pratos',     ano: 3, un: 'Números', bncc: 'EF03MA08', nome: 'Divisão em partes iguais (pratos)', t: 1.5 },
  { id: 'divResto', ano: 3, un: 'Números', bncc: 'EF03MA08', nome: 'Divisão com resto', t: 1.5 },
  { id: 'p3_dobro',   ano: 3, un: 'Números', bncc: 'EF03MA09', nome: 'Dobro e metade (números maiores)', tipo: 'double', niv: [2, 3, 4] },
  { id: 'partes',     ano: 3, un: 'Números', bncc: 'EF03MA09', nome: 'Metade, terça, quarta, quinta e décima parte', t: 1.5 },
  { id: 'p3_termo',   ano: 3, un: 'Álgebra', bncc: 'EF03MA11', nome: 'Termo desconhecido', tipo: 'missing', niv: [1, 2, 3] },
  { id: 'igualdade3', ano: 3, un: 'Álgebra', bncc: 'EF03MA11', nome: 'Igualdade na balança', t: 1.4 },
  { id: 'duracao',    ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA22 · EF03MA23', nome: 'Duração no relógio', t: 1.6 },
  { id: 'jarra',      ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA20', nome: 'Capacidade: ler a jarra (mL)', t: 1.4 },
  { id: 'reguaMm', ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA19', nome: 'Régua com milímetros', t: 1.5 },
  { id: 'balancaKg', ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA20', nome: 'Balança: quilos e gramas', t: 1.6 },
  { id: 'instrumento3', ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA17 · EF03MA18', nome: 'Qual instrumento usar para medir', t: 1.2 },
  { id: 'troco3', ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA24', nome: 'Compra e troco', t: 1.4 },
  { id: 'probTexto3', ano: 3, un: 'Números', bncc: 'EF03MA06 · EF03MA07 · EF03MA08', nome: 'Problemas de texto: as quatro operações', t: 2.0 },
  { id: 'solidos',    ano: 3, un: 'Geometria', bncc: 'EF03MA13', nome: 'Sólidos geométricos', t: 1.3 },
  { id: 'planif3', ano: 3, un: 'Geometria', bncc: 'EF03MA14', nome: 'Molde (planificação) dos sólidos', t: 1.4 },
  { id: 'figPlanas3', ano: 3, un: 'Geometria', bncc: 'EF03MA15', nome: 'Nome das figuras planas', t: 1.3 },
  { id: 'congruente3', ano: 3, un: 'Geometria', bncc: 'EF03MA16', nome: 'Figuras congruentes na malha', t: 1.5 },
  { id: 'areaComp3', ano: 3, un: 'Grandezas e medidas', bncc: 'EF03MA21', nome: 'Comparar áreas', t: 1.4 },
  { id: 'barras',     ano: 3, un: 'Probabilidade e estatística', bncc: 'EF03MA26 · EF03MA27', nome: 'Gráfico de barras', t: 1.5 },
  { id: 'resultados3', ano: 3, un: 'Probabilidade e estatística', bncc: 'EF03MA25', nome: 'Resultados possíveis', t: 1.4 },
  { id: 'p4_valor',   ano: 4, un: 'Números', bncc: 'EF04MA01 · EF04MA02', nome: 'Valor posicional', tipo: 'place', niv: [2, 3, 4] },
  { id: 'p4_tab',     ano: 4, un: 'Números', bncc: 'EF04MA06', nome: 'Multiplicação', tipo: 'mult', niv: [3, 4, 5] },
  { id: 'p4_div',     ano: 4, un: 'Números', bncc: 'EF04MA07', nome: 'Divisão', tipo: 'div', niv: [3, 4, 5] },
  { id: 'propriedades4', ano: 4, un: 'Números', bncc: 'EF04MA05', nome: 'Propriedades para calcular de cabeça', t: 1.4 },
  { id: 'inversa4', ano: 4, un: 'Números', bncc: 'EF04MA13 · EF04MA04', nome: 'Operação inversa para conferir a conta', t: 1.4 },
  { id: 'restos4', ano: 4, un: 'Números', bncc: 'EF04MA12 · EF04MA11', nome: 'Números com o mesmo resto', t: 1.4 },
  { id: 'igualdade4', ano: 4, un: 'Álgebra', bncc: 'EF04MA14 · EF04MA15', nome: 'Igualdade que se mantém', t: 1.4 },
  { id: 'decimos4', ano: 4, un: 'Números', bncc: 'EF04MA10', nome: 'Décimos e centésimos', t: 1.4 },
  { id: 'contagem',   ano: 4, un: 'Probabilidade e estatística', bncc: 'EF04MA08', nome: 'Contagem: combinações de roupas', t: 1.4 },
  { id: 'pizza',      ano: 4, un: 'Números', bncc: 'EF04MA09', nome: 'Frações com pizza', t: 1.4 },
  { id: 'fracfig',    ano: 4, un: 'Números', bncc: 'EF04MA09', nome: 'Fração da figura pintada', t: 1.4 },
  { id: 'fracReta4', ano: 4, un: 'Números', bncc: 'EF04MA09', nome: 'Frações na reta', t: 1.4 },
  { id: 'centavos',   ano: 4, un: 'Números', bncc: 'EF04MA10 · EF04MA25', nome: 'Dinheiro com centavos', t: 1.6 },
  { id: 'trocoDesc4', ano: 4, un: 'Grandezas e medidas', bncc: 'EF04MA25', nome: 'Desconto e troco', t: 1.5 },
  { id: 'probTexto4', ano: 4, un: 'Números', bncc: 'EF04MA03 · EF04MA06 · EF04MA07 · EF04MA08', nome: 'Problemas de texto: combinações, troco e divisão com resto', t: 2.1 },
  { id: 'horasDig4', ano: 4, un: 'Grandezas e medidas', bncc: 'EF04MA22', nome: 'Duração em horas, minutos e segundos', t: 1.6 },
  { id: 'areaMalha',  ano: 4, un: 'Grandezas e medidas', bncc: 'EF04MA21', nome: 'Área na malha quadriculada', t: 1.5 },
  { id: 'perimMalha', ano: 4, un: 'Grandezas e medidas', bncc: 'EF04MA20', nome: 'Perímetro na malha', t: 1.6 },
  { id: 'termometro', ano: 4, un: 'Grandezas e medidas', bncc: 'EF04MA23', nome: 'Leitura de termômetro', t: 1.3 },
  { id: 'graficoTemp4', ano: 4, un: 'Probabilidade e estatística', bncc: 'EF04MA24 · EF04MA27', nome: 'Gráfico de temperatura máxima e mínima', t: 1.6 },
  { id: 'simetria4',  ano: 4, un: 'Geometria', bncc: 'EF04MA19', nome: 'Simetria de reflexão', t: 1.4 },
  { id: 'anguloReto4', ano: 4, un: 'Geometria', bncc: 'EF04MA18', nome: 'Ângulos retos nas figuras', t: 1.4 },
  { id: 'pontoReta4', ano: 4, un: 'Geometria', bncc: 'EF04MA29', nome: 'Ponto, reta e plano', t: 1.2 },
  { id: 'faces',      ano: 4, un: 'Geometria', bncc: 'EF04MA17', nome: 'Faces, vértices e arestas', t: 1.5 },
  { id: 'roleta4', ano: 4, un: 'Probabilidade e estatística', bncc: 'EF04MA26', nome: 'Roleta: qual cor tem mais chance', t: 1.4 },
  { id: 'numGrandes5', ano: 5, un: 'Números', bncc: 'EF05MA01', nome: 'Números grandes: valor do algarismo e escrita', t: 1.5 },
  { id: 'p5_fracao',  ano: 5, un: 'Números', bncc: 'EF05MA03', nome: 'Fração de quantidade', tipo: 'fraction', niv: [1, 2, 3] },
  { id: 'fracMista5', ano: 5, un: 'Números', bncc: 'EF05MA03', nome: 'Frações maiores que o inteiro (pizzas)', t: 1.5 },
  { id: 'fracEquiv',  ano: 5, un: 'Números', bncc: 'EF05MA04', nome: 'Frações equivalentes com barras', t: 1.5 },
  { id: 'fracLacuna', ano: 5, un: 'Números', bncc: 'EF05MA04', nome: 'Frações equivalentes: complete o número', t: 1.4 },
  { id: 'decReta',    ano: 5, un: 'Números', bncc: 'EF05MA02 · EF05MA05', nome: 'Decimais na reta', t: 1.5 },
  { id: 'porcMalha',  ano: 5, un: 'Números', bncc: 'EF05MA06', nome: 'Porcentagem na malha 10×10', t: 1.4 },
  { id: 'notaFiscal5', ano: 5, un: 'Números', bncc: 'EF05MA07 · EF05MA08', nome: 'Decimais na nota da cantina', t: 1.7 },
  { id: 'probTexto5', ano: 5, un: 'Números', bncc: 'EF05MA07 · EF05MA08 · EF05MA12', nome: 'Problemas de texto: duas etapas, parcelas e proporção', t: 2.1 },
  { id: 'propTabela5', ano: 5, un: 'Álgebra', bncc: 'EF05MA12', nome: 'Tabela de proporção (quantidade × preço)', t: 1.5 },
  { id: 'partilha5', ano: 5, un: 'Álgebra', bncc: 'EF05MA13', nome: 'Partilha: dobro, triplo e a mais', t: 1.6 },
  { id: 'p5_termo',   ano: 5, un: 'Álgebra', bncc: 'EF05MA10 · EF05MA11', nome: 'Termo desconhecido (× e ÷)', tipo: 'missing', niv: [3, 4, 5] },
  { id: 'plano',      ano: 5, un: 'Geometria', bncc: 'EF05MA14 · EF05MA15', nome: 'Localização no plano (coordenadas)', t: 1.4 },
  { id: 'ampliacao',  ano: 5, un: 'Geometria', bncc: 'EF05MA18', nome: 'Ampliação e redução na malha', t: 1.6 },
  { id: 'cubinhos',   ano: 5, un: 'Grandezas e medidas', bncc: 'EF05MA21', nome: 'Volume com cubinhos', t: 1.6 },
  { id: 'vistas5', ano: 5, un: 'Geometria', bncc: 'EF05MA16', nome: 'Vistas de pilhas de cubos', t: 1.6 },
  { id: 'perimArea5', ano: 5, un: 'Grandezas e medidas', bncc: 'EF05MA20', nome: 'Perímetro e área na malha', t: 1.6 },
  { id: 'conversao5', ano: 5, un: 'Grandezas e medidas', bncc: 'EF05MA19', nome: 'Conversão de medidas', t: 1.4 },
  { id: 'chance',     ano: 5, un: 'Probabilidade e estatística', bncc: 'EF05MA22 · EF05MA23', nome: 'Chance com bolinhas', t: 1.4 },
  { id: 'potes',      ano: 5, un: 'Probabilidade e estatística', bncc: 'EF05MA22 · EF05MA23', nome: 'Probabilidade com potes', t: 1.5 },
  { id: 'graficoLinha5', ano: 5, un: 'Probabilidade e estatística', bncc: 'EF05MA24', nome: 'Gráfico de linhas', t: 1.5 },
  { id: 'decCompara6', ano: 6, un: 'Números', bncc: 'EF06MA01', nome: 'Comparar e ordenar decimais', t: 1.4 },
  { id: 'p6_expr',    ano: 6, un: 'Números', bncc: 'EF06MA03', nome: 'Expressões numéricas', tipo: 'expressao', niv: [1, 2, 3] },
  { id: 'fluxograma6', ano: 6, un: 'Álgebra', bncc: 'EF06MA04 · EF06MA23 · EF07MA05', nome: 'Fluxograma: siga os passos', t: 1.6 },
  { id: 'p6_mmc',     ano: 6, un: 'Números', bncc: 'EF06MA05 · EF06MA06', nome: 'MMC e MDC', tipo: 'mmcCurto', niv: [1, 2, 3] },
  { id: 'romanos6', ano: 6, un: 'Números', bncc: 'EF06MA02/ES', nome: 'Números romanos', t: 1.4 },
  { id: 'p6_potencia', ano: 6, un: 'Números', bncc: 'EF06MA11', nome: 'Potências', tipo: 'power', niv: [1, 3, 5] },
  { id: 'primos',     ano: 6, un: 'Números', bncc: 'EF06MA05', nome: 'Números primos e compostos', t: 1.3 },
  { id: 'arredonda',  ano: 6, un: 'Números', bncc: 'EF06MA12', nome: 'Arredondamento na reta', t: 1.4 },
  { id: 'cardapio',   ano: 6, un: 'Números', bncc: 'EF06MA35/ES', nome: 'Contagem: cardápio e cartões', t: 1.5 },
  { id: 'fracCompara', ano: 6, un: 'Números', bncc: 'EF06MA07', nome: 'Comparar frações com barras', t: 1.4 },
  { id: 'fracQtd',    ano: 6, un: 'Números', bncc: 'EF06MA09', nome: 'Fração de uma quantidade (figuras)', t: 1.5 },
  { id: 'somaFrac',   ano: 6, un: 'Números', bncc: 'EF06MA10/ES', nome: 'Somar e subtrair frações', t: 1.5 },
  { id: 'decOps6', ano: 6, un: 'Números', bncc: 'EF06MA11', nome: 'Operações com decimais', t: 1.5 },
  { id: 'partilha6', ano: 6, un: 'Números', bncc: 'EF06MA15', nome: 'Partilha em partes proporcionais', t: 1.6 },
  { id: 'balanca6', ano: 6, un: 'Álgebra', bncc: 'EF06MA14', nome: 'Balança da igualdade', t: 1.5 },
  { id: 'p6_equiv',   ano: 6, un: 'Números', bncc: 'EF06MA08', nome: 'Fração, decimal e %', tipo: 'equivalencia', niv: [1, 2, 3] },
  { id: 'p6_retaRac', ano: 6, un: 'Números', bncc: 'EF06MA08', nome: 'Racionais na reta', tipo: 'retaRacionais', niv: [2, 3, 5] },
  { id: 'p6_porc',    ano: 6, un: 'Números', bncc: 'EF06MA13', nome: 'Porcentagem (níveis maiores)', tipo: 'percent', niv: [3, 4, 5] },
  { id: 'tiposAng6', ano: 6, un: 'Geometria', bncc: 'EF06MA25 · EF06MA27', nome: 'Tipos de ângulos: agudo, reto, obtuso e raso', t: 1.3 },
  { id: 'abreAng6', ano: 6, un: 'Geometria', bncc: 'EF06MA25 · EF06MA27', nome: 'Abra o ângulo (arrastar)', t: 2.0 },
  { id: 'transferidor', ano: 6, un: 'Geometria', bncc: 'EF06MA25 · EF06MA27', nome: 'Medir ângulo com transferidor', t: 1.4 },
  { id: 'giro6', ano: 6, un: 'Geometria', bncc: 'EF06MA25 · EF06MA26', nome: 'Ângulo como giro e no relógio', t: 1.5 },
  { id: 'paralPerp6', ano: 6, un: 'Geometria', bncc: 'EF06MA22', nome: 'Retas paralelas e perpendiculares', t: 1.3 },
  { id: 'triangulos', ano: 6, un: 'Geometria', bncc: 'EF06MA19', nome: 'Classificar triângulos', t: 1.4 },
  { id: 'quadrilateros', ano: 6, un: 'Geometria', bncc: 'EF06MA20', nome: 'Quadriláteros', t: 1.5 },
  { id: 'prismas6', ano: 6, un: 'Geometria', bncc: 'EF06MA17', nome: 'Prismas e pirâmides: faces, vértices e arestas', t: 1.5 },
  { id: 'vistas6', ano: 6, un: 'Geometria', bncc: 'EF06MA17', nome: 'Vistas de pilhas de cubos (frente, cima e lado)', t: 1.7 },
  { id: 'poligonos',  ano: 6, un: 'Geometria', bncc: 'EF06MA18', nome: 'Nome dos polígonos', t: 1.3 },
  { id: 'vertices6', ano: 6, un: 'Geometria', bncc: 'EF06MA16/ES', nome: 'Vértices no plano (1º quadrante)', t: 1.5 },
  { id: 'dado',       ano: 6, un: 'Probabilidade e estatística', bncc: 'EF06MA30', nome: 'Probabilidade com dado', t: 1.4 },
  { id: 'graficoDuplo6', ano: 6, un: 'Probabilidade e estatística', bncc: 'EF06MA31 · EF06MA32', nome: 'Gráfico de barras duplas', t: 1.6 },
  { id: 'escala6', ano: 6, un: 'Grandezas e medidas', bncc: 'EF06MA28', nome: 'Planta baixa com escala', t: 1.5 },
  { id: 'quadAmplia6', ano: 6, un: 'Grandezas e medidas', bncc: 'EF06MA29', nome: 'Lado dobrou: e o perímetro e a área?', t: 1.4 },
  { id: 'p7_int',     ano: 7, un: 'Números', bncc: 'EF07MA04', nome: 'Operações com inteiros', tipo: 'inteiros', niv: [1, 2, 3] },
  { id: 'p7_reta',    ano: 7, un: 'Números', bncc: 'EF07MA03', nome: 'Inteiros na reta', tipo: 'retaInteiros', niv: [1, 2, 3] },
  { id: 'racNeg7', ano: 7, un: 'Números', bncc: 'EF07MA10', nome: 'Racionais negativos na reta', t: 1.5 },
  { id: 'opsRac7', ano: 7, un: 'Números', bncc: 'EF07MA11 · EF07MA12', nome: 'Operações com racionais (com sinal)', t: 1.6 },
  { id: 'tempCidades', ano: 7, un: 'Números', bncc: 'EF07MA03', nome: 'Negativos: temperaturas das cidades', t: 1.4 },
  { id: 'opostoModulo', ano: 7, un: 'Números', bncc: 'EF07MA03 · EF07MA04/ES', nome: 'Oposto, módulo e distância na reta', t: 1.4 },
  { id: 'variacaoTemp', ano: 7, un: 'Números', bncc: 'EF07MA04/ES', nome: 'Negativos: quanto subiu ou caiu a temperatura', t: 1.5 },
  { id: 'elevador',   ano: 7, un: 'Números', bncc: 'EF07MA04/ES', nome: 'Negativos: elevador e subsolo', t: 1.5 },
  { id: 'p7_extrato', ano: 7, un: 'Números', bncc: 'EF07MA04/ES', nome: 'Saldo bancário (extrato)', tipo: 'extrato', niv: [1, 3, 5] },
  { id: 'razao7', ano: 7, un: 'Números', bncc: 'EF07MA08 · EF07MA09', nome: 'Razão (receita com xícaras)', t: 1.5 },
  { id: 'p7_piramide', ano: 7, un: 'Números', bncc: 'EF07MA04', nome: 'Pirâmide de inteiros', tipo: 'piramide', niv: [1, 3, 5] },
  { id: 'p7_desc',    ano: 7, un: 'Números', bncc: 'EF07MA02', nome: 'Desconto e acréscimo', tipo: 'desconto', niv: [1, 2, 3] },
  { id: 'p7_balanca', ano: 7, un: 'Álgebra', bncc: 'EF07MA18', nome: 'Balança em equilíbrio', tipo: 'balanca', niv: [1, 3, 5] },
  { id: 'p7_valorNum', ano: 7, un: 'Álgebra', bncc: 'EF07MA13', nome: 'Valor numérico', tipo: 'valorNumerico', niv: [1, 3, 5] },
  { id: 'p7_traduzir', ano: 7, un: 'Álgebra', bncc: 'EF07MA13', nome: 'Linguagem algébrica', tipo: 'traduzir', niv: [1, 3, 5] },
  { id: 'p7_seq', ano: 7, un: 'Álgebra', bncc: 'EF07MA14 · EF07MA15', nome: 'Sequências', tipo: 'sequencia', niv: [1, 3, 5] },
  { id: 'equivExpr7', ano: 7, un: 'Álgebra', bncc: 'EF07MA16 · EF07MA15', nome: 'Expressões algébricas equivalentes', t: 1.6 },
  { id: 'p7_equacao', ano: 7, un: 'Álgebra', bncc: 'EF07MA18', nome: 'Equação do 1º grau', tipo: 'equacao', niv: [1, 2, 3] },
  { id: 'p7_prop',    ano: 7, un: 'Álgebra', bncc: 'EF07MA17', nome: 'Proporcionalidade', tipo: 'proporcao', niv: [1, 3, 5] },
  { id: 'inversa7', ano: 7, un: 'Álgebra', bncc: 'EF07MA17', nome: 'Proporção inversa', t: 1.5 },
  { id: 'p7_receita', ano: 7, un: 'Álgebra', bncc: 'EF07MA17', nome: 'Receita (proporção)', tipo: 'receita', niv: [1, 3, 5] },
  { id: 'p7_ang',     ano: 7, un: 'Geometria', bncc: 'EF07MA23 · EF06MA25', nome: 'Ângulos', tipo: 'angulos', niv: [1, 2, 3] },
  { id: 'p7_paral',   ano: 7, un: 'Geometria', bncc: 'EF07MA23', nome: 'Paralelas cortadas por transversal', tipo: 'paralelas', niv: [1, 3, 5] },
  { id: 'p6_coord',   ano: 7, un: 'Geometria', bncc: 'EF07MA19/ES', nome: 'Coordenadas no plano cartesiano', tipo: 'coordenadas', niv: [1, 3, 5] },
  { id: 'transf7', ano: 7, un: 'Geometria', bncc: 'EF07MA19/ES', nome: 'Reflexão, translação e multiplicação de coordenadas', t: 1.6 },
  { id: 'rotacao7', ano: 7, un: 'Geometria', bncc: 'EF07MA20 · EF07MA21', nome: 'Rotação de figuras', t: 1.6 },
  { id: 'p7_triang',  ano: 7, un: 'Geometria', bncc: 'EF07MA24', nome: 'Soma dos ângulos do triângulo', tipo: 'somaTriangulo', niv: [1, 3, 5] },
  { id: 'p7_existe', ano: 7, un: 'Geometria', bncc: 'EF07MA24', nome: 'Condição de existência do triângulo', tipo: 'trianguloExiste', niv: [1, 3, 5] },
  { id: 'rigidez7', ano: 7, un: 'Geometria', bncc: 'EF07MA25', nome: 'Rigidez do triângulo', t: 1.2 },
  { id: 'p7_poligono', ano: 7, un: 'Geometria', bncc: 'EF07MA27', nome: 'Ângulos de polígonos regulares', tipo: 'poligono', niv: [1, 3, 5] },
  { id: 'p6_areaFig', ano: 7, un: 'Grandezas e medidas', bncc: 'EF07MA31 · EF07MA32', nome: 'Área de figuras', tipo: 'areaFiguras', niv: [1, 3, 5] },
  { id: 'volume7', ano: 7, un: 'Grandezas e medidas', bncc: 'EF07MA30', nome: 'Volume e litros', t: 1.6 },
  { id: 'circunf7', ano: 7, un: 'Geometria', bncc: 'EF07MA22', nome: 'Circunferência: raio, diâmetro e pontos', t: 1.4 },
  { id: 'p7_circ', ano: 7, un: 'Grandezas e medidas', bncc: 'EF07MA33', nome: 'Circunferência e π', tipo: 'circunferencia', niv: [1, 3, 5] },
  { id: 'p7_conversao', ano: 7, un: 'Grandezas e medidas', bncc: 'EF07MA29/ES', nome: 'Unidades de medida', tipo: 'conversao', niv: [1, 3, 5] },
  { id: 'p7_media',   ano: 7, un: 'Probabilidade e estatística', bncc: 'EF07MA35', nome: 'Média', tipo: 'media', niv: [1, 2, 3] },
  { id: 'censo7', ano: 7, un: 'Probabilidade e estatística', bncc: 'EF07MA36', nome: 'Censo ou amostra', t: 1.3 },
  { id: 'p7_setores', ano: 7, un: 'Probabilidade e estatística', bncc: 'EF07MA37', nome: 'Gráfico de setores', tipo: 'setores', niv: [1, 3, 5] },
  { id: 'urna7',      ano: 7, un: 'Probabilidade e estatística', bncc: 'EF07MA34 · EF06MA30', nome: 'Probabilidade com pote (fração e %)', t: 1.5 },
  { id: 'doisDados',  ano: 7, un: 'Probabilidade e estatística', bncc: 'EF07MA34 · EF08MA22', nome: 'Dois dados: tabela de somas', t: 1.6 },
];
CAT.forEach((d, i) => { d.i = i; d.ordem = i; d.anoOrig = d.ano; d.prov = !!d.tipo; });
const POR_ID = Object.fromEntries(CAT.map(d => [d.id, d]));
/* até que ano a trilha vai (o professor escolhe; o que passa disso fica desligado) */
const LIMITE = { anoMax: 9, pRev: 0.20 };                 // pRev: parte das perguntas que é revisão (o professor escolhe)
const ativo = d => d.ano <= LIMITE.anoMax && !d.off && !d.retirada;   // retirada = tirada da trilha a pedido do professor (Fábio)          // off = o professor tirou a atividade no catálogo
/* degraus que são base para o 7º ano: na revisão aparecem com mais frequência */
const BASE_REV = new Set(['p3_tab', 'p4_tab', 'p4_div', 'pratos', 'divResto', 'disposicao', 'vezes2', 'fracfig', 'pizza', 'fracReta4', 'decimos4', 'p5_fracao', 'fracEquiv', 'fracLacuna', 'fracMista5',
  'decReta', 'porcMalha', 'p5_termo', 'propTabela5', 'notaFiscal5', 'fracCompara', 'fracQtd', 'somaFrac', 'decOps6', 'p6_equiv', 'p6_porc', 'p6_mmc', 'primos', 'p6_expr', 'p6_potencia']);
const catAtivo = () => CAT.filter(ativo);
const idxUltimoDoAno = ano => { let k = -1; CAT.forEach((d, i) => { if(d.ano <= ano) k = i; }); return k; };
const idxPrimeiroDoAno = ano => { const i = CAT.findIndex(d => d.ano >= ano); return i < 0 ? CAT.length - 1 : i; };

/* ajustes do professor no catálogo: tirar atividades (off) e mudar de ano (a atividade vai para o fim daquele ano) */
function aplicarAjustes(aj){
  aj = aj || {};
  const off = new Set(aj.off || []), anos = aj.anos || {};
  CAT.forEach(d => { d.off = off.has(d.id); d.ano = anos[d.id] ? +anos[d.id] : d.anoOrig; d.movida = !!anos[d.id] && +anos[d.id] !== d.anoOrig; });
  CAT.sort((a, b) => a.ano - b.ano || (a.movida - b.movida) || a.ordem - b.ordem);
  CAT.forEach((d, i) => { d.i = i; if(typeof TYPE_LABELS !== 'undefined') TYPE_LABELS[d.id] = (d.prov ? '' : `${d.ano}º · `) + d.nome; });
}
/* se o degrau atual foi tirado, pula para o próximo que está valendo */
function proximoAtivo(rec, desde){
  const livre = d => ativo(d) && !(rec.deg[d.id] && rec.deg[d.id].dom);
  return CAT.slice(Math.max(0, desde)).find(livre) || CAT.find(livre) || null;
}

/* rótulos e tempo por degrau (o relatório por tópico da Corrida já usa estes mapas) */
CAT.forEach(d => {
  TYPE_LABELS[d.id] = (d.prov ? '' : `${d.ano}º · `) + d.nome;
  TYPE_TIME_FACTOR[d.id] = d.prov ? (TYPE_TIME_FACTOR[d.tipo] || 1) : d.t;
});

function valoresRepetidos(ops){
  const val = s => { s = String(s).trim(); const f = s.match(/^(-?\d+)\s*\/\s*(\d+)$/); if(f) return +f[1] / +f[2];
    const n = s.replace(/[−–]/g, '-').replace(',', '.').replace('%', ''); return /^-?\d+(\.\d+)?$/.test(n) ? +n : null; };
  const vs = (ops || []).map(val);
  if(vs.some(v => v === null)) return false;
  return new Set(vs.map(v => v.toFixed(6))).size !== vs.length;
}
/* frações em pé: "3/4" vira {{3/4}} (o renderMath da Corrida desenha em pé) */
const fracEmPe = s => String(s == null ? '' : s).replace(/(^|[^\d{\/,.])(\d{1,3})\/(\d{1,3})(?![\d}\/])/g, '$1{{$2/$3}}');
const fracHTML = s => renderMath(fracEmPe(s));
/* gera uma questão do degrau no nível interno 1..3 */
const FALHAS = { n: 0, ult: '' };
function gerarQuestao(id, nivel){
  const d = POR_ID[id];
  nivel = Math.max(1, Math.min(3, nivel || 1));
  let q;
  if(d.prov){
    // o gerador antigo às vezes põe 2/4 e 4/8 juntas (mesmo valor): sorteia de novo
    let g;
    for(let k = 0; k < 30; k++){ g = generateQuestion({ allowed: null }, d.niv[nivel - 1], d.tipo); if(!valoresRepetidos(g.options)) break; }
    q = { ...g, fala: '', erros: null, meta: { antigo: d.tipo }, chave: (g.chave || '') + '|' + g.text };
    if(d.tipo === 'equacao') q.text = q.text.replace(/,\s*x\s*=\s*\?\s*$/, '');      // fica só "x + 12 = 23"
  } else {
    // nunca deixa a partida parar: se um sorteio falhar, sorteia de novo (o teste conta essas falhas)
    for(let k = 0; k < 20 && !q; k++){ try{ q = G[id](nivel); }catch(e){ FALHAS.n++; FALHAS.ult = id + ': ' + e.message; } }
    if(!q){ const g = generateQuestion({ allowed: null }, 1, 'add'); q = { ...g, fala: g.text, erros: null, meta: {}, chave: g.text }; }
  }
  q.text = fracEmPe(q.text);         // toda fração a/b do enunciado aparece em pé
  q.type = id;                       // relatório por tópico e tempo usam o id do degrau
  q.trilha = { id, nivel, ano: d.ano };
  return q;
}

/* =========================================================================
   MOTOR — progresso de um aluno (funções puras sobre o registro "rec")
========================================================================= */
const REGRA = {
  janelaDominio: 10, acertosDominio: 7, tempoDominio: 0.6,   // 7 de 10 no difícil, tempo médio < 60%
  nivelRevisao: 2,                                            // revisão no nível médio (confere se lembra, sem castigar por azar)
  apoioJanela: 10, apoioEntra: 0.5, apoioSai: 0.7,            // modo apoio: < 50% nas últimas 10 → mais fácil; ≥ 70% → volta ao normal
  apoioMinAtual: 8, apoioRecua: 0.4, pConforto: 0.4,          // em apoio: < 40% em 8 do degrau (no fácil) → volta ao pré-requisito
  sobeJanela: 5, sobeAcertos: 4,                              // sobe de nível: 4 das últimas 5
  desceJanela: 4, desceErros: 3,                              // desce de nível: 3 erros nas últimas 4
  pAtual: 0.70, pRevisao: 0.20,                               // o resto (10%) é prévia
  revIntervaloIni: 8, revIntervaloMax: 64,                    // revisão espaçada (em nº de respostas)
  bonusDominio: 150,
  ajudasPorDegrau: 3, pontosComAjuda: 50,                     // ajuda: dica + resposta; o acerto vale o mínimo
  diagPorSonda: 2,                                            // perguntas por degrau sondado no diagnóstico
  pausaJanela: 4, pausaErros: 3, pausaQtd: 5, maxSeguidas: 3, pAtual2: 0.4,  // errou 3 das últimas 4 do degrau: 5 perguntas de outras atividades; nunca mais de 3 seguidas iguais; 2º degrau = 40% do treino
  travaSeqErros: 5, travaQuedas: 2, travaMinRespostas: 25, travaAcerto: 0.6,
};

function novoRegistro(nome){
  return { v: 1, nome, chave: normNome(nome), atual: null, resp: 0, rev: 0, diag: null, deg: {}, trav: null, criado: new Date().toISOString() };
}
function degDo(rec, id){
  return rec.deg[id] || (rec.deg[id] = { n: 1, cnt: 0, h: [], dom: 0, domPor: '', domEm: '', tot: 0, ac: 0, totA: 0, err: {}, quedas: 0, seqErr: 0, revInt: REGRA.revIntervaloIni, revUlt: 0, revErr: 0 });
}

/* prepara o aluno: diagnóstico por saltos, início no ano, ou do começo */
function iniciar(rec, cfg){
  if(rec.atual || rec.diag) return;
  const anoIni = Math.min(cfg.ano || 1, LIMITE.anoMax);
  const ult = idxUltimoDoAno(anoIni);
  if(cfg.diag === 'saltos' && ult > 0){
    rec.diag = { lo: 0, hi: ult + 1, sonda: null, feitas: 0, ok: 0 };
    rec.diag.sonda = Math.floor((rec.diag.lo + rec.diag.hi) / 2);
    return;
  }
  const ini = cfg.diag === 'ano' ? idxPrimeiroDoAno(anoIni) : 0;
  for(let i = 0; i < ini; i++){ const d = degDo(rec, CAT[i].id); d.dom = 1; d.domPor = 'ano'; d.revUlt = 0; }
  rec.atual = CAT[ini].id;
  rec.diag = 'pulado';
}
function fimDiagnostico(rec){
  const lo = rec.diag.lo;
  for(let i = 0; i < Math.min(lo, CAT.length); i++){ const d = degDo(rec, CAT[i].id); if(!d.dom){ d.dom = 1; d.domPor = 'diag'; d.revUlt = rec.resp; } }
  const pa = lo < CAT.length ? proximoAtivo(rec, lo) : null;
  rec.atual = pa && pa.i >= lo ? pa.id : null;
  rec.diagRes = { degrau: rec.atual, em: new Date().toISOString() };
  rec.diag = 'feito';
  if(rec.atual) degDo(rec, rec.atual);
}

/* de onde vem a próxima pergunta: diagnóstico, degrau atual, revisão ou prévia */
/* nunca mais de 3 perguntas seguidas da MESMA atividade (vale para qualquer fonte, menos o diagnóstico) */
function escolherFonte(rec, sorte = Math.random()){
  const f = escolherFonteBase(rec, sorte);
  if(f.tipo === 'diag') return f;
  const ult = (rec.ultIds || []).slice(-REGRA.maxSeguidas);
  if(ult.length < REGRA.maxSeguidas || !ult.every(x => x === f.id)) return f;
  for(let k = 0; k < 8; k++){ const g = escolherFonteBase(rec, Math.random()); if(g.id !== f.id) return g; }
  const a2 = segundoDegrau(rec);
  if(a2 && a2.id !== f.id) return { tipo: 'atual2', id: a2.id, nivel: degDo(rec, a2.id).n };
  if(rec.atual && rec.atual !== f.id) return { tipo: 'atual', id: rec.atual, nivel: degDo(rec, rec.atual).n };
  return f;
}
function escolherFonteBase(rec, sorte = Math.random()){
  if(rec.diag && typeof rec.diag === 'object'){
    let s = rec.diag.sonda;                                           // sonda caiu numa atividade tirada: usa a vizinha que está valendo
    for(let k = 0; k < CAT.length && !ativo(CAT[s]); k++){ const a = rec.diag.sonda + k, b = rec.diag.sonda - k; if(a < CAT.length && ativo(CAT[a])){ s = a; break; } if(b >= 0 && ativo(CAT[b])){ s = b; break; } }
    return { tipo: 'diag', id: CAT[s].id, nivel: 3 };
  }
  if(rec.atual && POR_ID[rec.atual] && POR_ID[rec.atual].off){ const p = proximoAtivo(rec, POR_ID[rec.atual].i); rec.atual = p ? p.id : null; if(p) degDo(rec, p.id); }
  const dominados = CAT.filter(d => ativo(d) && rec.deg[d.id] && rec.deg[d.id].dom);
  if(!rec.atual || !ativo(POR_ID[rec.atual])){                     // terminou a trilha (ou passou do ano-limite): só revisão
    const d = dominados.length ? pick(dominados) : CAT[Math.max(0, idxUltimoDoAno(LIMITE.anoMax))];
    return { tipo: 'rev', id: d.id, nivel: REGRA.nivelRevisao };
  }
  /* variedade: (1) pausa — errou 3 das últimas 4 do degrau atual: 5 perguntas de outras atividades;
                 (2) nunca mais de 3 seguidas do mesmo degrau */
  const outra = () => {
    const antes = dominados.filter(d => d.i < POR_ID[rec.atual].i && !rec.deg[d.id].revErrTot);
    const base = antes.length ? antes : dominados;
    const ult = (rec.ultIds || []).slice(-1)[0];
    const a2 = segundoDegrau(rec);
    if(a2 && a2.id !== ult && sorte < 0.6) return { tipo: 'atual2', id: a2.id, nivel: degDo(rec, a2.id).n };     // pausa: aproveita para avançar no 2º degrau
    if(base.length){ let d = pick(base); if(base.length > 1 && d.id === ult) d = pick(base.filter(x => x.id !== ult)); return { tipo: 'conforto', id: d.id, nivel: 1 + Math.floor(sorte * 2) }; }
    const prox = CAT.slice(POR_ID[rec.atual].i + 1).filter(d => ativo(d) && !(rec.deg[d.id] && rec.deg[d.id].dom)).slice(0, 3);
    return prox.length ? { tipo: 'previa', id: pick(prox).id, nivel: 1 } : null;
  };
  if(rec.pausa){
    if(rec.resp >= rec.pausa.ate || rec.pausa.id !== rec.atual) rec.pausa = null;
    else { const o = outra(); if(o) return o; rec.pausa = null; }
  }
  const seguidas = (rec.ultIds || []).slice(-REGRA.maxSeguidas);
  if(seguidas.length >= REGRA.maxSeguidas && seguidas.every(x => x === rec.atual)){ const o = outra(); if(o) return o; }
  /* modo apoio: degrau atual no fácil + perguntas de conforto (coisas que ele já domina), sem revisão difícil nem prévia */
  if(rec.apoio){
    if(sorte < REGRA.pConforto && dominados.length){ const faceis = dominados.filter(d => d.i < POR_ID[rec.atual].i && !(rec.deg[d.id].revErrTot)); const d = pick(faceis.length ? faceis : dominados); return { tipo: 'conforto', id: d.id, nivel: 1 }; }
    return { tipo: 'atual', id: rec.atual, nivel: degDo(rec, rec.atual).n };
  }
  const pRev = LIMITE.pRev || REGRA.pRevisao, pAt = 0.9 - pRev;          // prévia continua 10%
  if(sorte >= pAt && sorte < pAt + pRev && dominados.length){
    // degraus-base (tabuada, frações, decimais, %…) voltam para revisão com o dobro da frequência
    const lista = dominados.map(d => ({ d, atraso: rec.resp - rec.deg[d.id].revUlt - rec.deg[d.id].revInt * (BASE_REV.has(d.id) ? 0.5 : 1) }));
    const vencidos = lista.filter(x => x.atraso >= 0);
    if(vencidos.length){ vencidos.sort((a, b) => b.atraso - a.atraso); return { tipo: 'rev', id: vencidos[0].d.id, nivel: REGRA.nivelRevisao }; }
    if(pRev > REGRA.pRevisao){ lista.sort((a, b) => b.atraso - a.atraso); return { tipo: 'rev', id: lista[0].d.id, nivel: REGRA.nivelRevisao }; }   // revisão reforçada: pega o mais antigo
  }
  const a2 = segundoDegrau(rec);
  if(sorte >= pAt + pRev){
    const prox = CAT.slice(POR_ID[(a2 || POR_ID[rec.atual]).id].i + 1).find(d => ativo(d) && !(rec.deg[d.id] && rec.deg[d.id].dom));
    if(prox) return { tipo: 'previa', id: prox.id, nivel: 1 };
  }
  /* dois degraus em paralelo: o atual e o seguinte (cada um sobe e é dominado pelas mesmas regras) */
  if(a2 && sorte < pAt * REGRA.pAtual2) return { tipo: 'atual2', id: a2.id, nivel: degDo(rec, a2.id).n };
  return { tipo: 'atual', id: rec.atual, nivel: degDo(rec, rec.atual).n };
}
/* o 2º degrau em treino: o próximo ainda não dominado depois do atual (fora do modo apoio) */
function segundoDegrau(rec){
  if(!rec.atual || rec.apoio || !POR_ID[rec.atual]) return null;
  return CAT.slice(POR_ID[rec.atual].i + 1).find(d => ativo(d) && !(rec.deg[d.id] && rec.deg[d.id].dom)) || null;
}

/* registra uma resposta. idx = alternativa marcada (-1 = tempo esgotado); frac = tempo usado / limite.
   Devolve eventos: {dominou, subiu, desceu, travou, destravou, diagFim, esqueceu} */
function registrar(rec, fonte, q, idx, ok, frac){
  const ev = {};
  rec.resp++; rec.rev++;
  (rec.ultIds || (rec.ultIds = [])).push(fonte.id); if(rec.ultIds.length > 8) rec.ultIds.shift();
  frac = Math.max(0, Math.min(1, +frac || 0));
  const d = degDo(rec, fonte.id);
  d.tot++; if(ok) d.ac++;
  d.ult = rec.resp;
  if(q && q._ajuda){ d.ajudas = (d.ajudas || 0) + 1; ev.ajuda = 1; return ev; }   // com ajuda: conta a resposta, mas não vale para o domínio
  if(!ok && idx >= 0 && q && q.erros && q.erros[idx]){ const e = q.erros[idx]; d.err[e] = (d.err[e] || 0) + 1; }
  if(!ok && idx < 0){ d.err['tempo esgotado'] = (d.err['tempo esgotado'] || 0) + 1; }

  if(fonte.tipo === 'diag'){
    const g = rec.diag;
    g.feitas++; if(ok) g.ok++;
    const reprovou = !ok, aprovou = g.ok >= REGRA.diagPorSonda;
    if(reprovou || aprovou){
      if(aprovou) g.lo = g.sonda + 1; else g.hi = g.sonda;
      g.feitas = 0; g.ok = 0;
      if(g.lo >= g.hi){ fimDiagnostico(rec); ev.diagFim = rec.atual; }
      else g.sonda = Math.floor((g.lo + g.hi) / 2);
    }
    return ev;
  }
  /* modo apoio: mede o acerto das últimas 10 respostas */
  const ult = rec.ultOk || (rec.ultOk = []);
  ult.push(ok ? 1 : 0); if(ult.length > REGRA.apoioJanela) ult.shift();
  const taxa = ult.reduce((a, b) => a + b, 0) / ult.length;
  if(!rec.apoio && rec.atual && ult.length >= REGRA.apoioJanela && taxa < REGRA.apoioEntra){
    rec.apoio = { em: rec.resp, at: 0, ok: 0 };
    const da = degDo(rec, rec.atual); da.n = 1; da.cnt = 0; da.seqErr = 0;              // o degrau atual recomeça no fácil
    ev.apoio = 'entrou';
  } else if(rec.apoio && ult.length >= REGRA.apoioJanela && taxa >= REGRA.apoioSai){
    rec.apoio = null; ev.apoio = 'saiu';
  }
  if(rec.apoio && fonte.tipo === 'atual'){
    rec.apoio.at++; if(ok) rec.apoio.ok++;
    if(rec.apoio.at >= REGRA.apoioMinAtual && rec.apoio.ok / rec.apoio.at < REGRA.apoioRecua){
      const at = POR_ID[rec.atual], pre = [...CAT.slice(0, at.i)].reverse().find(ativo);       // pré-requisito = degrau anterior que está valendo
      if(pre){
        const dp = degDo(rec, pre.id); dp.dom = 0; dp.domPor = ''; dp.n = 1; dp.cnt = 0; dp.h = []; dp.seqErr = 0;
        ev.voltou = { de: at.id, para: pre.id }; rec.atual = pre.id;                          // quando dominar, volta sozinho para o degrau em que travou
      }
      rec.apoio = { em: rec.resp, at: 0, ok: 0 };
    }
  }
  if(fonte.tipo === 'conforto') return ev;
  if(fonte.tipo === 'rev'){
    d.revUlt = rec.resp;
    if(ok){ d.revInt = Math.min(REGRA.revIntervaloMax, d.revInt * 2); d.revErr = 0; }
    else {
      d.revInt = REGRA.revIntervaloIni; d.revErr++; d.revErrTot = (d.revErrTot || 0) + 1;
      if(d.revErr >= 2){                                            // errou 2 revisões seguidas: volta a treinar
        d.dom = 0; d.domPor = ''; d.n = 2; d.cnt = 0; d.revErr = 0; ev.esqueceu = fonte.id;
        if(!rec.atual || POR_ID[fonte.id].i < POR_ID[rec.atual].i) rec.atual = fonte.id;
      }
    }
    return ev;
  }
  if(fonte.tipo === 'previa') return ev;

  // ---- degrau atual ----
  d.totA++;
  d.h.push([d.n, ok ? 1 : 0, Math.round(frac * 100) / 100]);
  if(d.h.length > 40) d.h.shift();
  d.cnt++;
  d.seqErr = ok ? 0 : d.seqErr + 1;
  if(!ok && fonte.id === rec.atual && d.totA - (d.pausaEm || 0) >= REGRA.pausaJanela && d.h.slice(-REGRA.pausaJanela).filter(x => !x[1]).length >= REGRA.pausaErros){
    rec.pausa = { id: fonte.id, ate: rec.resp + REGRA.pausaQtd }; d.pausaEm = d.totA; ev.pausa = fonte.id;
  }
  const janela = k => d.h.slice(-Math.min(k, d.cnt));
  if(d.n === 3){
    const w = janela(REGRA.janelaDominio);
    if(w.length >= REGRA.janelaDominio){
      const ac = w.reduce((s, x) => s + x[1], 0), tm = w.reduce((s, x) => s + x[2], 0) / w.length;
      if(ac >= REGRA.acertosDominio && tm < REGRA.tempoDominio){
        d.dom = 1; d.domPor = 'trilha'; d.domEm = new Date().toISOString(); d.revUlt = rec.resp; d.revInt = REGRA.revIntervaloIni;
        ev.dominou = fonte.id;
        rec.ajudas = REGRA.ajudasPorDegrau;                     // subiu de degrau: volta a ter 3 ajudas (não acumula)
        if(rec.trav && rec.trav.id === fonte.id){ rec.trav = null; ev.destravou = fonte.id; }
        if(fonte.id === rec.atual){                            // dominou o 2º degrau antes: o atual continua o mesmo
          const prox = CAT.slice(POR_ID[fonte.id].i + 1).find(x => ativo(x) && !(rec.deg[x.id] && rec.deg[x.id].dom));
          rec.atual = prox ? prox.id : null;
          if(prox) degDo(rec, prox.id);
        }
        return ev;
      }
    }
  }
  if(d.n < 3){
    const w = janela(REGRA.sobeJanela);
    if(w.length >= REGRA.sobeJanela && w.reduce((s, x) => s + x[1], 0) >= REGRA.sobeAcertos){
      d.n++; d.cnt = 0; ev.subiu = d.n;
      if(rec.trav && rec.trav.id === fonte.id){ rec.trav = null; ev.destravou = fonte.id; }
      return ev;
    }
  }
  if(d.n > 1){
    const w = janela(REGRA.desceJanela);
    if(w.length >= REGRA.desceJanela && w.filter(x => !x[1]).length >= REGRA.desceErros){ d.n--; d.cnt = 0; d.quedas++; ev.desceu = d.n; }
  }
  // travou?
  if(!rec.trav || rec.trav.id !== fonte.id){
    const ult10 = d.h.slice(-10), acc = ult10.length ? ult10.reduce((s, x) => s + x[1], 0) / ult10.length : 1;
    let motivo = null;
    if(d.seqErr >= REGRA.travaSeqErros) motivo = `${d.seqErr} erros seguidos`;
    else if(d.quedas >= REGRA.travaQuedas) motivo = `desceu de nível ${d.quedas} vezes`;
    else if(d.totA >= REGRA.travaMinRespostas && acc < REGRA.travaAcerto) motivo = `${d.totA} respostas e ${Math.round(acc * 100)}% de acerto nas últimas 10`;
    if(motivo){ rec.trav = { id: fonte.id, motivo, erro: erroMaisComum(d), em: new Date().toISOString() }; ev.travou = rec.trav; }
  }
  return ev;
}
function erroMaisComum(d){
  const e = Object.entries(d.err || {}).sort((a, b) => b[1] - a[1])[0];
  return e ? `${e[0]} (${e[1]}×)` : '';
}
function lacunas(rec){          // degraus já dominados em que o aluno errou revisões (do mais errado para o menos)
  return CAT.filter(d => rec.deg[d.id] && rec.deg[d.id].revErrTot).sort((a, b) => rec.deg[b.id].revErrTot - rec.deg[a.id].revErrTot || a.i - b.i);
}
function resumo(rec){
  const at = rec.atual ? POR_ID[rec.atual] : null, d = at ? rec.deg[at.id] : null;
  const dom = CAT.filter(x => rec.deg[x.id] && rec.deg[x.id].dom).length;
  return { degrau: at ? `${at.ano}º · ${at.nome}` : (rec.diag && typeof rec.diag === 'object' ? 'diagnóstico' : 'trilha concluída'),
    nivel: d ? d.n : 0, dominados: dom, diag: typeof rec.diag === 'object' && rec.diag !== null };
}
