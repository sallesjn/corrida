
/* =========================================================================
   PLACAR AO VIVO NA SALA REAL (correção acrescentada)
   Antes: na sala real a pista só andava quando chegava o "join" de 15 em 15 s
   e o Top 5 não atualizava nunca (hostPlayerBatch só somava os pontos).
   Agora: depois de cada lote recebido, redesenha pista e Top 5, no máximo
   uma vez a cada 3 s (mesmo ritmo da animação do carro, CAR_MOVE_MS).
   hostPlayerBatch, renderRaceTrack e renderRankLive continuam intactas.
========================================================================= */
(() => {
  const INTERVALO = CAR_MOVE_MS;           // 3000 ms
  let ultimo = 0, agendado = null;
  const desenhar = () => {
    agendado = null;
    if(app.mode !== 'teacher' || app.host.phase !== 'playing') return;
    ultimo = Date.now();
    app.renderRaceTrack();
    app.renderRankLive();
  };
  const hostPlayerBatch0 = app.hostPlayerBatch;
  app.hostPlayerBatch = function(msg){
    const r = hostPlayerBatch0.call(this, msg);
    if(this.host.phase === 'playing' && !agendado){
      agendado = setTimeout(desenhar, Math.max(0, INTERVALO - (Date.now() - ultimo)));
    }
    return r;
  };
})();

/* =========================================================================
   PADRÃO: 4 EQUIPES (acrescentado). O professor ainda pode trocar para 2 ou 3.
========================================================================= */
(() => {
  app.host.teamCount = 4;
  const seg = $('teamCount');
  if(seg) [...seg.children].forEach(b => b.classList.toggle('on', +b.dataset.n === 4));
  if($('teamInputs') && $('teamInputs').children.length) app.buildTeamInputs();
})();
