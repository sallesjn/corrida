
/* =========================================================================
   FICHA DO ALUNO (acrescentado) — o que cada aluno sabe fazer, em detalhe
   · ✅ Sabe fazer (dominou) · 🔶 Está aprendendo (nível e acertos recentes)
     · 🔁 Precisa retomar (errou na revisão / travou) · ⬜ Ainda não viu
   · Resumo por unidade (Números, Álgebra, Geometria…), descritores do Paebes,
     erros mais comuns, foco da aula, plano individual e evolução por data.
   · Abre pelo aluno no painel do treino, pelo botão "👤 Fichas dos alunos" no
     cartão da Trilha (funciona só com o arquivo da turma, sem jogar) e pelo
     relatório do fim. Tem "🖨️ Imprimir".
   Funções originais intactas (só botões e uma janela nova).
========================================================================= */
const UNIDADES = ['Números', 'Álgebra', 'Geometria', 'Grandezas e medidas', 'Probabilidade e estatística'];
function situacaoDegrau(r, d){
  const x = r && r.deg[d.id];
  if(!x || (!x.tot && !x.dom)) return { st: 'nao', txt: '⬜ ainda não viu' };
  const ult = (x.h || []).slice(-10), ac = ult.filter(h => h[1]).length;
  const erro = erroMaisComum(x);
  const retomar = (x.revErrTot || 0) > 0 || (r.trav && r.trav.id === d.id);
  if(x.dom){
    const como = { trilha: 'dominou', treino: 'dominou no treino', diag: 'já sabia (diagnóstico)', ano: 'anterior ao ano da turma' }[x.domPor] || 'dominou';
    const data = x.domEm ? ' em ' + new Date(x.domEm).toLocaleDateString('pt-BR') : '';
    return { st: retomar ? 'retomar' : 'sabe', txt: (retomar ? `🔁 errou ${x.revErrTot} revis${x.revErrTot === 1 ? 'ão' : 'ões'}` : '✅ ' + como + data), erro, ac, n: ult.length, tot: x.tot, acTot: x.ac };
  }
  return { st: retomar ? 'retomar' : 'aprendendo', txt: `${retomar ? '⚠️ travou · ' : '🔶 '}nível ${['', 'fácil', 'médio', 'difícil'][x.n] || x.n}${ult.length ? ` · últimas ${ult.length}: ${ac} certas` : ' · só viu na revisão/prévia'}`, erro, ac, n: ult.length, tot: x.tot, acTot: x.ac };
}
function fichaHTML(r){
  const anoTurma = Math.min(estado.cfg.ano || 7, LIMITE.anoMax || 9);
  const degs = CAT.filter(d => !d.retirada && !d.off && d.ano <= (LIMITE.anoMax || 9));
  const S = degs.map(d => ({ d, s: situacaoDegrau(r, d) }));
  const ate = S.filter(x => x.d.ano <= anoTurma);
  const nDom = ate.filter(x => x.s.st === 'sabe' || (x.s.st === 'retomar' && r.deg[x.d.id] && r.deg[x.d.id].dom)).length;
  const barra = (a, b) => `<div class="fi-bar"><i style="width:${b ? Math.round(a / b * 100) : 0}%"></i></div><span>${a}/${b}</span>`;
  const porUn = UNIDADES.map(u => { const L = ate.filter(x => x.d.un === u); return L.length ? `<div class="fi-un"><b>${u}</b>${barra(L.filter(x => r.deg[x.d.id] && r.deg[x.d.id].dom).length, L.length)}</div>` : ''; }).join('');
  // erros mais comuns (todas as atividades)
  const erros = [];
  Object.entries(r.deg || {}).forEach(([id, x]) => Object.entries(x.err || {}).forEach(([e, n]) => { if(POR_ID[id]) erros.push({ id, e, n }); }));
  erros.sort((a, b) => b.n - a.n);
  // evolução: degraus dominados por data
  const datas = {};
  Object.entries(r.deg || {}).forEach(([id, x]) => { if(x.dom && x.domEm && POR_ID[id]){ const k = x.domEm.slice(0, 10); (datas[k] || (datas[k] = [])).push(POR_ID[id].nome); } });
  const hist = Object.keys(datas).sort().reverse().slice(0, 6);
  // descritores
  const ds = descritoresDe(r, anoTurma), cods = Object.keys(ds);
  const fo = typeof focoDoAluno === 'function' ? focoDoAluno(r) : null;
  const lista = (titulo, cls, itens) => itens.length ? `<div class="fi-sec"><h3>${titulo} <span>(${itens.length})</span></h3><table class="fi-tab">${itens.map(({ d, s }) => `<tr class="${cls}"><td class="fi-ano">${d.ano}º</td><td><b>${esc(d.nome)}</b><div class="fi-un2">${esc(d.un)} · ${d.bncc}</div></td><td>${s.txt}${s.tot ? `<div class="fi-un2">${s.acTot}/${s.tot} certas no total</div>` : ''}</td><td class="fi-erro">${s.erro ? '❌ ' + esc(s.erro) : ''}</td></tr>`).join('')}</table></div>` : '';
  const ordem = (a, b) => a.d.i - b.d.i;
  return `<div class="fi-cab"><div><h2>👤 ${esc(r.nome || '')}</h2>
      <div class="fi-sub">Turma ${esc(estado.turma.nome || '')} · ${anoTurma}º ano · ${r.resp || 0} respostas no total${r.plano ? ` · 📌 plano: ${r.plano.ids ? r.plano.ids.length + ' atividade(s)' : 'até o ' + r.plano.ano + 'º ano'}` : ''} · atualizado ${estado.turma.atualizado ? new Date(estado.turma.atualizado).toLocaleString('pt-BR') : '—'}</div></div>
      <div class="fi-big">${nDom}<small>/${ate.length}</small><div>degraus dominados até o ${anoTurma}º ano</div></div></div>
    <div class="fi-grid">
      <div class="fi-box"><h3>Por unidade</h3>${porUn}</div>
      <div class="fi-box"><h3>Descritores do Paebes</h3>${cods.map(c => `<span class="fi-ds ${ds[c].st}" title="${esc(DESCRITORES[c])}">${c}</span>`).join('')}
        <div class="fi-un2" style="margin-top:6px">verde = domina · amarelo = começou · cinza = ainda não</div></div>
      <div class="fi-box"><h3>Erros mais comuns</h3>${erros.slice(0, 5).map(x => `<div>❌ <b>${esc(x.e)}</b> (${x.n}×) <span class="fi-un2">em ${esc(POR_ID[x.id].nome)}</span></div>`).join('') || '<div class="fi-un2">nenhum registrado</div>'}</div>
      <div class="fi-box"><h3>Evolução</h3>${hist.map(k => `<div><b>${new Date(k + 'T12:00').toLocaleDateString('pt-BR')}</b>: ${datas[k].length} degrau(s) — <span class="fi-un2">${esc(datas[k].slice(0, 4).join(', '))}${datas[k].length > 4 ? '…' : ''}</span></div>`).join('') || '<div class="fi-un2">ainda sem degraus dominados com data</div>'}
        ${fo && fo.tot ? `<div style="margin-top:6px">🎯 <b>Foco da aula</b>: ${fo.ac}/${fo.tot} (${Math.round(fo.ac / fo.tot * 100)}%)</div>` : ''}</div>
    </div>
    ${lista('🔁 Precisa retomar', 'retomar', S.filter(x => x.s.st === 'retomar').sort(ordem))}
    ${lista('🔶 Está aprendendo', 'aprendendo', S.filter(x => x.s.st === 'aprendendo').sort(ordem))}
    ${lista('✅ Sabe fazer', 'sabe', S.filter(x => x.s.st === 'sabe' && x.d.ano <= anoTurma).sort(ordem))}
    <details class="fi-sec"><summary><h3 style="display:inline">⬜ Ainda não viu (${S.filter(x => x.s.st === 'nao' && x.d.ano <= anoTurma).length} até o ${anoTurma}º ano)</h3></summary>
      <div class="fi-un2" style="margin-top:6px">${esc(S.filter(x => x.s.st === 'nao' && x.d.ano <= anoTurma).map(x => `${x.d.ano}º ${x.d.nome}`).join(' · ')) || '—'}</div></details>`;
}
function abrirFicha(chave){
  const alunos = Object.values(estado.turma.alunos || {}).filter(r => r && r.nome).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
  let box = $('fichaBox'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'fichaBox'; box.className = 'cat-fundo';
  document.body.appendChild(box);
  const mostrar = k => {
    const r = estado.turma.alunos[k];
    box.innerHTML = `<div class="cat-topo fi-nao-imprime"><h2>👤 Fichas dos alunos</h2>
        <select id="fiSel" style="width:auto;font-weight:800">${alunos.map(a => `<option value="${esc(a.chave || normNome(a.nome))}" ${(a.chave || normNome(a.nome)) === k ? 'selected' : ''}>${esc(a.nome)}</option>`).join('')}</select>
        <div class="dir"><button class="ab" data-ant="1">◀</button><button class="ab" data-prox="1">▶</button><button class="ab" data-imp="1">🖨️ Imprimir</button><button class="ab" data-fechar="1">✕ Fechar</button></div></div>
      <div class="fi-folha">${r ? fichaHTML(r) : '<div style="padding:20px;color:var(--muted)">Carregue o arquivo da turma (📂 Carregar turma) ou jogue com a turma para ver as fichas.</div>'}</div>`;
    box.scrollTop = 0;
  };
  const chaves = alunos.map(a => a.chave || normNome(a.nome));
  let atual = chave && estado.turma.alunos[chave] ? chave : chaves[0];
  mostrar(atual);
  box.onchange = e => { if(e.target.id === 'fiSel'){ atual = e.target.value; mostrar(atual); } };
  box.onclick = e => {
    if(e.target.closest('[data-fechar]')){ box.remove(); return; }
    if(e.target.closest('[data-imp]')){ document.body.classList.add('fi-imprimindo'); setTimeout(() => { window.print(); document.body.classList.remove('fi-imprimindo'); }, 50); return; }
    const i = chaves.indexOf(atual);
    if(e.target.closest('[data-ant]') && i > 0){ atual = chaves[i - 1]; mostrar(atual); }
    if(e.target.closest('[data-prox]') && i < chaves.length - 1){ atual = chaves[i + 1]; mostrar(atual); }
  };
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .fi-folha{max-width:1100px;margin:12px auto;background:var(--panel);border:2px solid var(--line);border-radius:16px;padding:16px 18px}
  .fi-cab{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center}
  .fi-cab h2{font-size:26px}
  .fi-sub,.fi-un2{color:var(--muted);font-size:13px}
  .fi-big{font-size:44px;font-weight:900;color:#22c55e;text-align:right;line-height:1}
  .fi-big small{font-size:22px;color:var(--muted)}
  .fi-big div{font-size:13px;color:var(--muted);font-weight:700}
  .fi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px;margin-top:12px}
  .fi-box{background:var(--panel2);border:2px solid var(--line);border-radius:12px;padding:10px 12px;font-size:14px;line-height:1.5}
  .fi-box h3,.fi-sec h3{font-size:16px;margin-bottom:6px}
  .fi-sec h3 span{color:var(--muted);font-weight:700}
  .fi-un{display:grid;grid-template-columns:1fr 90px 48px;gap:6px;align-items:center;font-size:13px}
  .fi-bar{height:10px;border-radius:6px;background:#334155;overflow:hidden}
  .fi-bar i{display:block;height:100%;background:#22c55e}
  .fi-ds{display:inline-block;margin:2px;padding:2px 7px;border-radius:8px;font-weight:900;font-size:12px;background:#334155;color:#cbd5e1}
  .fi-ds.dom{background:#16a34a;color:#fff}
  .fi-ds.and{background:#ca8a04;color:#fff}
  .fi-sec{margin-top:14px}
  .fi-tab{width:100%;border-collapse:collapse;font-size:14px}
  .fi-tab td{padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
  .fi-tab .fi-ano{font-weight:900;color:#93c5fd;width:34px}
  .fi-tab .fi-erro{color:#fca5a5;font-size:13px;width:28%}
  .fi-tab tr.retomar td{background:rgba(239,68,68,.07)}
  .fi-tab tr.aprendendo td{background:rgba(245,158,11,.06)}
  @media print{
    body.fi-imprimindo > *:not(#fichaBox){display:none !important}
    body.fi-imprimindo, html{background:#fff !important}
    body.fi-imprimindo #fichaBox{position:static;overflow:visible;background:#fff;padding:0}
    body.fi-imprimindo .fi-nao-imprime{display:none !important}
    body.fi-imprimindo .fi-folha{border:0;background:#fff;color:#000;max-width:none}
    body.fi-imprimindo .fi-box{background:#fff;border-color:#999}
    body.fi-imprimindo .fi-sub,body.fi-imprimindo .fi-un2,body.fi-imprimindo .fi-big div{color:#333}
    body.fi-imprimindo .fi-tab td{border-color:#bbb}
    body.fi-imprimindo details{display:block}
  }`;
  document.head.appendChild(st);
  function botao(){
    const ref = $('trDescritores') || $('trVerMapa'); if(!ref || $('trFichas')) return;
    const b = document.createElement('button'); b.className = 'ghost'; b.id = 'trFichas'; b.textContent = '👤 Fichas dos alunos';
    b.onclick = () => abrirFicha(); ref.after(b);
  }
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); botao(); return r; };
  botao();
  const renderClassReport0 = app.renderClassReport;
  app.renderClassReport = function(){
    const r = renderClassReport0.apply(this, arguments);
    const row = document.querySelector('#trRelatorio .tr-row');
    if(row && !$('trFichasFim')){ const b = document.createElement('button'); b.className = 'ghost'; b.id = 'trFichasFim'; b.textContent = '👤 Fichas dos alunos'; b.style.width = 'auto'; b.onclick = () => abrirFicha(); row.appendChild(b); }
    return r;
  };
})();
