
/* =========================================================================
   LOTE 8º ANO — Currículo SEDU/ES 2026 (EFAF), na ordem dos trimestres.
   Cada degrau: 3 níveis, alternativas com erro típico, conferência (C)
   refeita por outro caminho (quase sempre pelo avaliador de expressões ev8,
   que lê o próprio texto mostrado ao aluno).
========================================================================= */

/* ---------- utilitários do lote 8º/9º ---------- */
const SUP8 = { '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '-': '⁻' };
const sup8 = n => String(n).split('').map(c => SUP8[c]).join('');
const nD = v => fmtDec(v);                                            // número com vírgula e sinal −
const fr8 = (n, d) => {                                               // fração irredutível com sinal −
  if(d < 0){ n = -n; d = -d; }
  const g = mdc2(n, d) || 1; n /= g; d /= g;
  return (n < 0 ? '−' : '') + (d === 1 ? Math.abs(n) : `${Math.abs(n)}/${d}`);
};
const nt8 = s => String(s).toLowerCase().replace(/−/g, '-').replace(/\s+/g, ' ').trim();
const kv8 = v => Math.abs(v) < 1e-12 ? '0' : Number(v).toPrecision(9);
/* avaliador de expressões (lê o que o aluno vê): 2x² − 3y, (x + 1)(x − 2), √(5³), 3,5 × 10⁻², 7/4 … */
function ev8(s, vars = {}){
  const SUP = { '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4', '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9', '⁻': '-' };
  let t = String(s).replace(/[−–]/g, '-').replace(/[×·]/g, '*').replace(/[÷:]/g, '/').replace(/(\d)\.(?=\d)/g, '$1').replace(/(\d),(\d)/g, '$1.$2').replace(/\s+/g, '');
  t = t.replace(/[⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+/g, m => '^(' + m.split('').map(c => SUP[c]).join('') + ')');
  let i = 0;
  const peek = () => t[i];
  function expr(){ let v = term(); while(peek() === '+' || peek() === '-'){ const o = t[i++]; const w = term(); v = o === '+' ? v + w : v - w; } return v; }
  function term(){ let v = unario(); for(;;){ const c = peek(); if(c === '*' || c === '/'){ i++; const w = unario(); v = c === '*' ? v * w : v / w; } else if(c && /[\d.a-zπ(√∛]/.test(c)) v *= pot(); else break; } return v; }
  function unario(){ if(peek() === '-'){ i++; return -unario(); } if(peek() === '+'){ i++; return unario(); } return pot(); }
  function pot(){ const b = atomo(); if(peek() === '^'){ i++; return Math.pow(b, unario()); } return b; }
  function atomo(){
    const c = peek();
    if(c === '('){ i++; const v = expr(); if(t[i++] !== ')') throw new Error('parêntese'); return v; }
    if(c === '√'){ i++; return Math.sqrt(pot()); }
    if(c === '∛'){ i++; return Math.cbrt(pot()); }
    if(c === 'π'){ i++; return Math.PI; }
    if(/[\d.]/.test(c)){ const m = t.slice(i).match(/^\d*\.?\d+/); i += m[0].length; return +m[0]; }
    if(/[a-z]/.test(c)){ i++; if(!(c in vars)) throw new Error('variável ' + c); return vars[c]; }
    throw new Error('símbolo "' + c + '" em ' + t);
  }
  const v = expr(); if(i < t.length) throw new Error('sobrou ' + t.slice(i)); return v;
}
/* alternativas com texto e valor: não repete texto nem VALOR (1/2 e 2/4 contam como iguais) */
function alt8(certa, erradas, extra = []){
  const itens = [{ t: certa.t, v: certa.v, erro: null }];
  const kt = new Set([nt8(certa.t)]), kv = new Set(certa.v == null ? [] : [kv8(certa.v)]);
  const add = e => {
    if(itens.length >= 4 || !e || e.t == null || e.t === '') return;
    if(e.v != null && !Number.isFinite(e.v)) return;
    const a = nt8(e.t); if(kt.has(a)) return;
    if(e.v != null){ const b = kv8(e.v); if(kv.has(b)) return; kv.add(b); }
    kt.add(a); itens.push({ t: e.t, v: e.v, erro: e.erro || 'outro valor' });
  };
  shuffle(erradas.filter(Boolean)).forEach(add);
  extra.forEach(add);
  if(itens.length < 4) throw new Error('alt8: alternativas insuficientes');
  const sh = shuffle(itens);
  return { options: sh.map(i => i.t), correct: sh.findIndex(i => i.erro === null), erros: sh.map(i => i.erro), answer: certa.t };
}
/* número inteiro/decimal → {t, v} ; vizinhos para completar */
const nv8 = (v, suf = '') => ({ t: nD(v) + suf, v });
const viz8 = (v, suf = '', passo = 1) => [1, -1, 2, -2, 3, -3, 4, 5].map(k => ({ t: nD(v + k * passo) + suf, v: v + k * passo, erro: Math.abs(k) === 1 ? 'errou a conta por pouco' : 'errou a conta' }));
const pol8 = (a, b, x = 'x') => {                                     // "3x + 2", "3x − 1", "−x", "3x"
  const ax = a === 0 ? '' : a === 1 ? x : a === -1 ? '−' + x : nD(a) + x;
  if(!b) return ax || '0';
  return ax ? `${ax} ${b > 0 ? '+' : '−'} ${Math.abs(b)}` : nD(b);
};
/* valor → fração irredutível (para conferir respostas em fração) */
function fracDeVal8(v, maxD = 100000){
  for(let d = 1; d <= maxD; d++){ const n = Math.round(v * d); if(Math.abs(n / d - v) < 1e-9) return fr8(n, d); }
  return null;
}
/* valor → texto como o aluno escreve: 32.000.000 / 0,00045 */
function numTxt8(v){
  const r = Math.round(v);
  if(Math.abs(v) >= 1 && Math.abs(v - r) <= 1e-7 * Math.abs(v)) return String(r).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return String(+v.toPrecision(10)).replace('.', ',');
}
/* potência com expoente fracionário desenhado de verdade: base grande, fração em pé no expoente */
function potFracSVG(base, p, r){
  const bs = String(base), wB = bs.length * 36 + 10;
  let o = T(40 + wB / 2, 118, bs, { fs: 64 });
  const xf = 40 + wB + 22;
  o += T(xf, 48, p, { fs: 30 }) + `<line x1="${xf - 14}" y1="58" x2="${xf + 14}" y2="58" stroke="#111" stroke-width="3"/>` + T(xf, 88, r, { fs: 30 });
  return SVG(xf + 60, 150, o);
}

/* ============================ 1º TRIMESTRE ============================ */

/* Potências de expoente inteiro e notação científica (EF08MA01) */
function numCient8(m10, e){                 // m10 = mantissa × 10 (ex.: 32 → 3,2), e = expoente → texto do número por extenso ("32.000.000" / "0,00045")
  const dig = String(m10).replace(/0+$/, '') || '0', casasM = dig.length - 1;      // 3,2 → dígitos "32", 1 casa depois da vírgula
  const pos = e + 1;                                                                // quantos algarismos antes da vírgula
  if(pos >= dig.length){ const s = dig + '0'.repeat(pos - dig.length); return s.replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  if(pos > 0) return dig.slice(0, pos) + ',' + dig.slice(pos);
  return '0,' + '0'.repeat(-pos) + dig;
}
const mant8 = m10 => nD(m10 / 10);
G.pot8 = n => {
  if(n === 1){
    if(Math.random() < .2){
      const b = rnd(2, 12), e = pick([0, 1]);
      const certa = e === 0 ? 1 : b;
      const aa = alt8(nv8(certa), [{ t: '0', v: 0, erro: 'achou que expoente zero dá zero' }, { t: String(b * 10), v: b * 10, erro: 'juntou a base com o expoente' }, e === 0 ? { t: String(b), v: b, erro: 'achou que fica a própria base' } : { t: '1', v: 1, erro: 'confundiu expoente 1 com expoente 0' }], viz8(certa));
      return { ...aa, text: `Quanto vale ${b}${sup8(e)}?`, meta: { expr: `${b}${sup8(e)}`, tipo: 'val' }, chave: `p8z${b}${e}` };
    }
    let b, e, neg, par;
    do{ b = rnd(2, 6); e = rnd(2, 4); } while(Math.pow(b, e) > 700);
    neg = Math.random() < .6; par = neg && Math.random() < .5;          // (−3)⁴ ou −3⁴
    const expr = neg ? (par ? `(−${b})${sup8(e)}` : `−${b}${sup8(e)}`) : `${b}${sup8(e)}`;
    const v = ev8(expr), abs = Math.pow(b, e);
    const aa = alt8(nv8(v), [
      { t: nD(neg ? b * e * (par && e % 2 ? -1 : par ? 1 : -1) : b * e), v: neg ? b * e * (par && e % 2 ? -1 : par ? 1 : -1) : b * e, erro: 'multiplicou a base pelo expoente' },
      { t: nD(-v), v: -v, erro: par ? 'errou o sinal: expoente par com base negativa dá positivo; ímpar dá negativo' : neg ? 'o sinal de fora não é elevado: −3² = −(3²)' : 'errou o sinal' },
      { t: nD(Math.sign(v) * Math.pow(b, e - 1)), v: Math.sign(v) * Math.pow(b, e - 1), erro: 'multiplicou a base uma vez a menos' },
      { t: nD(Math.sign(v) * Math.pow(b, e + 1)), v: Math.sign(v) * Math.pow(b, e + 1), erro: 'multiplicou a base uma vez a mais' },
    ], viz8(v));
    return { ...aa, text: `Quanto vale ${expr}?`, meta: { expr, tipo: 'val' }, chave: 'p8' + expr };
  }
  if(n === 2){
    const modo = pick(['neg', 'neg', 'prop', 'prop', 'fracNeg']);
    if(modo === 'neg'){
      let b, e; do{ b = pick([2, 3, 4, 5, 10]); e = rnd(1, 3); } while(Math.pow(b, e) > 1000);
      const expr = `${b}${sup8(-e)}`, P = Math.pow(b, e);
      const aa = alt8({ t: fr8(1, P), v: 1 / P }, [
        { t: nD(-P), v: -P, erro: 'achou que expoente negativo deixa o número negativo' },
        { t: nD(-b * e), v: -b * e, erro: 'multiplicou a base pelo expoente' },
        { t: nD(P), v: P, erro: 'ignorou o sinal do expoente' },
        { t: fr8(1, b * e), v: 1 / (b * e), erro: 'multiplicou a base pelo expoente e inverteu' },
        { t: fr8(-1, P), v: -1 / P, erro: 'inverteu e ainda trocou o sinal' },
      ]);
      return { ...aa, text: `Quanto vale ${expr}?`, meta: { expr, tipo: 'val' }, chave: 'p8n' + expr };
    }
    if(modo === 'fracNeg'){
      let a, c; do{ a = rnd(1, 5); c = rnd(2, 6); } while(a === c || mdc2(a, c) !== 1);
      const e = pick([1, 2]);
      const expr = `(${a}/${c})${sup8(-e)}`, v = Math.pow(c / a, e);
      const aa = alt8({ t: fr8(Math.pow(c, e), Math.pow(a, e)), v }, [
        { t: fr8(Math.pow(a, e), Math.pow(c, e)), v: Math.pow(a / c, e), erro: 'não inverteu a fração' },
        { t: fr8(-Math.pow(a, e), Math.pow(c, e)), v: -Math.pow(a / c, e), erro: 'achou que expoente negativo deixa o número negativo' },
        { t: fr8(-Math.pow(c, e), Math.pow(a, e)), v: -v, erro: 'inverteu, mas trocou o sinal' },
        { t: fr8(c * e, a), v: c * e / a, erro: 'multiplicou pelo expoente em vez de elevar' },
      ]);
      return { ...aa, text: `Quanto vale ${expr}?`, meta: { expr, tipo: 'val' }, chave: 'p8f' + expr };
    }
    // propriedades: mesma base
    const a = pick([2, 3, 5, 7, 10]);
    let m, k; do{ m = rnd(2, 7); k = rnd(2, 6); } while(m === k || m * k === m + k);
    const op = pick(['mult', 'div', 'pot']);
    let expr, ec, erros;
    const P = (b, e) => ({ t: `${b}${sup8(e)}`, v: Math.pow(b, e) });
    if(op === 'mult'){ expr = `${a}${sup8(m)} · ${a}${sup8(k)}`; ec = m + k; erros = [{ ...P(a, m * k), erro: 'multiplicou os expoentes (na multiplicação, soma)' }, { ...P(a * a, m + k), erro: 'multiplicou as bases' }, { ...P(a, Math.abs(m - k)), erro: 'subtraiu os expoentes' }]; }
    else if(op === 'div'){ if(m < k) [m, k] = [k, m]; expr = `${a}${sup8(m)} : ${a}${sup8(k)}`; ec = m - k; erros = [{ ...P(a, m + k), erro: 'somou os expoentes (na divisão, subtrai)' }, { ...P(1, m - k), erro: 'dividiu as bases' }, m % k === 0 ? { ...P(a, m / k), erro: 'dividiu os expoentes' } : { ...P(a, m * k), erro: 'multiplicou os expoentes' }]; }
    else { expr = `(${a}${sup8(m)})${sup8(k)}`; ec = m * k; erros = [{ ...P(a, m + k), erro: 'somou os expoentes (potência de potência, multiplica)' }, { ...P(a * k, m), erro: 'multiplicou a base pelo expoente de fora' }, { ...P(a, Math.pow(m, k)), erro: 'elevou o expoente em vez de multiplicar' }]; }
    const aa = alt8(P(a, ec), erros, [{ ...P(a, ec + 1), erro: 'errou a conta dos expoentes' }, { ...P(a, ec - 1), erro: 'errou a conta dos expoentes' }]);
    return { ...aa, text: `Escreva como uma só potência: ${expr}`, meta: { expr, tipo: 'prop', a }, chave: 'p8p' + expr };
  }
  // n === 3: notação científica
  const grande = Math.random() < .55, ida = Math.random() < .5;
  const m10 = pick([12, 15, 18, 2, 25, 32, 35, 4, 45, 5, 64, 7, 72, 8, 93, 3, 6, 9]) * 1;
  const mm = m10 < 10 ? m10 * 10 : m10;                       // sempre 2 dígitos (ex.: 4 → 40 = 4,0)
  const e = grande ? rnd(3, 9) : -rnd(2, 6);
  const numero = numCient8(mm, e), cient = (x, ee) => `${mant8(x)} × 10${sup8(ee)}`;
  const val = (mm / 10) * Math.pow(10, e);
  if(ida){
    const aa = alt8({ t: cient(mm, e), v: val }, [
      { t: cient(mm, e + 1), v: val * 10, erro: 'contou uma casa a mais' },
      { t: cient(mm, e - 1), v: val / 10, erro: 'contou uma casa a menos' },
      { t: cient(mm, -e), v: (mm / 10) * Math.pow(10, -e), erro: grande ? 'usou expoente negativo em número grande' : 'usou expoente positivo em número menor que 1' },
    ], [{ t: cient(mm, e + 2), v: val * 100, erro: 'contou os zeros errado' }]);
    return { ...aa, text: `Escreva ${numero} em notação científica.`, meta: { expr: cient(mm, e), numero, tipo: 'ida' }, chave: 'nc' + mm + 'e' + e };
  }
  const outro = ee => numCient8(mm, ee);
  const aa = alt8({ t: numero, v: val }, [
    { t: outro(e + 1), v: val * 10, erro: 'andou uma casa a mais' },
    { t: outro(e - 1), v: val / 10, erro: 'andou uma casa a menos' },
    { t: outro(-e), v: (mm / 10) * Math.pow(10, -e), erro: 'andou com a vírgula para o lado errado' },
  ], [{ t: outro(e + 2), v: val * 100, erro: 'contou os zeros errado' }]);
  return { ...aa, text: `Qual número é igual a ${cient(mm, e)}?`, meta: { expr: cient(mm, e), numero, tipo: 'volta' }, chave: 'nv' + mm + 'e' + e };
};
C.pot8 = m => {                                    // refaz pelo valor da expressão (avaliador ev8), sem usar as contas do gerador
  const v = ev8(m.expr);
  if(m.tipo === 'val') return Number.isInteger(v) ? nD(v) : fracDeVal8(v);
  if(m.tipo === 'prop'){ const e = Math.round(Math.log(v) / Math.log(m.a)); return `${m.a}${sup8(e)}`; }
  if(m.tipo === 'volta') return numTxt8(v);
  const w = ev8(m.numero), e = Math.floor(Math.log10(w) + 1e-9), mt = Math.round(w / Math.pow(10, e) * 10) / 10;
  return `${nD(mt)} × 10${sup8(e)}`;
};

/* Raízes: exata, entre quais inteiros, raiz como potência de expoente fracionário (EF08MA02) */
const RADIC8 = { '1/2': B => `√${B}`, '1/3': B => `∛${B}`, '2/3': B => `∛(${B}²)`, '3/2': B => `√(${B}³)`, '2/1': B => `${B}²`, '3/1': B => `${B}³` };
G.raiz8 = n => {
  if(n === 1){
    const modo = pick(['int', 'int', 'dec', 'frac']);
    if(modo === 'int'){
      const r = rnd(4, 20), k = r * r;
      const aa = alt8(nv8(r), [{ t: nD(k / 2), v: k / 2, erro: 'dividiu por 2 em vez de tirar a raiz' }, { t: nD(k), v: k, erro: 'não tirou a raiz' }, { t: nD(r + 1), v: r + 1, erro: 'errou a tabuada' }, { t: nD(r - 1), v: r - 1, erro: 'errou a tabuada' }], viz8(r));
      return { ...aa, text: `Quanto vale √${k}?`, meta: { expr: `√${k}` }, chave: 'r8' + k };
    }
    if(modo === 'dec'){
      const r = rnd(2, 9), k = r * r;                                   // √0,49 = 0,7
      const rad = nD(k / 100);
      const aa = alt8(nv8(r / 10), [{ t: nD(r / 100), v: r / 100, erro: 'errou a posição da vírgula' }, { t: nD(r), v: r, erro: 'esqueceu a vírgula' }, { t: nD(k / 200), v: k / 200, erro: 'dividiu por 2 em vez de tirar a raiz' }, { t: nD(k / 10), v: k / 10, erro: 'não tirou a raiz' }]);
      return { ...aa, text: `Quanto vale √${rad}?`, meta: { expr: `√${rad}` }, chave: 'r8d' + k };
    }
    let a, b; do{ a = rnd(1, 9); b = rnd(2, 12); } while(a >= b || mdc2(a, b) !== 1);
    const aa = alt8({ t: `${a}/${b}`, v: a / b }, [{ t: `${a}/${b * b}`, v: a / (b * b), erro: 'tirou a raiz só do numerador' }, { t: `${a * a}/${b}`, v: a * a / b, erro: 'tirou a raiz só do denominador' }, { t: fr8(a * a, 2 * b * b), v: a * a / (2 * b * b), erro: 'dividiu por 2 em vez de tirar a raiz' }, { t: `${b}/${a}`, v: b / a, erro: 'inverteu a fração' }]);
    return { ...aa, text: `Quanto vale √(${a * a}/${b * b})?`, meta: { expr: `√(${a * a}/${b * b})` }, chave: 'r8f' + a + b };
  }
  if(n === 2){
    let k; do k = rnd(5, 230); while(Number.isInteger(Math.sqrt(k)));
    const a = Math.floor(Math.sqrt(k));
    if(Math.random() < .5){
      const e = (x, er) => ({ t: `entre ${x} e ${x + 1}`, v: null, erro: er });
      const aa = alt8(e(a, null), [e(a - 1, 'pegou o quadrado perfeito de baixo errado'), e(a + 1, 'pegou o quadrado perfeito de cima errado'), e(Math.floor(k / 2), 'dividiu por 2 em vez de tirar a raiz'), e(a + 2, 'errou os quadrados perfeitos')].filter(x => x.t !== `entre ${a} e ${a + 1}` && !x.t.includes('entre 0 ') && !x.t.includes('−')));
      return { ...aa, text: `√${k} está entre quais números inteiros?`, meta: { k, modo: 'entre' }, chave: 'r8e' + k };
    }
    const prox = k <= a * a + a ? a : a + 1;                           // (a + ½)² = a² + a + ¼
    const aa = alt8(nv8(prox), [{ t: nD(prox === a ? a + 1 : a), v: prox === a ? a + 1 : a, erro: 'não comparou com o quadrado mais perto' }, { t: nD(Math.round(k / 2)), v: Math.round(k / 2), erro: 'dividiu por 2 em vez de tirar a raiz' }, { t: nD(prox + 2), v: prox + 2, erro: 'errou os quadrados perfeitos' }, { t: nD(prox - 2), v: prox - 2, erro: 'errou os quadrados perfeitos' }], viz8(prox));
    return { ...aa, text: `Qual é o número inteiro mais próximo de √${k}?`, meta: { k, modo: 'prox' }, chave: 'r8p' + k };
  }
  // n === 3: potência de expoente fracionário
  if(Math.random() < .5){
    const r = pick([2, 3]), c = r === 2 ? rnd(2, 10) : rnd(2, 5), B = Math.pow(c, r);
    let p = r === 2 ? pick([1, 1, 3]) : pick([1, 2]); if(Math.pow(c, p) > 1000) p = 1;
    const v = Math.pow(c, p);
    const aa = alt8(nv8(v), [{ t: fr8(B * p, r), v: B * p / r, erro: 'multiplicou a base pela fração do expoente' }, { t: nD(c), v: c, erro: 'tirou a raiz e esqueceu de elevar' }, { t: nD(Math.pow(B, p)), v: Math.pow(B, p), erro: 'elevou e esqueceu de tirar a raiz' }, { t: fr8(B, r), v: B / r, erro: 'dividiu a base pelo índice' }], viz8(v));
    return { ...aa, text: `Quanto vale a potência da figura? (expoente ${p}/${r}: raiz de índice ${r}${p > 1 ? `, elevada a ${p}` : ''})`, image: svgURI(potFracSVG(B, p, r)), meta: { expr: `${B}^(${p}/${r})`, tipo: 'val' }, chave: 'r8x' + B + p + r };
  }
  const B = pick([2, 3, 5, 6, 7, 10, 11]);
  const ks = Object.keys(RADIC8), fracCerta = pick(['1/2', '1/3', '2/3', '3/2']);
  const [p, r] = fracCerta.split('/').map(Number);
  const erroDe = f => f === `${r}/${p}` ? 'trocou o índice com o expoente' : f.endsWith('/1') ? 'esqueceu a raiz (o denominador vira o índice)' : 'errou o índice ou o expoente';
  const aa = alt8({ t: RADIC8[fracCerta](B), v: Math.pow(B, p / r) }, ks.filter(f => f !== fracCerta).map(f => { const [x, y] = f.split('/').map(Number); return { t: RADIC8[f](B), v: Math.pow(B, x / y), erro: erroDe(f) }; }));
  return { ...aa, text: `Qual raiz é igual à potência da figura?`, image: svgURI(potFracSVG(B, p, r)), meta: { B, p, r, tipo: 'radical' }, chave: 'r8y' + B + fracCerta };
};
C.raiz8 = m => {
  if(m.modo === 'entre'){ let a = 0; while((a + 1) * (a + 1) < m.k) a++; return `entre ${a} e ${a + 1}`; }
  if(m.modo === 'prox'){ let a = 0; while((a + 1) * (a + 1) <= m.k) a++; return (m.k - a * a) < ((a + 1) * (a + 1) - m.k) ? nD(a) : nD(a + 1); }
  if(m.tipo === 'radical'){ const alvo = Math.pow(m.B, m.p / m.r); return Object.values(RADIC8).map(f => f(m.B)).find(t => Math.abs(ev8(t) - alvo) < 1e-9); }
  const v = ev8(m.expr.replace('^', '^'));
  if(Math.abs(v - Math.round(v)) < 1e-9) return nD(Math.round(v));
  const f = fracDeVal8(v, 400); return f && !/^\d+$/.test(f) && m.expr.includes('/') && !m.expr.includes('^') ? f : nD(Math.round(v * 1000) / 1000);
};

/* Problemas com racionais (EF07MA12) */
G.probRac8 = n => {
  if(n === 1){
    const A = rnd(4, 20) * 5 * 100, B = rnd(3, 40) * 50 + rnd(0, 4) * 10, Cc = rnd(2, 30) * 50 + rnd(0, 4) * 10;
    if(B + Cc >= A) return G.probRac8(n);
    const nome = pick(NOMES), it = shuffle([['um lanche', 'um suco'], ['um caderno', 'uma caneta'], ['uma revista', 'um chocolate'], ['a passagem', 'um pão de queijo']])[0];
    const certa = A - B - Cc;
    const aa = alt8({ t: fmtR(certa), v: certa }, [{ t: fmtR(A - B + Cc), v: A - B + Cc, erro: 'somou o segundo gasto em vez de subtrair' }, { t: fmtR(B + Cc), v: B + Cc, erro: 'calculou o gasto, não o que sobrou' }, { t: fmtR(certa + 100), v: certa + 100, erro: 'errou o empréstimo nos reais' }, { t: fmtR(certa - 10), v: certa - 10, erro: 'errou os centavos' }, { t: fmtR(certa + 10), v: certa + 10, erro: 'errou os centavos' }]);
    return { ...aa, text: `${nome} tinha ${fmtR(A)}. Gastou ${fmtR(B)} com ${it[0]} e ${fmtR(Cc)} com ${it[1]}. Quanto sobrou?`, meta: { expr: `${A} − ${B} − ${Cc}`, cent: 1 }, chave: `pr8${A}-${B}-${Cc}` };
  }
  if(n === 2){
    if(Math.random() < .45){
      const kg = pick([0.5, 1.5, 2.5, 0.25, 0.75, 1.2, 1.4, 2.4]), preco = rnd(4, 30) * 100 + pick([0, 20, 40, 50, 60, 80]);
      const certa = Math.round(kg * preco);
      if(Math.abs(kg * preco - certa) > 1e-9) return G.probRac8(n);
      const prod = pick(['do queijo', 'da carne', 'do feijão', 'do café', 'da uva', 'do tomate', 'da farinha']);
      const aa = alt8({ t: fmtR(certa), v: certa }, [{ t: fmtR(preco + Math.round(kg * 100)), v: preco + Math.round(kg * 100), erro: 'somou em vez de multiplicar' }, { t: fmtR(Math.round(preco / kg)), v: Math.round(preco / kg), erro: 'dividiu em vez de multiplicar' }, { t: fmtR(certa * 10), v: certa * 10, erro: 'errou a vírgula' }, { t: fmtR(Math.round(certa / 10)), v: Math.round(certa / 10), erro: 'errou a vírgula' }]);
      return { ...aa, text: `O quilo ${prod} custa ${fmtR(preco)}. Quanto custam ${nD(kg)} kg?`, meta: { expr: `${nD(kg)} × ${preco}`, cent: 1 }, chave: `pr8k${kg}-${preco}` };
    }
    let a, b; do{ a = rnd(1, 4); b = rnd(3, 8); } while(a >= b || mdc2(a, b) !== 1);
    const N = b * rnd(3, 15), certa = N * (b - a) / b;
    const coisa = pick([['Um tanque tem', 'litros de água', 'Foram usados', 'Quantos litros sobraram?'], ['Um livro tem', 'páginas', 'Já foram lidas', 'Quantas páginas faltam ler?'], ['Uma turma tem', 'alunos', 'Foram ao passeio', 'Quantos alunos ficaram na escola?'], ['Uma caixa tem', 'laranjas', 'Foram vendidas', 'Quantas laranjas sobraram?']]);
    const aa = alt8(nv8(certa), [{ t: nD(N * a / b), v: N * a / b, erro: 'calculou a parte usada, não o que sobrou' }, { t: nD(N / b), v: N / b, erro: 'fez só a divisão' }, { t: nD(N - a), v: N - a, erro: 'subtraiu o numerador' }, { t: nD(N - b), v: N - b, erro: 'subtraiu o denominador' }], viz8(certa));
    return { ...aa, text: `${coisa[0]} ${N} ${coisa[1]}. ${coisa[2]} ${a}/${b} do total. ${coisa[3]}`, meta: { expr: `${N} − ${N} × ${a}/${b}` }, chave: `pr8f${N}${a}${b}` };
  }
  let a, b, c, d;
  do{ a = rnd(1, 3); b = rnd(2, 5); c = rnd(1, 3); d = rnd(2, 5); } while(a >= b || c >= d || mdc2(a, b) !== 1 || mdc2(c, d) !== 1);
  const S = b * d * rnd(2, Math.max(2, Math.floor(600 / (b * d))));
  const resto1 = S - S * a / b, certa = resto1 - resto1 * c / d;
  const nome = pick(NOMES);
  const aa = alt8({ t: fmtR(certa * 100), v: certa }, [{ t: fmtR((S - S * a / b - S * c / d) * 100), v: S - S * a / b - S * c / d, erro: `calculou ${c}/${d} do total, não do que sobrou` }, { t: fmtR(resto1 * 100), v: resto1, erro: 'esqueceu a segunda compra' }, { t: fmtR(resto1 * c / d * 100), v: resto1 * c / d, erro: 'deu o valor da segunda compra' }, { t: fmtR(S * a / b * 100), v: S * a / b, erro: 'deu o valor da primeira compra' }].filter(e => e.v > 0 && Number.isInteger(e.v * 100)), [5, -5, 10, -10, 20].map(k => ({ t: fmtR((certa + k) * 100), v: certa + k, erro: 'errou a conta' })).filter(e => e.v > 0));
  return { ...aa, text: `${nome} recebeu ${fmtR(S * 100)}. Gastou ${a}/${b} com roupas e, do que sobrou, ${c}/${d} com um presente. Quanto dinheiro sobrou?`, meta: { expr: `(${S} − ${S} × ${a}/${b}) × (1 − ${c}/${d})`, reais: 1 }, chave: `pr8c${S}${a}${b}${c}${d}` };
};
C.probRac8 = m => { const v = ev8(m.expr); return m.cent ? fmtR(Math.round(v)) : m.reais ? fmtR(Math.round(v * 100)) : nD(Math.round(v * 1000) / 1000); };

/* Sequências: termo geral (não recursiva) e recursiva (EF08MA10 · EF08MA11) */
G.seq8 = n => {
  if(n === 1){
    const p = rnd(2, 9), q = sortearAte(() => rnd(-6, 9), v => v !== 0), k = rnd(6, 30);
    const certa = p * k + q, lei = pol8(p, q, 'n');
    const aa = alt8(nv8(certa), [{ t: nD(p * k), v: p * k, erro: `esqueceu o ${q > 0 ? '+' : '−'} ${Math.abs(q)}` }, { t: nD(p + k + q), v: p + k + q, erro: 'somou em vez de multiplicar' }, { t: nD(p * (k - 1) + q), v: p * (k - 1) + q, erro: 'usou a posição anterior' }, { t: nD(p * (k + q)), v: p * (k + q), erro: 'somou antes de multiplicar' }], viz8(certa));
    return { ...aa, text: `Uma sequência tem termo geral aₙ = ${lei}. Qual é o ${k}º termo?`, meta: { lei, k, modo: 'termo' }, chave: `sq8${p},${q},${k}` };
  }
  if(n === 2){
    const p = sortearAte(() => rnd(-4, 7), v => v !== 0 && v !== 1), q = sortearAte(() => rnd(-6, 9), v => v !== 0 && v !== -p);
    const termos = [1, 2, 3, 4].map(i => p * i + q);
    const a1 = termos[0];
    const cand = [[p, q, null], [1, p, 'somou a diferença ao n'], [p, a1, 'usou o 1º termo como o número somado'], [a1, p, 'trocou a diferença com o 1º termo'], [p, -q, 'errou o sinal do número somado'], [p + 1, q - 1, 'errou a diferença']];
    const vis = new Set(), itens = [];
    cand.forEach(([a, b, e]) => { const sig = [1, 2, 3, 4].map(i => a * i + b).join(','); if(!vis.has(sig) && a !== 0){ vis.add(sig); itens.push({ t: 'aₙ = ' + pol8(a, b, 'n'), v: null, erro: e }); } });
    const aa = alt8(itens[0], itens.slice(1));
    return { ...aa, text: `Os primeiros termos de uma sequência são ${termos.map(nD).join(', ')}, … Qual expressão dá o termo da posição n?`, meta: { termos, modo: 'lei' }, chave: `sq8l${p},${q}` };
  }
  if(Math.random() < .5){
    const r = pick([2, 3]), t = rnd(-1, 3), s = rnd(1, 4), alvo = r === 3 ? 4 : 5;
    const seq = [s]; for(let i = 1; i < alvo + 1; i++) seq.push(r * seq[i - 1] + t);
    const certa = seq[alvo - 1];
    const lei = `aₙ = ${r}·aₙ₋₁${t ? (t > 0 ? ' + ' + t : ' − ' + (-t)) : ''}`;
    const aa = alt8(nv8(certa), [{ t: nD(seq[alvo - 2]), v: seq[alvo - 2], erro: 'parou um termo antes' }, { t: nD(seq[alvo]), v: seq[alvo], erro: 'fez um termo a mais' }, { t: nD(s * Math.pow(r, alvo - 1)), v: s * Math.pow(r, alvo - 1), erro: `esqueceu o ${t > 0 ? '+' : '−'} ${Math.abs(t)}` }, { t: nD(s + (alvo - 1) * (r + t)), v: s + (alvo - 1) * (r + t), erro: 'somou em vez de multiplicar' }], viz8(certa));
    return { ...aa, text: `Numa sequência, a₁ = ${s} e ${lei} (cada termo é ${r} vezes o anterior${t ? (t > 0 ? ' mais ' + t : ' menos ' + (-t)) : ''}). Quanto vale a${String.fromCharCode(8320 + alvo)}?`, meta: { s, r, t, alvo, modo: 'rec' }, chave: `sq8r${s},${r},${t}` };
  }
  const x = rnd(1, 5), y = rnd(1, 6), alvo = pick([6, 7]);
  const seq = [x, y]; while(seq.length < alvo + 1) seq.push(seq[seq.length - 1] + seq[seq.length - 2]);
  const certa = seq[alvo - 1];
  const aa = alt8(nv8(certa), [{ t: nD(seq[alvo - 2]), v: seq[alvo - 2], erro: 'parou um termo antes' }, { t: nD(seq[alvo]), v: seq[alvo], erro: 'fez um termo a mais' }, { t: nD(seq[alvo - 2] * 2), v: seq[alvo - 2] * 2, erro: 'dobrou o anterior' }], viz8(certa));
  return { ...aa, text: `Numa sequência, a₁ = ${x}, a₂ = ${y} e cada termo, a partir do 3º, é a soma dos DOIS anteriores (aₙ = aₙ₋₁ + aₙ₋₂). Quanto vale a${String.fromCharCode(8320 + alvo)}?`, meta: { x, y, alvo, modo: 'fib' }, chave: `sq8f${x},${y},${alvo}` };
};
C.seq8 = m => {
  if(m.modo === 'termo') return nD(ev8(m.lei, { n: m.k }));
  if(m.modo === 'lei'){ const d = m.termos[1] - m.termos[0], b = m.termos[0] - d; return 'aₙ = ' + pol8(d, b, 'n'); }
  if(m.modo === 'rec'){ let a = m.s; for(let i = 2; i <= m.alvo; i++) a = m.r * a + m.t; return nD(a); }
  let a = m.x, b = m.y; for(let i = 3; i <= m.alvo; i++) [a, b] = [b, a + b]; return nD(m.alvo === 1 ? m.x : b);
};

/* Valor numérico, monômios e fator comum (EF08MA06) */
const FORMAS8 = ['x² + {k}y', '{k}x − y²', '(x + y)²', 'x·y − {k}', '2x² − y', 'x² − y²', '{k}x² + y'];
G.alg8 = n => {
  if(n === 1){
    const f = pick(FORMAS8), k = rnd(2, 5);
    const x = sortearAte(() => rnd(-5, 5), v => v !== 0), y = sortearAte(() => rnd(-5, 5), v => v !== 0 && v !== x);
    const expr = f.replace('{k}', k), vx = { x, y };
    const v = ev8(expr, vx);
    // erros típicos: (−3)² feito como −9 ; 2x² feito como (2x)² ; sinal de y esquecido
    const errTroca = ev8(expr, { x: y, y: x }), errSep = expr === '(x + y)²' ? x * x + y * y : null;
    const errSq = (() => { try{ return ev8(expr.replace(/x²/g, `(${x < 0 ? '−' : ''}${Math.abs(x)}·${Math.abs(x)})`).replace(/y²/g, `(${y < 0 ? '−' : ''}${Math.abs(y)}·${Math.abs(y)})`), vx); }catch(e){ return null; } })();
    const errCoef = /\dx²/.test(expr) ? ev8(expr.replace(/(\d)x²/, '($1x)²'), vx) : null;
    const errSinal = ev8(expr, { x, y: -y });
    const aa = alt8(nv8(v), [errSq !== null && { t: nD(errSq), v: errSq, erro: 'errou o sinal do quadrado: (−3)² = +9' }, errCoef !== null && { t: nD(errCoef), v: errCoef, erro: 'elevou o coeficiente também: 2x² é 2·x·x' }, { t: nD(errSinal), v: errSinal, erro: 'errou o sinal de y' }, { t: nD(errTroca), v: errTroca, erro: 'trocou os valores de x e y' }, errSep !== null && { t: nD(errSep), v: errSep, erro: 'elevou cada parcela separado: (x + y)² não é x² + y²' }], viz8(v));
    const sx = x < 0 ? `−${-x}` : x, sy = y < 0 ? `−${-y}` : y;
    return { ...aa, text: `Calcule o valor de ${expr} para x = ${sx} e y = ${sy}.`, meta: { expr, x, y, modo: 'vn' }, chave: `al8${expr}${x},${y}` };
  }
  if(n === 2){
    if(Math.random() < .5){
      const a = rnd(2, 9), b = rnd(2, 9), c = rnd(1, 8), e = pick([1, 2, 3]);
      const xe = e === 1 ? 'x' : 'x' + sup8(e), mon = (k, ee = e) => (k === 1 ? '' : k === -1 ? '−' : nD(k)) + (ee === 1 ? 'x' : 'x' + sup8(ee));
      const r = a + b - c;
      if(r === 0) return G.alg8(n);
      const expr = `${a}${xe} + ${b}${xe} − ${c}${xe}`;
      const aa = alt8({ t: mon(r), v: r * Math.pow(1.37, e) }, [{ t: mon(r, 3 * e), v: r * Math.pow(1.37, 3 * e), erro: 'somou os expoentes (na soma, o expoente não muda)' }, { t: mon(a + b + c), v: (a + b + c) * Math.pow(1.37, e), erro: 'somou todos os coeficientes' }, { t: nD(r), v: r, erro: 'sumiu com a letra' }, a * b - c !== 0 && { t: mon(a * b - c), v: (a * b - c) * Math.pow(1.37, e), erro: 'multiplicou os coeficientes' }], [1, -1, 2, -2, 3, -3].map(k => r + k !== 0 && { t: mon(r + k), v: (r + k) * Math.pow(1.37, e), erro: 'errou a conta dos coeficientes' }));
      return { ...aa, text: `Simplifique: ${expr}`, meta: { expr, modo: 'poli' }, chave: `al8s${expr}` };
    }
    const a = rnd(2, 7), b = rnd(2, 7), p = rnd(1, 3), q = rnd(1, 4);
    const X = e => e === 1 ? 'x' : 'x' + sup8(e);
    const expr = `(${a}${X(p)}) · (${b}${X(q)})`;
    const cand = [[a * b, p + q, null], [a * b, p * q, 'multiplicou os expoentes (no produto, soma)'], [a + b, p + q, 'somou os coeficientes'], [a * b, Math.max(p, q), 'não somou os expoentes'], [a + b, p * q, 'somou os coeficientes e multiplicou os expoentes']];
    const itens = cand.map(([c, e, er]) => ({ t: nD(c) + X(e), v: c * Math.pow(1.37, e), erro: er }));
    const aa = alt8(itens[0], itens.slice(1), [[a * b, p + q + 1], [a * b + 1, p + q], [a * b, p + q - 1]].map(([c, e]) => ({ t: nD(c) + X(e), v: c * Math.pow(1.37, e), erro: 'errou a conta' })));
    return { ...aa, text: `Calcule o produto: ${expr}`, meta: { expr, modo: 'poli' }, chave: `al8p${expr}` };
  }
  // n === 3: fator comum
  const k = rnd(2, 9);
  let a, b; do{ a = rnd(1, 7); b = sortearAte(() => rnd(-9, 9), v => v !== 0); } while(mdc2(a, Math.abs(b)) !== 1);
  const comX = Math.random() < .5;
  const s = v => v < 0 ? ` − ${-v}` : ` + ${v}`;
  const A = (c, v) => (c === 1 ? '' : nD(c)) + v;
  let expr, itens;
  if(!comX){
    expr = `${A(k * a, 'x')}${s(k * b)}`;
    itens = [[`${k}(${A(a, 'x')}${s(b)})`, null], [`${k}(${A(a, 'x')}${s(k * b)})`, 'dividiu só o primeiro termo'], [`${k}(${A(k * a, 'x')}${s(b)})`, 'dividiu só o segundo termo'], [`${k}(${A(a, 'x')}${s(-b)})`, 'errou o sinal dentro do parêntese'], [`${k * a}(x${s(b)})`, 'colocou em evidência um número que não divide os dois termos']];
  } else {
    expr = `${A(k * a, 'x²')}${s(k * b)}x`;
    itens = [[`${k}x(${A(a, 'x')}${s(b)})`, null], [`${k}(${A(a, 'x²')}${s(b)})`, 'esqueceu de colocar o x em evidência'], [`x(${A(k * a, 'x')}${s(b)})`, 'dividiu o segundo termo pelo número e não o primeiro'], [`${k}x(${A(a, 'x²')}${s(b)})`, 'deixou x² dentro do parêntese'], [`${k}x(${a}${s(b)}x)`, 'dividiu o termo errado por x']];
  }
  const vx = t => ev8(t, { x: 1.37 });
  const aa = alt8({ t: itens[0][0], v: vx(itens[0][0]) }, itens.slice(1).map(([t, e]) => ({ t, v: vx(t), erro: e })));
  return { ...aa, text: `Fatore colocando o fator comum em evidência: ${expr}`, meta: { expr, opts: itens.map(i => i[0]), modo: 'fator', k, a, b, comX }, chave: `al8f${expr}` };
};
C.alg8 = m => {
  if(m.modo === 'vn') return nD(ev8(m.expr, { x: m.x, y: m.y }));
  if(m.modo === 'poli'){ const pts = [1.37, 2.11, 0.73], alvo = pts.map(x => ev8(m.expr, { x }));
    // acha o monômio cx^e que bate nos três pontos
    for(let e = 1; e <= 12; e++){ const c = alvo[0] / Math.pow(1.37, e); if(Math.abs(c - Math.round(c)) < 1e-6 && pts.every((x, i) => Math.abs(Math.round(c) * Math.pow(x, e) - alvo[i]) < 1e-6)){ const cc = Math.round(c); return (cc === 1 ? '' : cc === -1 ? '−' : nD(cc)) + (e === 1 ? 'x' : 'x' + sup8(e)); } }
    return null; }
  // fator: a forma com o MAIOR fator comum (k, e x se houver) que dá o mesmo valor
  const s = v => v < 0 ? ` − ${-v}` : ` + ${v}`, A = (c, v) => (c === 1 ? '' : nD(c)) + v;
  const t = m.comX ? `${m.k}x(${A(m.a, 'x')}${s(m.b)})` : `${m.k}(${A(m.a, 'x')}${s(m.b)})`;
  return [1.37, 2.9].every(x => Math.abs(ev8(t, { x }) - ev8(m.expr, { x })) < 1e-9) ? t : null;
};

/* ============================ 2º TRIMESTRE ============================ */

/* Porcentagem (EF08MA04/ES) */
G.porc8 = n => {
  if(n === 1){
    const p = pick([10, 20, 25, 50, 75, 5, 1, 30]), base = { 10: 10, 20: 5, 25: 4, 50: 2, 75: 4, 5: 20, 1: 100, 30: 10 }[p];
    const N = base * rnd(2, p === 1 ? 9 : 40), certa = N * p / 100;
    const aa = alt8(nv8(certa), [{ t: nD(N / p), v: N / p, erro: 'dividiu pelo número da porcentagem' }, { t: nD(N - certa), v: N - certa, erro: 'calculou o que sobra, não a parte' }, { t: nD(N * p / 10), v: N * p / 10, erro: 'errou a vírgula (dividiu por 10, não por 100)' }, { t: nD(p), v: p, erro: 'repetiu o número da porcentagem' }], viz8(certa));
    return { ...aa, text: `Quanto é ${p}% de ${nD(N)}?`, meta: { expr: `${p}/100 × ${N}`, suf: '' }, chave: `pc8${p}-${N}` };
  }
  if(n === 2){
    if(Math.random() < .5){
      const p = rnd(3, 19) * 5, N = 20 * rnd(2, 30), certa = N * p / 100;
      if(!Number.isInteger(certa)) return G.porc8(n);
      const aa = alt8(nv8(certa), [{ t: nD(N - certa), v: N - certa, erro: 'calculou o que sobra, não a parte' }, { t: nD(N * p / 10), v: N * p / 10, erro: 'errou a vírgula (dividiu por 10, não por 100)' }, { t: nD(N / 100 + p), v: N / 100 + p, erro: 'somou em vez de multiplicar' }], viz8(certa, '', 2));
      return { ...aa, text: `Quanto é ${p}% de ${nD(N)}?`, meta: { expr: `${p}/100 × ${N}`, suf: '' }, chave: `pc8b${p}-${N}` };
    }
    const T0 = pick([20, 25, 40, 50, 60, 80, 120, 200, 250, 300]), p = sortearAte(() => rnd(1, 19) * 5, v => Number.isInteger(T0 * v / 100) && v !== 50), parte = T0 * p / 100;
    const ctx = pick([['Numa turma de', 'alunos', 'usam óculos'], ['Numa caixa com', 'lâmpadas', 'estão queimadas'], ['Numa prova com', 'questões', 'foram acertadas'], ['Num pomar com', 'árvores', 'dão manga']]);
    const aa = alt8({ t: p + '%', v: p }, [{ t: (100 - p) + '%', v: 100 - p, erro: 'calculou a parte que falta' }, { t: parte + '%', v: parte, erro: 'achou que a quantidade já é a porcentagem' }, { t: Math.round(T0 / parte * 10) / 10 === Math.round(T0 / parte) ? Math.round(T0 / parte) + '%' : null, v: Math.round(T0 / parte), erro: 'dividiu o total pela parte' }].filter(e => e.t && e.v !== p), [5, -5, 10, -10].map(k => p + k > 0 && p + k < 100 && { t: (p + k) + '%', v: p + k, erro: 'errou a conta' }));
    return { ...aa, text: `${ctx[0]} ${T0} ${ctx[1]}, ${parte} ${ctx[2]}. Que porcentagem isso representa?`, meta: { expr: `${parte}/${T0} × 100`, suf: '%' }, chave: `pc8q${T0}-${parte}` };
  }
  const P = rnd(4, 60) * 10, p = pick([10, 15, 20, 25, 30, 40]);
  const desc = P * p / 100, fim = P - desc;
  if(Math.random() < .55){
    const acr = Math.random() < .35, certa = acr ? P + desc : fim;
    const aa = alt8({ t: fmtR(certa * 100), v: certa }, [{ t: fmtR(desc * 100), v: desc, erro: acr ? 'calculou só o aumento' : 'calculou só o desconto' }, { t: fmtR((acr ? P - desc : P + desc) * 100), v: acr ? P - desc : P + desc, erro: acr ? 'tirou em vez de somar' : 'somou em vez de tirar' }, { t: fmtR((acr ? P + p : P - p) * 100), v: acr ? P + p : P - p, erro: `${acr ? 'somou' : 'tirou'} ${p} reais, não ${p}%` }], [10, -10, 5].map(k => ({ t: fmtR((certa + k) * 100), v: certa + k, erro: 'errou a conta' })));
    return { ...aa, text: `Um produto custa ${fmtR(P * 100)} e teve ${acr ? 'um AUMENTO' : 'um DESCONTO'} de ${p}%. Qual é o novo preço?`, meta: { expr: `${P} × (1 ${acr ? '+' : '−'} ${p}/100)` }, chave: `pc8d${P}-${p}${acr}` };
  }
  const aa = alt8({ t: fmtR(P * 100), v: P }, [{ t: fmtR(Math.round(fim * (1 + p / 100) * 100)), v: Math.round(fim * (1 + p / 100) * 100) / 100, erro: `somou ${p}% do preço com desconto (a base é o preço antigo)` }, { t: fmtR((fim + p) * 100), v: fim + p, erro: `somou ${p} reais` }, { t: fmtR(Math.round(fim * (1 - p / 100) * 100)), v: Math.round(fim * (1 - p / 100) * 100) / 100, erro: 'tirou a porcentagem de novo' }], [10, -10].map(k => ({ t: fmtR((P + k) * 100), v: P + k, erro: 'errou a conta' })));
  return { ...aa, text: `Com ${p}% de desconto, uma pessoa pagou ${fmtR(fim * 100)}. Qual era o preço antes do desconto?`, meta: { expr: `${nD(fim)} / (1 − ${p}/100)` }, chave: `pc8r${P}-${p}` };
};
C.porc8 = m => { const v = ev8(m.expr); return m.suf !== undefined ? nD(Math.round(v * 1000) / 1000) + m.suf : fmtR(Math.round(v * 100)); };

/* Tabela de frequência com classes (EF08MA24) */
function listaValoresSVG(vals, titulo){
  const col = 6, cw = 92, rh = 54, W = col * cw + 20, lin = Math.ceil(vals.length / col);
  let o = T(W / 2, 32, titulo, { fs: 22 });
  vals.forEach((v, i) => { const x = 10 + (i % col) * cw, y = 48 + Math.floor(i / col) * rh; o += `<rect x="${x + 3}" y="${y}" width="${cw - 6}" height="${rh - 8}" rx="8" fill="#f1f5f9" stroke="#475569" stroke-width="2"/>` + T(x + cw / 2, y + 33, v, { fs: 26 }); });
  return SVG(W, 60 + lin * rh, o);
}
G.classes8 = n => {
  const ctx = pick([{ nome: 'Altura dos alunos (cm)', ini: 140, larg: 5, k: 4 }, { nome: 'Massa dos atletas (kg)', ini: 50, larg: 10, k: 4 }, { nome: 'Nota na prova (0 a 100)', ini: 40, larg: 15, k: 4 }, { nome: 'Tempo na corrida (min)', ini: 20, larg: 5, k: 4 }]);
  const tot = n === 3 ? pick([20, 25]) : rnd(14, 18);
  const lim = i => ctx.ini + i * ctx.larg;
  let vals, cont;
  const gera = () => {
    const v = [];
    for(let i = 0; i < ctx.k; i++) v.push(lim(i));                                   // cada limite de baixo aparece (fica na própria classe)
    v.push(lim(1)); v.push(lim(2));
    while(v.length < tot) v.push(rnd(lim(0), lim(ctx.k) - 1));
    return shuffle(v);
  };
  const conta = (v, i, incluiTopo) => v.filter(x => x >= lim(i) && (incluiTopo ? x <= lim(i + 1) : x < lim(i + 1))).length;
  vals = sortearAte(gera, v => { const c = [0, 1, 2, 3].map(i => conta(v, i)); return new Set(c).size >= 3 && c.filter(x => x === Math.max(...c)).length === 1; });
  cont = [0, 1, 2, 3].map(i => conta(vals, i));
  const cl = i => `${lim(i)} ⊢ ${lim(i + 1)}`;
  const img = svgURI(listaValoresSVG(vals, ctx.nome));
  const leg = '(a ⊢ b: de a até b, sem incluir o b)';
  if(n === 2){
    const iM = cont.indexOf(Math.max(...cont)), comTopo = [0, 1, 2, 3].map(i => conta(vals, i, true)), iT = comTopo.indexOf(Math.max(...comTopo));
    const aa = alt8({ t: cl(iM), v: null }, [0, 1, 2, 3].filter(i => i !== iM).map(i => ({ t: cl(i), v: null, erro: i === iT ? 'contou o valor do limite de cima dentro da classe' : 'contou errado' })));
    return { ...aa, text: `Qual classe tem MAIS valores? ${leg}`, image: img, meta: { vals, ini: ctx.ini, larg: ctx.larg, modo: 'maior' }, chave: 'cl8m' + vals.join(',') };
  }
  const i = rnd(1, 2), c = cont[i], cT = conta(vals, i, true), cE = vals.filter(x => x > lim(i) && x < lim(i + 1)).length;
  if(n === 1){
    const aa = alt8(nv8(c), [{ t: nD(cT), v: cT, erro: 'contou o valor do limite de cima (ele é da classe seguinte)' }, { t: nD(cE), v: cE, erro: 'deixou de fora o valor do limite de baixo' }, { t: nD(cont[i + 1]), v: cont[i + 1], erro: 'contou a classe seguinte' }, { t: nD(cont[i - 1]), v: cont[i - 1], erro: 'contou a classe anterior' }], viz8(c));
    return { ...aa, text: `Quantos valores estão na classe ${cl(i)}? ${leg}`, image: img, meta: { vals, ini: ctx.ini, larg: ctx.larg, i, modo: 'conta' }, chave: 'cl8c' + i + vals.join(',') };
  }
  const pc = c * 100 / tot;
  const aa = alt8({ t: nD(pc) + '%', v: pc }, [{ t: nD(c) + '%', v: c, erro: 'deu a quantidade, não a porcentagem' }, { t: nD(cT * 100 / tot) + '%', v: cT * 100 / tot, erro: 'contou o valor do limite de cima' }, { t: nD(cE * 100 / tot) + '%', v: cE * 100 / tot, erro: 'deixou de fora o limite de baixo' }], [4, -4, 5, -5, 10].map(k => pc + k > 0 && { t: nD(pc + k) + '%', v: pc + k, erro: 'errou a conta' }));
  return { ...aa, text: `São ${tot} valores. Que porcentagem deles está na classe ${cl(i)}? ${leg}`, image: img, meta: { vals, ini: ctx.ini, larg: ctx.larg, i, modo: 'pct' }, chave: 'cl8p' + i + vals.join(',') };
};
C.classes8 = m => {
  const faixa = j => [m.ini + j * m.larg, m.ini + (j + 1) * m.larg];
  const quantos = j => { let k = 0; for(const v of m.vals){ const [a, b] = faixa(j); if(a <= v && v < b) k++; } return k; };
  if(m.modo === 'maior'){ let best = 0; for(let j = 1; j < 4; j++) if(quantos(j) > quantos(best)) best = j; const [a, b] = faixa(best); return `${a} ⊢ ${b}`; }
  if(m.modo === 'conta') return nD(quantos(m.i));
  return nD(quantos(m.i) / m.vals.length * 100) + '%';
};

/* Qual gráfico usar (EF08MA23) */
const GRAF8 = {
  setores: ['Gráfico de setores (pizza)', ['como os alunos da turma se dividem entre os sabores de sorvete preferidos (partes de um todo)', 'a porcentagem de votos de cada chapa na eleição do grêmio', 'como o salário da família é dividido entre aluguel, comida, transporte e lazer', 'que parte do lixo da escola é papel, plástico, orgânico ou metal']],
  linhas: ['Gráfico de linhas', ['a temperatura de uma cidade em cada dia da semana (subiu? desceu?)', 'o crescimento de uma planta medido mês a mês', 'o preço da gasolina de janeiro a dezembro', 'o número de visitantes de um parque em cada ano, de 2018 a 2026']],
  colunas: ['Gráfico de colunas', ['a quantidade de alunos de cada turma da escola', 'os gols marcados por cada time do campeonato', 'a quantidade de livros emprestados de cada tipo (aventura, poesia, HQ…)', 'a população das cinco maiores cidades do Espírito Santo']],
  duplas: ['Gráfico de colunas duplas (agrupadas)', ['comparar o esporte preferido dos MENINOS e das MENINAS', 'comparar as notas da turma A e da turma B em cada disciplina', 'comparar, em cada bairro, quantas casas têm e quantas não têm internet', 'comparar as vendas da cantina no 1º e no 2º semestre, produto por produto']],
};
const ERRO_GRAF8 = { setores: 'setores mostram partes de um todo (as fatias somam 100%)', linhas: 'linhas mostram como algo muda ao longo do tempo', colunas: 'colunas comparam quantidades de categorias', duplas: 'colunas duplas comparam dois grupos em cada categoria' };
G.grafAdeq8 = n => {
  const tipos = n === 1 ? ['setores', 'linhas', 'colunas'] : ['setores', 'linhas', 'colunas', 'duplas'];
  const tipo = pick(tipos), sit = pick(GRAF8[tipo][1]);
  const aa = alt8({ t: GRAF8[tipo][0], v: null }, Object.keys(GRAF8).filter(k => k !== tipo).map(k => ({ t: GRAF8[k][0], v: null, erro: `escolheu ${GRAF8[k][0].toLowerCase()}, mas ${ERRO_GRAF8[k]}` })));
  return { ...aa, text: `Qual gráfico é o MAIS adequado para mostrar ${sit}?`, meta: { sit }, chave: 'ga8' + sit };
};
C.grafAdeq8 = m => GRAF8[Object.keys(GRAF8).find(k => GRAF8[k][1].includes(m.sit))][0];

/* Média, moda, mediana e amplitude (EF08MA25) */
const ordena8 = v => v.slice().sort((a, b) => a - b);
const mediana8 = v => { const s = ordena8(v), k = s.length; return k % 2 ? s[(k - 1) / 2] : (s[k / 2 - 1] + s[k / 2]) / 2; };
const media8 = v => v.reduce((a, b) => a + b, 0) / v.length;
const moda8 = v => { const c = {}; v.forEach(x => c[x] = (c[x] || 0) + 1); const mx = Math.max(...Object.values(c)); const m = Object.keys(c).filter(k => c[k] === mx); return m.length === 1 ? +m[0] : null; };
G.medidas8 = n => {
  const ctx = pick(['Gols do time em cada jogo', 'Idades dos primos', 'Notas de Ana nas provas', 'Pontos de um jogador em cada partida', 'Livros lidos por aluno no mês']);
  let vals, pergunta;
  if(n === 1){
    pergunta = pick(['moda', 'amplitude']);
    vals = sortearAte(() => { const v = Array.from({ length: 7 }, () => rnd(1, 15)); v[rnd(0, 6)] = v[rnd(0, 6)]; return v; }, v => moda8(v) !== null && moda8(v) !== Math.max(...v) && mediana8(v) !== moda8(v) && ordena8(v).join() !== v.join());
  } else if(n === 2){
    pergunta = 'mediana';
    vals = sortearAte(() => Array.from({ length: pick([7, 9]) }, () => rnd(2, 30)), v => { const s = ordena8(v); return v[(v.length - 1) / 2] !== mediana8(v) && media8(v) !== mediana8(v) && s[0] !== s[1]; });
  } else {
    pergunta = pick(['media', 'mediana']);
    vals = sortearAte(() => Array.from({ length: pergunta === 'media' ? pick([5, 6]) : 6 }, () => rnd(2, 30)), v => pergunta === 'media' ? Number.isInteger(media8(v)) && media8(v) !== mediana8(v) : !Number.isInteger(mediana8(v)) && ordena8(v)[2] !== ordena8(v)[3]);
  }
  const s = ordena8(vals), mx = s[s.length - 1], mn = s[0];
  const certo = { moda: moda8(vals), amplitude: mx - mn, mediana: mediana8(vals), media: media8(vals) }[pergunta];
  const e = [];
  if(pergunta === 'moda') e.push({ t: nD(mx), v: mx, erro: 'pegou o maior valor' }, { t: nD(mediana8(vals)), v: mediana8(vals), erro: 'calculou a mediana' }, { t: nD(vals.filter(x => x === certo).length), v: vals.filter(x => x === certo).length, erro: 'deu quantas vezes aparece, não o valor' });
  if(pergunta === 'amplitude') e.push({ t: nD(mx), v: mx, erro: 'deu só o maior valor' }, { t: nD(mx + mn), v: mx + mn, erro: 'somou maior e menor' }, { t: nD(vals[vals.length - 1] - vals[0] > 0 ? vals[vals.length - 1] - vals[0] : vals[0] - vals[vals.length - 1]), v: Math.abs(vals[vals.length - 1] - vals[0]), erro: 'usou o último e o primeiro da lista, sem ordenar' });
  if(pergunta === 'mediana'){
    const k = vals.length;
    if(k % 2) e.push({ t: nD(vals[(k - 1) / 2]), v: vals[(k - 1) / 2], erro: 'pegou o do meio sem colocar em ordem' });
    else e.push({ t: nD(s[k / 2 - 1]), v: s[k / 2 - 1], erro: 'com quantidade par, a mediana é a média dos DOIS do meio' }, { t: nD(s[k / 2]), v: s[k / 2], erro: 'com quantidade par, a mediana é a média dos DOIS do meio' }, { t: nD((vals[k / 2 - 1] + vals[k / 2]) / 2), v: (vals[k / 2 - 1] + vals[k / 2]) / 2, erro: 'não colocou em ordem' });
    e.push({ t: nD(Math.round(media8(vals) * 10) / 10), v: Math.round(media8(vals) * 10) / 10, erro: 'calculou a média' });
  }
  if(pergunta === 'media') e.push({ t: nD(mediana8(vals)), v: mediana8(vals), erro: 'calculou a mediana' }, { t: nD(vals.reduce((a, b) => a + b, 0)), v: vals.reduce((a, b) => a + b, 0), erro: 'somou e esqueceu de dividir' }, { t: nD(Math.round(vals.reduce((a, b) => a + b, 0) / (vals.length - 1) * 10) / 10), v: Math.round(vals.reduce((a, b) => a + b, 0) / (vals.length - 1) * 10) / 10, erro: 'dividiu pela quantidade errada' });
  const aa = alt8(nv8(certo), e, viz8(certo));
  const nomeP = { moda: 'a MODA', amplitude: 'a AMPLITUDE', mediana: 'a MEDIANA', media: 'a MÉDIA' }[pergunta];
  return { ...aa, text: `${ctx}: ${vals.join(', ')}. Qual é ${nomeP}?`, meta: { vals, pergunta }, chave: 'md8' + pergunta + vals.join(',') };
};
C.medidas8 = m => {                             // outro caminho: contagem direta, sem ordenar com sort
  const v = m.vals.slice(), k = v.length;
  if(m.pergunta === 'amplitude') return nD(Math.max(...v) - Math.min(...v));
  if(m.pergunta === 'media'){ let s = 0; for(const x of v) s += x; return nD(s / k); }
  if(m.pergunta === 'moda'){ let best = null, bc = 0; for(const x of v){ const c = v.filter(y => y === x).length; if(c > bc){ bc = c; best = x; } } return nD(best); }
  const kth = j => v.find(x => v.filter(y => y < x).length <= j && v.filter(y => y <= x).length > j);   // j-ésimo menor (0 = menor)
  return nD(k % 2 ? kth((k - 1) / 2) : (kth(k / 2 - 1) + kth(k / 2)) / 2);
};

/* Princípio multiplicativo (EF08MA03) */
G.contagem8 = n => {
  if(n === 1){
    const a = rnd(2, 6), b = rnd(2, 6), ctx = pick([[`${a} camisetas e ${b} bermudas`, 'conjuntos diferentes (1 camiseta + 1 bermuda) dá para montar'], [`${a} tipos de pão e ${b} tipos de recheio`, 'sanduíches diferentes (1 pão + 1 recheio) dá para montar'], [`${a} caminhos da casa até a praça e ${b} caminhos da praça até a escola`, 'modos diferentes existem para ir da casa à escola passando pela praça']]);
    const certa = a * b;
    const aa = alt8(nv8(certa), [{ t: nD(a + b), v: a + b, erro: 'somou em vez de multiplicar' }, { t: nD(certa * 2), v: certa * 2, erro: 'contou cada conjunto duas vezes' }, { t: nD(Math.pow(a, b)), v: Math.pow(a, b), erro: 'fez potência' }], viz8(certa));
    return { ...aa, text: `Com ${ctx[0]}, quantos ${ctx[1]}?`, meta: { expr: `${a} × ${b}` }, chave: `ct8${a}x${b}${ctx[1].slice(0, 4)}` };
  }
  if(n === 2){
    const modo = pick(['tres', 'senhaRep', 'senhaSem']);
    if(modo === 'tres'){
      const a = rnd(2, 5), b = rnd(2, 5), c = rnd(2, 4), certa = a * b * c;
      const aa = alt8(nv8(certa), [{ t: nD(a + b + c), v: a + b + c, erro: 'somou em vez de multiplicar' }, { t: nD(a * b), v: a * b, erro: 'esqueceu a 3ª escolha' }, { t: nD(a * b + c), v: a * b + c, erro: 'somou a 3ª escolha' }], viz8(certa));
      return { ...aa, text: `Uma lanchonete tem ${a} sanduíches, ${b} sucos e ${c} sobremesas. Quantos combos diferentes (1 de cada) dá para montar?`, meta: { expr: `${a} × ${b} × ${c}` }, chave: `ct8t${a}${b}${c}` };
    }
    const d = rnd(3, 4), rep = modo === 'senhaRep';
    const certa = rep ? Math.pow(10, d) : [10, 9, 8, 7].slice(0, d).reduce((x, y) => x * y, 1);
    const outra = rep ? [10, 9, 8, 7].slice(0, d).reduce((x, y) => x * y, 1) : Math.pow(10, d);
    const aa = alt8(nv8(certa), [{ t: nD(outra), v: outra, erro: rep ? 'não deixou repetir algarismo' : 'deixou repetir algarismo' }, { t: nD(10 * d), v: 10 * d, erro: 'multiplicou 10 pelo número de dígitos' }, { t: nD(10 + 9 + 8 + (d === 4 ? 7 : 0)), v: 10 + 9 + 8 + (d === 4 ? 7 : 0), erro: 'somou em vez de multiplicar' }, { t: nD(Math.pow(9, d)), v: Math.pow(9, d), erro: 'esqueceu o zero' }], viz8(certa));
    return { ...aa, text: `Uma senha tem ${d} dígitos (de 0 a 9)${rep ? ', e PODE repetir dígito' : ', todos DIFERENTES'}. Quantas senhas são possíveis?`, meta: { d, rep, modo: 'senha' }, chave: `ct8s${d}${rep}` };
  }
  const modo = pick(['fila', 'distintos', 'cartoes']);
  if(modo === 'fila'){
    const k = rnd(4, 6), certa = [1, 2, 3, 4, 5, 6].slice(0, k).reduce((x, y) => x * y, 1);
    const aa = alt8(nv8(certa), [{ t: nD(k * k), v: k * k, erro: 'multiplicou o número de pessoas por ele mesmo' }, { t: nD(k * (k + 1) / 2), v: k * (k + 1) / 2, erro: 'somou em vez de multiplicar' }, { t: nD(Math.pow(k, k)), v: Math.pow(k, k), erro: 'deixou a mesma pessoa em dois lugares' }, { t: nD(certa / k), v: certa / k, erro: 'esqueceu um lugar da fila' }], viz8(certa));
    return { ...aa, text: `De quantas maneiras diferentes ${k} amigos podem formar uma fila?`, meta: { k, modo: 'fila' }, chave: 'ct8f' + k };
  }
  if(modo === 'distintos'){
    const aa = alt8(nv8(648), [{ t: '720', v: 720, erro: 'deixou o número começar com zero' }, { t: '900', v: 900, erro: 'deixou repetir algarismo' }, { t: '504', v: 504, erro: 'tirou o zero de todas as posições' }, { t: '1000', v: 1000, erro: 'contou de 000 a 999' }]);
    return { ...aa, text: 'Quantos números de 3 algarismos, todos DIFERENTES, existem? (o número não pode começar com zero)', meta: { modo: 'distintos' }, chave: 'ct8d' };
  }
  const k = rnd(4, 7), m = rnd(2, 3), certa = m === 2 ? k * (k - 1) : k * (k - 1) * (k - 2);
  const aa = alt8(nv8(certa), [{ t: nD(Math.pow(k, m)), v: Math.pow(k, m), erro: 'deixou repetir cartão' }, { t: nD(k * m), v: k * m, erro: 'multiplicou pelo número de posições' }, { t: nD(m === 2 ? k * (k - 1) / 2 : k * (k - 1) * (k - 2) / 6), v: m === 2 ? k * (k - 1) / 2 : k * (k - 1) * (k - 2) / 6, erro: 'achou que a ordem não importa' }], viz8(certa));
  return { ...aa, text: `Há ${k} cartões com algarismos diferentes (sem o zero). Quantos números de ${m} algarismos diferentes dá para formar com eles?`, meta: { k, m, modo: 'cartoes' }, chave: `ct8c${k}${m}` };
};
C.contagem8 = m => {                             // outro caminho: contagem por força bruta
  if(m.expr) return nD(ev8(m.expr));
  if(m.modo === 'senha'){ let c = 0; const lim = Math.pow(10, m.d); for(let x = 0; x < lim; x++){ const s = String(x).padStart(m.d, '0'); if(m.rep || new Set(s).size === m.d) c++; } return nD(c); }
  if(m.modo === 'fila'){ const perm = a => a.length <= 1 ? 1 : a.reduce((s, _, i) => s + perm(a.filter((__, j) => j !== i)), 0); return nD(perm([...Array(m.k).keys()])); }
  if(m.modo === 'distintos'){ let c = 0; for(let x = 100; x <= 999; x++) if(new Set(String(x)).size === 3) c++; return nD(c); }
  let c = 0; const lim = Math.pow(m.k, m.m);
  for(let x = 0; x < lim; x++){ const dig = []; let y = x; for(let j = 0; j < m.m; j++){ dig.push(y % m.k); y = Math.floor(y / m.k); } if(new Set(dig).size === m.m) c++; }
  return nD(c);
};

/* Probabilidade com espaço amostral (EF08MA22) */
G.prob8 = n => {
  if(n === 1){
    if(Math.random() < .5){
      const p = rnd(1, 19) * 5;
      const aa = alt8({ t: (100 - p) + '%', v: 100 - p }, [{ t: p + '%', v: p, erro: 'repetiu a chance do evento' }, { t: (100 + p) + '%', v: 100 + p, erro: 'somou em vez de tirar de 100%' }, { t: nD(100 / p === Math.round(100 / p) ? 100 / p : 50) + '%', v: 100 / p === Math.round(100 / p) ? 100 / p : 50, erro: 'dividiu 100 pela chance' }], [5, -5, 10].map(k => ({ t: (100 - p + k) + '%', v: 100 - p + k, erro: 'errou a conta' })));
      return { ...aa, text: `A chance de chover amanhã é ${p}%. Qual é a chance de NÃO chover? (a soma das chances de tudo que pode acontecer é 100%)`, meta: { expr: `100 − ${p}`, suf: '%' }, chave: 'pb8c' + p };
    }
    let a, b; do{ a = rnd(1, 9); b = rnd(3, 12); } while(a >= b || mdc2(a, b) !== 1);
    const aa = alt8({ t: fr8(b - a, b), v: (b - a) / b }, [{ t: `${a}/${b}`, v: a / b, erro: 'repetiu a chance do evento' }, { t: `1/${b}`, v: 1 / b, erro: 'contou só um resultado' }, { t: fr8(b, a), v: b / a, erro: 'inverteu a fração' }, { t: fr8(b - a, a), v: (b - a) / a, erro: 'usou as azuis no denominador' }]);
    return { ...aa, text: `Numa urna, a chance de tirar uma bola AZUL é ${a}/${b}. Qual é a chance de NÃO tirar azul? (as chances de tudo que pode acontecer somam 1)`, meta: { expr: `1 − ${a}/${b}`, frac: 1 }, chave: 'pb8u' + a + b };
  }
  const evN2 = [
    { txt: 'Lançando uma moeda DUAS vezes, qual a chance de sair CARA nas duas?', fav: 1, tot: 4, err: [[1, 2, 'olhou só uma moeda'], [1, 3, 'achou que só há 3 resultados (CC, CK, KK)'], [2, 4, 'contou cara-coroa como favorável']] },
    { txt: 'Lançando uma moeda DUAS vezes, qual a chance de sair UMA cara e UMA coroa (em qualquer ordem)?', fav: 2, tot: 4, err: [[1, 4, 'esqueceu que cara-coroa e coroa-cara são diferentes'], [1, 3, 'achou que só há 3 resultados (CC, CK, KK)'], [3, 4, 'contou também as iguais']] },
    { txt: 'Lançando uma moeda e um dado, qual a chance de sair CARA e número PAR?', fav: 3, tot: 12, err: [[1, 2, 'olhou só a moeda'], [3, 8, 'somou os resultados (2 + 6) em vez de multiplicar'], [4, 12, 'contou errado os pares']] },
    { txt: 'Lançando uma moeda e um dado, qual a chance de sair COROA e um número MAIOR que 4?', fav: 2, tot: 12, err: [[2, 6, 'olhou só o dado'], [2, 8, 'somou os resultados (2 + 6) em vez de multiplicar'], [3, 12, 'contou o 4 como maior que 4']] },
    { txt: 'Lançando uma moeda e um dado, qual a chance de sair CARA e o número 6?', fav: 1, tot: 12, err: [[1, 6, 'olhou só o dado'], [2, 12, 'contou errado'], [1, 8, 'somou os resultados (2 + 6) em vez de multiplicar']] },
  ];
  const evN3 = [
    { txt: 'Lançando uma moeda TRÊS vezes, qual a chance de sair EXATAMENTE duas caras?', fav: 3, tot: 8, err: [[1, 8, 'contou só uma ordem (CCK)'], [2, 3, 'dividiu pelo número de moedas'], [4, 8, 'contou também as três caras']] },
    { txt: 'Lançando uma moeda TRÊS vezes, qual a chance de sair PELO MENOS uma cara?', fav: 7, tot: 8, err: [[1, 8, 'contou só "uma cara"'], [3, 8, 'contou só "exatamente uma cara"'], [1, 2, 'olhou só uma moeda']] },
    { txt: 'Lançando uma moeda TRÊS vezes, qual a chance de as três darem o MESMO lado?', fav: 2, tot: 8, err: [[1, 8, 'contou só CCC'], [1, 3, 'achou que são 3 resultados'], [3, 8, 'contou errado']] },
    { txt: 'Uma família quer ter 3 filhos. Considerando menino e menina igualmente prováveis, qual a chance de nascerem 2 meninas e 1 menino?', fav: 3, tot: 8, err: [[1, 8, 'contou só uma ordem'], [1, 4, 'achou que são 4 resultados (0, 1, 2 ou 3 meninas)'], [2, 3, 'dividiu pelo número de filhos']] },
    { txt: 'Uma senha tem 1 letra (A ou B) e 1 algarismo (1, 2 ou 3). Sorteando uma senha, qual a chance de ser A com número ímpar?', fav: 2, tot: 6, err: [[1, 6, 'contou só A1'], [2, 5, 'somou os resultados (2 + 3) em vez de multiplicar'], [2, 3, 'olhou só o número']] },
  ];
  if(n === 2 && Math.random() < .7){
    const lado = pick(['C', 'K']), tipo = pick(['par', 'impar', 'maior', 'menor', 'mult3', 'igual']);
    const k = tipo === 'maior' ? rnd(2, 4) : tipo === 'menor' ? rnd(3, 5) : tipo === 'igual' ? rnd(1, 6) : 0;
    const cond = COND_DADO8[tipo](k), favD = [1, 2, 3, 4, 5, 6].filter(cond.f).length;
    const aa = alt8({ t: fr8(favD, 12), v: favD / 12 }, [{ t: fr8(favD, 6), v: favD / 6, erro: 'olhou só o dado' }, { t: fr8(favD, 8), v: favD / 8, erro: 'somou os resultados (2 + 6) em vez de multiplicar' }, { t: fr8(favD + 1, 12), v: (favD + 1) / 12, erro: 'contou errado os números do dado' }, { t: fr8(favD * 2, 12), v: favD / 6, erro: 'contou os dois lados da moeda' }, { t: fr8(1, 12), v: 1 / 12, erro: 'contou só um resultado' }], [{ t: '1/2', v: 1 / 2, erro: 'olhou só a moeda' }, { t: fr8(favD + 2, 12), v: (favD + 2) / 12, erro: 'contou errado os números do dado' }]);
    return { ...aa, text: `Lançando uma moeda e um dado, qual a chance de sair ${lado === 'C' ? 'CARA' : 'COROA'} e ${cond.t}?`, meta: { md: 1, lado, tipo, k }, chave: `pb8m${lado}${tipo}${k}` };
  }
  if(n === 3 && Math.random() < .6){
    const tipo = pick(['exato', 'pelomenos', 'nomaximo']), k = tipo === 'exato' ? rnd(0, 3) : rnd(1, 2);
    const ctx = pick([['Lançando uma moeda TRÊS vezes', 'cara', 'caras', 'sair'], ['Uma família vai ter 3 filhos (menino e menina igualmente prováveis)', 'menina', 'meninas', 'nascer']]);
    const C3 = [1, 3, 3, 1], fav = tipo === 'exato' ? C3[k] : tipo === 'pelomenos' ? C3.slice(k).reduce((a, b) => a + b) : C3.slice(0, k + 1).reduce((a, b) => a + b);
    const qt = x => `${x} ${x === 1 ? ctx[1] : ctx[2]}`;
    const oque = tipo === 'exato' ? (k === 0 ? `NENHUMA ${ctx[1]}` : `EXATAMENTE ${qt(k)}`) : tipo === 'pelomenos' ? `PELO MENOS ${qt(k)}` : `NO MÁXIMO ${qt(k)}`;
    const aa = alt8({ t: fr8(fav, 8), v: fav / 8 }, [{ t: '1/8', v: 1 / 8, erro: 'contou só uma ordem' }, { t: fr8(C3[k], 8), v: C3[k] / 8, erro: 'contou só "exatamente"' }, { t: fr8(k || 1, 3), v: (k || 1) / 3, erro: 'dividiu pelo número de lançamentos' }, { t: fr8(1, 4), v: 1 / 4, erro: 'achou que são 4 resultados (0, 1, 2 ou 3)' }, { t: fr8(fav + 1, 8), v: (fav + 1) / 8, erro: 'contou um resultado a mais' }, { t: fr8(fav, 6), v: fav / 6, erro: 'errou o total de resultados (são 2 × 2 × 2 = 8)' }]);
    return { ...aa, text: `${ctx[0]}, qual a chance de ${ctx[3]} ${oque}?`, meta: { m3: 1, tipo, k }, chave: `pb8t${tipo}${k}${ctx[1]}` };
  }
  const ev = pick(n === 2 ? evN2.slice(0, 2) : evN3);
  const aa = alt8({ t: fr8(ev.fav, ev.tot), v: ev.fav / ev.tot }, ev.err.map(([a, b, e]) => ({ t: fr8(a, b), v: a / b, erro: e })), [{ t: fr8(ev.fav, ev.tot + 2), v: ev.fav / (ev.tot + 2), erro: 'errou o total de resultados' }, { t: fr8(ev.fav + 1, ev.tot), v: (ev.fav + 1) / ev.tot, erro: 'contou um resultado a mais' }, { t: fr8(1, ev.tot), v: 1 / ev.tot, erro: 'contou só um resultado' }]);
  return { ...aa, text: ev.txt, meta: { txt: ev.txt, frac: 1 }, chave: 'pb8e' + ev.txt };
};
const COND_DADO8 = {
  par: () => ({ t: 'número PAR', f: d => d % 2 === 0 }), impar: () => ({ t: 'número ÍMPAR', f: d => d % 2 === 1 }),
  maior: k => ({ t: `um número MAIOR que ${k}`, f: d => d > k }), menor: k => ({ t: `um número MENOR que ${k}`, f: d => d < k }),
  mult3: () => ({ t: 'um múltiplo de 3', f: d => d % 3 === 0 }), igual: k => ({ t: `o número ${k}`, f: d => d === k }),
};
C.prob8 = m => {
  if(m.m3){ let f = 0; for(let x = 0; x < 8; x++){ const c = (x & 1) + ((x >> 1) & 1) + ((x >> 2) & 1); if(m.tipo === 'exato' ? c === m.k : m.tipo === 'pelomenos' ? c >= m.k : c <= m.k) f++; } return fr8(f, 8); }
  if(m.md){ let f = 0, t = 0; for(const c of ['C', 'K']) for(let d = 1; d <= 6; d++){ t++; const okD = m.tipo === 'par' ? d % 2 === 0 : m.tipo === 'impar' ? d % 2 === 1 : m.tipo === 'maior' ? d > m.k : m.tipo === 'menor' ? d < m.k : m.tipo === 'mult3' ? [3, 6].includes(d) : d === m.k; if(c === m.lado && okD) f++; } return fr8(f, t); }
  if(m.expr) return m.frac ? fracDeVal8(ev8(m.expr)) : nD(ev8(m.expr)) + (m.suf || '');
  // força bruta no espaço amostral de cada situação
  const moedas = k => { let r = [['']]; for(let i = 0; i < k; i++) r = r.flatMap(x => ['C', 'K'].map(c => [x[0] + c])); return r.map(x => x[0]); };
  const t = m.txt;
  let esp, ok;
  if(/moeda DUAS/.test(t)){ esp = moedas(2); ok = /nas duas/.test(t) ? s => s === 'CC' : s => s === 'CK' || s === 'KC'; }
  else if(/moeda e um dado/.test(t)){ esp = []; ['C', 'K'].forEach(c => [1, 2, 3, 4, 5, 6].forEach(d => esp.push([c, d]))); ok = /CARA e número PAR/.test(t) ? ([c, d]) => c === 'C' && d % 2 === 0 : /MAIOR que 4/.test(t) ? ([c, d]) => c === 'K' && d > 4 : ([c, d]) => c === 'C' && d === 6; }
  else if(/TRÊS vezes|3 filhos/.test(t)){ esp = moedas(3); const cc = s => s.split('').filter(x => x === 'C').length; ok = /EXATAMENTE duas|2 meninas/.test(t) ? s => cc(s) === 2 : /PELO MENOS/.test(t) ? s => cc(s) >= 1 : s => cc(s) === 0 || cc(s) === 3; }
  else { esp = []; ['A', 'B'].forEach(l => [1, 2, 3].forEach(d => esp.push([l, d]))); ok = ([l, d]) => l === 'A' && d % 2 === 1; }
  return fr8(esp.filter(ok).length, esp.length);
};

/* Direta, inversa ou não proporcional (EF08MA12/ES) */
const CTX_PROP8 = {
  direta: [['Pães', 'Preço (R$)'], ['Litros', 'Preço (R$)'], ['Horas', 'Km rodados'], ['Caixas', 'Laranjas']],
  inversa: [['Pintores', 'Dias'], ['Velocidade', 'Horas'], ['Torneiras', 'Minutos'], ['Amigos', 'R$ cada']],
  nao: [['Idade', 'Altura (cm)'], ['Minutos', 'Temperatura'], ['Semana', 'Peso (kg)'], ['Horas', 'R$ a pagar']],
};
const RAZ8 = {
  direta: 'Diretamente proporcionais: y ÷ x é sempre igual',
  inversa: 'Inversamente proporcionais: x · y é sempre igual',
  naoSobe: 'Não proporcionais: as duas aumentam, mas y ÷ x muda',
  naoDesce: 'Não proporcionais: uma aumenta e a outra diminui, mas x · y muda',
};
function tabela8(linhas){                          // tabela horizontal: 1ª coluna larga com o nome da grandeza
  const c0 = 190, cw = 86, rh = 48, W = c0 + cw * (linhas[0].length - 1) + 20;
  let o = '';
  linhas.forEach((l, i) => l.forEach((c, j) => { const x = j ? 10 + c0 + (j - 1) * cw : 10, w = j ? cw : c0, y = 10 + i * rh;
    o += `<rect x="${x}" y="${y}" width="${w}" height="${rh}" fill="${j === 0 ? '#1e40af' : '#fff'}" stroke="#111" stroke-width="1.5"/>` + T(x + w / 2, y + 31, c, { fs: j === 0 ? 18 : 22, cor: j === 0 ? '#fff' : '#111' }); }));
  return SVG(W, rh * linhas.length + 20, o);
}
function tabelaProp8(tipo, n){
  let xs, ys, lei;
  if(tipo === 'direta'){ const k = rnd(2, 9); xs = shuffle([1, 2, 3, 4, 5, 6, 8, 10]).slice(0, 4).sort((a, b) => a - b); ys = xs.map(x => k * x); lei = { t: `y = ${k}x`, f: x => k * x }; }
  else if(tipo === 'inversa'){ const K = pick([12, 24, 36, 48, 60, 72, 120]); const ds = []; for(let d = 1; d <= K; d++) if(K % d === 0) ds.push(d); xs = shuffle(ds.filter(d => d > 1 && d < K)).slice(0, 4).sort((a, b) => a - b); ys = xs.map(x => K / x); lei = { t: `y = ${K}/x`, f: x => K / x }; }
  else if(tipo === 'naoSobe'){ const k = rnd(2, 5), c = rnd(1, 9); xs = [1, 2, 3, 4].map(i => i * rnd(1, 2)).filter((v, i, a) => a.indexOf(v) === i); if(xs.length < 4) xs = [1, 2, 3, 4]; xs.sort((a, b) => a - b); ys = xs.map(x => k * x + c); lei = { t: `y = ${k}x + ${c}`, f: x => k * x + c }; }
  else { const c = rnd(20, 40); xs = [1, 2, 3, 4].map(i => i * (n > 1 ? 2 : 1)); ys = xs.map(x => c - x); lei = { t: `y = ${c} − x`, f: x => c - x }; }
  return { xs, ys, lei };
}
G.propTipo8 = n => {
  const tipo = pick(n === 1 ? ['direta', 'inversa', 'naoSobe'] : ['direta', 'inversa', 'naoSobe', 'naoDesce']);
  const { xs, ys, lei } = tabelaProp8(tipo, n);
  if(xs.length < 4 || new Set(xs).size < 4) return G.propTipo8(n);
  const ctx = pick(CTX_PROP8[tipo === 'direta' ? 'direta' : tipo === 'inversa' ? 'inversa' : 'nao']);
  const img = svgURI(tabela8([[ctx[0] + ' (x)', ...xs.map(String)], [ctx[1] + ' (y)', ...ys.map(String)]]));
  if(n < 3){
    const aa = alt8({ t: RAZ8[tipo], v: null }, Object.keys(RAZ8).filter(k => k !== tipo).map(k => ({ t: RAZ8[k], v: null, erro: k === 'direta' ? 'achou que "as duas aumentam" já é proporção direta' : k === 'inversa' ? 'achou que "uma aumenta e a outra diminui" já é proporção inversa' : 'não conferiu as divisões e os produtos' })));
    return { ...aa, text: `Observe a tabela. Como x e y variam?`, image: img, meta: { xs, ys }, chave: 'pt8' + tipo + xs.join() + ys.join() };
  }
  const k = ys[0] / xs[0], K = xs[0] * ys[0];
  const cand = [lei, { t: `y = ${nD(Math.round(k * 10) / 10)}x`, f: x => Math.round(k * 10) / 10 * x }, { t: `y = ${K}/x`, f: x => K / x }, { t: `y = x + ${ys[0] - xs[0]}`, f: x => x + ys[0] - xs[0] }, { t: `y = ${xs[1] - xs[0] ? nD((ys[1] - ys[0]) / (xs[1] - xs[0])) : 1}x`, f: x => (ys[1] - ys[0]) / (xs[1] - xs[0]) * x }];
  const itens = [], vis = new Set();
  cand.forEach((c, i) => { if(!/NaN|Infinity/.test(c.t) && !vis.has(c.t)){ const serve = xs.every((x, j) => Math.abs(c.f(x) - ys[j]) < 1e-9); if(i === 0 || !serve){ vis.add(c.t); itens.push({ t: c.t, v: null, erro: i === 0 ? null : i === 2 ? 'usou produto constante (inversa) sem conferir' : i === 3 ? 'olhou só a diferença do 1º par' : 'usou uma razão que só serve para um par' }); } } });
  [`y = ${rnd(2, 9)}x + ${rnd(1, 9)}`, `y = ${rnd(10, 60)}/x`, `y = x + ${rnd(1, 20)}`].forEach(t => { if(itens.length < 6 && !vis.has(t)){ const f = x => ev8(t.slice(4), { x }); if(!xs.every((x, j) => Math.abs(f(x) - ys[j]) < 1e-9)){ vis.add(t); itens.push({ t, v: null, erro: 'lei que não bate com a tabela' }); } } });
  const aa = alt8(itens[0], itens.slice(1));
  return { ...aa, text: 'Qual lei (sentença) relaciona x e y na tabela?', image: img, meta: { xs, ys, opts: itens.map(i => i.t) }, chave: 'pt8l' + xs.join() + ys.join() };
};
C.propTipo8 = m => {
  const { xs, ys } = m;
  if(m.opts) return m.opts.find(t => xs.every((x, j) => Math.abs(ev8(t.slice(4), { x }) - ys[j]) < 1e-9)) || null;
  const razoes = new Set(xs.map((x, j) => (ys[j] / x).toFixed(6))), prods = new Set(xs.map((x, j) => (ys[j] * x).toFixed(6)));
  if(razoes.size === 1) return RAZ8.direta;
  if(prods.size === 1) return RAZ8.inversa;
  return ys[3] > ys[0] ? RAZ8.naoSobe : RAZ8.naoDesce;
};

/* Regra de três simples e composta (EF08MA13/ES) */
G.regra3_8 = n => {
  if(n === 1){
    const a = rnd(2, 9), u = rnd(2, 15) * pick([1, 5]), b = sortearAte(() => rnd(2, 15), v => v !== a);
    const ctx = pick([
      [(q, v) => `${q} cadernos custam R$ ${v}.`, q => `Quanto custam ${q} cadernos, em reais?`],
      [(q, v) => `${q} kg de arroz custam R$ ${v}.`, q => `Quanto custam ${q} kg, em reais?`],
      [(q, v) => `${q} voltas na pista dão ${v} metros.`, q => `Quantos metros dão ${q} voltas?`],
      [(q, v) => `${q} torneiras iguais enchem ${v} litros em 1 hora.`, q => `Quantos litros ${q} torneiras enchem em 1 hora?`],
      [(q, v) => `Com ${q} ovos, uma receita rende ${v} pães de queijo.`, q => `Quantos pães de queijo rende com ${q} ovos?`],
    ]);
    const certa = u * b, inv = u * a * a / b;
    const aa = alt8(nv8(certa), [Number.isInteger(inv) && { t: nD(inv), v: inv, erro: 'fez como se fosse inversa' }, { t: nD(u * a + (b - a)), v: u * a + (b - a), erro: 'somou a diferença em vez de fazer a proporção' }, { t: nD(u * a * b), v: u * a * b, erro: 'multiplicou e esqueceu de dividir' }, { t: nD(u * a), v: u * a, erro: 'repetiu o valor dado' }], viz8(certa, '', u));
    return { ...aa, text: `${ctx[0](a, u * a)} ${ctx[1](b)}`, meta: { expr: `${u * a} × ${b} / ${a}` }, chave: `r38${a},${u},${b}${ctx[1](0).slice(0, 12)}` };
  }
  if(n === 2){
    const ctx = pick([['pedreiros constroem o muro em', 'dias', 'Em quantos dias', 'pedreiros construiriam o mesmo muro?'], ['torneiras iguais enchem a caixa em', 'minutos', 'Em quantos minutos', 'torneiras encheriam a caixa?'], ['Com velocidade de', 'km/h, a viagem dura', 'Com velocidade de', 'km/h, quantas horas dura a viagem?']]);
    let a, t, b; do{ a = rnd(2, 12); t = rnd(2, 12); b = rnd(2, 12); } while(a === b || (a * t) % b !== 0);
    if(ctx[0].startsWith('Com')){ a *= 10; b *= 10; }
    const certa = a * t / b, dir = t * b / a;
    const aa = alt8(nv8(certa), [Number.isInteger(dir) && { t: nD(dir), v: dir, erro: 'fez como se fosse direta (mais trabalhadores → menos tempo)' }, { t: nD(t + (a - b)), v: t + (a - b), erro: 'somou a diferença' }, { t: nD(a * t), v: a * t, erro: 'multiplicou e esqueceu de dividir' }], viz8(certa));
    const text = ctx[0].startsWith('Com') ? `Com velocidade de ${a} km/h, a viagem dura ${t} horas. Com velocidade de ${b} km/h, quantas horas dura a mesma viagem?` : `${a} ${ctx[0]} ${t} ${ctx[1]}. ${ctx[2]} ${b} ${ctx[3]}`;
    return { ...aa, text, meta: { expr: `${a} × ${t} / ${b}` }, chave: `r38i${a},${t},${b}${ctx[1]}` };
  }
  if(Math.random() < .5){
    let m1, h1, p1, m2, h2; do{ m1 = rnd(2, 6); h1 = rnd(2, 8); m2 = rnd(2, 8); h2 = rnd(2, 10); p1 = m1 * h1 * rnd(2, 10); } while((p1 * m2 * h2) % (m1 * h1) !== 0 || (m1 === m2 && h1 === h2));
    const certa = p1 * m2 * h2 / (m1 * h1), er1 = p1 * m2 / m1, er2 = p1 * h2 / h1;
    const aa = alt8(nv8(certa), [Number.isInteger(er1) && { t: nD(er1), v: er1, erro: 'esqueceu de ajustar as horas' }, Number.isInteger(er2) && { t: nD(er2), v: er2, erro: 'esqueceu de ajustar as máquinas' }, { t: nD(p1 + (m2 - m1) + (h2 - h1)), v: p1 + (m2 - m1) + (h2 - h1), erro: 'somou as diferenças' }], viz8(certa, '', m2));
    return { ...aa, text: `${m1} máquinas iguais fazem ${p1} peças em ${h1} horas. Quantas peças ${m2} máquinas fazem em ${h2} horas?`, meta: { expr: `${p1} × ${m2} / ${m1} × ${h2} / ${h1}` }, chave: `r38c${m1},${h1},${p1},${m2},${h2}` };
  }
  let o1, c1, d1, o2, c2; do{ o1 = rnd(2, 10); c1 = rnd(1, 6); d1 = rnd(3, 30); o2 = rnd(2, 12); c2 = rnd(1, 8); } while((d1 * o1 * c2) % (o2 * c1) !== 0 || o1 === o2 || c1 === c2);
  const certa = d1 * o1 * c2 / (o2 * c1), dir = d1 * o2 * c2 / (o1 * c1);
  const aa = alt8(nv8(certa), [Number.isInteger(dir) && { t: nD(dir), v: dir, erro: 'tratou operários como direta (mais operários → menos dias)' }, Number.isInteger(d1 * c2 / c1) && { t: nD(d1 * c2 / c1), v: d1 * c2 / c1, erro: 'esqueceu de ajustar os operários' }, Number.isInteger(d1 * o1 / o2) && { t: nD(d1 * o1 / o2), v: d1 * o1 / o2, erro: 'esqueceu de ajustar as casas' }], viz8(certa));
  return { ...aa, text: `${o1} operários constroem ${c1} ${c1 === 1 ? 'casa' : 'casas'} em ${d1} dias. Em quantos dias ${o2} operários constroem ${c2} ${c2 === 1 ? 'casa' : 'casas'}? (mesmo ritmo)`, meta: { expr: `${d1} × ${o1} / ${o2} × ${c2} / ${c1}` }, chave: `r38o${o1},${c1},${d1},${o2},${c2}` };
};
C.regra3_8 = m => nD(ev8(m.expr));

/* Equação com duas incógnitas e a reta (EF08MA07) */
function retaSVG8(mm, b, lim = 6){
  const s = 30, c = 20 + lim * s, X = v => c + v * s, Y = v => c - v * s;
  let o = '';
  for(let i = -lim; i <= lim; i++){ o += `<line x1="${X(i)}" y1="${Y(-lim)}" x2="${X(i)}" y2="${Y(lim)}" stroke="#e2e8f0" stroke-width="1.2"/><line x1="${X(-lim)}" y1="${Y(i)}" x2="${X(lim)}" y2="${Y(i)}" stroke="#e2e8f0" stroke-width="1.2"/>`; if(i && i % 2 === 0) o += T(X(i), c + 20, i < 0 ? '−' + (-i) : i, { fs: 15, cor: '#475569' }) + T(c - 12, Y(i) + 5, i < 0 ? '−' + (-i) : i, { fs: 15, cor: '#475569', anc: 'end' }); }
  o += `<line x1="${X(-lim)}" y1="${c}" x2="${X(lim)}" y2="${c}" stroke="#111" stroke-width="2.5"/><line x1="${c}" y1="${Y(-lim)}" x2="${c}" y2="${Y(lim)}" stroke="#111" stroke-width="2.5"/>` + T(X(lim) - 8, c - 8, 'x', { fs: 18 }) + T(c + 12, Y(lim) + 14, 'y', { fs: 18 });
  const pts = []; for(let x = -lim; x <= lim; x += .01){ const y = mm * x + b; if(y >= -lim && y <= lim) pts.push([x, y]); }
  o += `<line x1="${X(pts[0][0])}" y1="${Y(pts[0][1])}" x2="${X(pts[pts.length - 1][0])}" y2="${Y(pts[pts.length - 1][1])}" stroke="#2563eb" stroke-width="4"/>`;
  for(let x = -lim; x <= lim; x++){ const y = mm * x + b; if(Number.isInteger(y) && Math.abs(y) <= lim && (x === 0 || x === 1 || x === 2)) o += `<circle cx="${X(x)}" cy="${Y(y)}" r="6" fill="#dc2626"/>`; }
  return SVG(2 * c, 2 * c, o);
}
const eqTxt8 = (a, b, c) => `${a === 1 ? '' : a === -1 ? '−' : a}x ${b < 0 ? '−' : '+'} ${Math.abs(b) === 1 ? '' : Math.abs(b)}y = ${c < 0 ? '−' + (-c) : c}`;
const pt8 = (x, y) => `(${x < 0 ? '−' + (-x) : x}, ${y < 0 ? '−' + (-y) : y})`;
G.retaEq8 = n => {
  if(n === 1){
    const a = rnd(1, 3), b = pick([1, -1, 2]), x0 = rnd(0, 5), y0 = rnd(-3, 5), c = a * x0 + b * y0;
    const ok = (x, y) => a * x + b * y === c;
    const cand = [[y0, x0, 'trocou x com y'], [x0, -y0, 'errou o sinal de y'], [x0 + 1, y0, 'errou a conta'], [x0, y0 + 1, 'errou a conta'], [-x0, y0, 'errou o sinal de x'], [c, 0, 'pôs o resultado como x']];
    const itens = [{ t: pt8(x0, y0), v: null }], vis = new Set([pt8(x0, y0)]);
    for(let dx = 1; dx <= 3; dx++) cand.push([x0 + dx, y0 + dx, 'errou a conta'], [x0 - dx, y0 + 2 * dx, 'errou a conta'], [x0 + 2 * dx, y0 - dx, 'errou a conta']);
    cand.forEach(([x, y, e]) => { const t = pt8(x, y); if(!ok(x, y) && !vis.has(t) && itens.length < 7){ vis.add(t); itens.push({ t, v: null, erro: e }); } });
    const aa = alt8(itens[0], itens.slice(1));
    return { ...aa, text: `Qual ponto (x, y) pertence à reta da equação ${eqTxt8(a, b, c)}?`, meta: { a, b, c, opts: itens.map(i => i.t), modo: 'ponto' }, chave: `re8${a},${b},${c},${x0},${y0}` };
  }
  if(n === 2){
    const a = rnd(1, 4), b = rnd(2, 4), y0 = rnd(-3, 6), x0 = rnd(1, 8), c = a * x0 + b * y0;
    const aa = alt8(nv8(y0), [{ t: nD(c - a * x0), v: c - a * x0, erro: `esqueceu de dividir por ${b}` }, { t: nD((c + a * x0) / b), v: (c + a * x0) / b, erro: 'somou em vez de subtrair' }, { t: nD(c / b - x0), v: c / b - x0, erro: `dividiu só o ${c} por ${b}` }], viz8(y0).map(e => ({ ...e })));
    return { ...aa, text: `Na equação ${eqTxt8(a, b, c)}, quanto vale y quando x = ${x0}?`, meta: { a, b, c, x0, modo: 'y' }, chave: `re8y${a},${b},${c},${x0}` };
  }
  const mm = sortearAte(() => rnd(-3, 3), v => v !== 0), b = sortearAte(() => rnd(-4, 4), v => v !== 0 && Math.abs(mm * 2 + v) <= 6 && Math.abs(mm + v) <= 6);
  const f = (m1, b1) => `y = ${pol8(m1, b1)}`;
  const cand = [[mm, b, null], [-mm, b, 'errou a inclinação (a reta sobe ou desce?)'], [mm, -b, 'errou onde a reta corta o eixo y'], [b, mm, 'trocou a inclinação com o ponto do eixo y'], [mm * 2, b, 'contou errado quanto sobe para cada 1 à direita'], [mm, b + 1, 'errou onde a reta corta o eixo y']];
  const itens = [], vis = new Set();
  cand.forEach(([m1, b1, e]) => { const k = m1 + ',' + b1; if(m1 !== 0 && !vis.has(k)){ vis.add(k); itens.push({ t: f(m1, b1), v: null, erro: e }); } });
  const aa = alt8(itens[0], itens.slice(1));
  return { ...aa, text: 'Qual equação representa a reta azul? (os pontos vermelhos estão em x = 0, 1 e 2)', image: svgURI(retaSVG8(mm, b)), meta: { mm, b, opts: itens.map(i => i.t), modo: 'graf' }, chave: `re8g${mm},${b}` };
};
C.retaEq8 = m => {
  if(m.modo === 'ponto') return m.opts.find(t => { const [x, y] = t.replace(/[()]/g, '').split(',').map(s => ev8(s)); return m.a * x + m.b * y === m.c; });
  if(m.modo === 'y'){ for(let y = -50; y <= 50; y++) if(m.a * m.x0 + m.b * y === m.c) return nD(y); return null; }
  // gráfico: acha a lei que passa pelos pontos (0, b) e (1, m + b) lidos da reta
  return m.opts.find(t => [0, 1, 2].every(x => Math.abs(ev8(t.slice(4), { x }) - (m.mm * x + m.b)) < 1e-9));
};

/* Sistemas de equações do 1º grau (EF08MA08) */
G.sistema8 = n => {
  if(n === 1){
    const x = rnd(3, 20), y = sortearAte(() => rnd(1, 15), v => v !== x && v < x), S = x + y, D = x - y;
    const r = (a, b) => `x = ${a} e y = ${b}`;
    const aa = alt8({ t: r(x, y), v: null }, [{ t: r(y, x), v: null, erro: 'trocou x com y' }, { t: r(S + D, S - D), v: null, erro: 'somou as equações e esqueceu de dividir por 2' }, { t: r(S, D), v: null, erro: 'só copiou os números' }, { t: r(x, S + y), v: null, erro: 'errou a substituição' }]);
    return { ...aa, text: `Resolva o sistema: x + y = ${S} e x − y = ${D}.`, meta: { S, D, modo: 'sd' }, chave: `sis8${S},${D}` };
  }
  if(n === 2){
    const ctx = pick(['carros', 'galinhas', 'notas']);
    if(ctx === 'notas'){
      const a = rnd(2, 12), b = rnd(2, 12), tot = a + b, val = 5 * a + 10 * b, qual = pick(['5', '10']);
      const certa = qual === '5' ? a : b, outra = qual === '5' ? b : a;
      const aa = alt8(nv8(certa), [{ t: nD(outra), v: outra, erro: 'trocou as notas' }, { t: nD(tot / 2), v: tot / 2, erro: 'dividiu o total ao meio' }, { t: nD(val / 10), v: val / 10, erro: 'dividiu o valor pela nota' }], viz8(certa));
      return { ...aa, text: `Tenho ${tot} notas, só de R$ 5 e de R$ 10, somando R$ ${val}. Quantas notas de R$ ${qual} eu tenho?`, meta: { tot, val, qual, modo: 'notas' }, chave: `sis8n${tot},${val},${qual}` };
    }
    const car = ctx === 'carros';
    const a = rnd(3, 20), b = rnd(3, 20), tot = a + b, pes = (car ? 4 : 2) * a + (car ? 2 : 4) * b, qual = pick([0, 1]);
    const nomes = car ? ['carros', 'motos'] : ['galinhas', 'coelhos'];
    const certa = qual ? b : a, outra = qual ? a : b;
    const aa = alt8(nv8(certa), [{ t: nD(outra), v: outra, erro: 'trocou os dois' }, { t: nD(tot / 2), v: tot / 2, erro: 'dividiu o total ao meio' }, { t: nD(pes / 4), v: pes / 4, erro: 'dividiu tudo por 4' }], viz8(certa));
    return { ...aa, text: car ? `Num estacionamento há ${tot} veículos, entre carros e motos, e ${pes} rodas. Quantos são ${nomes[qual]}?` : `Num sítio há ${tot} animais, entre galinhas e coelhos, e ${pes} pés. Quantos são ${nomes[qual]}?`, meta: { tot, pes, car, qual, modo: 'rodas' }, chave: `sis8r${ctx}${tot},${pes},${qual}` };
  }
  if(Math.random() < .35){
    const caso = pick(['corta', 'paral', 'coinc']);
    const certo = { corta: 'Uma única solução', paral: 'Nenhuma solução', coinc: 'Infinitas soluções' }[caso];
    const txt = { corta: 'se cortam em UM ponto', paral: 'são PARALELAS (nunca se encontram)', coinc: 'são COINCIDENTES (uma em cima da outra)' }[caso];
    const aa = alt8({ t: certo, v: null }, [{ t: 'Uma única solução', v: null, erro: 'a solução é o ponto onde as retas se encontram' }, { t: 'Nenhuma solução', v: null, erro: 'a solução é o ponto onde as retas se encontram' }, { t: 'Infinitas soluções', v: null, erro: 'a solução é o ponto onde as retas se encontram' }, { t: 'Duas soluções', v: null, erro: 'duas retas não podem se encontrar em exatamente dois pontos' }]);
    return { ...aa, text: `As duas retas que representam um sistema ${txt}. Quantas soluções o sistema tem?`, meta: { caso, modo: 'graf' }, chave: 'sis8g' + caso };
  }
  const S = rnd(12, 60), D = rnd(2, 10), k = rnd(2, 4);
  const mod = pick([
    { txt: `A soma de dois números é ${S} e a diferença entre eles é ${D}.`, c: `x + y = ${S} e x − y = ${D}`, e: [[`x + y = ${D} e x − y = ${S}`, 'trocou a soma com a diferença'], [`x · y = ${S} e x − y = ${D}`, 'confundiu soma com produto'], [`x + y = ${S} e x + y = ${D}`, 'usou soma nas duas']] },
    { txt: `Pedro (x) tem ${k === 2 ? 'o dobro' : k === 3 ? 'o triplo' : 'o quádruplo'} da idade de Ana (y), e juntos eles têm ${S} anos.`, c: `x = ${k}y e x + y = ${S}`, e: [[`y = ${k}x e x + y = ${S}`, 'inverteu quem tem mais idade'], [`x = y + ${k} e x + y = ${S}`, `somou ${k} em vez de multiplicar`], [`x = ${k}y e x − y = ${S}`, 'usou diferença em vez de soma']] },
    { txt: `Um caderno (x) e uma caneta (y) custam juntos R$ ${S}. O caderno custa R$ ${D} a mais que a caneta.`, c: `x + y = ${S} e x = y + ${D}`, e: [[`x + y = ${S} e y = x + ${D}`, 'inverteu qual é mais caro'], [`x + y = ${D} e x = y + ${S}`, 'trocou os números'], [`x · y = ${S} e x = y + ${D}`, 'confundiu soma com produto']] },
  ]);
  const aa = alt8({ t: mod.c, v: null }, mod.e.map(([t, e]) => ({ t, v: null, erro: e })));
  return { ...aa, text: `Qual sistema representa a situação? ${mod.txt}`, meta: { txt: mod.txt, S, D, k, opts: [mod.c, ...mod.e.map(e => e[0])], modo: 'modelo' }, chave: 'sis8m' + mod.c };
};
C.sistema8 = m => {
  if(m.modo === 'sd'){ for(let x = 0; x <= 100; x++){ const y = m.S - x; if(x - y === m.D) return `x = ${x} e y = ${y}`; } return null; }
  if(m.modo === 'notas'){ for(let a = 0; a <= m.tot; a++) if(5 * a + 10 * (m.tot - a) === m.val) return nD(m.qual === '5' ? a : m.tot - a); return null; }
  if(m.modo === 'rodas'){ for(let a = 0; a <= m.tot; a++){ const b = m.tot - a; if((m.car ? 4 : 2) * a + (m.car ? 2 : 4) * b === m.pes) return nD(m.qual ? b : a); } return null; }
  if(m.modo === 'graf') return { corta: 'Uma única solução', paral: 'Nenhuma solução', coinc: 'Infinitas soluções' }[m.caso];
  // modelo: acha (x, y) inteiros que obedecem ao TEXTO e fica com o único sistema que esse par satisfaz
  let sol = null;
  for(let x = 0; x <= 120 && !sol; x++) for(let y = 0; y <= 120; y++){ const ok = /soma de dois/.test(m.txt) ? x + y === m.S && Math.abs(x - y) === m.D && x > y : /Pedro/.test(m.txt) ? x === m.k * y && x + y === m.S : x + y === m.S && x === y + m.D; if(ok){ sol = [x, y]; break; } }
  if(!sol){ if(/soma de dois/.test(m.txt) || !/Pedro/.test(m.txt)){ sol = [(m.S + m.D) / 2, (m.S - m.D) / 2]; } else sol = [m.S * m.k / (m.k + 1), m.S / (m.k + 1)]; }
  const bate = t => t.split(' e ').every(eq => { const [l, r] = eq.split('=').map(z => ev8(z, { x: sol[0], y: sol[1] })); return Math.abs(l - r) < 1e-9; });
  const ok = m.opts.filter(bate);
  return ok.length === 1 ? ok[0] : null;
};

/* ============================ 3º TRIMESTRE ============================ */

/* Quadriláteros pelas propriedades e casos de congruência (EF08MA14) */
const QUAD8 = ['quadrado', 'retângulo', 'losango', 'paralelogramo', 'trapézio'];
const PROP_LADOS8 = [
  ['Tem 4 lados iguais e 4 ângulos retos.', 'quadrado'], ['Tem 4 ângulos retos, mas os lados vizinhos têm tamanhos diferentes.', 'retângulo'],
  ['Tem 4 lados iguais, mas os ângulos NÃO são retos.', 'losango'], ['Tem os lados opostos paralelos e iguais, sem ângulos retos, e os lados vizinhos são diferentes.', 'paralelogramo'],
  ['Tem SÓ UM par de lados paralelos.', 'trapézio'],
];
const PROP_DIAG8 = [
  ['As diagonais são iguais, perpendiculares e se cortam ao meio.', 'quadrado'], ['As diagonais são iguais e se cortam ao meio, mas NÃO são perpendiculares.', 'retângulo'],
  ['As diagonais são perpendiculares e se cortam ao meio, mas têm tamanhos diferentes.', 'losango'], ['As diagonais se cortam ao meio, mas não são iguais nem perpendiculares.', 'paralelogramo'],
];
const CONGR8 = [
  ['Os três lados de um triângulo são iguais aos três lados do outro.', 'LLL'], ['Dois lados e o ângulo ENTRE eles são iguais nos dois triângulos.', 'LAL'],
  ['Dois ângulos e o lado ENTRE eles são iguais nos dois triângulos.', 'ALA'], ['Dois ângulos e o lado OPOSTO a um deles são iguais nos dois triângulos.', 'LAAo'],
  ['Só os três ângulos são iguais (os lados não foram medidos).', 'não garante congruência'],
];
const AFIRM8 = {
  v: ['Todo quadrado é um retângulo.', 'Todo quadrado é um losango.', 'Todo retângulo é um paralelogramo.', 'Todo losango é um paralelogramo.', 'As diagonais de um retângulo têm o mesmo tamanho.', 'As diagonais de um losango são perpendiculares.', 'Os ângulos opostos de um paralelogramo são iguais.'],
  f: ['Todo retângulo é um quadrado.', 'Todo losango é um quadrado.', 'Todo trapézio é um paralelogramo.', 'As diagonais de um losango têm sempre o mesmo tamanho.', 'O trapézio tem dois pares de lados paralelos.', 'Todo paralelogramo tem ângulos retos.', 'As diagonais de um paralelogramo são sempre perpendiculares.'],
};
G.quadProp8 = n => {
  if(n === 2 && Math.random() < .5){
    const certa = pick(AFIRM8.v);
    const aa = alt8({ t: certa, v: null }, shuffle(AFIRM8.f).slice(0, 3).map(t => ({ t, v: null, erro: 'afirmação falsa: confira lados, ângulos e diagonais' })));
    return { ...aa, text: 'Qual afirmação sobre quadriláteros é VERDADEIRA?', meta: { afirm: 1, opts: aa.options }, chave: 'qp8a' + aa.options.join('|') };
  }
  const lista = n === 1 ? PROP_LADOS8 : n === 2 ? PROP_DIAG8 : CONGR8;
  const [txt, certa] = pick(lista), nomes = n === 3 ? ['LLL', 'LAL', 'ALA', 'LAAo', 'não garante congruência'] : QUAD8;
  const erro = x => n === 3 ? (x === 'não garante congruência' ? 'achou que não dá para garantir' : certa === 'não garante congruência' ? 'ângulos iguais não garantem o mesmo tamanho (podem ser ampliação)' : 'confundiu a posição do lado e do ângulo') : x === 'trapézio' ? 'o trapézio só tem um par de lados paralelos' : 'confundiu as propriedades dos quadriláteros';
  const aa = alt8({ t: certa, v: null }, nomes.filter(x => x !== certa).map(x => ({ t: x, v: null, erro: erro(x) })));
  return { ...aa, text: n === 3 ? `${txt} Qual caso garante que os triângulos são congruentes?` : `Um quadrilátero: ${txt} Qual é ele?`, meta: { txt, n }, chave: 'qp8' + txt };
};
C.quadProp8 = m => m.afirm ? m.opts.find(t => AFIRM8.v.includes(t)) : (m.n === 1 ? PROP_LADOS8 : m.n === 2 ? PROP_DIAG8 : CONGR8).find(x => x[0] === m.txt)[1];

/* Área de triângulos, quadriláteros e círculo (EF08MA19) */
function figArea8(tipo, d){
  const larg = tipo === 'trap' ? d.B : tipo === 'los' ? d.D : tipo === 'par' ? d.b + d.desl : d.b || 10, alt = tipo === 'los' ? d.d : d.h || 10;
  const k = Math.min(320 / larg, 200 / alt, 30), lab = (x, y, t, o = {}) => T(x, y, t, { fs: 22, cor: '#b91c1c', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"', ...o });
  let o = '', W = 460, H = 260;
  const st = 'fill="#bfdbfe" stroke="#111" stroke-width="3"', tr = 'stroke="#111" stroke-width="2" stroke-dasharray="7,5"';
  if(tipo === 'tri'){ const b = d.b * k, h = d.h * k, x0 = 60, y0 = 40 + h, px = x0 + b * .3; o += `<polygon points="${x0},${y0} ${x0 + b},${y0} ${px},${y0 - h}" ${st}/><line x1="${px}" y1="${y0}" x2="${px}" y2="${y0 - h}" ${tr}/><rect x="${px}" y="${y0 - 14}" width="14" height="14" fill="none" stroke="#111" stroke-width="2"/>` + lab(x0 + b / 2, y0 + 26, d.b + ' cm') + lab(px + 8, y0 - h / 2, d.h + ' cm', { anc: 'start' }); W = x0 + b + 60; H = y0 + 40; }
  if(tipo === 'par'){ const b = d.b * k, h = d.h * k, s = d.desl * k, x0 = 40, y0 = 40 + h; o += `<polygon points="${x0},${y0} ${x0 + b},${y0} ${x0 + b + s},${y0 - h} ${x0 + s},${y0 - h}" ${st}/><line x1="${x0 + s}" y1="${y0}" x2="${x0 + s}" y2="${y0 - h}" ${tr}/><rect x="${x0 + s}" y="${y0 - 14}" width="14" height="14" fill="none" stroke="#111" stroke-width="2"/>` + lab(x0 + b / 2, y0 + 26, d.b + ' cm') + lab(x0 + s + 8, y0 - h / 2, d.h + ' cm', { anc: 'start' }) + lab(x0 + b + s / 2 + 12, y0 - h / 2, d.l + ' cm', { anc: 'start' }); W = x0 + b + s + 90; H = y0 + 40; }
  if(tipo === 'trap'){ const B = d.B * k, b = d.b * k, h = d.h * k, x0 = 40, y0 = 40 + h, s = (B - b) / 2; o += `<polygon points="${x0},${y0} ${x0 + B},${y0} ${x0 + s + b},${y0 - h} ${x0 + s},${y0 - h}" ${st}/><line x1="${x0 + s}" y1="${y0}" x2="${x0 + s}" y2="${y0 - h}" ${tr}/>` + lab(x0 + B / 2, y0 + 26, d.B + ' cm') + lab(x0 + s + b / 2, y0 - h - 10, d.b + ' cm') + lab(x0 + s + 8, y0 - h / 2, d.h + ' cm', { anc: 'start' }); W = x0 + B + 40; H = y0 + 40; }
  if(tipo === 'los'){ const D = d.D * k, dd = d.d * k, cx = 40 + D / 2, cy = 30 + dd / 2; o += `<polygon points="${cx - D / 2},${cy} ${cx},${cy - dd / 2} ${cx + D / 2},${cy} ${cx},${cy + dd / 2}" ${st}/><line x1="${cx - D / 2}" y1="${cy}" x2="${cx + D / 2}" y2="${cy}" ${tr}/><line x1="${cx}" y1="${cy - dd / 2}" x2="${cx}" y2="${cy + dd / 2}" ${tr}/>` + lab(cx + D / 4, cy - 8, d.D + ' cm') + lab(cx + 10, cy + dd / 4 + 8, d.d + ' cm', { anc: 'start' }); W = D + 80; H = dd + 60; }
  if(tipo === 'circ'){ const R = 90, cx = 130, cy = 120; o += `<circle cx="${cx}" cy="${cy}" r="${R}" ${st}/><circle cx="${cx}" cy="${cy}" r="4" fill="#111"/>` + (d.diam ? `<line x1="${cx - R}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#b91c1c" stroke-width="3"/>` + lab(cx, cy - 10, 'diâmetro ' + d.dm + ' cm') : `<line x1="${cx}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#b91c1c" stroke-width="3"/>` + lab(cx + R / 2, cy - 10, 'raio ' + d.r + ' cm')); W = 260; H = 240; }
  return SVG(Math.max(W, 200), Math.max(H, 160), o);
}
G.area8 = n => {
  const cm2 = v => ({ t: nD(v) + ' cm²', v });
  if(n === 1){
    if(Math.random() < .5){
      const b = rnd(4, 18), h = sortearAte(() => rnd(3, 12), v => (b * v) % 2 === 0);
      const A = b * h / 2;
      const aa = alt8(cm2(A), [{ ...cm2(b * h), erro: 'esqueceu de dividir por 2' }, { ...cm2(b + h), erro: 'somou base e altura' }, { ...cm2((b + h) * 2), erro: 'fez algo parecido com perímetro' }], viz8(A, ' cm²'));
      return { ...aa, text: 'Qual é a área do triângulo? (área = base × altura ÷ 2)', image: svgURI(figArea8('tri', { b, h })), meta: { tipo: 'tri', b, h }, chave: `ar8t${b},${h}` };
    }
    const b = rnd(5, 16), h = rnd(3, 9), desl = rnd(2, 5), l = Math.round(Math.sqrt(h * h + desl * desl)) + 1;
    const A = b * h;
    const aa = alt8(cm2(A), [{ ...cm2(b * l), erro: 'usou o lado inclinado em vez da altura' }, { ...cm2(b * h / 2), erro: 'dividiu por 2 (isso é do triângulo)' }, { ...cm2(2 * (b + l)), erro: 'calculou o perímetro' }], viz8(A, ' cm²'));
    return { ...aa, text: 'Qual é a área do paralelogramo? (área = base × altura)', image: svgURI(figArea8('par', { b, h, desl, l })), meta: { tipo: 'par', b, h }, chave: `ar8p${b},${h},${l}` };
  }
  if(n === 2){
    if(Math.random() < .5){
      let B, b, h; do{ B = rnd(8, 20); b = rnd(3, B - 2); h = rnd(3, 10); } while(((B + b) * h) % 2 || (B - b) % 2);
      const A = (B + b) * h / 2;
      const aa = alt8(cm2(A), [{ ...cm2((B + b) * h), erro: 'esqueceu de dividir por 2' }, { ...cm2(B * h), erro: 'usou só a base maior' }, { ...cm2(B * b * h / 2), erro: 'multiplicou as bases em vez de somar' }], viz8(A, ' cm²'));
      return { ...aa, text: 'Qual é a área do trapézio? (área = (base maior + base menor) × altura ÷ 2)', image: svgURI(figArea8('trap', { B, b, h })), meta: { tipo: 'trap', B, b, h }, chave: `ar8z${B},${b},${h}` };
    }
    let D, d; do{ D = rnd(8, 20); d = rnd(4, 14); } while((D * d) % 2 || d >= D);
    const A = D * d / 2;
    const aa = alt8(cm2(A), [{ ...cm2(D * d), erro: 'esqueceu de dividir por 2' }, { ...cm2((D + d) * 2), erro: 'somou as diagonais' }, { ...cm2(D * d / 4), erro: 'dividiu por 4' }], viz8(A, ' cm²'));
    return { ...aa, text: 'Qual é a área do losango? (área = diagonal maior × diagonal menor ÷ 2)', image: svgURI(figArea8('los', { D, d })), meta: { tipo: 'los', D, d }, chave: `ar8l${D},${d}` };
  }
  const diam = Math.random() < .4, r = rnd(2, 12), dm = 2 * r;
  const A = Math.round(3.14 * r * r * 100) / 100;
  const aa = alt8(cm2(A), [{ ...cm2(Math.round(2 * 3.14 * r * 100) / 100), erro: 'calculou o comprimento (2 · π · r)' }, { ...cm2(Math.round(3.14 * r * 100) / 100), erro: 'esqueceu de elevar o raio ao quadrado' }, { ...cm2(Math.round(3.14 * dm * dm * 100) / 100), erro: 'usou o diâmetro no lugar do raio' }, { ...cm2(Math.round(3.14 * 2 * r * 100) / 100 === Math.round(2 * 3.14 * r * 100) / 100 ? r * r * 3 : r * r * 3), erro: 'usou π = 3' }]);
  return { ...aa, text: 'Qual é a área do círculo? (use π = 3,14; área = π · r²)', image: svgURI(figArea8('circ', diam ? { diam: 1, dm } : { r })), meta: { tipo: 'circ', r }, chave: `ar8c${r}${diam}` };
};
C.area8 = m => {
  const f = { tri: `${m.b} × ${m.h} / 2`, par: `${m.b} × ${m.h}`, trap: `(${m.B} + ${m.b}) × ${m.h} / 2`, los: `${m.D} × ${m.d} / 2`, circ: `3,14 × ${m.r}²` }[m.tipo];
  return nD(Math.round(ev8(f) * 100) / 100) + ' cm²';
};

/* Volume do bloco e litros (EF08MA20 · EF08MA21) */
function blocoSVG8(a, b, c, un){
  const k = Math.min(260 / (a + b * .5), 160 / (c + b * .4)), A = a * k, B = b * k * .5, Cc = c * k, x0 = 40, y0 = 40 + B + Cc;
  const f = `${x0},${y0} ${x0 + A},${y0} ${x0 + A},${y0 - Cc} ${x0},${y0 - Cc}`, t = `${x0},${y0 - Cc} ${x0 + A},${y0 - Cc} ${x0 + A + B},${y0 - Cc - B * .8} ${x0 + B},${y0 - Cc - B * .8}`, l = `${x0 + A},${y0} ${x0 + A + B},${y0 - B * .8} ${x0 + A + B},${y0 - Cc - B * .8} ${x0 + A},${y0 - Cc}`;
  let o = `<polygon points="${f}" fill="#93c5fd" stroke="#111" stroke-width="2.5"/><polygon points="${t}" fill="#dbeafe" stroke="#111" stroke-width="2.5"/><polygon points="${l}" fill="#60a5fa" stroke="#111" stroke-width="2.5"/>`;
  o += T(x0 + A / 2, y0 + 26, `${nD(a)} ${un}`, { fs: 20, cor: '#b91c1c' }) + T(x0 + A + B / 2 + 16, y0 - B * .4 + 8, `${nD(b)} ${un}`, { fs: 20, cor: '#b91c1c', anc: 'start' }) + T(x0 - 8, y0 - Cc / 2, `${nD(c)} ${un}`, { fs: 20, cor: '#b91c1c', anc: 'end' });
  return SVG(x0 + A + B + 130, y0 + 40, `<g transform="translate(60,0)">${o}</g>`);
}
G.vol8 = n => {
  if(n === 1){
    const a = rnd(2, 12), b = rnd(2, 10), c = rnd(2, 10), V = a * b * c;
    const aa = alt8({ t: nD(V) + ' cm³', v: V }, [{ t: nD(a + b + c) + ' cm³', v: a + b + c, erro: 'somou as medidas' }, { t: nD(a * b) + ' cm³', v: a * b, erro: 'esqueceu a altura' }, { t: nD(2 * (a * b + a * c + b * c)) + ' cm³', v: 2 * (a * b + a * c + b * c), erro: 'calculou a área das faces' }], viz8(V, ' cm³'));
    return { ...aa, text: 'Qual é o volume do bloco retangular? (volume = comprimento × largura × altura)', image: svgURI(blocoSVG8(a, b, c, 'cm')), meta: { expr: `${a} × ${b} × ${c}`, suf: ' cm³' }, chave: `vo8${a},${b},${c}` };
  }
  if(n === 2){
    let a, b, c; do{ a = pick([1, 1.5, 2, 2.5, 3, 4]); b = pick([1, 1.5, 2, 2.5, 3]); c = pick([0.5, 1, 1.5, 2]); } while(!Number.isInteger(a * b * c * 1000) || a * b * c > 20);
    const V = a * b * c, L = V * 1000;
    const aa = alt8({ t: nD(L) + ' L', v: L }, [{ t: nD(V) + ' L', v: V, erro: 'esqueceu de converter (1 m³ = 1000 L)' }, { t: nD(V * 100) + ' L', v: V * 100, erro: 'multiplicou por 100 (1 m³ = 1000 L)' }, { t: nD(V * 10) + ' L', v: V * 10, erro: 'multiplicou por 10 (1 m³ = 1000 L)' }, { t: nD((a + b + c) * 1000) + ' L', v: (a + b + c) * 1000, erro: 'somou as medidas' }]);
    return { ...aa, text: 'Quantos litros cabem nesta caixa-d\'água em forma de bloco? (1 m³ = 1000 litros)', image: svgURI(blocoSVG8(a, b, c, 'm')), meta: { expr: `${nD(a)} × ${nD(b)} × ${nD(c)} × 1000`, suf: ' L' }, chave: `vo8m${a},${b},${c}` };
  }
  let a, b, c; do{ a = rnd(2, 8) * 10; b = rnd(2, 6) * 5; c = rnd(2, 6) * 5; } while((a * b * c) % 1000);
  const L = a * b * c / 1000;
  const aa = alt8({ t: nD(L) + ' L', v: L }, [{ t: nD(a * b * c) + ' L', v: a * b * c, erro: 'esqueceu de converter (1000 cm³ = 1 L)' }, { t: nD(a * b * c / 100) + ' L', v: a * b * c / 100, erro: 'dividiu por 100 (1000 cm³ = 1 L)' }, { t: nD(L / 10) + ' L', v: L / 10, erro: 'dividiu por 10 000' }, { t: nD(L * 10) + ' L', v: L * 10, erro: 'errou a conversão' }]);
  return { ...aa, text: 'Quantos litros de água cabem neste aquário? (1 dm³ = 1 litro = 1000 cm³)', image: svgURI(blocoSVG8(a, b, c, 'cm')), meta: { expr: `${a} × ${b} × ${c} / 1000`, suf: ' L' }, chave: `vo8a${a},${b},${c}` };
};
C.vol8 = m => nD(Math.round(ev8(m.expr) * 1000) / 1000) + m.suf;

/* Equação do tipo ax² = b (EF08MA09) */
G.eq2_8 = n => {
  const par = k => ({ t: `x = ${k} ou x = −${k}`, v: null });
  if(n < 3){
    const k = rnd(2, n === 1 ? 12 : 10), a = n === 1 ? 1 : rnd(2, 6), b = a * k * k;
    const cc = rnd(1, 20), forma = n === 1 ? pick([`x² = ${b}`, `x² − ${b} = 0`, `x² + ${cc} = ${b + cc}`]) : pick([`${a}x² = ${b}`, `${a}x² − ${b} = 0`]);
    const aa = alt8(par(k), [{ t: `x = ${k}`, v: null, erro: 'esqueceu a raiz negativa (−k também serve)' }, b % 2 === 0 && { t: `x = ${b / 2} ou x = −${b / 2}`, v: null, erro: 'dividiu por 2 em vez de tirar a raiz' }, n > 1 ? { t: `x = ${k * k} ou x = −${k * k}`, v: null, erro: 'dividiu, mas esqueceu de tirar a raiz' } : { t: `x = ${b}`, v: null, erro: 'não tirou a raiz' }, n > 1 && { t: `x = ${b - a}`, v: null, erro: 'subtraiu em vez de dividir' }].filter(Boolean).filter(e => e.t !== par(k).t), [{ t: `x = −${k}`, v: null, erro: 'esqueceu a raiz positiva' }, { t: `x = ${k + 1} ou x = −${k + 1}`, v: null, erro: 'errou a raiz' }]);
    return { ...aa, text: `Resolva: ${forma}`, meta: { forma, modo: 'eq' }, chave: 'e28' + forma };
  }
  const tipo = pick(['quadrado', 'numero', 'circulo']);
  if(tipo === 'quadrado'){
    const l = rnd(4, 20), A = l * l;
    const aa = alt8({ t: l + ' cm', v: l }, [{ t: nD(A / 2) + ' cm', v: A / 2, erro: 'dividiu por 2' }, { t: nD(A / 4) + ' cm', v: A / 4, erro: 'dividiu por 4 (isso seria pelo perímetro)' }, { t: (l + 1) + ' cm', v: l + 1, erro: 'errou a raiz' }, { t: (l - 1) + ' cm', v: l - 1, erro: 'errou a raiz' }]);
    return { ...aa, text: `A área de um quadrado é ${A} cm². Quanto mede o lado? (lado² = ${A})`, meta: { forma: `x² = ${A}`, modo: 'pos', suf: ' cm' }, chave: 'e28q' + A };
  }
  const k = rnd(2, 9), a = rnd(2, 5), b = a * k * k;
  const mult = { 2: 'O dobro', 3: 'O triplo', 4: 'O quádruplo', 5: 'O quíntuplo' }[a];
  const aa = alt8({ t: String(k), v: k }, [{ t: nD(b / a), v: b / a, erro: 'dividiu, mas esqueceu de tirar a raiz' }, { t: nD(b / 2), v: b / 2, erro: 'dividiu por 2' }, { t: nD(Math.round(Math.sqrt(b))), v: Math.round(Math.sqrt(b)), erro: 'tirou a raiz antes de dividir' }, { t: nD(b - a), v: b - a, erro: 'subtraiu' }], viz8(k));
  return { ...aa, text: `${mult} do quadrado de um número positivo é ${b}. Qual é o número?`, meta: { forma: `${a}x² = ${b}`, modo: 'pos', suf: '' }, chave: 'e28n' + a + b };
};
C.eq2_8 = m => {                                // resolve por tentativa: testa inteiros
  const [l, r] = m.forma.split('=');
  const sols = []; for(let x = -60; x <= 60; x++) if(Math.abs(ev8(l, { x }) - ev8(r, { x })) < 1e-9) sols.push(x);
  if(m.modo === 'pos') return String(sols.find(x => x > 0)) + m.suf;
  const p = sols.find(x => x > 0); return `x = ${p} ou x = −${p}`;
};

/* Diagonais do polígono, mediatriz e bissetriz (EF08MA15 · EF08MA17/ES) */
const POLI8 = { 4: 'quadrilátero', 5: 'pentágono', 6: 'hexágono', 7: 'heptágono', 8: 'octógono', 9: 'eneágono', 10: 'decágono', 12: 'dodecágono' };
const LUGAR8 = [
  ['Os pontos que ficam à MESMA distância de A e de B.', 'Mediatriz do segmento AB'], ['Uma antena deve ficar à mesma distância de duas cidades.', 'Mediatriz do segmento AB'],
  ['Os pontos que ficam à mesma distância dos DOIS LADOS de um ângulo.', 'Bissetriz do ângulo'], ['Um poste deve ficar à mesma distância de duas ruas que se cruzam.', 'Bissetriz do ângulo'],
  ['Todos os pontos que ficam a 3 km de uma escola.', 'Circunferência com centro no ponto'], ['A reta que divide um ângulo em dois ângulos iguais.', 'Bissetriz do ângulo'],
  ['A reta perpendicular a AB que passa pelo ponto médio de AB.', 'Mediatriz do segmento AB'], ['O limite até onde um cachorro alcança, preso por uma corda de 2 m a uma estaca.', 'Circunferência com centro no ponto'],
];
const LUGARES8 = ['Mediatriz do segmento AB', 'Bissetriz do ângulo', 'Circunferência com centro no ponto', 'Reta paralela ao segmento AB'];
G.geo8 = n => {
  if(n === 1){
    const k = pick([4, 5, 6, 7, 8, 9, 10, 12]), d = k * (k - 3) / 2;
    const aa = alt8(nv8(d), [{ t: nD(k * (k - 3)), v: k * (k - 3), erro: 'esqueceu de dividir por 2 (cada diagonal foi contada duas vezes)' }, { t: nD(k - 3), v: k - 3, erro: 'contou só as diagonais de um vértice' }, { t: nD(k * (k - 1) / 2), v: k * (k - 1) / 2, erro: 'contou os lados junto' }, { t: nD(k), v: k, erro: 'contou os lados' }], viz8(d));
    return { ...aa, text: `Quantas diagonais tem um ${POLI8[k]} (${k} lados)? (de cada vértice saem ${k} − 3 diagonais)`, meta: { k, modo: 'diag' }, chave: 'g8d' + k };
  }
  if(n === 2){
    const [txt, certa] = pick(LUGAR8);
    const aa = alt8({ t: certa, v: null }, LUGARES8.filter(x => x !== certa).map(x => ({ t: x, v: null, erro: 'confundiu os lugares geométricos: mediatriz = mesma distância de dois PONTOS; bissetriz = mesma distância de duas RETAS' })));
    return { ...aa, text: `${txt} Que figura é essa?`, meta: { txt, modo: 'lugar' }, chave: 'g8l' + txt };
  }
  const modo = pick(['bis', 'bisVolta', 'medi', 'diagVolta']);
  if(modo === 'bis'){
    const A = rnd(15, 85) * 2;
    const aa = alt8(nv8(A / 2, '°'), [{ t: A + '°', v: A, erro: 'não dividiu o ângulo' }, { t: nD(A * 2) + '°', v: A * 2, erro: 'dobrou em vez de dividir' }, { t: nD(180 - A) + '°', v: 180 - A, erro: 'calculou o suplemento' }, { t: nD(90 - A / 2) + '°', v: 90 - A / 2, erro: 'calculou o complemento da metade' }].filter(e => e.v > 0), viz8(A / 2, '°'));
    return { ...aa, text: `A bissetriz de um ângulo de ${A}° divide esse ângulo em dois. Quanto mede cada parte?`, meta: { expr: `${A} / 2`, suf: '°', modo: 'conta' }, chave: 'g8b' + A };
  }
  if(modo === 'bisVolta'){
    const p = rnd(10, 85);
    const aa = alt8(nv8(2 * p, '°'), [{ t: p + '°', v: p, erro: 'deu só uma parte' }, { t: nD(p / 2) + '°', v: p / 2, erro: 'dividiu em vez de dobrar' }, { t: nD(180 - p) + '°', v: 180 - p, erro: 'calculou o suplemento' }], viz8(2 * p, '°'));
    return { ...aa, text: `A bissetriz de um ângulo formou duas partes de ${p}°. Quanto mede o ângulo todo?`, meta: { expr: `2 × ${p}`, suf: '°', modo: 'conta' }, chave: 'g8v' + p };
  }
  if(modo === 'medi'){
    const d = rnd(3, 25), ab = rnd(4, 30);
    const aa = alt8(nv8(d, ' cm'), [{ t: nD(ab) + ' cm', v: ab, erro: 'usou a medida de AB' }, { t: nD(ab / 2) + ' cm', v: ab / 2, erro: 'usou a metade de AB' }, { t: nD(2 * d) + ' cm', v: 2 * d, erro: 'dobrou a distância' }], viz8(d, ' cm'));
    return { ...aa, text: `O ponto P está na mediatriz do segmento AB, que mede ${ab} cm. A distância de P até A é ${d} cm. Qual é a distância de P até B?`, meta: { expr: String(d), suf: ' cm', modo: 'conta' }, chave: 'g8m' + d + ',' + ab };
  }
  const k = pick([5, 6, 7, 8, 9, 10, 12]), d = k * (k - 3) / 2;
  const aa = alt8({ t: POLI8[k], v: k }, Object.keys(POLI8).map(Number).filter(x => x !== k).map(x => ({ t: POLI8[x], v: x, erro: x * (x - 3) === d ? 'esqueceu de dividir por 2' : 'errou a conta das diagonais' })));
  return { ...aa, text: `Um polígono tem ${d} diagonais. Qual é ele? (diagonais = n · (n − 3) ÷ 2)`, meta: { d, modo: 'diagVolta' }, chave: 'g8x' + d };
};
C.geo8 = m => {
  if(m.modo === 'diag'){ let c = 0; for(let i = 0; i < m.k; i++) for(let j = i + 2; j < m.k; j++) if(!(i === 0 && j === m.k - 1)) c++; return nD(c); }
  if(m.modo === 'lugar') return LUGAR8.find(x => x[0] === m.txt)[1];
  if(m.modo === 'conta') return nD(ev8(m.expr)) + m.suf;
  for(const k of Object.keys(POLI8).map(Number)){ let c = 0; for(let i = 0; i < k; i++) for(let j = i + 2; j < k; j++) if(!(i === 0 && j === k - 1)) c++; if(c === m.d) return POLI8[k]; }
  return null;
};
