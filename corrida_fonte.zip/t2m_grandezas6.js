/* =========================================================================
   EF06MA24 — PROBLEMAS COM GRANDEZAS (comprimento, massa, tempo, temperatura,
   capacidade, área e volume sem fórmulas), em situações do dia a dia.
   Nível 1: uma conversão + uma conta (copos na garrafa, pacotes, pedaços de fita,
            horário de chegada, diferença de temperatura).
   Nível 2: duas etapas (quanto tempo durou, garrafas para a festa, receita em kg,
            cubinhos na caixa).
   Nível 3: várias etapas (quanto falta na corrida, fim das aulas com intervalo,
            lajotas no piso).
   Conferência (C) por outro caminho: contagem por subtração repetida, relógio
   andando minuto a minuto etc. Usa o padrão do lote 8º/9º (alt8, nD, fmtDec).
========================================================================= */
const hm6 = min => { min = ((min % 1440) + 1440) % 1440; return `${Math.floor(min / 60)}h${String(min % 60).padStart(2, '0')}`; };
const dur6 = min => min >= 60 ? `${Math.floor(min / 60)} h${min % 60 ? ` ${min % 60} min` : ''}` : `${min} min`;
const un6 = (v, s, p) => `${nD(v)} ${Math.abs(v) === 1 ? s : p}`;
const quantos6 = (total, parte) => { let k = 0, r = total; while(r >= parte - 1e-9){ r -= parte; k++; } return { k, r }; };   // conta tirando de parte em parte
G.grandezas6 = n => {
  const tipo = pick(n === 1 ? ['copos', 'pacotes', 'fita', 'chegada', 'temp'] : n === 2 ? ['duracao', 'festa', 'receita', 'cubos'] : ['corrida', 'aulas', 'lajotas']);
  if(tipo === 'copos'){
    let L, c; do{ L = pick([1, 1.5, 2, 2.5, 3]); c = pick([200, 250, 300, 500]); } while((L * 1000) % c);
    const certa = L * 1000 / c;
    const aa = alt8({ t: un6(certa, 'copo', 'copos'), v: certa }, [
      { t: un6(L * 100 / c, 'copo', 'copos'), v: L * 100 / c, erro: 'usou 1 L = 100 mL' },
      { t: un6(L * 10000 / c, 'copo', 'copos'), v: L * 10000 / c, erro: 'usou 1 L = 10 000 mL' },
      { t: un6(certa + 1, 'copo', 'copos'), v: certa + 1, erro: 'errou a divisão' },
      { t: un6(certa - 1, 'copo', 'copos'), v: certa - 1, erro: 'errou a divisão' },
      { t: un6(Math.floor(L) * 1000 / c, 'copo', 'copos'), v: Math.floor(L) * 1000 / c, erro: 'esqueceu a parte decimal dos litros' }].filter(e => e.v > 0 && Number.isInteger(e.v) && e.v !== certa));
    return { ...aa, text: `Uma garrafa tem ${nD(L)} L de suco. Cada copo leva ${c} mL. Quantos copos ela enche?`, meta: { k: 'div', tot: L * 1000, parte: c, s: 'copo', p: 'copos' }, chave: `g6c${L}-${c}` };
  }
  if(tipo === 'pacotes'){
    let B, p; do{ B = pick([1, 2, 3, 5]); p = pick([100, 200, 250, 500]); } while((B * 1000) % p || B * 1000 / p < 2);
    const certa = B * 1000 / p;
    const prod = pick(['de café', 'de farinha', 'de arroz', 'de açúcar', 'de feijão']);
    const aa = alt8({ t: un6(certa, 'pacote', 'pacotes'), v: certa }, [
      { t: un6(B * 100 / p, 'pacote', 'pacotes'), v: B * 100 / p, erro: 'usou 1 kg = 100 g' },
      { t: un6(B * 10000 / p, 'pacote', 'pacotes'), v: B * 10000 / p, erro: 'usou 1 kg = 10 000 g' },
      { t: un6(certa * 2, 'pacote', 'pacotes'), v: certa * 2, erro: 'errou a divisão' },
      { t: un6(certa + 1, 'pacote', 'pacotes'), v: certa + 1, erro: 'errou a divisão' },
      { t: un6(certa - 1, 'pacote', 'pacotes'), v: certa - 1, erro: 'errou a divisão' }].filter(e => e.v > 0 && Number.isInteger(e.v) && e.v !== certa));
    return { ...aa, text: `Uma loja quer separar ${B} kg ${prod} em pacotes de ${p} g. Quantos pacotes vai fazer?`, meta: { k: 'div', tot: B * 1000, parte: p, s: 'pacote', p: 'pacotes' }, chave: `g6p${B}-${p}` };
  }
  if(tipo === 'fita'){
    let A, p; do{ A = pick([2, 3, 4, 5, 6]); p = pick([10, 20, 25, 40, 50]); } while((A * 100) % p);
    const certa = A * 100 / p;
    const aa = alt8({ t: un6(certa, 'pedaço', 'pedaços'), v: certa }, [
      { t: un6(A * 10 / p, 'pedaço', 'pedaços'), v: A * 10 / p, erro: 'usou 1 m = 10 cm' },
      { t: un6(A * 1000 / p, 'pedaço', 'pedaços'), v: A * 1000 / p, erro: 'usou 1 m = 1 000 cm' },
      { t: un6(certa + 1, 'pedaço', 'pedaços'), v: certa + 1, erro: 'errou a divisão' },
      { t: un6(certa - 1, 'pedaço', 'pedaços'), v: certa - 1, erro: 'errou a divisão' },
      { t: un6(certa * 2, 'pedaço', 'pedaços'), v: certa * 2, erro: 'errou a divisão' }].filter(e => e.v > 0 && Number.isInteger(e.v) && e.v !== certa));
    return { ...aa, text: `Uma fita de ${A} m vai ser cortada em pedaços de ${p} cm. Quantos pedaços saem?`, meta: { k: 'div', tot: A * 100, parte: p, s: 'pedaço', p: 'pedaços' }, chave: `g6f${A}-${p}` };
  }
  if(tipo === 'chegada'){
    const ini = rnd(6, 17) * 60 + rnd(0, 11) * 5, d = rnd(0, 3) * 60 + rnd(1, 11) * 5;
    if((ini % 60) + (d % 60) < 60) return G.grandezas6(n);                  // só os que "passam da hora" (é aí que se erra)
    const certa = ini + d;
    const sem = Math.floor(ini / 60) * 60 + Math.floor(d / 60) * 60;      // horas somadas, minutos somados sem virar hora
    const minSoma = (ini % 60) + (d % 60);
    const aa = alt8({ t: hm6(certa), v: certa }, [
      { t: `${Math.floor(sem / 60)}h${minSoma}`, v: null, erro: 'somou os minutos e não transformou 60 min em 1 h' },
      { t: hm6(certa + 60), v: certa + 60, erro: 'somou 1 hora a mais' },
      { t: hm6(certa - 60), v: certa - 60, erro: 'esqueceu de passar 1 hora' },
      { t: hm6(certa + 40), v: certa + 40, erro: 'contou a hora com 100 minutos' },
      { t: hm6(ini + Math.floor(d / 60) * 60), v: ini + Math.floor(d / 60) * 60, erro: 'somou só as horas' }]);
    return { ...aa, text: `Um ônibus sai às ${hm6(ini)} e a viagem dura ${dur6(d)}. A que horas ele chega?`, meta: { k: 'chegada', ini, d }, chave: `g6h${ini}-${d}` };
  }
  if(tipo === 'temp'){
    const mn = rnd(12, 21), mx = rnd(mn + 4, 36), certa = mx - mn;
    const cid = pick(['Vitória', 'João Neiva', 'Colatina', 'Linhares', 'Aracruz', 'Ibiraçu']);
    const aa = alt8({ t: `${certa} °C`, v: certa }, [
      { t: `${mx + mn} °C`, v: mx + mn, erro: 'somou as temperaturas' },
      { t: `${certa + 1} °C`, v: certa + 1, erro: 'errou a subtração' },
      { t: `${certa - 1} °C`, v: certa - 1, erro: 'errou a subtração' },
      { t: `${certa + 10} °C`, v: certa + 10, erro: 'errou a subtração' }]);
    return { ...aa, text: `Em ${cid}, a temperatura mínima do dia foi ${mn} °C e a máxima foi ${mx} °C. Quantos graus a temperatura subiu?`, meta: { k: 'temp', mn, mx }, chave: `g6t${mn}-${mx}` };
  }
  if(tipo === 'duracao'){
    const ini = rnd(7, 16) * 60 + rnd(0, 11) * 5, d = rnd(1, 3) * 60 + rnd(1, 11) * 5, fim = ini + d;
    if((fim % 60) >= (ini % 60)) return G.grandezas6(n);                  // só quando precisa "emprestar" 1 hora
    const evento = pick(['Um filme começou', 'Uma partida de futebol começou', 'Uma viagem começou', 'Uma prova começou', 'Um show começou']);
    const hd = Math.floor(fim / 60) - Math.floor(ini / 60), md = (fim % 60) - (ini % 60);   // subtração "de cabeça" errada
    const aa = alt8({ t: dur6(d), v: d }, [
      { t: `${hd} h ${md + 40} min`, v: null, erro: 'emprestou 1 hora como se fosse 100 minutos' },
      { t: dur6(d + 60), v: d + 60, erro: 'não tirou a hora emprestada' },
      { t: `${hd} h ${Math.abs(md)} min`, v: null, erro: 'subtraiu os minutos ao contrário' },
      { t: dur6(d - 5), v: d - 5, erro: 'contou 5 minutos a menos' },
      { t: dur6(d + 5), v: d + 5, erro: 'contou 5 minutos a mais' }].filter(e => e.v == null || e.v > 0));
    return { ...aa, text: `${evento} às ${hm6(ini)} e terminou às ${hm6(fim)}. Quanto tempo durou?`, meta: { k: 'duracao', ini, fim }, chave: `g6d${ini}-${fim}` };
  }
  if(tipo === 'festa'){
    const N = rnd(10, 40), m = pick([200, 250, 300]), G2 = 2000, tot = N * m;
    if(tot % G2 === 0) return G.grandezas6(n);                              // queremos o "arredonda para cima"
    const certa = Math.ceil(tot / G2);
    const aa = alt8({ t: un6(certa, 'garrafa', 'garrafas'), v: certa }, [
      { t: un6(Math.floor(tot / G2), 'garrafa', 'garrafas'), v: Math.floor(tot / G2), erro: 'não arredondou para cima: faltaria refrigerante' },
      { t: un6(Math.ceil(tot / 200), 'garrafa', 'garrafas'), v: Math.ceil(tot / 200), erro: 'usou 2 L = 200 mL' },
      { t: un6(Math.ceil(tot / 1000), 'garrafa', 'garrafas'), v: Math.ceil(tot / 1000), erro: 'contou os litros, não as garrafas de 2 L' },
      { t: un6(certa + 1, 'garrafa', 'garrafas'), v: certa + 1, erro: 'comprou uma garrafa a mais' },
      { t: un6(N, 'garrafa', 'garrafas'), v: N, erro: 'uma garrafa por pessoa' }].filter(e => e.v > 0 && e.v !== certa));
    return { ...aa, text: `Numa festa com ${N} pessoas, cada uma vai tomar ${m} mL de refrigerante. No mínimo, quantas garrafas de 2 L precisam comprar?`, meta: { k: 'festa', N, m }, chave: `g6r${N}-${m}` };
  }
  if(tipo === 'receita'){
    const k = rnd(2, 9), g = pick([150, 200, 250, 300, 350, 400, 450, 500, 750]), tot = k * g;
    const item = pick([['bolos', 'farinha'], ['pães', 'farinha'], ['tortas', 'açúcar'], ['pizzas', 'queijo']]);
    const aa = alt8({ t: `${nD(tot / 1000)} kg`, v: tot / 1000 }, [
      { t: `${nD(tot / 100)} kg`, v: tot / 100, erro: 'usou 1 kg = 100 g' },
      { t: `${nD(tot / 10000)} kg`, v: tot / 10000, erro: 'usou 1 kg = 10 000 g' },
      { t: `${nD(tot)} kg`, v: tot, erro: 'não converteu os gramas em quilos' },
      { t: `${nD((k + g) / 1000)} kg`, v: (k + g) / 1000, erro: 'somou em vez de multiplicar' },
      { t: `${nD(g / 1000)} kg`, v: g / 1000, erro: 'calculou para um só' }]);
    return { ...aa, text: `Cada um dos ${item[0]} leva ${g} g de ${item[1]}. Quantos quilos de ${item[1]} são necessários para fazer ${k} ${item[0]}?`, meta: { k: 'receita', n: k, g }, chave: `g6k${k}-${g}` };
  }
  if(tipo === 'cubos'){
    const a = rnd(2, 6), b = rnd(2, 6), c = rnd(2, 5), certa = a * b * c;
    const aa = alt8({ t: un6(certa, 'cubinho', 'cubinhos'), v: certa }, [
      { t: un6(a * b, 'cubinho', 'cubinhos'), v: a * b, erro: 'contou só uma camada' },
      { t: un6(a + b + c, 'cubinho', 'cubinhos'), v: a + b + c, erro: 'somou as medidas' },
      { t: un6(a * b + c, 'cubinho', 'cubinhos'), v: a * b + c, erro: 'somou as camadas em vez de multiplicar' },
      { t: un6(2 * (a * b + a * c + b * c), 'cubinho', 'cubinhos'), v: 2 * (a * b + a * c + b * c), erro: 'contou os quadradinhos da superfície' },
      { t: un6(certa + a * b, 'cubinho', 'cubinhos'), v: certa + a * b, erro: 'contou uma camada a mais' }].filter(e => e.v !== certa));
    return { ...aa, text: `Uma caixa é enchida com cubinhos de 1 cm. No fundo cabem ${a} fileiras de ${b} cubinhos, e a caixa tem ${c} camadas iguais a essa. Quantos cubinhos cabem na caixa?`, meta: { k: 'cubos', a, b, c }, chave: `g6v${a}${b}${c}` };
  }
  if(tipo === 'corrida'){
    const meta = pick([3, 5, 10]), pista = pick([400, 500]);
    const v = rnd(2, Math.floor(meta * 1000 / pista) - 1), feito = v * pista, falta = meta * 1000 - feito;
    const aa = alt8({ t: `${nD(falta / 1000)} km`, v: falta / 1000 }, [
      { t: `${nD(falta / 100)} km`, v: falta / 100, erro: 'usou 1 km = 100 m' },
      { t: `${nD(feito / 1000)} km`, v: feito / 1000, erro: 'calculou o que já correu, não o que falta' },
      { t: `${nD(meta - v)} km`, v: meta - v, erro: 'subtraiu o número de voltas dos quilômetros' },
      { t: `${nD((meta * 1000 - v * 100) / 1000)} km`, v: (meta * 1000 - v * 100) / 1000, erro: 'contou cada volta como 100 m' },
      { t: `${nD(falta / 1000 + 1)} km`, v: falta / 1000 + 1, erro: 'errou a subtração' }].filter(e => e.v > 0));
    return { ...aa, text: `Numa pista de ${pista} m, uma atleta já deu ${v} voltas. Ela quer correr ${meta} km ao todo. Quanto ainda falta correr?`, meta: { k: 'corrida', meta, pista, v }, chave: `g6m${meta}-${pista}-${v}` };
  }
  if(tipo === 'aulas'){
    const ini = pick([7 * 60, 7 * 60 + 10, 7 * 60 + 30, 13 * 60, 13 * 60 + 10]), na = rnd(4, 6), aula = pick([45, 50]), iv = pick([15, 20]);
    const certa = ini + na * aula + iv;
    const aa = alt8({ t: hm6(certa), v: certa }, [
      { t: hm6(ini + na * aula), v: ini + na * aula, erro: 'esqueceu o intervalo' },
      { t: hm6(ini + na * 60 + iv), v: ini + na * 60 + iv, erro: 'contou cada aula como 1 hora' },
      { t: hm6(certa + iv), v: certa + iv, erro: 'contou o intervalo duas vezes' },
      { t: hm6(ini + (na - 1) * aula + iv), v: ini + (na - 1) * aula + iv, erro: 'contou uma aula a menos' },
      { t: hm6(certa + 10), v: certa + 10, erro: 'errou a soma dos minutos' }]);
    return { ...aa, text: `As aulas começam às ${hm6(ini)}. São ${na} aulas de ${aula} min e um intervalo de ${iv} min depois da 3ª aula. A que horas termina a última aula?`, meta: { k: 'aulas', ini, na, aula, iv }, chave: `g6a${ini}-${na}-${aula}-${iv}` };
  }
  // lajotas
  const L = rnd(2, 6), Cm = rnd(2, 6), laj = pick([50, 25]), por = 100 / laj, certa = L * por * Cm * por;
  const aa = alt8({ t: un6(certa, 'lajota', 'lajotas'), v: certa }, [
    { t: un6(L * Cm, 'lajota', 'lajotas'), v: L * Cm, erro: 'contou uma lajota por metro quadrado' },
    { t: un6(L * Cm * por, 'lajota', 'lajotas'), v: L * Cm * por, erro: 'converteu só um dos lados' },
    { t: un6((L + Cm) * 2 * por, 'lajota', 'lajotas'), v: (L + Cm) * 2 * por, erro: 'contou só as lajotas da beirada (perímetro)' },
    { t: un6(L * Cm * 100 / laj, 'lajota', 'lajotas'), v: L * Cm * 100 / laj, erro: 'dividiu a área pelo lado da lajota' },
    { t: un6(certa + L * por, 'lajota', 'lajotas'), v: certa + L * por, erro: 'contou uma fileira a mais' }].filter(e => e.v !== certa));
  return { ...aa, text: `O piso de uma sala tem ${L} m por ${Cm} m. Ele vai ser coberto com lajotas quadradas de ${laj} cm de lado. Quantas lajotas são necessárias?`, meta: { k: 'lajotas', L, C: Cm, laj }, chave: `g6l${L}-${Cm}-${laj}` };
};
/* conferência por outro caminho */
C.grandezas6 = m => {
  const pl = (v, s, p) => `${nD(v)} ${v === 1 ? s : p}`;
  if(m.k === 'div'){ const r = quantos6(m.tot, m.parte); return pl(r.k, m.s, m.p); }
  if(m.k === 'chegada'){ let h = Math.floor(m.ini / 60), mi = m.ini % 60; for(let i = 0; i < m.d; i++){ mi++; if(mi === 60){ mi = 0; h = (h + 1) % 24; } } return `${h}h${String(mi).padStart(2, '0')}`; }
  if(m.k === 'temp'){ let t = m.mn, k = 0; while(t < m.mx){ t++; k++; } return `${k} °C`; }
  if(m.k === 'duracao'){ let t = m.ini, k = 0; while(t < m.fim){ t++; k++; } const h = Math.floor(k / 60), r = k - h * 60; return h ? `${h} h${r ? ` ${r} min` : ''}` : `${r} min`; }
  if(m.k === 'festa'){ let litros = 0, g = 0; while(litros < m.N * m.m){ litros += 2000; g++; } return pl(g, 'garrafa', 'garrafas'); }
  if(m.k === 'receita'){ let s = 0; for(let i = 0; i < m.n; i++) s += m.g; return `${nD(s / 1000)} kg`; }
  if(m.k === 'cubos'){ let k = 0; for(let i = 0; i < m.a; i++) for(let j = 0; j < m.b; j++) for(let l = 0; l < m.c; l++) k++; return pl(k, 'cubinho', 'cubinhos'); }
  if(m.k === 'corrida'){ let falta = m.meta * 1000; for(let i = 0; i < m.v; i++) falta -= m.pista; return `${nD(falta / 1000)} km`; }
  if(m.k === 'aulas'){ let t = m.ini; for(let i = 1; i <= m.na; i++){ t += m.aula; if(i === 3) t += m.iv; } return `${Math.floor(t / 60)}h${String(t % 60).padStart(2, '0')}`; }
  if(m.k === 'lajotas'){ const fx = Math.round(m.L * 100 / m.laj), fy = Math.round(m.C * 100 / m.laj); let k = 0; for(let i = 0; i < fx; i++) k += fy; return pl(k, 'lajota', 'lajotas'); }
  return '?';
};
