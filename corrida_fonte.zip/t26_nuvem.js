/* =========================================================================
   NUVEM (Firebase Realtime Database via REST) — lista de turmas + salvamento automático
   Bloco novo: não altera o jogo. Só o computador do professor grava.
   Dados: /prof/<uid>/lista/<id> = {nome, ano, n, atualizado}
          /prof/<uid>/turmas/<id> = {json, atualizado}   (turma inteira como texto)
========================================================================= */
(function(){
  const NV = {
    apiKey: 'AIzaSyAKvIg_uN2AcX0n0N8KXtr8id01nGFJM08',
    db: 'https://matematica-3df86-default-rtdb.firebaseio.com',
  };
  const LS_NV = 'cgm_nuvem';
  const nv = { sess: lsGet(LS_NV, null), tok: null, exp: 0, lista: null, enviado: '', ultEnvio: 0, status: 'off', hora: '', erro: '', ocupado: false, pegouNuvem: false };
  window.__nv = nv; window.__nvt = { est: () => estado, registroDe, limparTudo };   // para testes

  /* ---------- login (REST do Firebase Auth) ---------- */
  const ERROS = { INVALID_LOGIN_CREDENTIALS: 'E-mail ou senha errados', EMAIL_NOT_FOUND: 'E-mail não cadastrado', INVALID_PASSWORD: 'Senha errada', INVALID_EMAIL: 'E-mail inválido', USER_DISABLED: 'Usuário desativado', TOO_MANY_ATTEMPTS_TRY_LATER: 'Muitas tentativas. Espere alguns minutos' };
  const msgErro = e => { const m = String((e && e.message) || e || ''); const k = Object.keys(ERROS).find(x => m.indexOf(x) === 0); return k ? ERROS[k] : (/fetch|network|Failed/i.test(m) ? 'Sem internet' : m); };
  async function entrar(email, senha){
    const r = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${NV.apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: senha, returnSecureToken: true }) });
    const j = await r.json();
    if(!r.ok) throw new Error((j.error && j.error.message) || 'erro no login');
    nv.sess = { rt: j.refreshToken, uid: j.localId, email: j.email };
    nv.tok = j.idToken; nv.exp = Date.now() + (+j.expiresIn || 3600) * 1000;
    lsSet(LS_NV, nv.sess);
  }
  async function token(){
    if(!nv.sess) throw new Error('não conectado');
    if(nv.tok && Date.now() < nv.exp - 60000) return nv.tok;
    const r = await fetch(`https://securetoken.googleapis.com/v1/token?key=${NV.apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(nv.sess.rt) });
    const j = await r.json();
    if(!r.ok){ const m = (j.error && j.error.message) || ''; if(/TOKEN_EXPIRED|INVALID_REFRESH_TOKEN|USER_NOT_FOUND|USER_DISABLED/.test(m)) sair(true); throw new Error(m || 'erro no login'); }
    nv.tok = j.id_token; nv.exp = Date.now() + (+j.expires_in || 3600) * 1000;
    if(j.refresh_token && j.refresh_token !== nv.sess.rt){ nv.sess.rt = j.refresh_token; lsSet(LS_NV, nv.sess); }
    return nv.tok;
  }
  function sair(expirou){
    nv.sess = null; nv.tok = null; nv.lista = null; nv.status = 'off';
    try{ localStorage.removeItem(LS_NV); }catch(e){}
    desenhar();
    if(expirou) try{ app.toast('☁️ O login da nuvem expirou. Entre de novo no cartão da Trilha.', 'info'); }catch(e){}
  }
  async function api(metodo, caminho, corpo){
    const t = await token();
    const r = await fetch(`${NV.db}/prof/${nv.sess.uid}/${caminho}.json?auth=${encodeURIComponent(t)}`, { method: metodo, headers: { 'Content-Type': 'application/json' }, body: corpo === undefined ? undefined : JSON.stringify(corpo) });
    const j = await r.json().catch(() => null);
    if(!r.ok) throw new Error((j && j.error) || ('HTTP ' + r.status));
    return j;
  }

  /* ---------- pacote da turma (mesmo conteúdo do arquivo salvo) ---------- */
  function pacote(){
    const c = estado.cfg;
    return Object.assign({}, estado.turma, { cfg: { ano: c.ano, anoMax: c.anoMax || 9, rev: c.rev || 0.2, aj: c.aj, diag: c.diag, lista: c.lista, nomes: c.nomes || [],
      modo: c.modo, rank: c.rank, treinoMin: c.treinoMin, foco: c.foco, linkAlunos: c.linkAlunos, desafio: c.desafio } });
  }
  const resumo = t => ({ nome: t.nome || '(sem nome)', ano: (t.cfg && t.cfg.ano) || 0, n: (t.cfg && t.cfg.nomes && t.cfg.nomes.length) || Object.keys(t.alunos || {}).length, atualizado: t.atualizado || new Date().toISOString() });
  const ativa = () => !!(nv.sess && estado.turma && estado.turma.nuvemId);
  estado.nuvemAtiva = ativa;
  const horaAgora = () => new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  async function enviar(forcar){
    if(!ativa() || nv.ocupado) return;
    let demo = false; try{ demo = !!(app.host && app.host.isDemo) || app.mode !== 'teacher'; }catch(e){}
    if(demo) return;                       // só a tela do professor grava (aba de aluno no mesmo navegador não)
    const t = pacote(), s = JSON.stringify(t);
    if(!forcar && s === nv.enviado) return;
    const id = estado.turma.nuvemId;
    nv.ocupado = true; nv.status = 'salvando'; pintar();
    try{
      const at = new Date().toISOString();
      await api('PATCH', '', { [`turmas/${id}`]: { json: s, atualizado: at }, [`lista/${id}`]: Object.assign(resumo(t), { atualizado: at }) });
      nv.enviado = s; nv.ultEnvio = Date.now(); nv.status = 'ok'; nv.hora = horaAgora(); nv.erro = '';
      lsSet('cgm_nuvem_env', { id, at });
      if(nv.lista) nv.lista[id] = Object.assign(resumo(t), { atualizado: at });
      else carregarLista();                  // a lista não tinha carregado (ex.: regras ainda não publicadas): tenta de novo
    }catch(e){ nv.status = 'erro'; nv.erro = msgErro(e); }
    nv.ocupado = false; pintar();
  }
  async function carregarLista(){
    if(!nv.sess || nv.lendo) return;
    nv.lendo = true; nv.ultLista = Date.now();
    try{ nv.lista = (await api('GET', 'lista')) || {}; nv.erroLista = ''; nv.erro = ''; }
    catch(e){ nv.erroLista = msgErro(e); nv.erro = nv.erroLista; }
    nv.lendo = false;
    desenhar();
  }
  /* abre uma turma da nuvem usando o MESMO carregador do arquivo (carregarTurma) */
  function abrirTurma(id, silencioso){
    return (async () => {
      if(ativa() && estado.turma.nuvemId !== id) await enviar();      // guarda a turma atual antes de trocar
      const d = await api('GET', `turmas/${id}`);
      if(!d || !d.json) throw new Error('turma não encontrada');
      const t = JSON.parse(d.json); t.nuvemId = id;
      nv.abrindo = id;
      await new Promise(ok => {
        const blob = new Blob([JSON.stringify(t)], { type: 'application/json' });
        carregarTurma(blob);
        const ini = Date.now();
        const esp = setInterval(() => { if(estado.turma === t || (estado.turma && estado.turma.nuvemId === id) || Date.now() - ini > 3000){ clearInterval(esp); ok(); } }, 30);
      });
      if(estado.turma.nuvemId !== id) throw new Error('não foi possível abrir');
      if(!estado.turma.codigo) estado.turma.codigo = roomCode();             // turmas antigas ganham código fixo
      if(t.cfg && t.cfg.desafio !== undefined){ estado.cfg.desafio = t.cfg.desafio; salvarCfg(); }
      ['cgm_treino_hoje', 'cgm_partida_prof'].forEach(k => { try{ localStorage.removeItem(k); }catch(e){} });
      estado.snap = {}; estado.alertas = {}; estado.hoje = {};
      lsSet(LS_TURMA, estado.turma);
      nv.enviado = JSON.stringify(pacote()); nv.status = 'ok'; nv.hora = horaAgora();
      lsSet('cgm_nuvem_env', { id, at: d.atualizado || '' });
      const card = $('trilhaCard'); if(card){ card.remove(); montarCartao(); } else desenhar();
      if(!silencioso) app.toast(`☁️ Turma <b>${esc(t.nome || '')}</b> aberta · salvando automaticamente`, 'success');
    })().catch(e => { nv.erro = msgErro(e); desenhar(); alert('Não foi possível abrir a turma: ' + msgErro(e)); });
  }
  async function criarTurma(nome, ano, usarAtual){
    const id = 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    if(!usarAtual){
      limparTudo();
      estado.cfg.ano = ano; if((estado.cfg.anoMax || 9) < ano) estado.cfg.anoMax = ano;
      if(estado.cfg.aj) delete estado.cfg.aj.tema;
      salvarCfg();
    }
    estado.turma.nome = nome; estado.turma.nuvemId = id; estado.turma.atualizado = new Date().toISOString();
    if(!estado.turma.codigo) estado.turma.codigo = roomCode();               // código fixo da turma
    if(!usarAtual){ estado.cfg.lista = true; salvarCfg(); }                    // turma nova: aluno entra tocando no nome
    lsSet(LS_TURMA, estado.turma);
    nv.enviado = '';
    await enviar(true);
    if(nv.status !== 'ok'){ alert('A turma foi criada neste computador, mas ainda não subiu para a nuvem (' + nv.erro + '). Ela sobe sozinha quando a internet voltar.'); }
    const card = $('trilhaCard'); if(card){ card.remove(); montarCartao(); }
    app.toast(`☁️ Turma <b>${esc(nome)}</b> ${usarAtual ? 'guardada na nuvem' : 'criada'} · salvando automaticamente`, 'success');
  }
  async function apagarTurma(id){
    await api('PATCH', '', { [`turmas/${id}`]: null, [`lista/${id}`]: null });
    if(nv.lista) delete nv.lista[id];
    if(estado.turma.nuvemId === id){ delete estado.turma.nuvemId; lsSet(LS_TURMA, estado.turma); nv.enviado = ''; }
    desenhar();
  }

  /* ---------- interface no cartão da Trilha ---------- */
  const st = document.createElement('style');
  st.textContent = `
  .nv-box{background:linear-gradient(135deg,#0c4a6e,#1e3a8a);border:2px solid #38bdf8;border-radius:14px;padding:12px;margin:0 0 14px;color:#e0f2fe}
  .nv-box h4{margin:0 0 8px;font-size:15px;display:flex;align-items:center;gap:8px}
  .nv-box h4 small{margin-left:auto;font-weight:600;font-size:11px;color:#bae6fd}
  .nv-box input,.nv-box select{width:100%;margin:4px 0;box-sizing:border-box}
  .nv-box button{cursor:pointer}
  .nv-lista{display:flex;flex-direction:column;gap:6px;max-height:260px;overflow:auto;margin:6px 0}
  .nv-item{display:flex;align-items:center;gap:6px}
  .nv-item .nv-abre{flex:1;text-align:left;background:#f0f9ff;color:#0c4a6e;border:2px solid #7dd3fc;border-radius:10px;padding:9px 12px;font-weight:900;font-size:15px}
  .nv-item .nv-abre small{display:block;font-weight:600;font-size:11px;color:#0369a1}
  .nv-item.atual .nv-abre{background:#dcfce7;border-color:#22c55e;color:#14532d}
  .nv-item .nv-del{background:transparent;border:none;color:#fca5a5;font-size:16px;padding:4px}
  .nv-acoes{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
  .nv-acoes button{flex:1;min-width:120px;border-radius:10px;padding:8px;font-weight:800;border:2px solid #7dd3fc;background:#082f49;color:#e0f2fe}
  .nv-ok{color:#86efac;font-weight:800}.nv-er{color:#fca5a5;font-weight:800}
  .nv-cod{font-size:13px;margin-bottom:6px;display:flex;align-items:center;gap:8px}
  .nv-cod b{font-size:20px;letter-spacing:3px;color:#fde68a;background:#082f49;border-radius:8px;padding:2px 10px}
  .nv-cod button{margin-left:auto;background:transparent;border:1px solid #7dd3fc;color:#bae6fd;border-radius:8px;padding:3px 8px;font-size:12px}
  .nv-form{background:#082f49;border-radius:10px;padding:8px;margin-top:6px}
  #nvSelo{position:fixed;right:10px;bottom:8px;z-index:50;font:700 12px system-ui,sans-serif;background:rgba(8,47,73,.85);color:#e0f2fe;border:1px solid #38bdf8;border-radius:999px;padding:3px 10px;pointer-events:none}
  #nvSelo.er{border-color:#f87171;color:#fecaca}`;
  document.head.appendChild(st);

  function linhaStatus(){
    if(!ativa()) return '';
    if(nv.status === 'salvando') return '⏳ salvando…';
    if(nv.status === 'erro') return `<span class="nv-er">⚠️ ${esc(nv.erro || 'sem conexão')} — guardado neste computador, sobe quando voltar</span>`;
    return nv.hora ? `<span class="nv-ok">✓ salvo às ${nv.hora}</span>` : '<span class="nv-ok">✓ salvando automaticamente</span>';
  }
  function boxHTML(){
    if(!nv.sess) return `<h4>☁️ Turmas na nuvem</h4>
      <div style="font-size:12px;margin-bottom:6px">Entre uma vez neste computador: depois é só escolher a turma; o progresso salva sozinho.</div>
      <input id="nvEmail" type="email" placeholder="seu e-mail" autocomplete="username">
      <input id="nvSenha" type="password" placeholder="senha" autocomplete="current-password">
      <div class="nv-acoes"><button id="nvEntrar">Entrar</button></div>
      <div id="nvMsg" class="nv-er" style="font-size:12px;margin-top:4px">${esc(nv.erro || '')}</div>`;
    const L = nv.lista;
    const cur = estado.turma && estado.turma.nuvemId;
    const itens = L ? Object.entries(L).sort((a, b) => String(a[1].nome).localeCompare(String(b[1].nome), 'pt-BR', { numeric: true })) : [];
    const nAl = Object.keys(estado.turma.alunos || {}).length;
    return `<h4>☁️ Turmas na nuvem <small>${esc(nv.sess.email || '')} · <a href="#" id="nvSair" style="color:#bae6fd">sair</a></small></h4>
      ${cur ? `<div style="font-size:13px;margin-bottom:4px">Aberta: <b>${esc(estado.turma.nome || '(sem nome)')}</b> · <span id="nvLinha">${linhaStatus()}</span></div>
        <div class="nv-cod">Código da turma: <b>${esc(estado.turma.codigo || '----')}</b><button id="nvTrocaCod" title="Gera um código novo (use se o código vazar)">🔄 trocar</button></div>` : `<div style="font-size:13px;margin-bottom:4px;color:#fde68a;font-weight:800">👇 Escolha a turma desta aula</div>`}
      <div class="nv-lista">${L === null ? `<div style="font-size:12px">${nv.erroLista ? `<span class="nv-er">⚠️ Não consegui ler a lista: ${esc(nv.erroLista)}</span> · tentando de novo…` : 'carregando…'}</div>` : itens.length ? itens.map(([id, t]) => `<div class="nv-item ${id === cur ? 'atual' : ''}">
          <button class="nv-abre" data-nvabre="${esc(id)}">${id === cur ? '✅ ' : ''}${esc(t.nome)}<small>${t.ano ? t.ano + 'º ano · ' : ''}${t.n || 0} aluno${t.n === 1 ? '' : 's'} · ${t.atualizado ? new Date(t.atualizado).toLocaleDateString('pt-BR') : ''}</small></button>
          <button class="nv-del" data-nvdel="${esc(id)}" title="Apagar esta turma da nuvem">🗑</button></div>`).join('') : '<div style="font-size:12px">Nenhuma turma ainda. Crie a primeira abaixo.</div>'}</div>
      ${nv.erro && !cur ? `<div class="nv-er" style="font-size:12px">⚠️ ${esc(nv.erro)}</div>` : ''}
      <div class="nv-acoes"><button id="nvNova">➕ Nova turma</button>${!cur && nAl ? `<button id="nvSubir" title="Guarda na nuvem a turma que está aberta agora (por exemplo, a que veio de um arquivo)">⬆️ Guardar a turma atual (${nAl} alunos)</button>` : ''}</div>
      <div id="nvForm"></div>`;
  }
  function formHTML(usarAtual){
    const anoAtual = estado.cfg.ano || 6;
    return `<div class="nv-form"><input id="nvNome" maxlength="40" placeholder="Nome da turma (ex.: 6º M01)" value="${usarAtual ? esc(estado.turma.nome || '') : ''}">
      ${usarAtual ? '' : `<select id="nvAno">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<option value="${a}" ${a === anoAtual ? 'selected' : ''}>${a}º ano</option>`).join('')}</select>`}
      <div class="nv-acoes"><button id="nvCriar" data-atual="${usarAtual ? 1 : 0}">${usarAtual ? '⬆️ Guardar' : '✅ Criar'}</button><button id="nvCancela">Cancelar</button></div></div>`;
  }
  function desenhar(){
    const card = $('trilhaCard'); if(!card) return;
    let box = $('nvBox');
    if(!box){
      box = document.createElement('div'); box.id = 'nvBox'; box.className = 'nv-box';
      const lab = card.querySelector('label'); if(lab) lab.after(box); else card.prepend(box);
      box.onclick = async e => {
        const t = e.target;
        if(t.id === 'nvEntrar'){
          const em = $('nvEmail').value.trim(), se = $('nvSenha').value;
          if(!em || !se) return;
          t.disabled = true; t.textContent = 'Entrando…';
          try{ await entrar(em, se); nv.erro = ''; nv.lista = null; desenhar(); await carregarLista(); }
          catch(err){ nv.erro = msgErro(err); desenhar(); }
          return;
        }
        if(t.id === 'nvSair'){ e.preventDefault(); if(confirm('Sair da nuvem neste computador? (o progresso já salvo continua na nuvem)')) sair(); return; }
        const ab = t.closest('[data-nvabre]');
        if(ab){
          const id = ab.dataset.nvabre;
          if(estado.turma.nuvemId === id) return;
          const nAl = Object.keys(estado.turma.alunos || {}).length;
          if(!estado.turma.nuvemId && nAl && !confirm(`A turma aberta agora (${nAl} alunos) NÃO está na nuvem e será substituída. Continuar?\n\n(Para guardá-la, cancele e use "⬆️ Guardar a turma atual".)`)) return;
          ab.disabled = true; ab.style.opacity = .6;
          await abrirTurma(id); return;
        }
        const dl = t.closest('[data-nvdel]');
        if(dl){
          const id = dl.dataset.nvdel, nm = (nv.lista && nv.lista[id] && nv.lista[id].nome) || '';
          if(prompt(`Apagar a turma "${nm}" da nuvem com todo o progresso?\nIsso não tem volta. Digite APAGAR para confirmar.`) !== 'APAGAR') return;
          try{ await apagarTurma(id); app.toast('🗑 Turma apagada da nuvem', 'info'); }catch(err){ alert('Não foi possível apagar: ' + msgErro(err)); }
          return;
        }
        if(t.id === 'nvNova' || t.id === 'nvSubir'){ $('nvForm').innerHTML = formHTML(t.id === 'nvSubir'); $('nvNome').focus(); return; }
        if(t.id === 'nvTrocaCod'){
          if(!confirm(`Trocar o código da turma ${estado.turma.nome || ''}?\nO código ${estado.turma.codigo} deixa de valer; os alunos passam a digitar o novo.${app.room ? '\n(Vale a partir da próxima sala que você criar.)' : ''}`)) return;
          let c; do{ c = roomCode(); }while(c === estado.turma.codigo);
          estado.turma.codigo = c; salvarTurmaLocal(); estado.turma.atualizado = new Date().toISOString(); lsSet(LS_TURMA, estado.turma);
          desenhar(); app.toast(`🔄 Código novo da turma: <b>${c}</b>`, 'success'); return;
        }
        if(t.id === 'nvCancela'){ $('nvForm').innerHTML = ''; return; }
        if(t.id === 'nvCriar'){
          const nome = $('nvNome').value.trim(); if(!nome){ $('nvNome').focus(); return; }
          const usarAtual = t.dataset.atual === '1';
          if(!usarAtual){
            const nAl = Object.keys(estado.turma.alunos || {}).length;
            if(!estado.turma.nuvemId && nAl && !confirm(`A turma aberta agora (${nAl} alunos) NÃO está na nuvem e será substituída pela turma nova. Continuar?`)) return;
          }
          t.disabled = true;
          if(ativa() && !usarAtual) await enviar();
          await criarTurma(nome, usarAtual ? estado.cfg.ano : +$('nvAno').value, usarAtual);
          return;
        }
      };
      box.onkeydown = e => { if(e.key === 'Enter' && (e.target.id === 'nvSenha' || e.target.id === 'nvEmail')) $('nvEntrar').click(); if(e.key === 'Enter' && e.target.id === 'nvNome') $('nvCriar').click(); };
    }
    box.innerHTML = boxHTML();
  }
  function pintar(){
    const l = $('nvLinha'); if(l) l.innerHTML = linhaStatus();
    let s = $('nvSelo');
    let prof = false; try{ prof = app.mode === 'teacher' && !app.host.isDemo; }catch(e){}
    if(!ativa() || !prof){ if(s) s.remove(); return; }
    if(!s){ s = document.createElement('div'); s.id = 'nvSelo'; document.body.appendChild(s); }
    s.className = nv.status === 'erro' ? 'er' : '';
    s.textContent = nv.status === 'erro' ? '☁️ ⚠️ sem conexão · guardado aqui' : nv.status === 'salvando' ? '☁️ salvando…' : `☁️ ✓ ${nv.hora || ''}`;
  }

  /* arquivo aberto à mão nunca fica ligado à nuvem (evita que um arquivo velho sobrescreva o progresso) */
  const carregarTurma0 = carregarTurma;
  carregarTurma = function(file){
    const abrindo = nv.abrindo; nv.abrindo = null;
    if(!file || typeof file.text !== 'function') return carregarTurma0.apply(this, arguments);
    file.text().then(txt => {
      try{ const t = JSON.parse(txt); if(t && t.nuvemId && t.nuvemId !== abrindo){ delete t.nuvemId; txt = JSON.stringify(t); } }catch(e){}
      carregarTurma0(new Blob([txt], { type: 'application/json' }));
    });
  };

  /* o cartão é refeito em vários momentos: recoloca o bloco */
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); desenhar(); return r; };

  /* ao abrir: se a nuvem tem versão mais nova da turma aberta (outro computador), puxa */
  async function inicio(){
    desenhar();
    if(!nv.sess) return;
    await carregarLista();
    const id = estado.turma && estado.turma.nuvemId;
    if(id && nv.lista){
      const r = nv.lista[id];
      if(!r){ delete estado.turma.nuvemId; lsSet(LS_TURMA, estado.turma); desenhar(); return; }   // apagada em outro computador
      const env = lsGet('cgm_nuvem_env', {});
      if(r.atualizado && (env.id !== id || !env.at || r.atualizado > env.at)){ await abrirTurma(id, true); app.toast(`☁️ Turma <b>${esc(r.nome)}</b> atualizada com a versão da nuvem`, 'info'); }
      else { nv.enviado = ''; enviar(); }
    }
  }
  setTimeout(inicio, 300);

  /* salvamento automático: confere a cada 5 s e sobe no máximo a cada 15 s */
  setInterval(() => {
    if(nv.sess && nv.lista === null && Date.now() - (nv.ultLista || 0) > 10000) carregarLista();   // lista não veio: tenta a cada 10 s
    if(!ativa()) { pintar(); return; }
    if(Date.now() - nv.ultEnvio >= 15000 || nv.status === 'erro') enviar();
    pintar();
  }, 5000);
  window.addEventListener('online', () => { if(ativa()) enviar(); });
  document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'hidden' && ativa()) enviar(); });
  /* no fim da partida, salva na hora */
  const fim0 = app.endGame;
  if(typeof fim0 === 'function') app.endGame = function(){ const r = fim0.apply(this, arguments); setTimeout(() => enviar(), 2500); return r; };
})();
