
/* =========================================================================
   INTEGRAÇÃO COM A CORRIDA (só wrappers — as funções originais não mudam)
========================================================================= */
const LS_CFG = 'cgm_trilha_cfg', LS_TURMA = 'cgm_trilha_turma';
const lsGet = (k, pad) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : pad; } catch(e){ return pad; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} };

const estado = {
  cfg: Object.assign({ ano: 1, anoMax: 9, rev: 0.2, diag: 'saltos', lista: false, nomes: [] }, lsGet(LS_CFG, {}), { on: true }),   // trilha sempre abre LIGADA
  turma: lsGet(LS_TURMA, null) || { tipo: 'corrida-trilha-turma', versao: 1, nome: '', criado: new Date().toISOString(), alunos: {} },
  snap: {}, alertas: {}, salvarT: null, hoje: {}, enviado: {},
};
LIMITE.anoMax = estado.cfg.anoMax || 9; LIMITE.pRev = estado.cfg.rev || 0.2;
if(!estado.cfg.aj) estado.cfg.aj = { off: [], anos: {} };
aplicarAjustes(estado.cfg.aj);
const salvarCfg = () => { LIMITE.anoMax = estado.cfg.anoMax || 9; LIMITE.pRev = estado.cfg.rev || 0.2; aplicarAjustes(estado.cfg.aj); lsSet(LS_CFG, estado.cfg); };
const salvarTurmaLocal = () => { clearTimeout(estado.salvarT); estado.salvarT = setTimeout(() => { estado.turma.atualizado = new Date().toISOString(); lsSet(LS_TURMA, estado.turma); }, 1500); };
function registroDe(nome){
  const k = normNome(nome);
  if(!k) return null;
  let r = estado.turma.alunos[k];
  if(!r){ r = estado.turma.alunos[k] = novoRegistro(String(nome).trim()); salvarTurmaLocal(); }
  return r;
}

/* ---------------- estilos (acrescentados) ---------------- */
function injetarEstilos(){
  const st = document.createElement('style');
  st.id = 'trilhaCSS';
  st.textContent = `
  .pp-question .qimage.trilha-fig{max-height:300px;max-width:100%}
  @media(max-height:800px){.pp-question .qimage.trilha-fig{max-height:220px}}
  @media(max-height:640px){.pp-question .qimage.trilha-fig{max-height:160px}}
  .pp-opt.tr-img{padding:8px}
  .pp-opt.tr-img img{max-height:96px;max-width:100%;pointer-events:none;background:#fff;border-radius:10px}
  @media(max-width:520px){.pp-opt.tr-img{min-height:64px;padding:6px}.pp-opt.tr-img img{max-height:60px}}
  .tr-info{font-size:13px;font-weight:800;color:var(--muted);letter-spacing:.3px;position:relative;z-index:1}
  .tr-info b{color:#93c5fd}
  .tr-ajuda-btn{position:relative;z-index:1;margin:6px auto 0;display:block;background:#fef3c7;color:#92400e;border:2px solid #f59e0b;border-radius:999px;font-weight:900;font-size:15px;padding:6px 16px;cursor:pointer}
  .tr-ajuda-btn:disabled{opacity:.45;cursor:default}
  .tr-ajuda{position:relative;z-index:1;margin:8px auto 0;max-width:640px;background:#fffbeb;color:#422006;border:2px solid #f59e0b;border-radius:14px;padding:10px 14px;font-size:clamp(15px,3.6vw,20px);font-weight:700;line-height:1.35;text-align:left}
  .tr-ajuda .resp{margin-top:6px;color:#166534;font-weight:900}
  .pp-opt.tr-dica-certa{outline:5px solid #22c55e;outline-offset:2px}
  .tr-banner{position:fixed;left:50%;bottom:96px;transform:translateX(-50%);pointer-events:none;z-index:300;background:linear-gradient(135deg,#f59e0b,#d97706);
    color:#fff;font-weight:900;font-size:clamp(20px,5vw,30px);padding:18px 28px;border-radius:18px;box-shadow:0 12px 40px rgba(0,0,0,.5);
    text-align:center;animation:trPop .5s}
  @keyframes trPop{0%{transform:translateX(-50%) scale(.6);opacity:0}100%{transform:translateX(-50%) scale(1);opacity:1}}
  .tr-nomes{margin-top:14px;text-align:left}
  .tr-nomes .tt{font-weight:900;font-size:18px;margin-bottom:10px;text-align:center}
  .tr-nomes .grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
  .tr-nomes button{padding:16px 10px;border-radius:14px;background:var(--panel2);border:3px solid var(--line);color:var(--text);
    font-size:20px;font-weight:900;cursor:pointer}
  .tr-nomes button:hover:not(:disabled){border-color:#3b82f6}
  .tr-nomes button:disabled{opacity:.35;cursor:not-allowed;text-decoration:line-through}
  .tr-alertas{margin-top:14px;background:rgba(239,68,68,.08);border:2px solid rgba(239,68,68,.5);border-radius:16px;padding:14px 18px}
  .tr-alertas h3{font-size:16px;margin-bottom:8px}
  .tr-alerta{display:flex;gap:12px;align-items:center;padding:8px 0;border-top:1px solid var(--line);font-size:14px}
  .tr-alerta b{font-size:15px}
  .tr-alerta .ok{margin-left:auto}
  .tr-tab{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px}
  .tr-tab th,.tr-tab td{padding:7px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
  .tr-tab th{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.8px}
  .tr-tab tr.trav td{background:rgba(239,68,68,.08)}
  .tr-mapa{max-height:320px;overflow:auto;margin-top:10px;border:1px solid var(--line);border-radius:10px}
  .tr-sec{margin-top:26px;text-align:left;background:var(--panel);border:2px solid var(--line);border-radius:16px;padding:20px}
  .tr-sec h2{font-size:20px;margin-bottom:6px}
  .tr-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px}
  .tr-row label{margin:0}
  .cat-fundo{position:fixed;inset:0;z-index:500;background:#020617;overflow:auto;padding:14px}
  .cat-topo{position:sticky;top:0;z-index:2;background:#0f172a;border:2px solid var(--line);border-radius:14px;padding:12px 14px;display:flex;flex-wrap:wrap;gap:8px;align-items:center}
  .cat-topo h2{font-size:18px;margin-right:10px}
  .cat-topo .ab{padding:9px 14px;border-radius:10px;background:var(--panel2);border:2px solid var(--line);color:var(--text);font-weight:900;cursor:pointer}
  .cat-topo .ab.on{background:#3b82f6;border-color:#3b82f6}
  .cat-topo .dir{margin-left:auto;display:flex;gap:8px}
  .cat-deg{margin-top:14px;background:var(--panel);border:2px solid var(--line);border-radius:14px;padding:12px}
  .cat-deg h3{font-size:16px;margin-bottom:2px}
  .cat-deg.desligada{opacity:.45}
  .cat-deg.desligada h3::after{content:' — fora da trilha';color:#f87171;font-size:13px}
  .cat-ctl{display:flex;flex-wrap:wrap;gap:14px;align-items:center;float:right;font-size:14px;font-weight:800;color:var(--text)}
  .cat-ctl input{width:20px;height:20px;vertical-align:middle;accent-color:#22c55e}
  .cat-ctl select{width:auto;padding:4px 8px;font-weight:800}
  .cat-ctl .era{color:#fbbf24;font-size:12px}
  .cat-deg .sub{color:var(--muted);font-size:12px;margin-bottom:10px}
  .cat-grade{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
  @media(max-width:900px){.cat-grade{grid-template-columns:1fr}}
  .cat-q{background:#f8fafc;color:#0f172a;border-radius:12px;padding:10px;display:flex;flex-direction:column;gap:8px}
  .cat-q .cab{display:flex;justify-content:space-between;align-items:center;font-size:12px;font-weight:900;color:#475569}
  .cat-q .cab button{background:#e2e8f0;border:1px solid #94a3b8;border-radius:8px;padding:3px 8px;font-weight:800;cursor:pointer}
  .cat-q .enun{font-size:18px;font-weight:900;line-height:1.2}
  .cat-mais{display:block;margin:10px auto 0;background:#1e3a8a;color:#fff;border:0;border-radius:10px;padding:10px 18px;font-weight:800;font-size:15px;cursor:pointer}
  .cat-q .dica{font-size:13px;color:#92400e;background:#fffbeb;border-radius:8px;padding:4px 8px;margin:4px 0;line-height:1.3}
  .cat-q img.fig{max-width:100%;max-height:210px;align-self:center;border:1px solid #cbd5e1;border-radius:8px;background:#fff}
  .cat-q .alts{display:grid;grid-template-columns:1fr 1fr;gap:6px}
  .cat-q .alt{border:2px solid #cbd5e1;border-radius:8px;padding:6px;font-weight:900;font-size:16px;background:#fff}
  .cat-q .alt.certa{border-color:#16a34a;background:#dcfce7}
  .cat-q .alt img{height:46px;display:block;margin:0 auto 2px}
  .cat-q .alt small{display:block;font-size:11px;font-weight:700;color:#b91c1c}
  .cat-q .alt.certa small{color:#15803d}
  .tr-bot{font-size:11px;font-weight:800;color:#fbbf24;margin-top:6px;text-align:center}
  `;
  document.head.appendChild(st);
}

/* ---------------- cartão da trilha na tela do professor ---------------- */
function segHTML(id, itens, valor){
  return `<div class="seg" id="${id}">` + itens.map(([v, t]) => `<button data-v="${v}" class="${String(v) === String(valor) ? 'on' : ''}">${t}</button>`).join('') + `</div>`;
}
function montarCartao(){
  const ref = $('gradeSelect') && $('gradeSelect').closest('.card');
  if(!ref || $('trilhaCard')) return;
  const c = estado.cfg;
  const card = document.createElement('div');
  card.className = 'card'; card.id = 'trilhaCard';
  card.innerHTML = `
    <label>🧗 Trilha BNCC (1º ao 9º ano)</label>
    <div style="color:var(--muted);font-size:12px;line-height:1.55;margin-bottom:10px">
      Cada aluno sobe degrau a degrau conforme domina a habilidade. Quando ligada, substitui a série e o banco de questões.
    </div>
    ${segHTML('trOn', [[0, 'Desligada'], [1, '✅ Ligada']], c.on ? 1 : 0)}
    <button class="ghost" id="trCatalogo" style="width:100%;margin-top:10px;font-size:14px;padding:12px">📋 Ver todas as atividades (por ano)</button>
    <div id="trOpts" class="${c.on ? '' : 'hidden'}" style="margin-top:14px">
      <div class="tr-row"><label>A trilha vai até</label>
        <select id="trAnoMax" style="width:auto;font-weight:800">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<option value="${a}" ${a === (c.anoMax || 9) ? 'selected' : ''}>${a === 9 ? 'o 9º ano (tudo)' : `o ${a}º ano`}</option>`).join('')}</select></div>
      <div style="color:var(--muted);font-size:12px;margin:-4px 0 6px">Os anos depois deste ficam desligados: nenhum aluno recebe atividade deles. Fica salvo neste navegador.</div>
      <div class="tr-row"><label>Ano da turma</label>
        <select id="trAno" style="width:auto;font-weight:800">${[1, 2, 3, 4, 5, 6, 7, 8, 9].filter(a => a <= (c.anoMax || 9)).map(a => `<option value="${a}" ${a === c.ano ? 'selected' : ''}>${a}º ano</option>`).join('')}</select></div>
      <div style="margin-top:12px"><label>Quem ainda não tem progresso começa por</label>
        ${segHTML('trDiag', [['saltos', '🔎 Diagnóstico por saltos'], ['ano', 'Início do ano da turma'], ['inicio', 'Primeiro degrau']], c.diag)}</div>
      <div style="margin-top:12px"><label>Quanto é revisão dos anos anteriores</label>
        ${segHTML('trRev', [['0.2', '2 de cada 10'], ['0.4', '4 de cada 10'], ['0.5', '5 de cada 10']], String(c.rev || 0.2))}
        <div style="color:var(--muted);font-size:12px;margin-top:4px">Tabuada, divisão, frações, decimais e porcentagem voltam com mais frequência.</div></div>
      <div style="margin-top:12px"><label>Aluno entra tocando no nome (lista)</label>
        ${segHTML('trLista', [[0, 'Não'], [1, '✅ Sim']], c.lista ? 1 : 0)}
        <textarea id="trNomes" spellcheck="false" style="margin-top:8px;min-height:90px" placeholder="Um nome por linha (vem do arquivo da turma)">${esc((c.nomes || []).join('\n'))}</textarea></div>
      <div class="tr-row"><label>Turma</label><input id="trTurmaNome" style="width:200px" maxlength="40" placeholder="Ex.: 1º ano A" value="${esc(estado.turma.nome || '')}"></div>
      <div class="config-actions" style="margin-top:12px">
        <button class="ghost" id="trCarregar">📂 Carregar turma</button>
        <button class="ghost" id="trSalvar" title="Salva alunos, progresso e TODAS as configurações (tipo de sala, foco da aula, lista…). Pode salvar antes de jogar.">💾 Salvar turma e configurações</button>
        <button class="ghost" id="trNova">🧹 Nova turma</button>
        <button class="ghost" id="trVerMapa">🗺️ Ver degraus</button>
        <input type="file" id="trArquivo" accept=".json,application/json" class="hidden">
      </div>
      <div id="trStatus" style="color:var(--muted);font-size:12px;margin-top:10px;line-height:1.5"></div>
      <div id="trMapa" class="tr-mapa hidden"></div>
    </div>`;
  ref.after(card);

  const seg = (id, fn) => { $(id).onclick = e => { const b = e.target.closest('button[data-v]'); if(!b) return; [...$(id).children].forEach(x => x.classList.toggle('on', x === b)); fn(b.dataset.v); salvarCfg(); }; };
  seg('trOn', v => { c.on = v === '1'; $('trOpts').classList.toggle('hidden', !c.on); });
  seg('trDiag', v => c.diag = v);
  seg('trRev', v => c.rev = +v);
  seg('trLista', v => c.lista = v === '1');
  $('trAno').onchange = e => { c.ano = +e.target.value; salvarCfg(); };
  $('trAnoMax').onchange = e => {
    c.anoMax = +e.target.value;
    if(c.ano > c.anoMax) c.ano = c.anoMax;
    $('trAno').innerHTML = [1, 2, 3, 4, 5, 6, 7, 8, 9].filter(a => a <= c.anoMax).map(a => `<option value="${a}" ${a === c.ano ? 'selected' : ''}>${a}º ano</option>`).join('');
    salvarCfg(); atualizarStatus();
  };
  $('trNomes').oninput = e => { c.nomes = nomesDaCaixa(); salvarCfg(); };
  $('trTurmaNome').oninput = e => { estado.turma.nome = e.target.value.trim(); salvarTurmaLocal(); };
  $('trCarregar').onclick = () => $('trArquivo').click();
  $('trArquivo').onchange = e => { const f = e.target.files && e.target.files[0]; if(f) carregarTurma(f); e.target.value = ''; };
  $('trSalvar').onclick = () => baixarTurma();
  $('trNova').onclick = () => {
    if(!confirm('Começar uma turma nova? O progresso atual continua no arquivo que você salvou (salve antes, se precisar).')) return;
    estado.turma = { tipo: 'corrida-trilha-turma', versao: 1, nome: '', criado: new Date().toISOString(), alunos: {} };
    $('trTurmaNome').value = ''; salvarTurmaLocal(); atualizarStatus();
  };
  $('trCatalogo').onclick = () => abrirCatalogo(c.ano || 1);
  $('trVerMapa').onclick = () => { const m = $('trMapa'); m.classList.toggle('hidden'); if(!m.classList.contains('hidden')) m.innerHTML = mapaHTML(); };
  atualizarStatus();
}
/* ---------------- catálogo: todas as atividades para o professor analisar ---------------- */
function cartaoQuestao(d, n, k){
  let q; try{ q = gerarQuestao(d.id, n); }catch(e){ return `<div class="cat-q">erro: ${esc(e.message)}</div>`; }
  const cod = `${d.id}-N${n}`;
  const alts = q.options.map((o, i) => `<div class="alt ${i === q.correct ? 'certa' : ''}">${q.optImgs ? `<img src="${q.optImgs[i]}" alt="">` : ''}${fracHTML(o)}
      <small>${i === q.correct ? '✔ certa' : q.erros && q.erros[i] ? esc(q.erros[i]) : ''}</small></div>`).join('');
  return `<div class="cat-q" data-deg="${d.id}" data-n="${n}">
    <div class="cab"><span>${['', 'FÁCIL', 'MÉDIO', 'DIFÍCIL'][n]} · <span style="color:#2563eb">${cod}</span></span><button data-outra="1">🔄 outra</button></div>
    <div class="enun">${renderMath(q.text)}</div>
    <div class="dica">💡 ${fracHTML(dicaDe(q))}</div>
    ${q.image ? `<img class="fig" src="${q.image}" alt="">` : ''}
    <div class="alts">${alts}</div></div>`;
}
function degrauHTML(d){
  return `<div class="cat-deg ${d.off ? 'desligada' : ''}" data-cd="${d.id}"><div class="cat-ctl"><label><input type="checkbox" data-usar="${d.id}" ${d.off ? '' : 'checked'}> Usar na trilha</label>
      <label>Ano: <select data-mudaano="${d.id}">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<option value="${a}" ${a === d.ano ? 'selected' : ''}>${a}º</option>`).join('')}</select></label>
      ${d.ano !== d.anoOrig ? `<span class="era">(era do ${d.anoOrig}º ano)</span>` : ''}</div>
    <h3>${d.i + 1}. ${esc(d.nome)}${d.prov ? ' <span style="color:#fbbf24;font-size:13px">(provisório — gerador antigo da Corrida)</span>' : ''}</h3>
    <div class="sub">${d.ano}º ano · ${esc(d.un)} · ${d.bncc} · código <b>${d.id}</b></div>
    <div class="cat-grade">${[1, 2, 3].map(n => cartaoQuestao(d, n)).join('')}</div>
    <button class="cat-mais" data-mais="${d.id}">➕ Ver mais exemplos desta atividade</button></div>`;
}
function abrirCatalogo(ano){
  let box = $('trCatalogoBox');
  if(!box){
    box = document.createElement('div'); box.id = 'trCatalogoBox'; box.className = 'cat-fundo';
    document.body.appendChild(box);
    box.onclick = e => {
      const aba = e.target.closest('button[data-ano]'); if(aba){ abrirCatalogo(+aba.dataset.ano); return; }
      if(e.target.closest('[data-fechar]')){ box.remove(); return; }
      if(e.target.closest('[data-todas]')){ abrirCatalogo(+box.dataset.ano); return; }
      if(e.target.closest('[data-restaurar]')){ if(confirm('Ligar todas as atividades e voltar cada uma para o ano original?')){ estado.cfg.aj = { off: [], anos: {} }; salvarCfg(); atualizarStatus(); abrirCatalogo(+box.dataset.ano); } return; }
      const mais = e.target.closest('[data-mais]');
      if(mais){ const g = document.createElement('div'); g.className = 'cat-grade'; g.innerHTML = [1, 2, 3].map(n => cartaoQuestao(POR_ID[mais.dataset.mais], n)).join(''); mais.before(g); return; }   // mais uma fileira (fácil, médio, difícil)
      const b = e.target.closest('[data-outra]');
      if(b){ const c = b.closest('.cat-q'); c.outerHTML = cartaoQuestao(POR_ID[c.dataset.deg], +c.dataset.n); }
    };
    box.onchange = e => {                 // professor liga/desliga ou muda a atividade de ano
      const aj = estado.cfg.aj || (estado.cfg.aj = { off: [], anos: {} });
      const u = e.target.closest('[data-usar]');
      if(u){ const id = u.dataset.usar; aj.off = aj.off.filter(x => x !== id); if(!u.checked) aj.off.push(id); salvarCfg(); atualizarStatus(); u.closest('.cat-deg').classList.toggle('desligada', !u.checked); return; }
      const m = e.target.closest('[data-mudaano]');
      if(m){ const id = m.dataset.mudaano, a = +m.value; if(a === POR_ID[id].anoOrig) delete aj.anos[id]; else aj.anos[id] = a; salvarCfg(); atualizarStatus();
        app.toast(`📦 <b>${esc(POR_ID[id].nome)}</b> agora está no <b>${a}º ano</b>`, 'success'); const y = box.scrollTop; abrirCatalogo(+box.dataset.ano); box.scrollTop = y; }
    };
    document.addEventListener('keydown', function fechar(e){ if(e.key === 'Escape' && $('trCatalogoBox')){ $('trCatalogoBox').remove(); } });
  }
  box.dataset.ano = ano;
  const degs = CAT.filter(d => d.ano === ano && !d.retirada);
  box.innerHTML = `<div class="cat-topo"><h2>📋 Atividades da trilha</h2>
      ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<button class="ab ${a === ano ? 'on' : ''}" data-ano="${a}" style="${a > LIMITE.anoMax ? 'opacity:.45' : ''}">${a}º ano</button>`).join('')}
      <div class="dir"><button class="ab" data-restaurar="1" title="Volta todas as atividades para o ano original e liga todas">↩️ Restaurar tudo</button><button class="ab" data-todas="1">🔄 Sortear de novo</button><button class="ab" data-fechar="1">✕ Fechar</button></div></div>
    ${ano > LIMITE.anoMax ? `<div style="background:#78350f;color:#fde68a;border-radius:10px;padding:8px 12px;margin:10px 4px;font-weight:700">⚠️ Este ano está desligado (a trilha vai até o ${LIMITE.anoMax}º ano). Para usar, mude "A trilha vai até" no cartão da Trilha.</div>` : ''}
    <div style="color:var(--muted);font-size:13px;margin:10px 4px">${degs.length} degrau${degs.length === 1 ? '' : 's'} no ${ano}º ano · cada um mostra um exemplo de cada nível · alternativa verde = certa; em vermelho, o erro típico de cada errada · para pedir correção, informe o <b>código</b> (ex.: soma10-N2).</div>
    ${degs.map(degrauHTML).join('')}`;
  box.scrollTop = 0;
}

function nomesDaCaixa(){
  return [...new Set(String($('trNomes') ? $('trNomes').value : '').split('\n').map(s => s.trim()).filter(Boolean))];
}
function atualizarStatus(){
  const el = $('trStatus'); if(!el) return;
  const al = Object.values(estado.turma.alunos || {});
  const dom = al.reduce((s, r) => s + CAT.filter(d => r.deg[d.id] && r.deg[d.id].dom).length, 0);
  el.innerHTML = `Turma <b>${esc(estado.turma.nome || '(sem nome)')}</b>: ${al.length} aluno${al.length === 1 ? '' : 's'} com progresso · ${dom} degraus dominados no total.` +
    `<br>Trilha ${LIMITE.anoMax < 9 ? `do 1º ao <b>${LIMITE.anoMax}º ano</b>` : 'do 1º ao 9º ano'}: <b>${catAtivo().length}</b> degraus ativos (de ${CAT.filter(d => !d.retirada).length}; ${catAtivo().filter(d => !d.prov).length} com gerador próprio).`;
}
function mapaHTML(){
  return `<table class="tr-tab"><tr><th>#</th><th>Ano</th><th>Degrau</th><th>BNCC</th><th>Unidade</th></tr>` +
    CAT.filter(d => !d.retirada).map(d => `<tr style="${ativo(d) ? '' : 'opacity:.4'}"><td>${d.i + 1}</td><td>${d.ano}º</td><td>${esc(d.nome)}${d.prov ? ' <span style="color:#fbbf24">(provisório)</span>' : ''}</td><td>${d.bncc}</td><td>${d.un}</td></tr>`).join('') + `</table>`;
}
function baixarTurma(){
  estado.turma.nome = ($('trTurmaNome') && $('trTurmaNome').value.trim()) || estado.turma.nome || '';
  estado.turma.atualizado = new Date().toISOString();
  estado.turma.cfg = { ano: estado.cfg.ano, anoMax: estado.cfg.anoMax || 9, rev: estado.cfg.rev || 0.2, aj: estado.cfg.aj, diag: estado.cfg.diag, lista: estado.cfg.lista, nomes: nomesDaCaixa(),
    modo: estado.cfg.modo, rank: estado.cfg.rank, treinoMin: estado.cfg.treinoMin, foco: estado.cfg.foco, linkAlunos: estado.cfg.linkAlunos };   // todas as configurações da turma (dá para salvar antes de jogar)
  const blob = new Blob([JSON.stringify(estado.turma, null, 1)], { type: 'application/json' });
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  const nm = (estado.turma.nome || 'turma').replace(/[^\w\-]+/g, '_');
  a.href = url; a.download = `trilha-${nm}-${new Date().toISOString().slice(0, 10)}.json`; a.click();
  URL.revokeObjectURL(url);
  lsSet(LS_TURMA, estado.turma);
  app.toast('✅ Arquivo da turma salvo!', 'success');
}
function carregarTurma(file){
  const rd = new FileReader();
  rd.onload = ev => {
    try{
      const t = JSON.parse(ev.target.result);
      if(t.tipo !== 'corrida-trilha-turma' || typeof t.alunos !== 'object') throw new Error('não é um arquivo de turma da Trilha');
      Object.values(t.alunos).forEach(r => { if(!r.deg) r.deg = {}; Object.keys(r.deg).forEach(k => { if(!POR_ID[k]) delete r.deg[k]; }); if(r.atual && !POR_ID[r.atual]) r.atual = null; });
      estado.turma = t;
      if(t.cfg){
        Object.assign(estado.cfg, { ano: t.cfg.ano || estado.cfg.ano, anoMax: t.cfg.anoMax || estado.cfg.anoMax || 9, rev: t.cfg.rev || estado.cfg.rev || 0.2, aj: t.cfg.aj || estado.cfg.aj, diag: t.cfg.diag || estado.cfg.diag, lista: !!t.cfg.lista, nomes: t.cfg.nomes || [] });
        ['modo', 'rank', 'treinoMin', 'foco', 'linkAlunos'].forEach(k => { if(t.cfg[k] !== undefined) estado.cfg[k] = t.cfg[k]; });
      }
      const nomesTurma = Object.values(t.alunos).map(r => r.nome).filter(Boolean);
      estado.cfg.nomes = [...new Set([...((t.cfg && t.cfg.nomes) || []), ...nomesTurma])].sort((a, b) => a.localeCompare(b, 'pt-BR'));   // só os nomes DESTA turma
      salvarCfg(); lsSet(LS_TURMA, estado.turma);
      const card = $('trilhaCard'); if(card) card.remove();
      montarCartao();
      app.toast(`✅ Turma <b>${esc(t.nome || '')}</b> carregada: ${estado.cfg.nomes.length} nomes, com as configurações salvas`, 'success');
    }catch(err){ alert('Não foi possível carregar: ' + err.message); }
  };
  rd.readAsText(file, 'UTF-8');
}

/* ---------------- professor: rede e placar ---------------- */
function enviarTrilha(p){
  if(!estado.cfg.on || !p || p.isBot || app.host.isDemo) return;
  const rec = registroDe(p.name);
  if(!rec) return;
  // retida: se o aluno recarregar a página, recebe a trilha junto com o estado da sala
  estado.enviado[p.id] = Date.now();
  app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'trilha', on: true, cfg: { ano: estado.cfg.ano, anoMax: estado.cfg.anoMax || 9, rev: estado.cfg.rev || 0.2, diag: estado.cfg.diag, aj: estado.cfg.aj }, rec }, true);
}
function publicarNomes(){
  if(!estado.cfg.on || !estado.cfg.lista || app.host.isDemo || !app.room) return;
  const usados = app.host.players.map(p => normNome(p.name));
  app.pub(`${BASE}/${app.room}/nomes`, { type: 'nomes', nomes: estado.cfg.nomes || [], usados, bloqueio: true }, true);   // com a lista ligada, só entra quem está nela
}
function hostRecebeRec(msg){
  const p = app.host.players.find(x => x.id === msg.id);
  if(!p || (!msg.rec && !msg.topo)) return;
  const k = normNome(p.name);
  const antigo = estado.turma.alunos[k];
  if(msg.rec){                                            // registro completo
    if(!antigo || (msg.rec.rev || 0) >= (antigo.rev || 0)){
      msg.rec.nome = p.name; msg.rec.chave = k;
      estado.turma.alunos[k] = msg.rec;
      salvarTurmaLocal();
    } else if(Date.now() - (estado.enviado[p.id] || 0) > 10000) enviarTrilha(p);   // o celular ficou com uma cópia velha: manda a do professor
  } else {                                                // só o que mudou desde o último envio (mensagem pequena)
    if(!antigo || (antigo.rev || 0) !== msg.base){ app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'trilhaTudo' }); }
    else {
      Object.assign(antigo, msg.topo); Object.assign(antigo.deg || (antigo.deg = {}), msg.deg || {});
      antigo.nome = p.name; antigo.chave = k;
      salvarTurmaLocal();
    }
  }
  (msg.evs || []).forEach(ev => {
    if(ev.dominou){ estado.hoje[p.id] = (estado.hoje[p.id] || 0) + 1; }
    if(ev.dominou){ const d = POR_ID[ev.dominou]; app.toast(`🏅 <b>${esc(p.name)}</b> dominou <b>${esc(d ? d.nome : ev.dominou)}</b>`, 'success'); }
    if(ev.travou){ estado.alertas[p.id] = { nome: p.name, ...ev.travou }; desenharAlertas(true); }
    if(ev.destravou && estado.alertas[p.id]){ delete estado.alertas[p.id]; desenharAlertas(); }
    if(ev.diagFim){ const d = POR_ID[ev.diagFim]; app.toast(`🔎 ${esc(p.name)}: diagnóstico concluído → <b>${esc(d ? d.nome : 'trilha concluída')}</b>`, 'info'); }
    if(ev.apoio === 'entrou') app.toast(`💪 <b>${esc(p.name)}</b> entrou em modo apoio (perguntas mais fáceis)`, 'info');
    if(ev.voltou){ const a = POR_ID[ev.voltou.de], b = POR_ID[ev.voltou.para]; app.toast(`🔙 <b>${esc(p.name)}</b> travou em <b>${esc(a ? a.nome : '')}</b> e voltou para reforçar <b>${esc(b ? b.nome : '')}</b>`, 'info'); }
  });
}
function desenharAlertas(novo){
  let box = $('trAlertas');
  if(!box){
    const ref = document.querySelector('#hostGame .hg-middle'); if(!ref) return;
    box = document.createElement('div'); box.id = 'trAlertas'; box.className = 'tr-alertas';
    ref.after(box);
    box.onclick = e => { const b = e.target.closest('button[data-ok]'); if(!b) return; delete estado.alertas[b.dataset.ok]; desenharAlertas(); };
  }
  const itens = Object.entries(estado.alertas);
  box.classList.toggle('hidden', !itens.length);
  box.innerHTML = `<h3>⚠️ Precisa de ajuda (${itens.length})</h3>` + itens.map(([id, a]) => {
    const d = POR_ID[a.id];
    const erro = a.erro ? ` · erro mais comum: <b style="color:#fca5a5">${esc(a.erro)}</b>` : '';
    return `<div class="tr-alerta"><b>${esc(a.nome)}</b><span>${esc(d ? `${d.ano}º · ${d.nome}` : a.id)}</span>
      <span style="color:var(--muted)">${esc(a.motivo)}${erro}</span>
      <button class="ghost ok" data-ok="${esc(id)}">✓ vi</button></div>`;
  }).join('');
  if(novo) beep(440, .25, 'square', 0.07);
}
function relatorioTrilha(){
  const wrap = $('classReport'); if(!wrap || !estado.cfg.on) return;
  const reais_ = app.host.players.filter(p => !p.isBot || p._rec);
  const linhas = reais_.map(p => {
    const r = p._rec || estado.turma.alunos[normNome(p.name)];
    if(!r) return null;
    const rs = resumo(r), d = r.atual ? r.deg[r.atual] : null;
    const novos = rs.dominados - (estado.snap[p._rec ? p.id : normNome(p.name)] || 0);
    const tot = (p.correct || 0) + (p.wrong || 0) + (p.timeouts || 0);
    return { nome: p.name, rs, novos, acc: tot ? Math.round(p.correct / tot * 100) : 0, erro: d ? erroMaisComum(d) : '', trav: r.trav, lac: lacunas(r).slice(0, 3).map(x => `${x.ano}º ${x.nome}`) };
  }).filter(Boolean).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
  const sec = document.createElement('div');
  sec.className = 'tr-sec'; sec.id = 'trRelatorio';
  sec.innerHTML = `<h2>🧗 Trilha da turma ${esc(estado.turma.nome || '')}</h2>
    <div style="color:var(--muted);font-size:13px">Salve o arquivo da turma para continuar de onde pararam na próxima aula.</div>
    <div class="tr-row"><button class="primary" id="trSalvarFim">💾 Salvar arquivo da turma (JSON)</button></div>
    ${linhas.length ? `<table class="tr-tab"><tr><th>Aluno</th><th>Degrau atual</th><th>Nível</th><th>Dominados</th><th>Nesta partida</th><th>Acerto</th><th>Erro mais comum</th><th>Lacunas (errou na revisão)</th></tr>` +
      linhas.map(l => `<tr class="${l.trav ? 'trav' : ''}"><td><b>${esc(l.nome)}</b>${l.trav ? ' ⚠️' : ''}</td><td>${esc(l.rs.degrau)}</td><td>${l.rs.nivel ? ['', 'fácil', 'médio', 'difícil'][l.rs.nivel] : '—'}</td>
        <td>${l.rs.dominados}</td><td>${l.novos > 0 ? '+' + l.novos + ' 🏅' : '—'}</td><td>${l.acc}%</td><td>${esc(l.erro || '—')}</td><td>${l.lac.length ? esc(l.lac.join(' · ')) : '—'}</td></tr>`).join('') + `</table>`
      : '<div style="color:var(--muted);padding:12px">Sem alunos reais nesta partida.</div>'}`;
  const old = $('trRelatorio'); if(old) old.remove();
  wrap.prepend(sec);
  $('trSalvarFim').onclick = () => baixarTurma();
}

/* ---------------- aluno: figuras e avisos ---------------- */
function aviso(txt, ms = 2600){
  document.querySelectorAll('.tr-banner').forEach(x => x.remove());
  const b = document.createElement('div'); b.className = 'tr-banner'; b.innerHTML = txt;
  document.body.appendChild(b); setTimeout(() => b.remove(), ms);
}
function extrasPergunta(q){
  const card = $('ppQuestionCard'), img = $('ppQImage');
  // fração sempre em pé: enunciado e alternativas (vale também fora da trilha)
  if(q){
    if(/\d\/\d/.test(q.text || '')) $('ppQuestion').innerHTML = fracHTML(q.text);
    [...$('ppOptions').children].forEach((b, i) => { const t = q.options && q.options[i]; if(t != null && /\d\/\d/.test(String(t)) && !(q.optImgs && q.optImgs[i])) b.innerHTML = fracHTML(t); });
  }
  const velho = $('ppAjudaBox'); if(velho) velho.remove();
  const velhoB = $('ppAjudaBtn'); if(velhoB) velhoB.remove();
  img.classList.toggle('trilha-fig', !!(q && q.trilha));
  let info = $('ppTrilhaInfo');
  if(!info){ info = document.createElement('div'); info.id = 'ppTrilhaInfo'; info.className = 'tr-info'; card.prepend(info); }
  if(!q || !q.trilha){ info.classList.add('hidden'); return; }
  const d = POR_ID[q.trilha.id], f = q.fonte || {};
  const rot = f.tipo === 'diag' ? '🔎 descobrindo seu degrau' : f.tipo === 'rev' || f.tipo === 'conforto' ? '🔁 revisão' : f.tipo === 'previa' ? '👀 prévia do próximo' : `🧗 <b>${esc(d.nome)}</b> · ${['', 'fácil', 'médio', 'difícil'][q.trilha.nivel]}`;
  info.innerHTML = rot; info.classList.remove('hidden');
  botaoAjuda(q, info);
  // com figura, o enunciado fica menor para a figura caber na tela do celular
  if(q.image || q.optImgs) $('ppQuestion').style.fontSize = (q.text || '').length > 24 ? 'clamp(20px,4.6vw,32px)' : 'clamp(26px,6vw,44px)';
  if(q.optImgs){
    [...$('ppOptions').children].forEach((b, i) => {
      if(!q.optImgs[i]) return;
      b.classList.add('tr-img');
      b.innerHTML = `<img alt="${esc(q.options[i])}" src="${q.optImgs[i]}">`;
    });
  }
}

/* ---------------- aluno: ajudas (3 por degrau, não acumulam) ---------------- */
function botaoAjuda(q, info){
  const pt = app.player.trilha;
  if(!pt || !pt.rec || !q.fonte || q.fonte.tipo === 'diag') return;
  const resta = pt.rec.ajudas === undefined ? REGRA.ajudasPorDegrau : pt.rec.ajudas;
  const b = document.createElement('button');
  b.id = 'ppAjudaBtn'; b.className = 'tr-ajuda-btn'; b.type = 'button';
  b.innerHTML = `💡 Ajuda (${resta})`;
  b.disabled = resta <= 0;
  b.title = resta > 0 ? 'Mostra uma dica e a resposta. O acerto vale só ' + REGRA.pontosComAjuda + ' pontos.' : 'Acabaram as ajudas deste degrau';
  b.onclick = () => {
    if(q._ajuda || app.player.questionBlocked) return;
    const r = pt.rec.ajudas === undefined ? REGRA.ajudasPorDegrau : pt.rec.ajudas;
    if(r <= 0) return;
    pt.rec.ajudas = r - 1; pt.sujo = true; q._ajuda = true;
    b.disabled = true; b.innerHTML = `💡 Ajuda (${r - 1})`;
    const box = document.createElement('div'); box.id = 'ppAjudaBox'; box.className = 'tr-ajuda';
    box.innerHTML = `💡 ${fracHTML(dicaDe(q))}<div class="resp">✅ Resposta: ${fracHTML(q.options[q.correct])} ${typeof treinoAluno === 'function' && treinoAluno() ? '' : `<span style="font-weight:600;color:#92400e">(acerto com ajuda vale ${REGRA.pontosComAjuda} pontos)</span>`}</div>`;
    b.after(box);
    const bt = $('ppOptions').children[q.correct]; if(bt) bt.classList.add('tr-dica-certa');
  };
  info.after(b);
}

/* ---------------- aluno: entrada tocando no nome ---------------- */
const listaNomes = { cli: null, sala: null };
function buscarNomes(sala){
  if(listaNomes.sala === sala) return;
  pararNomes();
  listaNomes.sala = sala;
  if(typeof mqtt === 'undefined') return;
  try{
    const urls = window.__rede ? window.__rede.SERVIDORES.map(x => x.url) : [BROKER];     // procura a lista em todos os servidores
    listaNomes.clis = urls.map(url => {
      const cli = mqtt.connect(url, { clientId: 'cgm_n_' + uid(), clean: true, keepalive: 30, reconnectPeriod: 3000, connectTimeout: 10000 });
      cli.on('connect', () => cli.subscribe(`${BASE}/${sala}/nomes`, { qos: 0 }));
      cli.on('message', (t, payload) => { let m; try{ m = JSON.parse(payload.toString()); }catch(e){ return; } if(m && m.type === 'nomes') desenharNomes(m); });
      return cli;
    });
    listaNomes.cli = listaNomes.clis[0];
  }catch(e){}
}
function pararNomes(){
  (listaNomes.clis || (listaNomes.cli ? [listaNomes.cli] : [])).forEach(c => { try{ c.end(true); }catch(e){} }); listaNomes.clis = null;
  listaNomes.cli = null; listaNomes.sala = null;
  const box = $('trNomesAluno'); if(box) box.remove();
  campoNomeLivre(true);
}
function campoNomeLivre(mostrar){                         // lista ligada: some o campo de digitar o nome (só entra tocando na lista)
  const f = $('joinName') && $('joinName').closest('.join-field'); if(f) f.style.display = mostrar ? '' : 'none';
  if($('joinBtn')) $('joinBtn').style.display = mostrar ? '' : 'none';
}
function desenharNomes(m){
  let box = $('trNomesAluno');
  if(!m.nomes || !m.nomes.length){ if(box) box.remove(); campoNomeLivre(true); return; }
  campoNomeLivre(!m.bloqueio);
  if(!box){ box = document.createElement('div'); box.id = 'trNomesAluno'; box.className = 'tr-nomes'; $('joinBtn').before(box); }
  const usados = new Set(m.usados || []);
  box.innerHTML = `<div class="tt">👆 Toque no seu nome</div><div class="grade">` +
    m.nomes.map(n => `<button data-n="${esc(n)}" ${usados.has(normNome(n)) ? 'disabled' : ''}>${esc(n)}</button>`).join('') + `</div>`;
  box.onclick = e => {
    const b = e.target.closest('button[data-n]'); if(!b || b.disabled) return;
    $('joinName').value = b.dataset.n;
    pararNomes();
    app.playerJoin();
  };
}

/* =========================================================================
   WRAPPERS
========================================================================= */
function instalar(){
  injetarEstilos();
  montarCartao();

  /* rede: mensagens novas (trilhaRec → professor; trilha → aluno) */
  const onMessage0 = app.onMessage;
  app.onMessage = function(topic, msg){
    if(this.mode === 'teacher' && topic.endsWith('/tohost') && msg && msg.type === 'trilhaRec'){ hostRecebeRec(msg); return; }
    if(this.mode === 'teacher' && topic.endsWith('/tohost') && msg && msg.type === 'trilhaPede'){ const p = this.host.players.find(x => x.id === msg.id); if(p && estado.cfg.on && Date.now() - (estado.enviado[p.id] || 0) > 3000) enviarTrilha(p); return; }
    if(this.mode !== 'teacher' && msg && msg.type === 'trilha' && topic.endsWith(`/to/${this.playerId}`)){ alunoRecebeTrilha(msg); return; }
    if(this.mode !== 'teacher' && msg && msg.type === 'trilhaTudo' && topic.endsWith(`/to/${this.playerId}`)){ const pt = this.player.trilha; if(pt){ pt.baseRev = 0; pt.env = {}; pt.sujo = true; } return; }
    return onMessage0.call(this, topic, msg);
  };

  /* professor */
  const createRoom0 = app.createRoom;
  app.createRoom = function(isDemo){
    // com a trilha ligada, a pergunta de reserva (antes do progresso chegar ao celular) é soma/subtração fácil
    if(estado.cfg.on){ if(!estado.cfgAntes) estado.cfgAntes = { ...this.host.cfg }; this.host.cfg = { type: 'mixed', diff: 'easy', allowed: ['add', 'sub'] }; }
    else if(estado.cfgAntes){ this.host.cfg = estado.cfgAntes; estado.cfgAntes = null; }
    const r = createRoom0.call(this, isDemo);
    if(estado.cfg.on){
      estado.cfg.nomes = nomesDaCaixa(); salvarCfg();
      $('hModeLabel').innerHTML = `<span style="color:#fbbf24">TRILHA ${estado.cfg.ano}º${(estado.cfg.anoMax || 9) < 9 ? ` · até ${estado.cfg.anoMax}º` : ''}</span>`;
      estado.alertas = {}; estado.enviado = {};
      if(estado.cfg.lista && !isDemo){
        let k = 0; const t = setInterval(() => { if(this.mqtt && this.mqtt.connected){ publicarNomes(); clearInterval(t); } else if(++k > 60) clearInterval(t); }, 300);
        clearInterval(estado.nomesT); const sala = this.room;          // repete a lista a cada 10 s (servidor que não guarda mensagem retida)
        estado.nomesT = setInterval(() => { if(app.room !== sala || app.mode !== 'teacher' || app.host.phase === 'end') clearInterval(estado.nomesT); else publicarNomes(); }, 10000);
      }
    }
    return r;
  };
  const hostPlayerJoin0 = app.hostPlayerJoin;
  app.hostPlayerJoin = function(msg){
    const jaEstava = !!(msg && this.host.players.find(x => x.id === msg.id));
    const r = hostPlayerJoin0.call(this, msg);
    if(estado.cfg.on && !jaEstava){ const p = this.host.players.find(x => x.id === msg.id); if(p){ enviarTrilha(p); publicarNomes(); } }   // o "join" se repete a cada 15 s: a trilha vai só na 1ª vez
    return r;
  };
  const startGame0 = app.startGame;
  app.startGame = function(){
    if(estado.cfg.on){
      estado.snap = {};
      this.host.players.forEach(p => {
        if(p.isBot) return;
        const rec = registroDe(p.name);
        estado.snap[normNome(p.name)] = rec ? CAT.filter(d => rec.deg[d.id] && rec.deg[d.id].dom).length : 0;
        if(!estado.enviado[p.id]) enviarTrilha(p);         // quem entrou no saguão já recebeu (evita rajada de mensagens grandes no início)
      });
    }
    const r = startGame0.call(this);
    if(estado.cfg.on) desenharAlertas();
    return r;
  };
  const renderClassReport0 = app.renderClassReport;
  app.renderClassReport = function(){
    const r = renderClassReport0.call(this);
    if(estado.cfg.on){ lsSet(LS_TURMA, estado.turma); relatorioTrilha(); }
    return r;
  };
  const perguntaDoBot0 = app.perguntaDoBot;
  // demonstração: cada bot faz a trilha como um aluno, a partir do 1º degrau do 1º ano (progresso não vai para a turma)
  app.perguntaDoBot = function(bot){
    if(!estado.cfg.on) return perguntaDoBot0.call(this, bot);
    LIMITE.anoMax = estado.cfg.anoMax || 9; LIMITE.pRev = estado.cfg.rev || 0.2;
    if(!bot._rec){ bot._rec = novoRegistro(bot.name); iniciar(bot._rec, { diag: 'inicio', ano: 1 }); estado.snap[bot.id] = 0; }
    const fonte = escolherFonte(bot._rec);
    const q = gerarQuestao(fonte.id, fonte.nivel);
    q.fonte = fonte;
    bot.level = fonte.nivel;
    return q;
  };
  const botAnswer0 = app.botAnswer;
  app.botAnswer = function(bot){
    const r = botAnswer0.call(this, bot);
    const tela = bot._tela, q = tela && tela.q;
    if(!estado.cfg.on || !bot._rec || !q || !q.trilha || !q.fonte || tela.acertou === null) return r;
    const lim = this.host.questionTime * (TIME_MULT_BY_LEVEL[q.fonte.nivel] || 1) * (TYPE_TIME_FACTOR[q.type] || 1) * 1000;
    const ev = registrar(bot._rec, q.fonte, q, tela.escolha, tela.acertou, tela.prazo / lim);
    if(ev.dominou){
      bot.score += REGRA.bonusDominio;
      const t = this.host.teams[bot.team];
      if(t) t.score = this.host.players.filter(x => x.team === bot.team).reduce((sm, x) => sm + (x.score || 0), 0);
      app.toast(`🏅 <b>${esc(bot.name)}</b> dominou <b>${esc(POR_ID[ev.dominou].nome)}</b> (+${REGRA.bonusDominio})`, 'success');
      this.renderRaceTrack(); this.renderRankLive();
    }
    if(ev.travou){ estado.alertas[bot.id] = { nome: bot.name, ...ev.travou }; desenharAlertas(true); }
    if(ev.destravou && estado.alertas[bot.id]){ delete estado.alertas[bot.id]; desenharAlertas(); }
    bot.level = bot._rec.atual ? degDo(bot._rec, bot._rec.atual).n : 3;
    this.renderBotScreen(bot);
    return r;
  };
  const renderBotScreen0 = app.renderBotScreen;
  app.renderBotScreen = function(bot){
    const r = renderBotScreen0.call(this, bot);
    const el = document.getElementById('tela_' + bot.id);
    if(el) el.querySelectorAll('.opts .opt').forEach(o => { if(/\d\/\d/.test(o.textContent)) o.innerHTML = fracHTML(o.textContent); });
    if(el && bot._rec){
      const rs = resumo(bot._rec), at = bot._rec.atual ? POR_ID[bot._rec.atual] : null;
      const f = bot._tela && bot._tela.q && bot._tela.q.fonte;
      const tipo = f ? { atual: '', atual2: ' · 2º degrau', foco: ' · 🎯', rev: ' · 🔁 revisão', conforto: ' · 💪 apoio', previa: ' · 👀 prévia', diag: ' · 🔎' }[f.tipo] : '';
      el.insertAdjacentHTML('beforeend', `<div class="tr-bot">🧗 degrau ${at ? catAtivo().indexOf(at) + 1 : catAtivo().length}/${catAtivo().length} · ${['', 'fácil', 'médio', 'difícil'][rs.nivel] || ''} · ${rs.dominados} dominado${rs.dominados === 1 ? '' : 's'}${tipo}</div>`);
    }
    return r;
  };

  /* aluno */
  const getNextQuestion0 = app.getNextQuestion;
  app.getNextQuestion = function(){
    const pt = this.player.trilha;
    if(!pt || !pt.on || !pt.rec) return getNextQuestion0.call(this);
    const plano = pt.rec.plano;                             // plano individual (atividades adaptadas para este aluno)
    LIMITE.anoMax = plano && plano.ids ? 9 : Math.min((pt.cfg && pt.cfg.anoMax) || 9, (plano && plano.ano) || 9);      // limite escolhido pelo professor
    LIMITE.pRev = (pt.cfg && pt.cfg.rev) || 0.2;
    const ajBase = (pt.cfg && pt.cfg.aj) || {};
    const ajEf = plano && plano.ids ? { off: CAT.map(d => d.id).filter(id => !plano.ids.includes(id)), anos: ajBase.anos || {} } : ajBase;
    const ajK = JSON.stringify(ajEf); if(ajK !== estado.ajAluno){ estado.ajAluno = ajK; aplicarAjustes(ajEf); }   // atividades que o professor tirou/mudou
    iniciar(pt.rec, pt.cfg || {});
    const recentes = this.player.recentTexts || (this.player.recentTexts = []);
    let fonte, q;
    for(let i = 0; i < 12; i++){
      fonte = escolherFonte(pt.rec);
      q = gerarQuestao(fonte.id, fonte.nivel);
      if(!recentes.includes(q.text + '|' + (q.chave || ''))) break;
    }
    recentes.push(q.text + '|' + (q.chave || '')); if(recentes.length > 15) recentes.shift();
    q.fonte = fonte;
    this.player.stats.level = fonte.nivel;          // tempo por nível (TIME_MULT_BY_LEVEL 1–3)
    return q;
  };
  const renderPlayerQuestion0 = app.renderPlayerQuestion;
  app.renderPlayerQuestion = function(q){
    const r = renderPlayerQuestion0.call(this, q);
    try{ extrasPergunta(q); }catch(e){ console.warn('[Trilha]', e); }
    return r;
  };
  const posResposta = (q, idx, ok, frac) => {
    const pt = app.player.trilha;
    if(!pt || !pt.rec || !q || !q.trilha || !q.fonte) return;
    const treino = typeof treinoAluno === 'function' && treinoAluno();
    const ev = registrar(pt.rec, q.fonte, q, idx, ok, treino ? 0 : frac);   // treino: sem tempo, conta só o acerto
    if(treino && ev.dominou && pt.rec.deg[ev.dominou]) pt.rec.deg[ev.dominou].domPor = 'treino';
    pt.sujo = true;
    if(Object.keys(ev).length) pt.evs.push(ev);
    const s = app.player.stats;
    if(ev.dominou){
      s.score += REGRA.bonusDominio;
      app.player.pendingBatch.scoreDelta += REGRA.bonusDominio;
      app.updatePlayerStatsUI();
      festa(esc(POR_ID[ev.dominou].nome), treino ? 'Próximo degrau liberado! 🚀' : `+${REGRA.bonusDominio} pontos`);
    } else if(ev.diagFim){
      aviso(`🔎 Pronto! Você começa em<br>${esc(ev.diagFim ? POR_ID[ev.diagFim].nome : 'revisão')}`);
    } else if(ev.voltou){ aviso(`🔙 Vamos reforçar a base:<br>${esc(POR_ID[ev.voltou.para].nome)}<br>Depois você volta!`, 3200);
    } else if(ev.pausa){ aviso('🔄 Vamos variar um pouco!<br>Daqui a pouco você volta', 2200);
    } else if(ev.apoio === 'entrou'){ aviso('💪 Vamos com calma:<br>perguntas mais fáceis', 2400);
    } else if(ev.apoio === 'saiu'){ aviso('🚀 Boa! De volta ao ritmo normal', 2200);
    } else if(ev.subiu){ aviso(`⬆️ Nível ${['', 'fácil', 'médio', 'difícil'][ev.subiu]}`, 1400); }
    s.level = pt.rec.atual ? degDo(pt.rec, pt.rec.atual).n : 3;
  };
  const localAnswer0 = app.localAnswer;
  app.localAnswer = function(idx){
    const q = this.player.currentQuestion, bloq = this.player.questionBlocked;
    const tempo = performance.now() - this.player.questionStart, lim = this.player.questionLimit * 1000;
    const s0 = this.player.stats.score;
    const r = localAnswer0.call(this, idx);
    if(!bloq && q && q._ajuda && idx === q.correct){        // acerto com ajuda vale só o mínimo
      const fase = getSprintPhase(Math.max(0, this.player.matchEndTime - Date.now()), this.player.matchTotalMs, this.player.sprintEnabled);
      const corr = (this.player.stats.score - s0) - Math.round(REGRA.pontosComAjuda * fase.mult);
      if(corr > 0){ this.player.stats.score -= corr; this.player.pendingBatch.scoreDelta -= corr; this.updatePlayerStatsUI(); }
    }
    if(!bloq && q) posResposta(q, idx, idx === q.correct, tempo / lim);
    return r;
  };
  const localTimeout0 = app.localTimeout;
  app.localTimeout = function(){
    const q = this.player.currentQuestion, bloq = this.player.questionBlocked;
    const r = localTimeout0.call(this);
    if(!bloq && q) posResposta(q, -1, false, 1);
    return r;
  };
  const flushBatch0 = app.flushBatch;
  app.flushBatch = function(){
    const r = flushBatch0.call(this);
    const pt = this.player.trilha;
    if(pt && pt.sujo && pt.rec && this.mqtt && this.mqtt.connected){
      const env = pt.env || (pt.env = {}), mud = {};
      Object.entries(pt.rec.deg || {}).forEach(([id, d]) => { const j = JSON.stringify(d); if(env[id] !== j){ mud[id] = d; env[id] = j; } });
      if(!pt.baseRev){                                     // 1ª vez (ou o professor pediu): registro completo
        this.pub(`${BASE}/${this.room}/tohost`, { type: 'trilhaRec', id: this.playerId, rec: pt.rec, evs: pt.evs });
      } else {                                             // depois: só os degraus que mudaram (≈1 KB em vez de 30 KB)
        const topo = { ...pt.rec }; delete topo.deg;
        this.pub(`${BASE}/${this.room}/tohost`, { type: 'trilhaRec', id: this.playerId, base: pt.baseRev, topo, deg: mud, evs: pt.evs });
      }
      pt.baseRev = pt.rec.rev;
      pt.sujo = false; pt.evs = [];
    }
    return r;
  };
  const finishPlayerMatch0 = app.finishPlayerMatch;
  app.finishPlayerMatch = function(){
    const r = finishPlayerMatch0.call(this);
    const pt = this.player.trilha;
    if(pt && pt.rec && $('pdStats')){
      const rs = resumo(pt.rec);
      const atN = pt.rec.atual && POR_ID[pt.rec.atual] ? POR_ID[pt.rec.atual].nome : rs.degrau;          // sem mostrar o ano ao aluno
      $('pdStats').insertAdjacentHTML('beforeend', `<br>🧗 Trilha: <b>${esc(atN)}</b> · ${rs.dominados} degrau${rs.dominados === 1 ? '' : 's'} dominado${rs.dominados === 1 ? '' : 's'}`);
    }
    return r;
  };
  const playerJoin0 = app.playerJoin;
  app.playerJoin = function(){ pararNomes(); return playerJoin0.call(this); };

  /* entrada por lista: quando o código tem 4 letras, procura a lista de nomes da sala */
  const campo = $('joinRoom');
  if(campo){
    const verificar = () => { const v = campo.value.trim().toUpperCase(); if(v.length === 4 && app.mode === 'student' && !app.room) buscarNomes(v); else if(v.length < 4) pararNomes(); };
    campo.addEventListener('input', verificar);
    setTimeout(verificar, 600);                         // link com ?sala=ABCD
  }
}
function alunoRecebeTrilha(msg){
  const pt = app.player.trilha || (app.player.trilha = { on: false, cfg: {}, rec: null, evs: [], sujo: false });
  pt.on = msg.on !== false;
  pt.cfg = msg.cfg || pt.cfg;
  if(msg.rec && (!pt.rec || (msg.rec.rev || 0) > (pt.rec.rev || 0))){
    pt.rec = msg.rec; pt.baseRev = 0; pt.env = {};
    // a pergunta na tela não vale mais (era a de reserva antes da trilha chegar, ou ficou fora do plano do aluno): troca já
    const q = app.player.currentQuestion, pl = pt.rec.plano;
    if(app.player.phase === 'playing' && q && !app.player.questionBlocked &&
       (!q.trilha || (pl && pl.ids && !pl.ids.includes(q.trilha.id)) || (pl && pl.ano && q.trilha.ano > pl.ano))) setTimeout(() => { if(app.player.currentQuestion === q && !app.player.questionBlocked) app.nextLocalQuestion(); }, 50);
  }
}
