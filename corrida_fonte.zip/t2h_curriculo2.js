
/* =========================================================================
   LOTE 5 — o que ainda faltava do currículo ES (1º ao 7º ano)
========================================================================= */

/* ============================ 1º ANO ============================ */

/* Direita e esquerda de outra pessoa (EF01MA12) */
function pessoaSVG(cx, cy, frente){
  const pele = '#f5c9a0';
  let o = `<circle cx="${cx}" cy="${cy - 70}" r="26" fill="${frente ? pele : '#5b3a1e'}" stroke="#111" stroke-width="2.5"/>`;
  if(frente) o += `<circle cx="${cx - 9}" cy="${cy - 74}" r="3" fill="#111"/><circle cx="${cx + 9}" cy="${cy - 74}" r="3" fill="#111"/><path d="M${cx - 9} ${cy - 60} Q${cx} ${cy - 53} ${cx + 9} ${cy - 60}" fill="none" stroke="#111" stroke-width="2.5"/>`;
  o += `<rect x="${cx - 26}" y="${cy - 42}" width="52" height="62" rx="12" fill="#ec4899" stroke="#111" stroke-width="2.5"/>` +
    `<line x1="${cx - 26}" y1="${cy - 30}" x2="${cx - 50}" y2="${cy}" stroke="#111" stroke-width="7" stroke-linecap="round"/><line x1="${cx + 26}" y1="${cy - 30}" x2="${cx + 50}" y2="${cy}" stroke="#111" stroke-width="7" stroke-linecap="round"/>` +
    `<line x1="${cx - 12}" y1="${cy + 20}" x2="${cx - 14}" y2="${cy + 62}" stroke="#111" stroke-width="8" stroke-linecap="round"/><line x1="${cx + 12}" y1="${cy + 20}" x2="${cx + 14}" y2="${cy + 62}" stroke="#111" stroke-width="8" stroke-linecap="round"/>`;
  return o;
}
G.posicaoRef1 = n => {
  const [a, b] = shuffle(['maca', 'bola', 'flor', 'estrela', 'balao', 'peixe']).slice(0, 2);     // a = do lado ESQUERDO da tela, b = do lado DIREITO
  const frente = n === 1 ? false : n === 2 ? true : Math.random() < .6;
  const lado = pick(['DIREITA', 'ESQUERDA']);
  // de costas: a direita dela é a direita da tela. De frente: é o contrário.
  const tela = frente ? (lado === 'DIREITA' ? 'esq' : 'dir') : (lado === 'DIREITA' ? 'dir' : 'esq');
  const certa = NOME_ICONE[tela === 'esq' ? a : b][0], errada = NOME_ICONE[tela === 'esq' ? b : a][0];
  const img = SVG(420, 220, ICONES[a](70, 150, 80) + pessoaSVG(210, 120, frente) + ICONES[b](350, 150, 80) + T(210, 212, frente ? 'de FRENTE para você' : 'de COSTAS para você', { fs: 17, cor: '#475569' }));
  const aa = alternativas(certa, [{ v: errada, erro: frente ? 'usou a própria direita, não a da menina' : 'trocou direita com esquerda' }, { v: 'a menina', erro: 'escolheu a própria menina' }, { v: 'nenhum dos dois', erro: 'achou que não tem nada desse lado' }], String);
  return { ...aa, text: `O que está à ${lado} da menina (a mão ${lado.toLowerCase()} DELA)?`, image: svgURI(img), meta: { a, b, frente, lado }, chave: `pr${a}${b}${frente}${lado}` };
};
C.posicaoRef1 = m => { const ladoTelaDir = (m.lado === 'DIREITA') !== m.frente; return NOME_ICONE[ladoTelaDir ? m.b : m.a][0]; };

/* ============================ 2º ANO ============================ */

/* Mapa do bairro com caminho (EF02MA13) */
const LUGARES = [['Escola', '#3b82f6'], ['Praça', '#22c55e'], ['Mercado', '#f59e0b'], ['Igreja', '#a855f7'], ['Posto de saúde', '#ef4444'], ['Padaria', '#ec4899'], ['Campo', '#14b8a6'], ['Biblioteca', '#6366f1'], ['Farmácia', '#0ea5e9'], ['Correios', '#eab308'], ['Sorveteria', '#f43f5e'], ['Quadra', '#65a30d']];
G.mapa2 = n => {
  const Lx = 3, Ly = 2, s = 180;                              // mapa menor = nomes maiores                              // quarteirões 4 × 3; ruas nas linhas
  const blocos = shuffle(LUGARES);                            // 12 quarteirões, 12 lugares diferentes
  const quarteirao = (i, j) => blocos[(j * Lx + i) % blocos.length];
  // caminho pelas ruas: da casa (canto) virando nas esquinas
  const passos = n === 1 ? 2 : 3;
  let p, pts;
  do{                                                          // o caminho termina num canto que tem quarteirão abaixo e à direita
    p = [0, rnd(0, Ly - 1)]; pts = [p.slice()];
    for(let k = 0; k < passos; k++){
      const hor = k % 2 === 0, lim = hor ? Lx : Ly;
      let alvo; do alvo = rnd(0, lim); while(alvo === (hor ? p[0] : p[1]));
      p = hor ? [alvo, p[1]] : [p[0], alvo]; pts.push(p.slice());
    }
  } while(p[0] >= Lx || p[1] >= Ly);
  // lugar onde termina: o quarteirão logo abaixo-direita do ponto final (dentro do mapa)
  const fx = p[0], fy = p[1];
  const destino = quarteirao(fx, fy)[0];
  let o = `<rect x="0" y="0" width="${Lx * s + 40}" height="${Ly * s + 40}" fill="#94a3b8"/>`;
  for(let i = 0; i < Lx; i++) for(let j = 0; j < Ly; j++){
    const [nm, cor] = quarteirao(i, j), cx0 = 20 + i * s + s / 2, cy0 = 20 + j * s + s / 2;
    o += `<rect x="${20 + i * s + 10}" y="${20 + j * s + 10}" width="${s - 20}" height="${s - 20}" rx="8" fill="${cor}" stroke="#111" stroke-width="2"/>`;
    const partes = nm.length > 9 && nm.includes(' ') ? [nm.slice(0, nm.lastIndexOf(' ')), nm.slice(nm.lastIndexOf(' ') + 1)] : [nm];      // nome comprido em 2 linhas
    const fs = Math.min(30, Math.floor((s - 34) / Math.max(...partes.map(p => p.length)) * 1.75));
    partes.forEach((p, k) => { o += T(cx0, cy0 + 8 + (k - (partes.length - 1) / 2) * (fs + 4), p, { fs, cor: '#fff', extra: ' stroke="#111" stroke-width="0.8" paint-order="stroke"' }); });
  }
  const P = ([x, y]) => [20 + x * s, 20 + y * s];
  o += `<polyline points="${pts.map(q => P(q).join(',')).join(' ')}" fill="none" stroke="#fff" stroke-width="7" stroke-dasharray="12,8" stroke-linecap="round"/>`;
  const [cx, cy] = P(pts[0]), [ex, ey] = P(p);
  o += `<rect x="${cx - 22}" y="${cy - 22}" width="44" height="44" rx="6" fill="#fef3c7" stroke="#111" stroke-width="2.5"/>` + T(cx, cy + 7, '🏠', { fs: 24 }) + `<circle cx="${ex}" cy="${ey}" r="13" fill="#dc2626" stroke="#fff" stroke-width="3"/>`;
  const vizinhos = [[fx - 1, fy], [fx, fy - 1], [fx - 1, fy - 1], [fx + 1, fy]].filter(([i, j]) => i >= 0 && j >= 0 && i < Lx && j < Ly).map(([i, j]) => quarteirao(i, j)[0]);
  const erradas = [...new Set(vizinhos)].filter(x => x !== destino).map(x => ({ v: x, erro: 'olhou o quarteirão errado na esquina' })).concat(blocos.slice(0, Lx * Ly).map(b => ({ v: b[0], erro: 'não seguiu o caminho' })));      // só lugares que aparecem no mapa
  const aa = alternativas(destino, erradas.filter(e => e.v !== destino), String);
  return { ...aa, text: 'Siga o caminho tracejado de casa 🏠 até a bolinha vermelha. Qual lugar fica logo abaixo e à direita dela?', image: svgURI(SVG(Lx * s + 40, Ly * s + 40, o)), meta: { blocos: blocos.map(b => b[0]), fx, fy, Lx }, chave: 'mp' + pts.join('|') + blocos.map(b => b[0][0]).join('') };
};
C.mapa2 = m => m.blocos[(m.fy * m.Lx + m.fx) % m.blocos.length];

/* ============================ 3º ANO ============================ */

/* Qual instrumento usar (EF03MA17 · EF03MA18) */
const INSTR = [['a altura da porta', 'fita métrica'], ['o comprimento do lápis', 'régua'], ['o peso do saco de arroz', 'balança'], ['o peso de uma pessoa', 'balança'], ['a febre de uma criança', 'termômetro'], ['a temperatura do dia', 'termômetro'],
  ['o tempo de uma corrida', 'cronômetro'], ['a hora do recreio', 'relógio'], ['o leite de uma receita', 'copo medidor'], ['a água para o bolo', 'copo medidor'], ['a largura da sala', 'fita métrica'], ['o lado do caderno', 'régua']];
G.instrumento3 = n => {
  const [coisa, certa] = pick(INSTR);
  const todos = ['régua', 'fita métrica', 'balança', 'termômetro', 'cronômetro', 'relógio', 'copo medidor'];
  const perto = { 'régua': 'fita métrica', 'fita métrica': 'régua', 'cronômetro': 'relógio', 'relógio': 'cronômetro' };
  const pool = todos.filter(t => t !== certa && t !== perto[certa]);        // nunca coloca as duas que serviriam
  const erradas = shuffle(pool).slice(0, 3).map(v => ({ v, erro: 'escolheu instrumento de outra grandeza' }));
  const aa = alternativas(certa, erradas, String);
  return { ...aa, text: `Qual instrumento é o melhor para medir ${coisa}?`, meta: { coisa }, chave: 'in' + coisa };
};
C.instrumento3 = m => INSTR.find(x => x[0] === m.coisa)[1];

/* Figuras congruentes na malha (EF03MA16) */
const normCel = cel => { const mr = Math.min(...cel.map(c => c[0])), mc = Math.min(...cel.map(c => c[1])); return cel.map(([r, c]) => [r - mr, c - mc]).sort((a, b) => a[0] - b[0] || a[1] - b[1]); };
const chaveCel = cel => JSON.stringify(normCel(cel));
const girar = cel => cel.map(([r, c]) => [c, -r]), espelhar = cel => cel.map(([r, c]) => [r, -c]);
const formasIguais = cel => { const k = new Set(); let x = cel; for(let i = 0; i < 4; i++){ k.add(chaveCel(x)); k.add(chaveCel(espelhar(x))); x = girar(x); } return k; };
function figMalhaSVG(cel, cor){ const c = normCel(cel), L = Math.max(...c.map(x => x[0])) + 1, W = Math.max(...c.map(x => x[1])) + 1; return malhaSVG(c.map(([r, k]) => [r + 1, k + 1]), L + 2, W + 2, cor, 24); }
G.congruente3 = n => {
  const k = n === 1 ? 4 : n === 2 ? 5 : 6;
  const A = sortearAte(() => poliomino(k, 6, 6), c => formasIguais(c).size >= 4);
  const iguais = formasIguais(A);
  let x = A; for(let i = 0; i < rnd(1, 3); i++) x = girar(x); if(n === 3 && Math.random() < .5) x = espelhar(x);
  const certa = x;
  const quase = () => sortearAte(() => { const c = normCel(A).map(v => v.slice()); const i = rnd(0, c.length - 1); const [r, cc] = pick(c.filter((_, j) => j !== i)); const d = pick([[1, 0], [-1, 0], [0, 1], [0, -1]]); c[i] = [r + d[0], cc + d[1]]; return c; },
    c => new Set(c.map(v => v.join(','))).size === k && !iguais.has(chaveCel(c)) && ligada(c));
  const erradas = [], vistos = new Set([...iguais]);
  for(let t = 0; erradas.length < 3 && t < 5000; t++){ const c = quase(); const key = chaveCel(c);
    if(new Set(c.map(v => v.join(','))).size === k && ligada(c) && !vistos.has(key)){ [...formasIguais(c)].forEach(z => vistos.add(z)); erradas.push(c); } }
  if(erradas.length < 3) throw new Error('congruente: poucas figuras diferentes');
  const itens = shuffle([[certa, null], ...erradas.map(c => [c, 'mudou um quadradinho de lugar'])]);
  return { options: letrasABCD.slice(0, itens.length), correct: itens.findIndex(i => i[1] === null), erros: itens.map(i => i[1]), answer: letrasABCD[itens.findIndex(i => i[1] === null)],
    optImgs: itens.map(i => svgURI(figMalhaSVG(i[0], '#60a5fa'))), text: `Qual figura é IGUAL à amarela (congruente)? Ela pode estar girada${n === 3 ? ' ou virada' : ''}.`, image: svgURI(figMalhaSVG(A, '#fbbf24')),
    meta: { A, ops: itens.map(i => i[0]) }, chave: 'cg' + chaveCel(A) };
};
function ligada(c){ const s = new Set(c.map(v => v.join(','))), vis = new Set([c[0].join(',')]), fila = [c[0]]; while(fila.length){ const [r, k] = fila.pop(); [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([a, b]) => { const key = (r + a) + ',' + (k + b); if(s.has(key) && !vis.has(key)){ vis.add(key); fila.push([r + a, k + b]); } }); } return vis.size === c.length; }
C.congruente3 = m => { const alvo = formasIguais(m.A); return 'ABCD'[m.ops.findIndex(c => alvo.has(chaveCel(c)))]; };

/* Comparar áreas (EF03MA21) */
G.areaComp3 = n => {
  const a1 = n === 1 ? rnd(4, 8) : rnd(6, 12);
  const a2 = n === 3 && Math.random() < .3 ? a1 : sortearAte(() => rnd(Math.max(3, a1 - 4), a1 + 4), v => v !== a1);
  const A = normCel(poliomino(a1, 5, 5)), B = normCel(poliomino(a2, 5, 5));
  const mais = Math.random() < .6;
  const certa = A.length === B.length ? 'As duas ocupam o mesmo espaço' : (mais ? A.length > B.length : A.length < B.length) ? 'Figura A' : 'Figura B';
  const erradas = [{ v: certa === 'Figura A' ? 'Figura B' : 'Figura A', erro: 'olhou o tamanho do contorno, não os quadradinhos' }, { v: certa === 'Figura B' ? 'Figura A' : 'Figura B', erro: 'contou errado' }, { v: 'As duas ocupam o mesmo espaço', erro: 'achou que são iguais' }, { v: 'Não dá para comparar', erro: 'achou que não dá para comparar' }];
  const aa = alternativas(certa, erradas.filter(e => e.v !== certa), String);
  return { ...aa, text: `Qual figura ocupa ${mais ? 'MAIS' : 'MENOS'} espaço (tem ${mais ? 'maior' : 'menor'} área)?`, image: svgURI(duasFigurasMalha(A, B)), meta: { a: A.length, b: B.length, mais }, chave: 'ac' + chaveCel(A) + chaveCel(B) + mais };
};
C.areaComp3 = m => m.a === m.b ? 'As duas ocupam o mesmo espaço' : (m.mais ? m.a > m.b : m.a < m.b) ? 'Figura A' : 'Figura B';

/* ============================ 4º ANO ============================ */

/* Operação inversa para conferir (EF04MA13) */
G.inversa4 = n => {
  const op = n === 1 ? '+' : n === 2 ? pick(['+', '−']) : pick(['−', '×', '÷']);
  let a, b, r;
  if(op === '+'){ a = rnd(120, 800); b = rnd(100, 900 - a > 100 ? 900 - a : 150); r = a + b; }
  else if(op === '−'){ a = rnd(300, 999); b = rnd(100, a - 50); r = a - b; }
  else if(op === '×'){ a = rnd(12, 60); b = rnd(3, 9); r = a * b; }
  else { b = rnd(3, 9); r = rnd(12, 60); a = b * r; }
  const conta = `${a} ${op} ${b} = ${r}`;
  const cand = { '+': [[`${r} − ${b} = ${a}`, null], [`${r} + ${b} = ${a + 2 * b}`, 'repetiu a mesma operação'], [`${a} − ${b} = ${a - b}`, 'fez a conta inversa com os números errados'], [`${r} + ${a} = ${r + a}`, 'somou o resultado']],
    '−': [[`${r} + ${b} = ${a}`, null], [`${a} + ${b} = ${a + b}`, 'somou os números da conta'], [`${r} − ${b} = ${r - b}`, 'repetiu a mesma operação'], [`${b} − ${r} = ${b - r}`, 'inverteu a ordem']],
    '×': [[`${r} ÷ ${b} = ${a}`, null], [`${r} × ${b} = ${r * b}`, 'repetiu a mesma operação'], [`${a} ÷ ${b} = ?`, 'dividiu o número errado'], [`${r} − ${b} = ${r - b}`, 'usou subtração']],
    '÷': [[`${r} × ${b} = ${a}`, null], [`${a} × ${b} = ${a * b}`, 'multiplicou os números errados'], [`${r} ÷ ${b} = ?`, 'repetiu a mesma operação'], [`${r} + ${b} = ${r + b}`, 'usou adição']] }[op];
  if(a === b || new Set(cand.map(c => c[0])).size < 4) return G.inversa4(n);     // números iguais deixariam alternativas repetidas
  const emb = shuffle(cand);
  return { options: emb.map(c => c[0]), correct: emb.findIndex(c => c[1] === null), erros: emb.map(c => c[1]), answer: cand[0][0], text: `A conta ${conta} está certa. Qual conta CONFIRMA isso (operação inversa)?`, meta: { a, b, r, op }, chave: 'iv' + conta };
};
C.inversa4 = m => ({ '+': `${m.r} − ${m.b} = ${m.a}`, '−': `${m.r} + ${m.b} = ${m.a}`, '×': `${m.r} ÷ ${m.b} = ${m.a}`, '÷': `${m.r} × ${m.b} = ${m.a}` })[m.op];

/* Propriedades para calcular de cabeça (EF04MA05) */
G.propriedades4 = n => {
  if(n === 1){
    const [p, q] = pick([[25, 4], [5, 2], [50, 2], [20, 5], [4, 25]]), k = rnd(3, 9), ordem = shuffle([p, k, q]), v = p * q * k;
    const erradas = [{ v: p + q + k, erro: 'somou em vez de multiplicar' }, { v: p * q, erro: 'esqueceu um número' }, { v: v + k, erro: 'errou a conta' }, { v: v / 10 === Math.floor(v / 10) ? v / 10 : v - k, erro: 'errou os zeros' }];
    const aa = alternativas(v, erradas.filter(e => e.v !== v), String, { min: 1 });
    return { ...aa, text: `Calcule de cabeça: ${ordem.join(' × ')} = ?  (dica: junte ${p} × ${q} primeiro)`, meta: { f: [p, q, k] }, chave: 'pa' + ordem.join('x') };
  }
  const k = rnd(3, 9), d = rnd(1, 9) * 10, u = rnd(1, 9), num = d + u;
  if(n === 2){
    const v = k * num;
    const erradas = [{ v: k * d + u, erro: 'multiplicou só as dezenas' }, { v: k * d, erro: 'esqueceu as unidades' }, { v: k * u + d, erro: 'multiplicou só as unidades' }, { v: v + k, erro: 'errou a conta' }];
    const aa = alternativas(v, erradas.filter(e => e.v !== v), String, { min: 1 });
    return { ...aa, text: `${k} × ${num} = ${k} × ${d} + ${k} × ${u} = ?`, meta: { k, d, u, modo: 'total' }, chave: `pd${k}x${num}` };
  }
  const erradas = [{ v: num, erro: 'repetiu o número inteiro' }, { v: d, erro: 'repetiu as dezenas' }, { v: k * u, erro: 'já multiplicou' }, { v: u + 1, erro: 'um a mais' }];
  const aa = alternativas(u, erradas.filter(e => e.v !== u), String, { min: 1 });
  return { ...aa, text: `Complete: ${k} × ${num} = ${k} × ${d} + ${k} × ?`, meta: { k, d, u, modo: 'falta' }, chave: `pf${k}x${num}` };
};
C.propriedades4 = m => m.f ? String(m.f[0] * m.f[1] * m.f[2]) : m.modo === 'total' ? String(m.k * (m.d + m.u)) : String(m.u);

/* Números com o mesmo resto (EF04MA12) */
G.restos4 = n => {
  const d = rnd(3, n === 1 ? 5 : 9), r = rnd(1, d - 1), ini = r + d * rnd(0, 3);
  const seq = [0, 1, 2, 3].map(i => ini + i * d);
  if(n < 3){
    const erradas = [{ v: d, erro: 'respondeu o divisor' }, { v: 0, erro: 'achou que a divisão é exata' }, { v: r + 1, erro: 'errou a conta' }, { v: d - r, erro: 'contou quanto falta, não o que sobra' }];
    const aa = alternativas(r, erradas.filter(e => e.v !== r && e.v >= 0), String, { min: 0 });
    return { ...aa, text: `Os números ${seq.join(', ')}… divididos por ${d} deixam sempre o mesmo resto. Qual é esse resto?`, meta: { d, r, modo: 'resto' }, chave: `rs${ini}/${d}` };
  }
  const intruso = seq[3] + rnd(1, d - 1) - (r > 0 ? 0 : 0);
  const certoFora = intruso % d === r ? intruso + 1 : intruso;
  const bons = [seq[3] + d, seq[3] + 2 * d, seq[3] + 3 * d];
  const cand = shuffle([[certoFora, null], ...bons.map(v => [v, 'não conferiu o resto'])]);
  return { options: cand.map(c => String(c[0])), correct: cand.findIndex(c => c[1] === null), erros: cand.map(c => c[1]), answer: String(certoFora), text: `A sequência ${seq.join(', ')}… vai de ${d} em ${d} e todos deixam resto ${r} na divisão por ${d}. Qual número NÃO faz parte dela?`, meta: { d, r, ops: cand.map(c => c[0]), modo: 'fora' }, chave: `rf${ini}/${d}` };
};
C.restos4 = m => m.modo === 'resto' ? String(m.r) : String(m.ops.find(v => v % m.d !== m.r));

/* Igualdade que se mantém (EF04MA14) */
G.igualdade4 = n => {
  const a = rnd(3, 20), b = rnd(2, 15), s = a + b, k = rnd(2, 9), sub = n === 3 && Math.random() < .5;
  const esq = sub ? `${a} + ${b} − ${k}` : `${a} + ${b} + ${k}`, dir = `${s} ${sub ? '−' : '+'} ?`;
  const erradas = [{ v: s, erro: 'repetiu o resultado' }, { v: s + k, erro: 'calculou em vez de completar' }, { v: k + 1, erro: 'errou por um' }, { v: b, erro: 'repetiu um número da conta' }];
  const aa = alternativas(k, erradas.filter(e => e.v !== k), String, { min: 1 });
  return { ...aa, text: `Se ${a} + ${b} = ${s}, a balança continua equilibrada assim: ${esq} = ${dir}. Qual número falta?`, image: svgURI(balancaNumeros(esq, dir)), meta: { k }, chave: `ig${a}+${b}${sub ? '-' : '+'}${k}` };
};
C.igualdade4 = m => String(m.k);

/* Gráfico de temperatura máxima e mínima (EF04MA24) */
function colunasDuplas(rot, A, B, nomeA, nomeB, corA, corB, titulo, unid, maxV, passo){
  const W = 540, H = 330, x0 = 60, y0 = 270, h = 210, gw = (W - x0 - 20) / rot.length, Y = v => y0 - v / maxV * h;
  let o = T(W / 2, 24, titulo, { fs: 18 });
  for(let v = 0; v <= maxV; v += passo) o += `<line x1="${x0}" y1="${Y(v)}" x2="${W - 10}" y2="${Y(v)}" stroke="#e2e8f0" stroke-width="1.5"/>` + T(x0 - 8, Y(v) + 6, v, { fs: 14, anc: 'end', fw: 'normal' });
  rot.forEach((r, i) => { const x = x0 + i * gw + gw * .15, bw = gw * .33;
    o += `<rect x="${x}" y="${Y(A[i])}" width="${bw}" height="${y0 - Y(A[i])}" fill="${corA}" stroke="#111" stroke-width="1.5"/><rect x="${x + bw}" y="${Y(B[i])}" width="${bw}" height="${y0 - Y(B[i])}" fill="${corB}" stroke="#111" stroke-width="1.5"/>` + T(x + bw, y0 + 22, r, { fs: 15 }); });
  o += `<line x1="${x0}" y1="${y0}" x2="${W - 10}" y2="${y0}" stroke="#111" stroke-width="2.5"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y0 - h - 8}" stroke="#111" stroke-width="2.5"/>` + T(x0 - 40, y0 - h - 16, unid, { fs: 13, anc: 'start', cor: '#475569' }) +
    `<rect x="${x0 + 10}" y="${H - 26}" width="16" height="16" fill="${corA}" stroke="#111"/>` + T(x0 + 32, H - 13, nomeA, { fs: 14, anc: 'start', fw: 'normal' }) + `<rect x="${x0 + 170}" y="${H - 26}" width="16" height="16" fill="${corB}" stroke="#111"/>` + T(x0 + 192, H - 13, nomeB, { fs: 14, anc: 'start', fw: 'normal' });
  return SVG(W, H, o);
}
G.graficoTemp4 = n => {
  const dias = ['SEG', 'TER', 'QUA', 'QUI', 'SEX'], DIAN = { SEG: 'segunda', TER: 'terça', QUA: 'quarta', QUI: 'quinta', SEX: 'sexta' };
  const mx = sortearAte(() => dias.map(() => 2 * rnd(12, 17)), v => new Set(v).size >= 4), mn = mx.map(v => v - 2 * rnd(2, 6));
  const amp = mx.map((v, i) => v - mn[i]);
  const img = svgURI(colunasDuplas(dias, mx, mn, 'máxima', 'mínima', '#ef4444', '#3b82f6', 'Temperaturas da semana', '°C', 36, 4));
  if(n === 1){ const i = rnd(0, 4); const aa = alternativas(mx[i], [{ v: mn[i], erro: 'leu a mínima' }, { v: mx[i] + 2, erro: 'leu a escala errado' }, { v: mx[(i + 1) % 5], erro: 'olhou outro dia' }], v => v + ' °C', { min: 1, passo: 2 });
    return { ...aa, text: `Qual foi a temperatura MÁXIMA na ${DIAN[dias[i]]}?`, image: img, meta: { mx, mn, i, modo: 'max' }, chave: 'gt' + mx.join(',') + i }; }
  if(n === 2){ const i = rnd(0, 4); const aa = alternativas(amp[i], [{ v: mx[i], erro: 'respondeu só a máxima' }, { v: mx[i] + mn[i], erro: 'somou as temperaturas' }, { v: amp[i] + 2, erro: 'leu a escala errado' }], v => v + ' °C', { min: 1, passo: 2 });
    return { ...aa, text: `Na ${DIAN[dias[i]]}, qual a diferença entre a máxima e a mínima?`, image: img, meta: { mx, mn, i, modo: 'dif' }, chave: 'gd' + mx.join(',') + mn.join(',') + i }; }
  const best = Math.max(...amp); if(amp.filter(a => a === best).length > 1) return G.graficoTemp4(n);
  const i = amp.indexOf(best), iM = mx.indexOf(Math.max(...mx));
  const aa = alternativas(DIAN[dias[i]], dias.filter((d, k) => k !== i).map(d => ({ v: DIAN[d], erro: DIAN[d] === DIAN[dias[iM]] ? 'escolheu o dia mais quente' : 'comparou errado' })), String);
  return { ...aa, text: 'Em que dia a diferença entre a máxima e a mínima foi MAIOR?', image: img, meta: { mx, mn, modo: 'maiorDif', dias }, chave: 'gm' + mx.join(',') + mn.join(',') };
};
C.graficoTemp4 = m => { if(m.modo === 'max') return m.mx[m.i] + ' °C'; if(m.modo === 'dif') return (m.mx[m.i] - m.mn[m.i]) + ' °C'; const DIAN = ['segunda', 'terça', 'quarta', 'quinta', 'sexta']; let b = 0; m.mx.forEach((v, k) => { if(v - m.mn[k] > m.mx[b] - m.mn[b]) b = k; }); return DIAN[b]; };

/* Ponto, reta e plano (EF04MA29) */
const PRP = [['a ponta de um lápis', 'ponto'], ['um furinho feito com alfinete', 'ponto'], ['uma estrela vista no céu', 'ponto'], ['um fio de varal bem esticado', 'reta'], ['a linha do horizonte', 'reta'], ['um raio de laser', 'reta'],
  ['o tampo da mesa', 'plano'], ['o chão da sala', 'plano'], ['o quadro da sala', 'plano'], ['a folha do caderno', 'plano']];
G.pontoReta4 = n => {
  const [obj, certa] = pick(PRP);
  const erradas = ['ponto', 'reta', 'plano'].filter(t => t !== certa).map(v => ({ v, erro: 'confundiu ponto, reta e plano' })).concat([{ v: 'sólido (tem volume)', erro: 'achou que é um sólido' }]);
  const aa = alternativas(certa, erradas, String);
  return { ...aa, text: `${obj[0].toUpperCase() + obj.slice(1)} dá a ideia de:`, meta: { obj }, chave: 'pr' + obj };
};
C.pontoReta4 = m => PRP.find(x => x[0] === m.obj)[1];

/* ============================ 5º ANO ============================ */

/* Números grandes: valor do algarismo e escrita (EF05MA01) */
const UN = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove'], DZ = ['', 'dez', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'],
  DEZ = ['dez', 'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'], CEN = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
function ate999(v){ if(v === 0) return ''; if(v === 100) return 'cem'; const c = Math.floor(v / 100), r = v % 100, d = Math.floor(r / 10), u = r % 10; const p = []; if(c) p.push(CEN[c]); if(r >= 10 && r < 20) p.push(DEZ[r - 10]); else { if(d) p.push(DZ[d]); if(u) p.push(UN[u]); } return p.join(' e '); }
function extenso(v){ const mil = Math.floor(v / 1000), r = v % 1000; const a = mil ? (mil === 1 ? 'mil' : ate999(mil) + ' mil') : ''; const b = ate999(r); if(!a) return b; if(!b) return a; return a + (r < 100 || r % 100 === 0 ? ' e ' : ' ') + b; }
G.numGrandes5 = n => {
  const v = sortearAte(() => rnd(n === 1 ? 10000 : 100000, n === 1 ? 99999 : 999999), x => new Set(String(x)).size >= 4);
  const s = String(v);
  if(n < 3){
    const pos = rnd(0, s.length - 2), dig = +s[pos], casas = s.length - 1 - pos, val = dig * 10 ** casas;
    if(dig === 0) return G.numGrandes5(n);
    const nomes = ['unidades', 'dezenas', 'centenas', 'unidades de milhar', 'dezenas de milhar', 'centenas de milhar'];
    const erradas = [{ v: dig, erro: 'respondeu só o algarismo' }, { v: dig * 10 ** (casas - 1), erro: 'contou uma casa a menos' }, { v: dig * 10 ** (casas + 1), erro: 'contou uma casa a mais' }, { v: dig * 10 ** Math.max(0, casas - 2), erro: 'contou as casas errado' }];
    const aa = alternativas(val, erradas.filter(e => e.v !== val && Number.isInteger(e.v)), x => x.toLocaleString('pt-BR'), { min: 1 });
    return { ...aa, text: `No número ${v.toLocaleString('pt-BR')}, quanto vale o algarismo ${dig} que está na casa das ${nomes[casas]}?`, meta: { v, pos }, chave: `ng${v}.${pos}` };
  }
  const troca = v + (Math.random() < .5 ? 1000 : -1000) * rnd(1, 3), zero = v - v % 1000 + (v % 100);
  const erradas = [{ v: extenso(troca), erro: 'errou os milhares' }, { v: extenso(zero), erro: 'esqueceu as centenas' }, { v: extenso(v + 10), erro: 'errou as dezenas' }, { v: extenso(v - 100 >= 100000 ? v - 100 : v + 200), erro: 'errou as centenas' }];
  const aa = alternativas(extenso(v), erradas.filter(e => e.v !== extenso(v)), String);
  return { ...aa, text: `Como se escreve ${v.toLocaleString('pt-BR')} por extenso?`, meta: { v, modo: 'ext' }, chave: 'ne' + v };
};
C.numGrandes5 = m => { if(m.modo === 'ext') return extenso(m.v); const s = String(m.v), casas = s.length - 1 - m.pos; return (+s[m.pos] * Math.pow(10, casas)).toLocaleString('pt-BR'); };

/* Conversão de medidas (EF05MA19) */
const CONV = [['m', 'cm', 100], ['cm', 'mm', 10], ['km', 'm', 1000], ['kg', 'g', 1000], ['L', 'mL', 1000], ['h', 'min', 60], ['min', 's', 60]];
G.conversao5 = n => {
  const [gr, pq, f] = pick(n === 1 ? CONV.filter(c => ['m', 'cm', 'kg', 'h'].includes(c[0])) : CONV);
  const inv = n === 3 && Math.random() < .5;
  let x, v;
  if(!inv){ x = n === 3 && f !== 60 ? rnd(11, 95) / 10 : rnd(2, 9); v = r3(x * f); }
  else { v = n === 3 && f !== 60 ? rnd(11, 95) / 10 : rnd(2, 9); x = r3(v * f); }
  const de = inv ? pq : gr, para = inv ? gr : pq;
  const erradas = inv ? [{ v: r3(x * f), erro: 'multiplicou em vez de dividir' }, { v: r3(x / (f === 1000 ? 100 : f === 100 ? 10 : f === 60 ? 100 : 100)), erro: 'usou o fator errado' }, { v: r3(v * 10), erro: 'errou a vírgula' }, { v: r3(v + 1), erro: 'errou a conta' }]
    : [{ v: r3(x / f), erro: 'dividiu em vez de multiplicar' }, { v: r3(x * (f === 1000 ? 100 : f === 100 ? 10 : f === 60 ? 100 : 100)), erro: f === 60 ? 'achou que 1 hora tem 100 minutos' : 'usou o fator errado' }, { v: r3(v * 10), erro: 'um zero a mais' }, { v: r3(x + f), erro: 'somou em vez de multiplicar' }];
  const o = opcoesDecimaisTR(v, erradas.filter(e => e.v > 0), z => fmtDec(z) + ' ' + para);
  return { ...o, text: `${fmtDec(x)} ${de} = quantos ${para}?`, meta: { x, de, para }, chave: `cv${x}${de}${para}` };
};
C.conversao5 = m => { const c = CONV.find(q => (q[0] === m.de && q[1] === m.para) || (q[1] === m.de && q[0] === m.para)); const v = c[0] === m.de ? m.x * c[2] : m.x / c[2]; return fmtDec(r3(v)) + ' ' + m.para; };

/* ============================ 6º ANO ============================ */

/* Comparar e ordenar decimais (EF06MA01) */
G.decCompara6 = n => {
  const base = rnd(0, n === 1 ? 5 : 9);
  const d1 = rnd(1, 9), d2 = rnd(0, 9), d3 = rnd(1, 9);
  let nums = n === 1 ? [base + d1 / 10, base + (d1 - 1 >= 0 ? (d1 - 1) : 0) / 10 + d3 / 100, base + d1 / 100 + d3 / 1000, base + ((d1 + 1) % 10) / 100]
    : [base + d1 / 10, base + (d1 === 0 ? 0 : d1 - 1) / 10 + (9) / 100 + d3 / 1000, base + d1 / 100 + d2 / 1000, base + d1 / 10 + d3 / 1000];
  nums = [...new Set(nums.map(x => r3(x)))];
  while(nums.length < 4) nums.push(r3(base + rnd(1, 999) / 1000));
  nums = [...new Set(nums)]; if(nums.length < 4) return G.decCompara6(n);
  const mais = Math.random() < .6, alvo = mais ? Math.max(...nums) : Math.min(...nums);
  const maisCasas = nums.reduce((b, x) => String(x).length > String(b).length ? x : b, nums[0]);
  if(n < 3){
    const cand = shuffle(nums.map(x => [fmtDec(x), x === alvo ? null : (x === maisCasas ? 'achou que mais casas decimais é maior' : 'comparou errado')]));
    return { options: cand.map(c => c[0]), correct: cand.findIndex(c => c[1] === null), erros: cand.map(c => c[1]), answer: fmtDec(alvo), text: `Qual número é o ${mais ? 'MAIOR' : 'MENOR'}?`, meta: { nums, mais }, chave: 'dc' + nums.join(',') + mais };
  }
  const cres = [...nums].sort((a, b) => a - b), f = arr => arr.map(fmtDec).join(' < ');
  const errs = [[f(cres), null], [f([...nums].sort((a, b) => String(a).length - String(b).length || a - b)), 'ordenou pela quantidade de algarismos'], [f([...cres].reverse()), 'colocou em ordem decrescente'], [f([cres[1], cres[0], cres[2], cres[3]]), 'trocou dois números']];
  const vistos = new Set(), itens = [];
  errs.forEach(e => { if(!vistos.has(e[0]) && !(e[1] && e[0] === f(cres))){ vistos.add(e[0]); itens.push(e); } });
  for(const pm of [[0, 2, 1, 3], [0, 1, 3, 2], [1, 0, 3, 2], [3, 2, 0, 1], [2, 0, 1, 3]]){ const t = f(pm.map(i => cres[i])); if(itens.length < 4 && !vistos.has(t)){ vistos.add(t); itens.push([t, 'trocou números de lugar']); } }
  const emb = shuffle(itens.slice(0, 4));
  return { options: emb.map(c => c[0]), correct: emb.findIndex(c => c[1] === null), erros: emb.map(c => c[1]), answer: f(cres), text: 'Qual é a ordem CRESCENTE (do menor para o maior)?', meta: { nums, modo: 'ordem' }, chave: 'do' + nums.join(',') };
};
C.decCompara6 = m => m.modo === 'ordem' ? [...m.nums].sort((a, b) => a - b).map(fmtDec).join(' < ') : fmtDec(m.mais ? Math.max(...m.nums) : Math.min(...m.nums));

/* Fluxograma (EF06MA04 · EF06MA23 · EF07MA05–07) */
function fluxoSVG(passos, entrada, saida, decisao){
  const W = 560, bx = 170, bw = 220; let y = 14, o = '';
  const caixa = (t, cor, forma) => { let s; if(forma === 'oval') s = `<rect x="${bx}" y="${y}" width="${bw}" height="46" rx="23" fill="${cor}" stroke="#111" stroke-width="2.5"/>`; else s = `<rect x="${bx}" y="${y}" width="${bw}" height="46" rx="6" fill="${cor}" stroke="#111" stroke-width="2.5"/>`; s += T(bx + bw / 2, y + 31, t, { fs: 21 }); y += 46; return s; };
  const seta = () => { const s = `<line x1="${bx + bw / 2}" y1="${y}" x2="${bx + bw / 2}" y2="${y + 22}" stroke="#111" stroke-width="3"/><polygon points="${bx + bw / 2 - 7},${y + 14} ${bx + bw / 2 + 7},${y + 14} ${bx + bw / 2},${y + 24}" fill="#111"/>`; y += 26; return s; };
  o += caixa(`ENTRA: ${entrada}`, '#bbf7d0', 'oval') + seta();
  passos.forEach(p => { o += caixa(p, '#dbeafe') + seta(); });
  if(decisao){
    const cy = y + 36; o += `<polygon points="${bx + bw / 2},${y} ${bx + bw},${cy} ${bx + bw / 2},${cy + 36} ${bx},${cy}" fill="#fef3c7" stroke="#111" stroke-width="2.5"/>` + T(bx + bw / 2, cy + 7, decisao.pergunta, { fs: 17 });
    o += `<line x1="${bx}" y1="${cy}" x2="${bx - 60}" y2="${cy}" stroke="#111" stroke-width="3"/>` + T(bx - 30, cy - 8, 'SIM', { fs: 14 }) + `<rect x="${bx - 160}" y="${cy + 16}" width="130" height="42" rx="6" fill="#dbeafe" stroke="#111" stroke-width="2.5"/>` + T(bx - 95, cy + 44, decisao.sim, { fs: 19 }) + `<line x1="${bx - 60}" y1="${cy}" x2="${bx - 95}" y2="${cy + 16}" stroke="#111" stroke-width="3"/>`;
    o += `<line x1="${bx + bw}" y1="${cy}" x2="${bx + bw + 60}" y2="${cy}" stroke="#111" stroke-width="3"/>` + T(bx + bw + 30, cy - 8, 'NÃO', { fs: 14 }) + `<rect x="${bx + bw + 30}" y="${cy + 16}" width="130" height="42" rx="6" fill="#dbeafe" stroke="#111" stroke-width="2.5"/>` + T(bx + bw + 95, cy + 44, decisao.nao, { fs: 19 }) + `<line x1="${bx + bw + 60}" y1="${cy}" x2="${bx + bw + 95}" y2="${cy + 16}" stroke="#111" stroke-width="3"/>`;
    y = cy + 70; o += T(W / 2, y + 20, `SAI: ${saida}`, { fs: 21 });
    return SVG(W, y + 34, o);
  }
  o += caixa(`SAI: ${saida}`, '#fecaca', 'oval');
  return SVG(W, y + 14, o);
}
const OPS_FLUXO = { '×': (a, b) => a * b, '+': (a, b) => a + b, '−': (a, b) => a - b, '÷': (a, b) => a / b };
G.fluxograma6 = n => {
  if(n === 3){
    const x = rnd(3, 30), par = x % 2 === 0, a = rnd(2, 5), b = rnd(3, 9);
    const r = par ? x / 2 : x * a + b;
    const erradas = [{ v: par ? x * a + b : x / 2, erro: 'seguiu o caminho errado do "é par?"' }, { v: par ? x * 2 : x * a, erro: 'fez só parte da conta' }, { v: r + 1, erro: 'errou a conta' }, { v: x, erro: 'repetiu a entrada' }];
    const aa = alternativas(r, erradas.filter(e => Number.isInteger(e.v) && e.v !== r), String, { min: 1 });
    return { ...aa, text: 'Siga o fluxograma. Qual número SAI?', image: svgURI(fluxoSVG([], x, '?', { pergunta: 'é par?', sim: '÷ 2', nao: `× ${a} + ${b}` })), meta: { x, a, b, modo: 'dec' }, chave: `fd${x}.${a}.${b}` };
  }
  const k = n === 1 ? 2 : 2, ops = [[pick(['×', '+']), rnd(2, 5)], [pick(['+', '−']), rnd(1, 9)]].slice(0, k);
  const inv = n === 2 && Math.random() < .5;
  let x = rnd(2, 15), r = x; ops.forEach(([o, v]) => { r = OPS_FLUXO[o](r, v); });
  if(r < 1) return G.fluxograma6(n);
  const tx = ops.map(([o, v]) => `${o} ${v}`);
  if(inv){
    const erradas = [{ v: r, erro: 'repetiu a saída' }, { v: ops.reduceRight((acc, [o, v]) => OPS_FLUXO[o](acc, v), r), erro: 'fez as contas de novo em vez de desfazer' }, { v: x + 1, erro: 'errou a conta' }, { v: x - 1 > 0 ? x - 1 : x + 2, erro: 'errou a conta' }];
    const aa = alternativas(x, erradas.filter(e => Number.isInteger(e.v) && e.v > 0 && e.v !== x), String, { min: 1 });
    return { ...aa, text: `Saiu ${r}. Qual número ENTROU? (desfaça os passos de baixo para cima)`, image: svgURI(fluxoSVG(tx, '?', r)), meta: { ops, r, modo: 'inv' }, chave: 'fi' + tx.join('') + r };
  }
  const erradas = [{ v: ops.length > 1 ? OPS_FLUXO[ops[1][0]](x, ops[1][1]) : x, erro: 'pulou um passo' }, { v: ops.length > 1 ? OPS_FLUXO[ops[0][0]](OPS_FLUXO[ops[1][0]](x, ops[1][1]), ops[0][1]) : x + 1, erro: 'fez os passos fora de ordem' }, { v: r + 1, erro: 'errou a conta' }, { v: r - 1, erro: 'errou a conta' }];
  const aa = alternativas(r, erradas.filter(e => Number.isInteger(e.v) && e.v > 0 && e.v !== r), String, { min: 1 });
  return { ...aa, text: `Entra ${x}. Siga os passos: qual número SAI?`, image: svgURI(fluxoSVG(tx, x, '?')), meta: { ops, x, modo: 'dir' }, chave: 'fx' + tx.join('') + x };
};
C.fluxograma6 = m => {
  if(m.modo === 'dec') return String(m.x % 2 === 0 ? m.x / 2 : m.x * m.a + m.b);
  const INV = { '×': '÷', '÷': '×', '+': '−', '−': '+' };
  if(m.modo === 'inv'){ let v = m.r; [...m.ops].reverse().forEach(([o, k]) => { v = OPS_FLUXO[INV[o]](v, k); }); return String(v); }
  let v = m.x; m.ops.forEach(([o, k]) => { v = OPS_FLUXO[o](v, k); }); return String(v);
};

/* Balança da igualdade no 6º ano (EF06MA14) */
G.balanca6 = n => {
  const k = n === 1 ? 1 : rnd(2, n === 2 ? 3 : 4), x = rnd(2, n === 1 ? 9 : 8), a = n === 2 ? 0 : rnd(1, 9), dir = k * x + a;
  const erradas = [{ v: dir - a, erro: 'tirou o peso, mas não dividiu pelas caixas' }, { v: dir, erro: 'respondeu o peso do outro lado' }, { v: dir + a, erro: 'somou o peso em vez de tirar' }, { v: x + 1, erro: 'errou a conta' }, { v: Math.round(dir / k), erro: 'dividiu sem tirar o peso' }];
  const aa = alternativas(x, erradas.filter(e => e.v !== x && e.v > 0), v => v + ' kg', { min: 1 });
  return { ...aa, text: `A balança está equilibrada. Quanto pesa cada caixa x?${n > 1 ? ' (tire o mesmo dos dois lados e depois divida)' : ''}`, image: svgURI(svgBalanca(k, a, 0, dir)), meta: { k, a, dir }, chave: `b6${k}.${a}.${dir}` };
};
C.balanca6 = m => ((m.dir - m.a) / m.k) + ' kg';

/* Gráfico de barras duplas: ler e interpretar (EF06MA31 · EF06MA32) */
G.graficoDuplo6 = n => {
  const esportes = ['Futebol', 'Vôlei', 'Basquete', 'Natação'], cats = esportes;
  const A = esportes.map(() => 2 * rnd(2, 12)), B = esportes.map(() => 2 * rnd(2, 12));
  const img = svgURI(colunasDuplas(cats, A, B, 'meninas', 'meninos', '#ec4899', '#3b82f6', 'Esporte preferido do 6º ano', 'alunos', 26, 2));
  if(n === 1){ const i = rnd(0, 3); const aa = alternativas(A[i], [{ v: B[i], erro: 'leu a barra dos meninos' }, { v: A[i] + 2, erro: 'leu a escala errado' }, { v: A[i] + B[i], erro: 'somou as duas barras' }], String, { min: 1, passo: 2 });
    return { ...aa, text: `Quantas MENINAS preferem ${esportes[i].toLowerCase()}?`, image: img, meta: { A, B, i, modo: 'le' }, chave: 'gd' + A.join(',') + B.join(',') + i }; }
  if(n === 2){ const i = rnd(0, 3), t = A[i] + B[i]; const aa = alternativas(t, [{ v: A[i], erro: 'contou só as meninas' }, { v: Math.abs(A[i] - B[i]) || 1, erro: 'subtraiu' }, { v: t + 2, erro: 'errou a soma' }], String, { min: 1, passo: 2 });
    return { ...aa, text: `Quantos alunos ao todo (meninas + meninos) preferem ${esportes[i].toLowerCase()}?`, image: img, meta: { A, B, i, modo: 'soma' }, chave: 'gs' + A.join(',') + B.join(',') + i }; }
  const dif = A.map((v, i) => Math.abs(v - B[i])), mx = Math.max(...dif); if(dif.filter(d => d === mx).length > 1) return G.graficoDuplo6(n);
  const i = dif.indexOf(mx), tot = A.map((v, k) => v + B[k]), iT = tot.indexOf(Math.max(...tot));
  const aa = alternativas(esportes[i], esportes.filter((e, k) => k !== i).map(e => ({ v: e, erro: e === esportes[iT] ? 'escolheu o esporte com mais alunos' : 'comparou errado' })), String);
  return { ...aa, text: 'Em qual esporte a diferença entre meninas e meninos é MAIOR?', image: img, meta: { A, B, modo: 'dif' }, chave: 'gx' + A.join(',') + B.join(',') };
};
C.graficoDuplo6 = m => { const E = ['Futebol', 'Vôlei', 'Basquete', 'Natação']; if(m.modo === 'le') return String(m.A[m.i]); if(m.modo === 'soma') return String(m.A[m.i] + m.B[m.i]); let b = 0; m.A.forEach((v, k) => { if(Math.abs(v - m.B[k]) > Math.abs(m.A[b] - m.B[b])) b = k; }); return E[b]; };

/* ============================ 7º ANO ============================ */

/* Expressões algébricas equivalentes (EF07MA16) */
G.equivExpr7 = n => {
  let alvo, cands;      // cada candidata: [texto, função, erro]
  if(n === 1){ const a = rnd(2, 5), b = rnd(1, 9); alvo = `${a}(x + ${b})`;
    cands = [[`${a}x + ${a * b}`, x => a * x + a * b, null], [`${a}x + ${b}`, x => a * x + b, 'multiplicou só o x'], [`x + ${a * b}`, x => x + a * b, 'multiplicou só o número'], [`${a + b}x`, x => (a + b) * x, 'juntou tudo com o x']]; }
  else if(n === 2){ const a = rnd(2, 7), b = rnd(2, 7), c = rnd(1, 9); alvo = `${a}x + ${b}x + ${c}`;
    cands = [[`${a + b}x + ${c}`, x => (a + b) * x + c, null], [`${a * b}x + ${c}`, x => a * b * x + c, 'multiplicou os coeficientes'], [`${a + b + c}x`, x => (a + b + c) * x, 'juntou o número com os x'], [`${a + b}x² + ${c}`, x => (a + b) * x * x + c, 'transformou em x²']]; }
  else { const a = rnd(2, 5), b = sortearAte(() => rnd(1, 7), v => v !== a); alvo = `a sequência ${[1, 2, 3, 4].map(k => a * k + b).join(', ')}… (termo = ${a}n + ${b})`;
    cands = [[`${a}(n + 1) + ${b - a}`.replace('+ -', '− '), m => a * (m + 1) + b - a, null], [`${a}(n + ${b})`, m => a * (m + b), 'colocou tudo dentro dos parênteses'], [`${a + b}n`, m => (a + b) * m, 'juntou os termos'], [`${a}n + ${b + a}`, m => a * m + b + a, 'errou o número']]; }
  const f0 = cands[0][1];
  const ok = cands.slice(1).every(([, f]) => [1, 2, 3, 5].some(x => f(x) !== f0(x)));
  if(!ok) return G.equivExpr7(n);
  const emb = shuffle(cands);
  return { options: emb.map(c => c[0]), correct: emb.findIndex(c => c[2] === null), erros: emb.map(c => c[2]), answer: cands[0][0], text: n === 3 ? `Qual expressão também gera ${alvo}?` : `Qual expressão é equivalente a ${alvo}?`, meta: { txt: emb.map(c => c[0]), vals: emb.map(c => [1, 2, 3, 5, 10].map(c[1])), ref: [1, 2, 3, 5, 10].map(f0) }, chave: 'ee' + alvo };
};
C.equivExpr7 = m => m.txt[m.vals.findIndex(v => v.every((y, i) => y === m.ref[i]))];

/* Circunferência: raio, diâmetro e pontos a mesma distância (EF07MA22) */
G.circunf7 = n => {
  const r = n === 3 ? rnd(4, 9) : rnd(2, 9);
  const cx = n === 3 ? 200 : 180, cy = n === 3 ? 180 : 170, R = n === 3 ? 100 : 120, esc = R / r;
  let o = `<circle cx="${cx}" cy="${cy}" r="${R}" fill="#eff6ff" stroke="#1d4ed8" stroke-width="4"/><circle cx="${cx}" cy="${cy}" r="5" fill="#111"/>` + T(cx - 16, cy + 26, 'O', { fs: 20 });
  if(n < 3){
    const dado = n === 1 ? 'r' : 'd', v = dado === 'r' ? 2 * r : r;
    if(dado === 'r') o += `<line x1="${cx}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#dc2626" stroke-width="4"/>` + T(cx + R / 2, cy - 12, `raio = ${r} cm`, { fs: 20, cor: '#dc2626' });
    else o += `<line x1="${cx - R}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#dc2626" stroke-width="4"/>` + T(cx, cy - 16, `diâmetro = ${2 * r} cm`, { fs: 20, cor: '#dc2626' });
    const erradas = dado === 'r' ? [{ v: r, erro: 'repetiu o raio' }, { v: r * 3, erro: 'multiplicou por 3 (π)' }, { v: r / 2, erro: 'dividiu em vez de dobrar' }, { v: 2 * r + 1, erro: 'errou a conta' }] : [{ v: 2 * r, erro: 'repetiu o diâmetro' }, { v: 4 * r, erro: 'dobrou em vez de dividir' }, { v: r + 1, erro: 'errou a conta' }];
    const aa = alternativas(v, erradas.filter(e => Number.isInteger(e.v) && e.v !== v && e.v > 0), x => x + ' cm', { min: 1 });
    return { ...aa, text: dado === 'r' ? 'Quanto mede o DIÂMETRO?' : 'Quanto mede o RAIO?', image: svgURI(SVG(360, 340, o)), meta: { r, dado }, chave: `ci${r}${dado}` };
  }
  const dist = shuffle([r, r - 1, r + 1, r + 2].filter(d => d > 0));
  const pts = dist.slice(0, 4).map((d, i) => { const ang = (-40 + i * 80) * Math.PI / 180; return [d, cx + d * esc * Math.cos(ang), cy + d * esc * Math.sin(ang)]; });
  pts.forEach(([d, x, y], i) => { o += `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#94a3b8" stroke-width="2" stroke-dasharray="5,4"/><circle cx="${x}" cy="${y}" r="7" fill="#dc2626"/>` + T(x + 14, y + 6, letrasABCD[i], { fs: 20, cor: '#dc2626', anc: 'start' }) + T((cx + x) / 2 - 6, (cy + y) / 2 - 6, d + ' cm', { fs: 17, cor: '#475569' }); });
  o += T(cx, 330, `raio = ${r} cm`, { fs: 18, cor: '#1d4ed8' });
  const certa = letrasABCD[pts.findIndex(p => p[0] === r)];
  const itens = pts.map((p, i) => [letrasABCD[i], p[0] === r ? null : p[0] < r ? 'escolheu um ponto de dentro' : 'escolheu um ponto de fora']);
  return { options: itens.map(i => i[0]), correct: itens.findIndex(i => i[1] === null), erros: itens.map(i => i[1]), answer: certa, text: 'Qual ponto está EXATAMENTE sobre a circunferência (à distância do raio até o centro O)?', image: svgURI(SVG(400, 380, o.replace(T(cx, 330, `raio = ${r} cm`, { fs: 18, cor: '#1d4ed8' }), T(cx, 370, `raio = ${r} cm`, { fs: 18, cor: '#1d4ed8' })))), meta: { r, dists: pts.map(p => p[0]) }, chave: `cp${r}${pts.map(p => p[0]).join('')}` };
};
C.circunf7 = m => m.dists ? 'ABCD'[m.dists.indexOf(m.r)] : (m.dado === 'r' ? 2 * m.r : m.r) + ' cm';

/* Rotação de figuras (EF07MA20 · EF07MA21) */
G.rotacao7 = n => {
  const k = n === 1 ? 4 : 5;
  const A = sortearAte(() => poliomino(k, 5, 5), c => formasIguais(c).size >= 8);
  const rot = (c, q) => { let x = c; for(let i = 0; i < q; i++) x = girar(x); return x; };     // girar = 90° no sentido horário (linha, coluna) → (coluna, −linha)
  const q = n === 1 ? 1 : pick([1, 2, 3]);
  const nomeGiro = { 1: '90° no sentido HORÁRIO', 2: '180° (meia volta)', 3: '90° no sentido ANTI-HORÁRIO' }[q];
  const certa = rot(A, q);
  const cand = [[certa, null], [rot(A, (4 - q) % 4), 'girou para o lado contrário'], [espelhar(A), 'espelhou em vez de girar'], [rot(A, q === 2 ? 1 : 2), 'girou o ângulo errado'], [espelhar(certa), 'espelhou depois de girar']];
  const vistos = new Set([chaveCel(A)]), itens = [];
  cand.forEach(([c, e]) => { const key = chaveCel(c); if(itens.length < 4 && !vistos.has(key)){ vistos.add(key); itens.push([c, e]); } });
  if(itens.length < 4 || itens[0][1] !== null) return G.rotacao7(n);
  const emb = shuffle(itens);
  return { options: letrasABCD.slice(0, 4), correct: emb.findIndex(i => i[1] === null), erros: emb.map(i => i[1]), answer: letrasABCD[emb.findIndex(i => i[1] === null)], optImgs: emb.map(i => svgURI(figMalhaSVG(i[0], '#60a5fa'))),
    text: `Qual é a figura amarela girada ${nomeGiro}?`, image: svgURI(figMalhaSVG(A, '#fbbf24')), meta: { A, q, ops: emb.map(i => i[0]) }, chave: 'ro' + chaveCel(A) + q };
};
C.rotacao7 = m => { let x = m.A; for(let i = 0; i < m.q; i++) x = x.map(([r, c]) => [c, -r]); const k = chaveCel(x); return 'ABCD'[m.ops.findIndex(c => chaveCel(c) === k)]; };

/* Rigidez do triângulo (EF07MA25) */
function armacaoSVG(tipo, x0){
  const st = 'stroke="#78350f" stroke-width="9" stroke-linecap="round"', no = (x, y) => `<circle cx="${x}" cy="${y}" r="7" fill="#111"/>`;
  if(tipo === 'triângulo') return `<line x1="${x0}" y1="150" x2="${x0 + 120}" y2="150" ${st}/><line x1="${x0}" y1="150" x2="${x0 + 60}" y2="40" ${st}/><line x1="${x0 + 120}" y1="150" x2="${x0 + 60}" y2="40" ${st}/>` + no(x0, 150) + no(x0 + 120, 150) + no(x0 + 60, 40);
  if(tipo === 'quadrado') return `<rect x="${x0}" y="40" width="110" height="110" fill="none" ${st}/>` + no(x0, 40) + no(x0 + 110, 40) + no(x0, 150) + no(x0 + 110, 150);
  if(tipo === 'pentágono') return `<polygon points="${x0 + 60},30 ${x0 + 120},75 ${x0 + 100},150 ${x0 + 20},150 ${x0},75" fill="none" ${st}/>` + no(x0 + 60, 30) + no(x0 + 120, 75) + no(x0 + 100, 150) + no(x0 + 20, 150) + no(x0, 75);
  return `<rect x="${x0}" y="60" width="140" height="90" fill="none" ${st}/>` + no(x0, 60) + no(x0 + 140, 60) + no(x0, 150) + no(x0 + 140, 150);
}
G.rigidez7 = n => {
  if(n < 3){
    const formas = shuffle(['triângulo', 'quadrado', 'pentágono', 'retângulo']);
    let o = ''; formas.forEach((f, i) => { o += armacaoSVG(f, 20 + i * 165) + T(80 + i * 165, 185, letrasABCD[i], { fs: 22 }); });
    const iC = formas.indexOf('triângulo');
    const itens = formas.map((f, i) => [letrasABCD[i], f === 'triângulo' ? null : 'achou que mais lados deixa mais firme']);
    return { options: itens.map(i => i[0]), correct: iC, erros: itens.map(i => i[1]), answer: letrasABCD[iC], text: 'As varetas estão presas com pregos nos cantos (podem girar). Qual armação NÃO deforma quando empurrada?', image: svgURI(SVG(680, 200, o)), meta: { formas }, chave: 'rg' + formas.join('') };
  }
  const aa = alternativas('uma trave na diagonal, formando triângulos', [{ v: 'mais uma trave na horizontal', erro: 'continua formando quadriláteros' }, { v: 'pregos maiores nos cantos', erro: 'os cantos continuam podendo girar' }, { v: 'varetas mais grossas', erro: 'a forma continua deformando' }], String);
  return { ...aa, text: 'O portão retangular está entortando. O que deixa ele firme?', image: svgURI(SVG(220, 200, armacaoSVG('retângulo', 40))), meta: {}, chave: 'rg-portao' };
};
C.rigidez7 = m => m.formas ? 'ABCD'[m.formas.indexOf('triângulo')] : 'uma trave na diagonal, formando triângulos';

/* Censo ou amostra (EF07MA36) */
const PESQ = [['saber a altura de cada aluno da sua turma (30 alunos)', 'censo'], ['saber em quem os eleitores do país pretendem votar', 'amostra'], ['testar se as lâmpadas de uma fábrica duram (o teste queima a lâmpada)', 'amostra'],
  ['saber a nota de cada aluno na prova da turma', 'censo'], ['saber o sabor de sorvete preferido dos moradores da cidade', 'amostra'], ['conferir a qualidade da água de um rio', 'amostra'], ['saber quantas pessoas moram em cada casa do Brasil (IBGE, a cada 10 anos)', 'censo']];
G.censo7 = n => {
  const [sit, tipo] = pick(PESQ);
  const txt = { censo: 'Censo: pesquisar TODOS', amostra: 'Amostra: pesquisar uma PARTE escolhida ao acaso' };
  const aa = alternativas(txt[tipo], [{ v: txt[tipo === 'censo' ? 'amostra' : 'censo'], erro: tipo === 'censo' ? 'não viu que dá para perguntar a todos' : 'não viu que é impossível (ou caro) pesquisar todos' }, { v: 'Amostra: perguntar só aos amigos', erro: 'amostra viciada (não é ao acaso)' }, { v: 'Não precisa pesquisar, é só chutar', erro: 'não pesquisou' }], String);
  return { ...aa, text: `Para ${sit}, o melhor é fazer:`, meta: { sit }, chave: 'cs' + sit };
};
C.censo7 = m => { const t = PESQ.find(x => x[0] === m.sit)[1]; return t === 'censo' ? 'Censo: pesquisar TODOS' : 'Amostra: pesquisar uma PARTE escolhida ao acaso'; };
