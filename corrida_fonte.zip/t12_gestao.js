
/* =========================================================================
   GESTÃO DOS ALUNOS NO TREINO (acrescentado)
   · Professor clica no NOME do aluno no painel do treino → o celular do aluno
     trava numa tela "Troque seu nome" até ele escolher um nome válido (da
     lista da turma, se houver, ou digitado). O professor não digita nada.
   · Se o nome novo já tem progresso salvo na turma, o professor confirma e o
     progresso é juntado (em cada degrau fica o mais avançado).
   · ✕ Remover (nos Detalhes) usa o kickPlayer original do jogo.
   Funções originais intactas: só embrulhos (hostPlayerJoin, onMessage).
========================================================================= */
/* junta dois registros do mesmo aluno (apelido + nome verdadeiro): em cada degrau fica o mais avançado */
function juntarRegistros(a, b){
  if(!a) return b; if(!b) return a;
  const base = JSON.parse(JSON.stringify((a.resp || 0) >= (b.resp || 0) ? a : b));
  const ids = new Set([...Object.keys(a.deg || {}), ...Object.keys(b.deg || {})]);
  base.deg = {};
  ids.forEach(id => {
    const x = a.deg && a.deg[id], y = b.deg && b.deg[id];
    base.deg[id] = JSON.parse(JSON.stringify(!x ? y : !y ? x : (x.dom && !y.dom) ? x : (y.dom && !x.dom) ? y : ((x.totA || 0) >= (y.totA || 0) ? x : y)));
  });
  base.resp = (a.resp || 0) + (b.resp || 0);
  base.rev = Math.max(a.rev || 0, b.rev || 0) + 10;
  if(a.diag === 'feito' || b.diag === 'feito') base.diag = 'feito';
  base.trav = null; base.pausa = null;
  if(base.atual && base.deg[base.atual] && base.deg[base.atual].dom){ const p = proximoAtivo(base, POR_ID[base.atual] ? POR_ID[base.atual].i : 0); base.atual = p ? p.id : null; }
  return base;
}
/* professor: pede ao aluno que troque o nome */
function pedirTrocaNome(pid){
  const p = app.host.players.find(x => x.id === pid); if(!p) return;
  if(p._trocando){ if(confirm(`Cancelar o pedido de troca de nome de "${p.name}"?`)){ p._trocando = false; app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'trocaNomeFim' }); } return; }
  if(!confirm(`Pedir para "${p.name}" trocar o nome?\nO celular dele fica parado até ele escolher um nome válido.`)) return;
  p._trocando = true;
  enviarPedidoNome(p);
  app.toast(`✏️ Pedido enviado para <b>${esc(p.name)}</b>`, 'info');
}
function enviarPedidoNome(p, motivo){
  const usados = app.host.players.filter(x => x.id !== p.id).map(x => normNome(x.name));
  const lista = (estado.cfg.lista && estado.cfg.nomes) || [];
  app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'trocaNome', nomes: lista, usados, motivo: motivo || '', bloqueio: lista.length > 0 });
}
/* professor: o aluno mandou o nome novo */
function hostNovoNome(msg){
  const p = app.host.players.find(x => x.id === msg.id); if(!p || !p._trocando) return;
  const novo = String(msg.nome || '').trim();
  const erro = m => enviarPedidoNome(p, m);
  const ck = checkName(novo); if(!ck.ok) return erro(ck.reason);
  const kOld = normNome(p.name), kNew = normNome(novo);
  if(kOld === kNew) return erro('Escolha um nome diferente do atual.');
  if(estado.cfg.lista && (estado.cfg.nomes || []).length && !(estado.cfg.nomes || []).some(n => normNome(n) === kNew)) return erro('Escolha o seu nome na lista.');
  if(app.host.players.some(x => x.id !== p.id && normNome(x.name) === kNew)) return erro('Esse nome já está sendo usado na sala.');
  const rOld = estado.turma.alunos[kOld], rNew = estado.turma.alunos[kNew];
  if(rNew && rOld && !confirm(`"${p.name}" quer usar o nome "${novo}", que já tem progresso salvo na turma.\nÉ o mesmo aluno? (OK = juntar o progresso; Cancelar = pedir outro nome)`)) return erro('Esse nome já pertence a outro aluno da turma. Use o seu nome.');
  const junto = juntarRegistros(rNew, rOld);
  if(junto){ junto.nome = novo; junto.chave = kNew; estado.turma.alunos[kNew] = junto; }
  if(kOld !== kNew) delete estado.turma.alunos[kOld];
  if(estado.snap[kOld] !== undefined){ estado.snap[kNew] = estado.snap[kOld]; delete estado.snap[kOld]; }
  salvarTurmaLocal();
  const antigo = p.name;
  p.name = novo; p._nomeFixo = novo; p._trocando = false;
  app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'renomear', nome: novo });
  if(estado.cfg.on) setTimeout(() => enviarTrilha(p), 400);     // o celular recebe o progresso já juntado
  app.broadcastState(); publicarNomes();
  app.toast(`✏️ <b>${esc(antigo)}</b> agora é <b>${esc(novo)}</b>`, 'success');
}
/* aluno: tela obrigatória de troca de nome */
function alunoTrocaNome(msg){
  let box = $('trocaNomeBox');
  if(box && !msg.motivo) return;                                    // já está na tela (o pedido se repete): não apaga o que ele digitou
  const digitado = box && $('tnNome') ? $('tnNome').value : '';
  if(!box){
    box = document.createElement('div'); box.id = 'trocaNomeBox'; box.className = 'tn-fundo';
    document.body.appendChild(box);
  }
  const usados = new Set(msg.usados || []);
  const nomes = (msg.nomes || []).filter(n => !usados.has(normNome(n)) && normNome(n) !== normNome(app.playerName || ''));
  box.innerHTML = `<div class="tn-card">
      <div class="tn-tt">✏️ O professor pediu para você trocar seu nome</div>
      <div class="tn-sub">Use o seu nome de verdade para o seu progresso ficar guardado.</div>
      ${msg.motivo ? `<div class="tn-erro">⚠️ ${esc(msg.motivo)}</div>` : ''}
      ${nomes.length ? `<div class="tn-lista">${nomes.map(n => `<button data-n="${esc(n)}">${esc(n)}</button>`).join('')}</div>${msg.bloqueio ? '' : '<div class="tn-ou">ou digite:</div>'}` : ''}
      <div class="tn-linha" ${msg.bloqueio && nomes.length ? 'style="display:none"' : ''}><input id="tnNome" maxlength="18" placeholder="Seu nome" autocomplete="off"><button class="primary" id="tnOk">Confirmar</button></div>
      <div class="tn-espera hidden" id="tnEspera">Enviando…</div></div>`;
  const enviar = nome => {
    nome = String(nome || '').trim();
    const ck = checkName(nome); if(!ck.ok){ const e = box.querySelector('.tn-erro') || document.createElement('div'); e.className = 'tn-erro'; e.textContent = '⚠️ ' + ck.reason; box.querySelector('.tn-sub').after(e); return; }
    app.pub(`${BASE}/${app.room}/tohost`, { type: 'novoNome', id: app.playerId, nome });
    $('tnEspera').classList.remove('hidden');
  };
  if(digitado) $('tnNome').value = digitado;
  box.onclick = e => { const b = e.target.closest('button[data-n]'); if(b) enviar(b.dataset.n); if(e.target.id === 'tnOk') enviar($('tnNome').value); };
  $('tnNome').onkeydown = e => { if(e.key === 'Enter') enviar(e.target.value); };
}
function alunoRenomeado(nome){
  app.playerName = nome;
  try{ const k = 'cgm_partida_aluno', s = JSON.parse(sessionStorage.getItem(k) || 'null'); if(s){ s.name = nome; sessionStorage.setItem(k, JSON.stringify(s)); } }catch(e){}
  const box = $('trocaNomeBox'); if(box) box.remove();
  aviso(`✅ Pronto! Agora você é<br><b>${esc(nome)}</b>`, 2600);
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .tn-fundo{position:fixed;inset:0;z-index:650;background:rgba(2,6,23,.92);display:flex;align-items:center;justify-content:center;padding:16px}
  .tn-card{background:var(--panel);border:3px solid #f59e0b;border-radius:20px;padding:20px;max-width:560px;width:100%;max-height:94vh;overflow:auto;text-align:center}
  .tn-tt{font-size:clamp(20px,5vw,28px);font-weight:900;color:#fbbf24}
  .tn-sub{color:var(--muted);font-weight:700;margin:6px 0 10px}
  .tn-erro{background:rgba(239,68,68,.15);border:2px solid #ef4444;color:#fecaca;border-radius:12px;padding:8px 10px;font-weight:800;margin-bottom:10px}
  .tn-lista{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px}
  .tn-lista button{padding:14px 8px;border-radius:12px;background:var(--panel2);border:2px solid var(--line);color:var(--text);font-size:18px;font-weight:900;cursor:pointer}
  .tn-ou{color:var(--muted);font-weight:800;margin:12px 0 6px}
  .tn-linha{display:flex;gap:8px}
  .tn-linha input{flex:1;font-size:20px;font-weight:800}
  .tn-linha button{width:auto;padding:10px 16px}
  .tn-espera{margin-top:10px;color:#93c5fd;font-weight:800}`;
  document.head.appendChild(st);

  const hostPlayerJoin0 = app.hostPlayerJoin;
  app.hostPlayerJoin = function(msg){
    const p = msg && this.host.players.find(x => x.id === msg.id);
    if(p && p._trocando) enviarPedidoNome(p);                        // o pedido chega mesmo se o aluno recarregar a página
    if(p && p._nomeFixo && msg.name !== p._nomeFixo){                // o "join" repetido não desfaz a troca
      this.pub(`${BASE}/${this.room}/to/${p.id}`, { type: 'renomear', nome: p._nomeFixo });
      msg = Object.assign({}, msg, { name: p._nomeFixo });
    }
    return hostPlayerJoin0.call(this, msg);
  };
  const onMessage0 = app.onMessage;
  app.onMessage = function(topic, msg){
    if(this.mode === 'teacher' && msg && msg.type === 'novoNome' && topic.endsWith('/tohost')){ hostNovoNome(msg); return; }
    if(this.mode !== 'teacher' && msg && topic.endsWith(`/to/${this.playerId}`)){
      if(msg.type === 'trocaNome'){ alunoTrocaNome(msg); return; }
      if(msg.type === 'renomear'){ alunoRenomeado(msg.nome); return; }
      if(msg.type === 'trocaNomeFim'){ const b = $('trocaNomeBox'); if(b) b.remove(); return; }
    }
    return onMessage0.call(this, topic, msg);
  };
})();
