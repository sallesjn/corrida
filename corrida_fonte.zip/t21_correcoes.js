
/* =========================================================================
   CORREÇÕES DE QUESTÕES (acrescentado)
   · Valor posicional (gerador antigo): o número não pode repetir o
     algarismo perguntado ("valor do 5 em 6557" era ambíguo: 50 ou 500).
     Sorteia de novo até o algarismo aparecer uma vez só.
   Função original intacta: só embrulho em generateQuestion.
========================================================================= */
(() => {
  const gq0 = generateQuestion;
  const ambiguo = q => { const m = q && /Valor do algarismo (\d) em (\d+)/.exec(q.text || ''); return !!m && m[2].split(m[1]).length - 1 > 1; };
  generateQuestion = function(){
    let q = gq0.apply(this, arguments);
    for(let k = 0; k < 40 && ambiguo(q); k++) q = gq0.apply(this, arguments);
    return q;
  };
})();
