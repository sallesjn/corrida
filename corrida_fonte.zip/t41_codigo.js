/* =========================================================================
   CÓDIGO DA ATIVIDADE NA TELA DO ALUNO
   · Canto superior direito do cartão da pergunta, pequeno e discreto:
     "p6_potencia-N3" (mesmo código do histórico 📜 e do histórico do professor).
   · Serve para o professor saber de qual atividade o aluno está reclamando.
   Bloco novo: wrapper de app.renderPlayerQuestion e CSS.
========================================================================= */
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  #ppQuestionCard{position:relative}
  #ppCodAtiv{position:absolute;top:6px;right:12px;font-size:11px;font-weight:700;color:#64748b;letter-spacing:.3px;pointer-events:none;user-select:text;z-index:2}`;
  document.head.appendChild(st);
  const render0 = app.renderPlayerQuestion;
  app.renderPlayerQuestion = function(q){
    const r = render0.apply(this, arguments);
    try{
      const card = $('ppQuestionCard'); if(!card) return r;
      let el = $('ppCodAtiv');
      if(!el){ el = document.createElement('div'); el.id = 'ppCodAtiv'; card.appendChild(el); }
      const id = q && q.trilha ? q.trilha.id : (q && q.type) || '';
      const n = q && q.trilha ? q.trilha.nivel : 0;
      el.textContent = id ? id + (n ? '-N' + n : '') : '';
    }catch(e){}
    return r;
  };
})();
