
/* =========================================================================
   VISUAL NOVO DAS FIGURAS + DIVISÃO DO 4º EM 3 DIFICULDADES (acrescentado)
   · Frutas e objetos (maçã, banana, uva, laranja, morango, estrela, bola,
     flor, peixe, balão) agora usam os ícones Fluent Emoji da Microsoft
     (licença MIT), no lugar dos desenhos simples.
   · "Divisão" do 4º ano com gerador próprio:
       fácil  → tabuada ao contrário (56 ÷ 7), de cabeça
       médio  → 3 algarismos ÷ 1 algarismo (144 ÷ 6), no papel
       difícil→ divisor de 2 algarismos (156 ÷ 12), no papel
   · Questões de papel mostram "✏️ Pode armar a conta no papel" e ganham
     mais tempo na Corrida.
   Funções originais intactas: só trocas de ícones no objeto ICONES e
   embrulhos (extrasPergunta, getNextQuestion).
========================================================================= */
Object.keys(EMOJI_SVG).forEach(k => {
  ICONES[k] = (x, y, s) => { const t = s * 0.98; return `<svg x="${(x - t / 2).toFixed(1)}" y="${(y - t / 2).toFixed(1)}" width="${t.toFixed(1)}" height="${t.toFixed(1)}" viewBox="0 0 32 32" overflow="visible">${EMOJI_SVG[k]}</svg>`; };
});

/* Divisão (EF04MA07) — gerador próprio */
G.p4_div = n => {
  let a, b, q;
  if(n === 1){ b = rnd(2, 9); q = rnd(2, 10); }
  else if(n === 2){ do{ b = rnd(2, 9); q = rnd(12, 99); } while(b * q < 100 || b * q > 999); }
  else { do{ b = rnd(11, 25); q = rnd(4, 30); } while(b * q < 100 || b * q > 650 || b % 10 === 0); }
  a = b * q;
  const semZero = String(q).includes('0') && q >= 10 ? +String(q).replace('0', '') : null;
  const aa = alternativas(q, [{ v: q + 1, erro: 'errou a tabuada' }, { v: q - 1, erro: 'errou a tabuada' }, { v: semZero, erro: 'esqueceu o zero no quociente' }, { v: n > 1 ? q + 10 : null, erro: 'errou a dezena do quociente' }, { v: n > 1 ? q - 10 : null, erro: 'errou a dezena do quociente' }, { v: a - b, erro: 'subtraiu em vez de dividir' }, { v: b, erro: 'repetiu o divisor' }].filter(e => e.v !== null && e.v > 0 && e.v !== q), String);
  return { ...aa, text: `${a} ÷ ${b} = ?`, meta: { a, b }, chave: `dv4${a},${b}`, papel: n > 1 };
};
C.p4_div = m => { let r = 0, x = m.a; while(x >= m.b){ x -= m.b; r++; } return x === 0 ? String(r) : null; };   // outro caminho: subtrações sucessivas
(() => {
  const d = POR_ID.p4_div; if(!d) return;
  d.prov = false; delete d.tipo; d.t = 1.4;
  TYPE_LABELS.p4_div = `${d.ano}º · ${d.nome}`; TYPE_TIME_FACTOR.p4_div = d.t;
})();
const PAPEL_EXTRA = { decOps6: [3], probTexto4: [3], probTexto5: [3] };      // outras atividades em que vale armar a conta
const ehPapel = q => !!(q && (q.papel || (q.trilha && (PAPEL_EXTRA[q.trilha.id] || []).includes(q.trilha.nivel))));

if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `.papel-tag{display:inline-block;margin-left:8px;background:#e0f2fe;color:#075985;border:2px solid #38bdf8;border-radius:999px;padding:2px 10px;font-size:14px;font-weight:900;vertical-align:middle}`;
  document.head.appendChild(st);
  const extras0 = extrasPergunta;
  extrasPergunta = function(q){
    const r = extras0.apply(this, arguments);
    const info = $('ppTrilhaInfo');
    if(info && ehPapel(q) && !info.querySelector('.papel-tag')){ const t = document.createElement('span'); t.className = 'papel-tag'; t.textContent = '✏️ Pode armar a conta no papel'; info.appendChild(t); }
    return r;
  };
  // conta de papel: 60% a mais de tempo na Corrida
  const getNextQuestion0 = app.getNextQuestion;
  app.getNextQuestion = function(){
    const q = getNextQuestion0.apply(this, arguments);
    try{ if(q && q.type && POR_ID[q.type]){ const base = POR_ID[q.type].t || TYPE_TIME_FACTOR[q.type] || 1; TYPE_TIME_FACTOR[q.type] = ehPapel(q) ? base * 1.6 : base; } }catch(e){}
    return q;
  };
})();
DICA.p4_div = m => m.b < 10 && m.a < 100 ? `Pense na tabuada do ${m.b}: ${m.b} × ? = ${m.a}.` : `Arme a conta: veja quantas vezes o ${m.b} cabe em cada parte, da esquerda para a direita. Confira: resultado × ${m.b} tem que dar ${m.a}.`;
