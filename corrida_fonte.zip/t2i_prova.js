
/* =========================================================================
   LOTE 6 — itens no estilo SAEB / Paebes
   · Problemas de texto (D148: diferentes significados das operações) — 2º ao 5º
   · Vistas de pilhas de cubos (D111: poliedros e suas vistas) — 5º e 6º
========================================================================= */

/* ------------------------------------------------------------------ */
/* PROBLEMAS DE TEXTO                                                   */
/* ------------------------------------------------------------------ */
const fmtMil = v => String(v).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const PT_NOMES = ['Ana', 'Beto', 'Caio', 'Duda', 'Enzo', 'Lia', 'Theo', 'Malu', 'Davi', 'Sofia', 'João', 'Maria', 'Pedro', 'Júlia', 'Lucas', 'Bia', 'Rafa', 'Nina'];
const PT_COISAS = [['figurinha', 'figurinhas', 'f'], ['bolinha de gude', 'bolinhas de gude', 'f'], ['lápis', 'lápis', 'm'], ['livro', 'livros', 'm'], ['adesivo', 'adesivos', 'm'], ['laranja', 'laranjas', 'f'], ['carrinho', 'carrinhos', 'm'], ['pão de queijo', 'pães de queijo', 'm']];
const ptDois = () => { const [a, b] = shuffle(PT_NOMES).slice(0, 2); return [a, b]; };
const ptN = (c, v) => `${fmtMil(v)} ${v === 1 ? c[0] : c[1]}`;
const quantos = c => c[2] === 'f' ? 'Quantas' : 'Quantos';
const ptReais = v => 'R$ ' + fmtMil(v);

/* cada modelo devolve { t: texto, v: resposta, e: [{v, erro}], meta } ; a conta é refeita em C por "tipo" */
const PT_CONTA = {
  juntar: m => m.a + m.b, ganhou: m => m.a + m.b, perdeu: m => m.a - m.b, comparar: m => m.a - m.b, completar: m => m.a - m.b,
  aMais: m => m.a + m.b, eraMais: m => m.a - m.b, aMenos: m => m.a - m.b,
  grupos: m => m.a * m.b, repartir: m => m.a / m.b, caber: m => m.a / m.b, vezes: m => m.a * m.b,
  combina: m => m.a * m.b, compraTroco: m => m.p - m.q * m.u, vans: m => Math.ceil(m.a / m.b), sobra: m => m.a % m.b,
  doisPassos: m => m.a - m.b + m.c, parcelas: m => m.a / m.b, prop: m => m.u * m.q2, maisBarato: m => (m.q * m.u) - (m.q * m.u2),
};
const ptModelos = {
  juntar(r){ const [x, y] = ptDois(), c = pick(PT_COISAS), a = rnd(r[0], r[1]), b = rnd(r[0], r[1]);
    return { t: `${x} tem ${ptN(c, a)} e ${y} tem ${ptN(c, b)}. ${quantos(c)} ${c[1]} os dois têm juntos?`, meta: { tipo: 'juntar', a, b },
      e: [{ v: Math.abs(a - b), erro: 'subtraiu em vez de juntar' }, { v: Math.max(a, b), erro: 'respondeu só uma das quantidades' }, { v: a + b + 10, erro: 'errou a dezena na soma' }, { v: a + b - 10, erro: 'errou a dezena na soma' }] }; },
  ganhou(r){ const [x] = ptDois(), c = pick(PT_COISAS), a = rnd(r[0], r[1]), b = rnd(r[0], r[1]);
    return { t: `${x} tinha ${ptN(c, a)}. Ganhou mais ${b} da avó. Com ${c[2] === 'f' ? 'quantas' : 'quantos'} ${c[1]} ${x} ficou?`, meta: { tipo: 'ganhou', a, b },
      e: [{ v: a - b, erro: 'tirou em vez de acrescentar' }, { v: b, erro: 'respondeu só o que ganhou' }, { v: a + b + 1, erro: 'contou um a mais' }, { v: a + b + 10, erro: 'errou a dezena' }] }; },
  perdeu(r){ const [x] = ptDois(), c = pick(PT_COISAS); const [a, b] = sortearAte(() => [rnd(r[0], r[1]) + r[0], rnd(r[0], r[1])], ([p, q]) => p > q + 2);
    return { t: `${x} tinha ${ptN(c, a)} e deu ${b} para o primo. Com ${c[2] === 'f' ? 'quantas' : 'quantos'} ${c[1]} ${x} ficou?`, meta: { tipo: 'perdeu', a, b },
      e: [{ v: a + b, erro: 'somou em vez de tirar' }, { v: b, erro: 'respondeu o que deu' }, { v: a - b + 10, erro: 'errou o "empresta" da dezena' }, { v: a - b - 1, erro: 'contou um a menos' }] }; },
  comparar(r){ const [x, y] = ptDois(), c = pick(PT_COISAS); const [a, b] = sortearAte(() => [rnd(r[0], r[1]) + r[0], rnd(r[0], r[1])], ([p, q]) => p > q + 2);
    return { t: `${x} tem ${ptN(c, a)}. ${y} tem ${ptN(c, b)}. ${quantos(c)} ${c[1]} ${x} tem a mais que ${y}?`, meta: { tipo: 'comparar', a, b },
      e: [{ v: a + b, erro: 'somou em vez de comparar' }, { v: a, erro: 'respondeu a quantidade maior' }, { v: b, erro: 'respondeu a quantidade menor' }, { v: a - b + 1, erro: 'contou um a mais' }] }; },
  completar(r){ const [x] = ptDois(), c = pick(PT_COISAS); const [a, b] = sortearAte(() => [rnd(r[0], r[1]) + r[0], rnd(r[0], r[1])], ([p, q]) => p > q + 2);
    return { t: `${x} quer juntar ${ptN(c, a)}. Já tem ${b}. ${quantos(c)} ${c[1]} ainda faltam?`, meta: { tipo: 'completar', a, b },
      e: [{ v: a + b, erro: 'somou em vez de completar' }, { v: b, erro: 'respondeu o que já tem' }, { v: a, erro: 'respondeu o total' }, { v: a - b - 1, erro: 'contou um a menos' }] }; },
  aMais(r){ const [x, y] = ptDois(), c = pick(PT_COISAS), a = rnd(r[0], r[1]), b = rnd(Math.max(2, Math.floor(r[0] / 2)), r[1]);
    return { t: `${y} tem ${ptN(c, a)}. ${x} tem ${b} a mais que ${y}. ${quantos(c)} ${c[1]} tem ${x}?`, meta: { tipo: 'aMais', a, b },
      e: [{ v: a - b, erro: 'tirou em vez de somar' }, { v: b, erro: 'respondeu só a diferença' }, { v: a, erro: 'respondeu a quantidade do outro' }, { v: a + a + b, erro: 'somou tudo' }] }; },
  eraMais(r){ const [x, y] = ptDois(), c = pick(PT_COISAS); const [a, b] = sortearAte(() => { const p = rnd(r[0], r[1]) + r[0]; return [p, rnd(Math.max(2, Math.floor(p * 0.15)), Math.floor(p * 0.6))]; }, ([p, q]) => p > q + 2);
    return { t: `${x} tem ${ptN(c, a)}. Isso é ${b} a mais do que ${y} tem. ${quantos(c)} ${c[1]} tem ${y}?`, meta: { tipo: 'eraMais', a, b },
      e: [{ v: a + b, erro: 'somou porque leu "a mais"' }, { v: b, erro: 'respondeu só a diferença' }, { v: a, erro: 'respondeu a quantidade do outro' }, { v: a - b + 1, erro: 'contou um a mais' }] }; },
  aMenos(r){ const [x, y] = ptDois(), c = pick(PT_COISAS); const [a, b] = sortearAte(() => [rnd(r[0], r[1]) + r[0], rnd(2, r[1])], ([p, q]) => p > q + 2);
    return { t: `${y} tem ${ptN(c, a)}. ${x} tem ${b} a menos que ${y}. ${quantos(c)} ${c[1]} tem ${x}?`, meta: { tipo: 'aMenos', a, b },
      e: [{ v: a + b, erro: 'somou em vez de tirar' }, { v: b, erro: 'respondeu só a diferença' }, { v: a, erro: 'respondeu a quantidade do outro' }, { v: a - b - 1, erro: 'contou um a menos' }] }; },
  grupos(r){ const q = rnd(r[0], r[1]), u = rnd(r[2], r[3]);
    const [cont, g, obj, go] = pick([['caixas', 'f', 'lápis', 'm'], ['pacotes', 'm', 'figurinhas', 'f'], ['saquinhos', 'm', 'balas', 'f'], ['bandejas', 'f', 'ovos', 'm'], ['mesas', 'f', 'cadeiras', 'f']]);
    return { t: `Na escola há ${q} ${cont} com ${u} ${obj} em cada ${g === 'f' ? 'uma' : 'um'}. ${go === 'f' ? 'Quantas' : 'Quantos'} ${obj} há ao todo?`, meta: { tipo: 'grupos', a: q, b: u },
      e: [{ v: q + u, erro: 'somou em vez de multiplicar' }, { v: q * u + u, erro: 'contou um grupo a mais' }, { v: q * u - u, erro: 'contou um grupo a menos' }, { v: q * (u + 1), erro: 'errou a tabuada' }] }; },
  repartir(r){ const k = rnd(r[0], r[1]), u = rnd(r[2], r[3]), a = k * u, [x] = ptDois(), c = pick(PT_COISAS.filter(c => c[1] !== 'lápis'));
    return { t: `${x} vai repartir ${ptN(c, a)} igualmente entre ${k} amigos. ${quantos(c)} ${c[1]} cada amigo vai receber?`, meta: { tipo: 'repartir', a, b: k },
      e: [{ v: a - k, erro: 'subtraiu em vez de dividir' }, { v: a + k, erro: 'somou em vez de dividir' }, { v: u + 1, erro: 'errou a divisão' }, { v: u - 1, erro: 'errou a divisão' }, { v: k, erro: 'respondeu o número de amigos' }] }; },
  caber(r){ const u = rnd(r[0], r[1]), k = rnd(r[2], r[3]), a = k * u;
    const [obj, cont, g] = pick([['ovos', 'caixas', 'f'], ['alunos', 'grupos', 'm'], ['livros', 'prateleiras', 'f']]);
    return { t: `Há ${a} ${obj}. Cabem ${u} ${obj} em cada ${g === 'f' ? 'uma das' : 'um dos'} ${cont}. ${g === 'f' ? 'Quantas' : 'Quantos'} ${cont} ficam ${g === 'f' ? 'cheias' : 'completos'}?`, meta: { tipo: 'caber', a, b: u },
      e: [{ v: a - u, erro: 'subtraiu em vez de dividir' }, { v: a * u > 999 ? a + u : a * u, erro: a * u > 999 ? 'somou em vez de dividir' : 'multiplicou em vez de dividir' }, { v: k + 1, erro: 'errou a divisão' }, { v: k - 1, erro: 'errou a divisão' }, { v: u, erro: 'respondeu quanto cabe em cada' }] }; },
  vezes(r){ const [x, y] = ptDois(), c = pick(PT_COISAS), a = rnd(r[0], r[1]), b = pick([2, 3, 4, 5]), nome = { 2: 'o dobro', 3: 'o triplo', 4: 'o quádruplo', 5: 'cinco vezes' }[b];
    return { t: `${y} tem ${ptN(c, a)}. ${x} tem ${nome}${b === 5 ? ' essa quantidade' : ''}. ${quantos(c)} ${c[1]} tem ${x}?`, meta: { tipo: 'vezes', a, b },
      e: [{ v: a + b, erro: 'somou em vez de multiplicar' }, { v: a * (b + 1), erro: 'multiplicou por um a mais' }, { v: a * b - a, erro: 'contou uma vez a menos' }, { v: a, erro: 'respondeu a quantidade do outro' }] }; },
  combina(r){ const a = rnd(r[0], r[1]), b = rnd(r[2], r[3]), par = pick([['sabores de sorvete', 'coberturas', 'sorvetes diferentes (1 sabor e 1 cobertura)'], ['camisetas', 'bermudas', 'jeitos diferentes de se vestir (1 camiseta e 1 bermuda)'], ['tipos de pão', 'recheios', 'lanches diferentes (1 pão e 1 recheio)']]);
    return { t: `Uma lanchonete tem ${a} ${par[0]} e ${b} ${par[1]}. Quantos ${par[2]} dá para montar?`.replace('Uma lanchonete tem', par[0] === 'camisetas' ? 'Lia tem' : 'Uma lanchonete tem'), meta: { tipo: 'combina', a, b },
      e: [{ v: a + b, erro: 'somou em vez de multiplicar' }, { v: a * b + a, erro: 'contou uma fileira a mais' }, { v: Math.max(a, b), erro: 'contou só um dos grupos' }, { v: a * b - 1, erro: 'contou um a menos' }] }; },
  compraTroco(r){ const q = rnd(2, r[0]), u = rnd(r[1], r[2]), notas = [20, 50, 100, 200].filter(p => p > q * u), p = notas.length ? notas[0] : 200, [x] = ptDois(), obj = pick(['cadernos', 'canetas coloridas', 'livros', 'bonés']);
    return { t: `${x} comprou ${q} ${obj} de ${ptReais(u)} cada um e pagou com uma nota de ${ptReais(p)}. Quanto recebeu de troco?`, meta: { tipo: 'compraTroco', q, u, p }, fmt: ptReais,
      e: [{ v: p - u, erro: 'esqueceu de multiplicar pela quantidade' }, { v: q * u, erro: 'respondeu o preço da compra' }, { v: p - q * u + u, erro: 'contou um item a menos' }, { v: p - q - u, erro: 'subtraiu os números sem multiplicar' }] }; },
  vans(r){ const b = rnd(r[0], r[1]); const a = sortearAte(() => rnd(r[2], r[3]), v => v % b !== 0 && v > b); const k = Math.ceil(a / b);
    return { t: `${a} alunos vão ao passeio. Cada van leva ${b} alunos. Qual é o menor número de vans para levar todos?`, meta: { tipo: 'vans', a, b },
      e: [{ v: k - 1, erro: 'esqueceu os alunos que sobraram' }, { v: a % b, erro: 'respondeu o resto da divisão' }, { v: k + 1, erro: 'arredondou demais' }, { v: a - b, erro: 'subtraiu em vez de dividir' }] }; },
  sobra(r){ const b = rnd(r[0], r[1]); const a = sortearAte(() => rnd(r[2], r[3]), v => v % b !== 0 && v > b); const [x] = ptDois();
    return { t: `${x} tem ${a} figurinhas e vai colar ${b} em cada página do álbum, completando as páginas. Quantas figurinhas vão sobrar?`, meta: { tipo: 'sobra', a, b },
      e: [{ v: Math.floor(a / b), erro: 'respondeu o número de páginas' }, { v: b - a % b, erro: 'contou o que falta para outra página' }, { v: a % b + 1, erro: 'contou um a mais' }, { v: a - b, erro: 'subtraiu uma vez só' }] }; },
  doisPassos(r){ const [x] = ptDois(), a = rnd(r[0], r[1]), b = rnd(Math.floor(r[0] / 3), Math.floor(r[0] * 0.8)), c = rnd(Math.floor(r[0] / 3), r[0]);
    return { t: `Um ônibus saiu com ${a} passageiros. No 1º ponto desceram ${b} e no 2º ponto subiram ${c}. Quantos passageiros há agora?`, meta: { tipo: 'doisPassos', a, b, c },
      e: [{ v: a + b + c, erro: 'somou tudo' }, { v: a - b - c, erro: 'tirou tudo' }, { v: a - b, erro: 'fez só a primeira parte' }, { v: a + c, erro: 'esqueceu quem desceu' }] }; },
  parcelas(r){ const b = pick([2, 3, 4, 5, 6, 8, 10, 12]), u = rnd(r[0], r[1]) * 5, a = b * u, obj = pick(['uma bicicleta', 'uma televisão', 'um celular', 'uma geladeira']);
    return { t: `${obj[0].toUpperCase() + obj.slice(1)} custa ${ptReais(a)}. O pagamento será feito em ${b} parcelas iguais, sem juros. Qual é o valor de cada parcela?`, meta: { tipo: 'parcelas', a, b }, fmt: ptReais,
      e: [{ v: a - b, erro: 'subtraiu em vez de dividir' }, { v: u + 10, erro: 'errou a divisão' }, { v: u - 5, erro: 'errou a divisão' }, { v: u * 2, erro: 'dividiu pela metade das parcelas' }] }; },
  prop(r){ const q = rnd(2, 5), u = rnd(r[0], r[1]), q2 = sortearAte(() => rnd(3, 12), v => v !== q), obj = pick(['pacotes de biscoito', 'cadernos', 'sucos', 'sorvetes']);
    return { t: `${q} ${obj} custam ${ptReais(q * u)}. Quanto custam ${q2} ${obj} iguais a esses?`, meta: { tipo: 'prop', u, q2, q }, fmt: ptReais,
      e: [{ v: q * u + (q2 - q), erro: 'somou a diferença de quantidade ao preço' }, { v: u * q2 + u, erro: 'contou um a mais' }, { v: q * u * q2, erro: 'multiplicou o preço total' }, { v: u, erro: 'respondeu o preço de um' }] }; },
  maisBarato(r){ const q = rnd(2, 6), u = rnd(r[0], r[1]), u2 = u - rnd(1, 4), [x] = ptDois();
    return { t: `Na loja A, cada caderno custa ${ptReais(u)}. Na loja B, custa ${ptReais(u2)}. ${x} vai comprar ${q} cadernos. Quanto economiza comprando na loja B?`, meta: { tipo: 'maisBarato', q, u, u2 }, fmt: ptReais,
      e: [{ v: u - u2, erro: 'calculou a diferença de um só caderno' }, { v: q * u2, erro: 'respondeu o preço na loja B' }, { v: q * u, erro: 'respondeu o preço na loja A' }, { v: q * (u - u2) + q, erro: 'errou a conta' }] }; },
};
/* o que cada ano e nível sorteia (faixas de números) */
const PT_PLANO = {
  2: { 1: [['juntar', [5, 30]], ['ganhou', [5, 30]], ['perdeu', [5, 30]]], 2: [['comparar', [10, 45]], ['completar', [10, 45]], ['juntar', [15, 49]]], 3: [['aMais', [10, 40]], ['aMenos', [10, 40]], ['eraMais', [10, 40]]] },
  3: { 1: [['ganhou', [100, 450]], ['perdeu', [100, 450]], ['comparar', [100, 450]]], 2: [['grupos', [2, 9, 2, 9]], ['repartir', [2, 9, 2, 9]], ['vezes', [3, 20]]], 3: [['caber', [3, 9, 3, 10]], ['eraMais', [60, 400]], ['completar', [150, 480]]] },
  4: { 1: [['combina', [2, 6, 2, 6]], ['grupos', [6, 15, 6, 12]], ['caber', [4, 9, 6, 15]]], 2: [['compraTroco', [5, 4, 15]], ['doisPassos', [20, 45]], ['repartir', [3, 9, 11, 30]]], 3: [['vans', [6, 15, 30, 120]], ['sobra', [6, 12, 30, 110]], ['eraMais', [300, 2000]]] },
  5: { 1: [['compraTroco', [6, 8, 30]], ['doisPassos', [40, 90]], ['combina', [3, 8, 4, 9]]], 2: [['prop', [3, 25]], ['parcelas', [10, 90]], ['maisBarato', [8, 30]]], 3: [['vans', [15, 45, 100, 400]], ['prop', [12, 60]], ['maisBarato', [15, 60]]] },
};
function probTexto(ano, n){
  const [tipo, faixa] = pick(PT_PLANO[ano][n]);
  const p = ptModelos[tipo](faixa);
  const v = PT_CONTA[p.meta.tipo](p.meta);
  const fmt = p.fmt || fmtMil;
  const o = alternativas(v, p.e.filter(e => Number.isInteger(e.v) && e.v > 0 && e.v !== v), fmt, { min: 1, max: 99999 });
  return { ...o, text: p.t, fala: p.t, meta: { ...p.meta, ano, dinheiro: !!p.fmt }, chave: tipo + JSON.stringify(p.meta) };
}
const C_PT = m => {                    // refaz a conta por outro caminho (sem usar PT_CONTA)
  let v;
  switch(m.tipo){
    case 'juntar': case 'ganhou': case 'aMais': v = m.b + m.a; break;
    case 'perdeu': case 'comparar': case 'completar': case 'eraMais': case 'aMenos': v = -(m.b - m.a); break;
    case 'grupos': case 'vezes': case 'combina': v = 0; for(let k = 0; k < m.b; k++) v += m.a; break;
    case 'repartir': case 'caber': case 'parcelas': v = 0; while((v + 1) * m.b <= m.a) v++; break;
    case 'compraTroco': v = m.p; for(let k = 0; k < m.q; k++) v -= m.u; break;
    case 'vans': v = 0; while(v * m.b < m.a) v++; break;
    case 'sobra': v = m.a; while(v >= m.b) v -= m.b; break;
    case 'doisPassos': v = m.a + m.c - m.b; break;
    case 'prop': v = (m.q * m.u) / m.q * m.q2; break;
    case 'maisBarato': v = m.q * m.u - m.q * m.u2; break;
  }
  return m.dinheiro ? 'R$ ' + v.toLocaleString('pt-BR') : v.toLocaleString('pt-BR');
};
[2, 3, 4, 5].forEach(a => { G['probTexto' + a] = n => probTexto(a, n); C['probTexto' + a] = C_PT; });

/* ------------------------------------------------------------------ */
/* VISTAS DE PILHAS DE CUBOS                                            */
/* ------------------------------------------------------------------ */
/* h[y][x] = altura da pilha; y = 0 é a fileira da FRENTE; x = 0 é a esquerda.
   Fileiras de trás nunca são mais baixas que as da frente (todo cubo fica visível no desenho). */
function pilhasSVG(h){
  const D = h.length, W = h[0].length, s = 52, dx = 24, dy = 18;
  const maxH = Math.max(...h.flat());
  const X0 = 40, Yb = 40 + maxH * s + D * dy;               // base da fileira da frente
  let o = '';
  // chão (malha)
  for(let y = 0; y <= D; y++) o += `<line x1="${X0 + y * dx}" y1="${Yb - y * dy}" x2="${X0 + W * s + y * dx}" y2="${Yb - y * dy}" stroke="#cbd5e1" stroke-width="2"/>`;
  for(let x = 0; x <= W; x++) o += `<line x1="${X0 + x * s}" y1="${Yb}" x2="${X0 + x * s + D * dx}" y2="${Yb - D * dy}" stroke="#cbd5e1" stroke-width="2"/>`;
  const cubo = (x, y, z) => {
    const px = X0 + x * s + y * dx, py = Yb - y * dy - z * s;            // canto inferior esquerdo da face da frente
    const f = `${px},${py} ${px + s},${py} ${px + s},${py - s} ${px},${py - s}`;
    const t = `${px},${py - s} ${px + s},${py - s} ${px + s + dx},${py - s - dy} ${px + dx},${py - s - dy}`;
    const r = `${px + s},${py} ${px + s + dx},${py - dy} ${px + s + dx},${py - s - dy} ${px + s},${py - s}`;
    return `<polygon points="${f}" fill="#60a5fa" stroke="#0f172a" stroke-width="2"/><polygon points="${t}" fill="#bfdbfe" stroke="#0f172a" stroke-width="2"/><polygon points="${r}" fill="#2563eb" stroke="#0f172a" stroke-width="2"/>`;
  };
  for(let y = D - 1; y >= 0; y--) for(let x = 0; x < W; x++) for(let z = 0; z < h[y][x]; z++) o += cubo(x, y, z);
  const xl = X0 + W * s + D * dx + 12, Wt = xl + 100;
  o += T(X0 + W * s / 2, Yb + 34, 'FRENTE ▲', { fs: 22, cor: '#b91c1c' });
  o += T(xl, Yb - maxH * s / 2 - 4, '◀ LADO', { fs: 20, cor: '#b91c1c', anc: 'start' });
  o += T(xl, Yb - maxH * s / 2 + 18, 'DIREITO', { fs: 20, cor: '#b91c1c', anc: 'start' });
  return SVG(Wt, Yb + 50, o);
}
/* vista = lista de colunas (alturas) ou malha de cima (0/1). Assinatura única por desenho. */
const vistaFrente = h => h[0].map((_, x) => Math.max(...h.map(r => r[x])));
const vistaLado = h => h.map(r => Math.max(...r));                         // da esquerda para a direita = da frente para trás
const vistaCima = h => h.slice().reverse().map(r => r.map(v => v > 0 ? 1 : 0));   // de cima: a fileira de trás fica em cima
const sigCol = c => 'colunas ' + c.join('-');
const sigCima = g => 'de cima ' + g.map(r => r.join('')).join('|');
function vistaSVG(sig){
  const s = 34, pad = 10;
  let o = '', W, H;
  if(sig.startsWith('colunas ')){
    const c = sig.slice(8).split('-').map(Number), R = 4;
    W = c.length * s + 2 * pad; H = R * s + 2 * pad;
    c.forEach((v, x) => { for(let z = 0; z < v; z++) o += `<rect x="${pad + x * s}" y="${pad + (R - 1 - z) * s}" width="${s}" height="${s}" fill="#60a5fa" stroke="#0f172a" stroke-width="2.5"/>`; });
    o += `<line x1="${pad - 4}" y1="${pad + R * s}" x2="${pad + c.length * s + 4}" y2="${pad + R * s}" stroke="#0f172a" stroke-width="3"/>`;
  } else {
    const g = sig.slice(8).split('|').map(r => r.split('').map(Number));
    W = g[0].length * s + 2 * pad; H = g.length * s + 2 * pad;
    g.forEach((r, y) => r.forEach((v, x) => { o += `<rect x="${pad + x * s}" y="${pad + y * s}" width="${s}" height="${s}" fill="${v ? '#bfdbfe' : '#fff'}" stroke="${v ? '#0f172a' : '#cbd5e1'}" stroke-width="${v ? 2.5 : 1.5}" ${v ? '' : 'stroke-dasharray="4,3"'}/>`; }));
  }
  return SVG(Math.max(W, 150), Math.max(H, 150), `<g transform="translate(${(Math.max(W, 150) - W) / 2},${(Math.max(H, 150) - H) / 2})">${o}</g>`);
}
function sortearPilhas(W, D, n){
  return sortearAte(() => {
    const h = [];
    for(let y = 0; y < D; y++) h.push(Array.from({ length: W }, () => 0));
    for(let x = 0; x < W; x++){                      // de trás para a frente, alturas que não crescem
      let v = rnd(1, 3);
      for(let y = D - 1; y >= 0; y--){ h[y][x] = v; v = rnd(y === 1 && n > 1 ? 0 : 1, v); }
    }
    return h;
  }, h => {
    const f = vistaFrente(h);
    if(new Set(f).size < 2) return false;                                   // frente com alturas diferentes
    if(f.join() === f.slice().reverse().join()) return false;               // sem simetria (o espelho vira distrator)
    if(D > 1 && h[0].join() === f.join()) return false;                     // tem cubo escondido que muda a vista
    if(D > 1 && vistaLado(h).join() === f.join()) return false;
    return true;
  });
}
function vistasItem(n, ano){
  const W = 3, D = n === 1 ? (ano === 5 ? 1 : 2) : n === 2 ? 2 : pick([2, 3]);
  const h = sortearPilhas(W, D, n);
  const opcoes = n === 1 ? ['frente'] : n === 2 ? ['frente', 'cima'] : ['frente', 'cima', 'lado'];
  let qual = pick(opcoes);
  if(qual === 'cima' && !h[0].some(v => v === 0)) qual = 'frente';        // vista de cima só quando há um buraco no chão
  const certa = qual === 'frente' ? sigCol(vistaFrente(h)) : qual === 'lado' ? sigCol(vistaLado(h)) : sigCima(vistaCima(h));
  const f = vistaFrente(h), l = vistaLado(h), c = vistaCima(h);
  const mexe = arr => { const a = arr.slice(), i = rnd(0, a.length - 1); a[i] = a[i] >= 3 ? a[i] - 1 : a[i] + 1; return a; };
  const cand = [];
  if(qual === 'frente'){
    cand.push({ v: sigCol(f.slice().reverse()), erro: 'olhou de trás (desenho espelhado)' });
    if(D > 1) cand.push({ v: sigCol(h[0]), erro: 'olhou só a fileira da frente e esqueceu os cubos de trás' });
    if(D > 1) cand.push({ v: sigCol(l), erro: 'desenhou a vista do lado' });
    cand.push({ v: sigCima(c), erro: 'desenhou a vista de cima' });
    if(D > 1){ const soma = h[0].map((_, x) => h.reduce((s, r) => s + r[x], 0)); if(Math.max(...soma) <= 4) cand.push({ v: sigCol(soma), erro: 'empilhou todos os cubos da coluna' }); }
    cand.push({ v: sigCol(mexe(f)), erro: 'contou errado a altura de uma pilha' });
  } else if(qual === 'lado'){
    cand.push({ v: sigCol(l.slice().reverse()), erro: 'olhou pelo lado esquerdo' });
    cand.push({ v: sigCol(f), erro: 'desenhou a vista da frente' });
    cand.push({ v: sigCima(c), erro: 'desenhou a vista de cima' });
    cand.push({ v: sigCol(mexe(l)), erro: 'contou errado a altura de uma pilha' });
  } else {
    cand.push({ v: sigCol(f), erro: 'desenhou a vista da frente' });
    cand.push({ v: sigCima(c.slice().reverse()), erro: 'trocou a frente com o fundo' });
    cand.push({ v: sigCima(c.map(r => r.slice().reverse())), erro: 'desenho espelhado' });
    cand.push({ v: sigCima(c.map(r => r.map(() => 1))), erro: 'achou que tem cubo em todo o chão' });
    const g2 = c.map(r => r.slice()); const zeros = []; g2.forEach((r, y) => r.forEach((v, x) => { if(v) zeros.push([y, x]); }));
    const [yy, xx] = pick(zeros); g2[yy][xx] = 0; if(g2.flat().some(Boolean)) cand.push({ v: sigCima(g2), erro: 'esqueceu uma pilha' });
  }
  // alternativas com comparação exata do desenho
  const itens = [{ v: certa, erro: null }], vistos = new Set([certa]);
  shuffle(cand.slice(0, cand.length - 1)).concat(cand.slice(-1)).forEach(e => { if(itens.length < 4 && !vistos.has(e.v)){ vistos.add(e.v); itens.push(e); } });
  for(let k = 0; itens.length < 4 && k < 60; k++){ const base = qual === 'cima' ? null : (qual === 'lado' ? l : f); const v = base ? sigCol(mexe(mexe(base))) : sigCima(c.map(r => r.map(() => rnd(0, 1)))); if(!vistos.has(v) && !/^de cima (0+\|?)+$/.test(v)){ vistos.add(v); itens.push({ v, erro: 'contou errado as pilhas' }); } }
  if(itens.length < 4) throw new Error('vistas: alternativas insuficientes');
  const sh = shuffle(itens);
  const nomeV = { frente: 'de FRENTE', cima: 'de CIMA', lado: 'do LADO DIREITO' }[qual];
  return { options: sh.map(i => i.v), correct: sh.findIndex(i => i.erro === null), erros: sh.map(i => i.erro), answer: certa,
    optImgs: sh.map(i => svgURI(vistaSVG(i.v))), image: svgURI(pilhasSVG(h)),
    text: `Qual desenho mostra a pilha de cubos vista ${nomeV}?`, fala: `Olhe a pilha de cubos. Qual desenho mostra como ela é vista ${nomeV.toLowerCase()}?`,
    meta: { h, qual }, chave: 'vis' + qual + JSON.stringify(h) };
}
G.vistas5 = n => vistasItem(n, 5);
G.vistas6 = n => vistasItem(n, 6);
C.vistas5 = C.vistas6 = m => {                 // refaz por outro caminho: percorre cubo a cubo
  const D = m.h.length, W = m.h[0].length;
  if(m.qual === 'cima'){ const linhas = []; for(let y = D - 1; y >= 0; y--){ let t = ''; for(let x = 0; x < W; x++) t += m.h[y][x] ? '1' : '0'; linhas.push(t); } return 'de cima ' + linhas.join('|'); }
  const col = []; const N = m.qual === 'frente' ? W : D;
  for(let i = 0; i < N; i++){ let alto = 0; for(let j = 0; j < (m.qual === 'frente' ? D : W); j++){ const v = m.qual === 'frente' ? m.h[j][i] : m.h[i][j]; for(let z = 1; z <= v; z++) if(z > alto) alto = z; } col.push(alto); }
  return 'colunas ' + col.join('-');
};
