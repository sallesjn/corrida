/* =========================================================================
   SUBIDA MAIS RÁPIDA EM DEGRAUS BEM ABAIXO DO ANO DA TURMA + REFAZER DIAGNÓSTICO
   · Degrau 2 ou mais anos abaixo do ano da turma: domina com 5 acertos seguidos
     no nível médio ou difícil (quem já sabe não fica preso revendo o básico).
     Errou: segue a regra normal (3 níveis, 7 de 10 no difícil).
   · Degraus do ano da turma e do ano anterior: regra normal, sem mudança.
   · refazerDiagnostico(chave): o aluno faz o diagnóstico de novo na próxima vez que
     jogar. O que ele conquistou jogando continua; só o que o diagnóstico antigo
     "deu de presente" é refeito.
   Bloco novo: wrapper do registrar (fica por dentro dos de desafio, medalhas e tema).
========================================================================= */
REGRA.rapidoSeguidos = 5;      // acertos seguidos (médio/difícil) para dominar
REGRA.rapidoAnos = 2;          // vale para degraus N anos ou mais abaixo do ano da turma
REGRA.rapidoTaxa = 0.8;        // e acerto geral no degrau de pelo menos 80%
const anoDaTurma = () => {
  try{ const pt = app.player && app.player.trilha; if(app.mode !== 'teacher' && pt && pt.cfg && pt.cfg.ano) return +pt.cfg.ano; }catch(e){}
  return +((estado && estado.cfg && estado.cfg.ano) || 1);
};
const registrarSemRapido = registrar;
registrar = function(rec, fonte, q, idx, ok, frac){
  const ev = registrarSemRapido.apply(this, arguments);
  try{
    if(!ev || ev.dominou || !ok || !fonte || !POR_ID[fonte.id] || (q && q._ajuda)) return ev;
    if(['diag', 'conforto', 'rev', 'previa', 'desafio'].includes(fonte.tipo)) return ev;
    const d = rec.deg[fonte.id]; if(!d || d.dom) return ev;
    if(POR_ID[fonte.id].ano > anoDaTurma() - REGRA.rapidoAnos) return ev;
    const w = (d.h || []).slice(-REGRA.rapidoSeguidos);
    if(w.length < REGRA.rapidoSeguidos || !w.every(x => x[0] >= 2 && x[1])) return ev;
    const hh = d.h || [], taxa = hh.reduce((s2, x) => s2 + x[1], 0) / hh.length;
    if(taxa < REGRA.rapidoTaxa) return ev;                     // quem oscila (acerta metade) não passa pelo atalho
    if(w.reduce((s2, x) => s2 + (x[2] || 0), 0) / w.length >= REGRA.tempoDominio) return ev;   // mesma exigência de rapidez da regra normal (no treino não conta tempo)
    // domina (o mesmo que a regra normal faz)
    d.dom = 1; d.domPor = 'trilha'; d.rapido = 1; d.domEm = new Date().toISOString(); d.revUlt = rec.resp; d.revInt = REGRA.revIntervaloIni;
    ev.dominou = fonte.id; ev.rapido = 1;
    rec.ajudas = REGRA.ajudasPorDegrau;
    if(rec.trav && rec.trav.id === fonte.id){ rec.trav = null; ev.destravou = fonte.id; }
    if(fonte.id === rec.atual){
      const prox = CAT.slice(POR_ID[fonte.id].i + 1).find(x => ativo(x) && !(rec.deg[x.id] && rec.deg[x.id].dom));
      rec.atual = prox ? prox.id : null;
      if(prox) degDo(rec, prox.id);
    }
  }catch(e){}
  return ev;
};

/* professor: refazer o diagnóstico de um aluno */
function refazerDiagnostico(chave){
  const rec = estado.turma && estado.turma.alunos && estado.turma.alunos[chave];
  if(!rec) return false;
  Object.values(rec.deg || {}).forEach(d => { if(d.dom && (d.domPor === 'diag' || d.domPor === 'ano')){ d.dom = 0; d.domPor = ''; } });
  rec.diag = null; rec.atual = null; delete rec.diagRes; delete rec.temaAt; delete rec.temaInfo;
  rec.apoio = null; rec.trav = null; rec.pausa = null; rec.ultOk = [];
  rec.rev = (rec.rev || 0) + 1000;                // a cópia do professor fica mais nova que a do Chromebook
  try{ salvarTurmaLocal(); }catch(e){}
  try{
    const p = app.mode === 'teacher' && app.room && app.host.players.find(x => !x.isBot && normNome(x.name) === chave);
    if(p){ estado.enviado[p.id] = 0; enviarTrilha(p); }
  }catch(e){}
  return true;
}
estado.refazerDiagnostico = refazerDiagnostico;
