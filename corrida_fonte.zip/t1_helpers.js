/* =========================================================================
   TRILHA BNCC 1º–7º ANO  —  bloco acrescentado (não altera as funções acima)
   ─────────────────────────────────────────────────────────────────────────
   • Cada degrau = uma habilidade, com gerador próprio e 3 níveis internos.
   • Domínio: 8 acertos nas últimas 10 no nível difícil e tempo médio < 60%
     do limite → bônus de 150 pontos e sobe para o próximo degrau.
   • Diagnóstico inicial por saltos (busca binária nos degraus do ano).
   • Sorteio: 70% degrau atual · 20% revisão espaçada · 10% prévia.
   • Cada alternativa errada leva o nome do erro típico (q.erros).
   • Alerta ao professor quando o aluno trava.
   • 1º e 2º ano: figuras e entrada por lista de nomes.
   • Progresso no arquivo JSON da turma (professor salva e carrega).
   Integração: só por "embrulho" (wrapper) de métodos do app; o código
   original fica intacto.  Teste no console: testarTrilha()
========================================================================= */
const TRILHA = (() => {

/* ---------------- utilitários ---------------- */
const normNome = s => String(s || '').toLowerCase().normalize('NFD')
  .replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
const reais = v => 'R$ ' + String(v);
const EXTENSO = ['zero','um','dois','três','quatro','cinco','seis','sete','oito','nove','dez'];

/* Alternativas com erro típico.
   certa: número ou texto; erradas: [{v, erro}]; fmt: formata o valor.
   vizinhos: completa com certa±1, ±2… (só números) se faltarem erros típicos.
   Garante 4 alternativas distintas, nenhuma igual (em valor) à certa. */
function alternativas(certa, erradas, fmt = String, cfg = {}){
  const num = typeof certa === 'number';
  const chave = v => num ? 'n' + (+v) : 't' + normNome(fmt(v));
  const itens = [{ v: certa, erro: null }];
  const usados = new Set([chave(certa)]);
  const ok = v => v !== undefined && v !== null && v !== '' &&
    (!num || (Number.isFinite(v) && Number.isInteger(v) && (cfg.negativo || v >= 0) && (cfg.max === undefined || v <= cfg.max) && (cfg.min === undefined || v >= cfg.min)));
  const add = e => {
    if(itens.length >= 4 || !e || !ok(e.v)) return;
    const k = chave(e.v); if(usados.has(k)) return;
    usados.add(k); itens.push({ v: e.v, erro: e.erro || 'outro valor' });
  };
  shuffle(erradas.filter(Boolean)).forEach(add);
  if(num){
    const passo = cfg.passo || 1;
    [1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, 7, 8, 9, 10].forEach(k =>
      add({ v: certa + k * passo, erro: Math.abs(k) === 1 ? (k > 0 ? 'um a mais' : 'um a menos') : 'errou a conta' }));
  }
  (cfg.reserva || []).forEach(v => add({ v, erro: 'outro valor' }));
  if(itens.length < 4) throw new Error('alternativas insuficientes: ' + JSON.stringify(itens));
  const sh = shuffle(itens);
  return { options: sh.map(i => fmt(i.v)), correct: sh.findIndex(i => i.erro === null),
           erros: sh.map(i => i.erro), answer: fmt(certa) };
}

/* ---------------- desenhos (SVG) ---------------- */
const esc2 = s => String(s).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));
const T = (x, y, t, o = {}) => `<text x="${x}" y="${y}" font-size="${o.fs || 24}" font-weight="${o.fw || 'bold'}" text-anchor="${o.anc || 'middle'}" fill="${o.cor || '#111'}"${o.extra || ''}>${esc2(t)}</text>`;

/* ícones desenhados, centrados em (x, y), tamanho s */
const ICONES = {
  maca(x, y, s){ const r = s * .40;
    return `<path d="M${x} ${y - r * .75} q-${r * .15} -${r * .45} ${r * .25} -${r * .6}" stroke="#78350f" stroke-width="${s * .07}" fill="none" stroke-linecap="round"/>` +
      `<ellipse cx="${x + r * .45}" cy="${y - r * .95}" rx="${r * .38}" ry="${r * .18}" fill="#16a34a" transform="rotate(-25 ${x + r * .45} ${y - r * .95})"/>` +
      `<circle cx="${x - r * .32}" cy="${y + r * .08}" r="${r * .78}" fill="#dc2626"/><circle cx="${x + r * .32}" cy="${y + r * .08}" r="${r * .78}" fill="#dc2626"/>` +
      `<ellipse cx="${x - r * .4}" cy="${y - r * .2}" rx="${r * .16}" ry="${r * .28}" fill="#fca5a5"/>`; },
  estrela(x, y, s){ const R = s * .46, r = R * .45, p = [];
    for(let i = 0; i < 10; i++){ const a = Math.PI / 5 * i - Math.PI / 2, d = i % 2 ? r : R; p.push(`${(x + d * Math.cos(a)).toFixed(1)},${(y + d * Math.sin(a)).toFixed(1)}`); }
    return `<polygon points="${p.join(' ')}" fill="#facc15" stroke="#a16207" stroke-width="${s * .05}" stroke-linejoin="round"/>`; },
  bola(x, y, s){ const r = s * .42;
    return `<circle cx="${x}" cy="${y}" r="${r}" fill="#2563eb" stroke="#1e3a8a" stroke-width="${s * .05}"/>` +
      `<path d="M${x - r} ${y} Q${x} ${y - r * .55} ${x + r} ${y}" stroke="#fff" stroke-width="${s * .07}" fill="none"/>` +
      `<path d="M${x - r * .95} ${y + r * .3} Q${x} ${y + r * .8} ${x + r * .95} ${y + r * .3}" stroke="#fff" stroke-width="${s * .07}" fill="none"/>`; },
  flor(x, y, s){ const r = s * .17; let o = '';
    for(let i = 0; i < 5; i++){ const a = 2 * Math.PI / 5 * i; o += `<circle cx="${x + r * 1.35 * Math.cos(a)}" cy="${y + r * 1.35 * Math.sin(a)}" r="${r * 1.05}" fill="#ec4899"/>`; }
    return o + `<circle cx="${x}" cy="${y}" r="${r * .95}" fill="#facc15" stroke="#a16207" stroke-width="${s * .03}"/>`; },
  peixe(x, y, s){ const r = s * .42;
    return `<polygon points="${x + r * .55},${y} ${x + r * 1.05},${y - r * .5} ${x + r * 1.05},${y + r * .5}" fill="#f97316"/>` +
      `<ellipse cx="${x - r * .1}" cy="${y}" rx="${r * .78}" ry="${r * .52}" fill="#fb923c" stroke="#c2410c" stroke-width="${s * .04}"/>` +
      `<circle cx="${x - r * .45}" cy="${y - r * .12}" r="${r * .1}" fill="#111"/>`; },
  balao(x, y, s){ const r = s * .36;
    return `<path d="M${x} ${y + r * 1.05} q${r * .25} ${r * .4} -${r * .1} ${r * .75}" stroke="#555" stroke-width="${s * .03}" fill="none"/>` +
      `<ellipse cx="${x}" cy="${y - r * .15}" rx="${r * .85}" ry="${r * 1.05}" fill="#8b5cf6" stroke="#5b21b6" stroke-width="${s * .04}"/>` +
      `<ellipse cx="${x - r * .35}" cy="${y - r * .55}" rx="${r * .15}" ry="${r * .25}" fill="#ddd6fe"/>`; },
  banana(x, y, s){ const r = s * .45;
    return `<path d="M${x - r} ${y - r * .5} Q${x - r * .6} ${y + r * .9} ${x + r} ${y + r * .1} Q${x - r * .1} ${y + r * .35} ${x - r * .7} ${y - r * .6} Z" fill="#facc15" stroke="#a16207" stroke-width="${s * .04}" stroke-linejoin="round"/>`; },
  uva(x, y, s){ const r = s * .12; let o = '';
    [[0,-2.2],[-1,-1.3],[1,-1.3],[-1.6,-.3],[0,-.3],[1.6,-.3],[-.9,.7],[.9,.7],[0,1.7]].forEach(([a, b]) => o += `<circle cx="${x + a * r * 1.2}" cy="${y + b * r * 1.2}" r="${r * 1.15}" fill="#7e22ce" stroke="#4c1d95" stroke-width="${s * .02}"/>`);
    return o + `<path d="M${x} ${y - r * 3.3} l${r * .8} -${r * .9}" stroke="#15803d" stroke-width="${s * .05}"/>`; },
  laranja(x, y, s){ const r = s * .40;
    return `<circle cx="${x}" cy="${y + r * .08}" r="${r}" fill="#f97316" stroke="#c2410c" stroke-width="${s * .04}"/>` +
      `<ellipse cx="${x + r * .35}" cy="${y - r * .95}" rx="${r * .32}" ry="${r * .15}" fill="#16a34a"/>`; },
  morango(x, y, s){ const r = s * .42;
    return `<path d="M${x - r * .85} ${y - r * .35} Q${x} ${y - r * .75} ${x + r * .85} ${y - r * .35} Q${x + r * .6} ${y + r * .6} ${x} ${y + r * 1.0} Q${x - r * .6} ${y + r * .6} ${x - r * .85} ${y - r * .35} Z" fill="#e11d48" stroke="#9f1239" stroke-width="${s * .04}"/>` +
      `<path d="M${x - r * .55} ${y - r * .5} L${x} ${y - r * .85} L${x + r * .55} ${y - r * .5} L${x} ${y - r * .3} Z" fill="#16a34a"/>` +
      `<circle cx="${x - r * .3}" cy="${y}" r="${s * .025}" fill="#fde68a"/><circle cx="${x + r * .25}" cy="${y + r * .2}" r="${s * .025}" fill="#fde68a"/><circle cx="${x}" cy="${y + r * .55}" r="${s * .025}" fill="#fde68a"/>`; },
};
const NOME_ICONE = { maca:['maçã','maçãs'], estrela:['estrela','estrelas'], bola:['bola','bolas'], flor:['flor','flores'],
  peixe:['peixe','peixes'], balao:['balão','balões'], banana:['banana','bananas'], uva:['uva','uvas'], laranja:['laranja','laranjas'], morango:['morango','morangos'] };
const OBJETOS = ['maca', 'estrela', 'bola', 'flor', 'peixe', 'balao'];
const FRUTAS = ['banana', 'uva', 'laranja', 'morango', 'maca'];
const plural = (tipo, n) => NOME_ICONE[tipo][n === 1 ? 0 : 1];
const genero = tipo => ['maca','estrela','bola','flor','banana','uva','laranja'].includes(tipo) ? 'f' : 'm';

/* grupo de n ícones em fileiras de 5 (como o quadro de dez); devolve {svg, w, h} */
function grupoIcones(tipo, n, x0, y0, s = 44, porLinha = 5, riscados = 0){
  let o = '';
  for(let i = 0; i < n; i++){
    const c = i % porLinha, l = Math.floor(i / porLinha);
    const cx = x0 + s / 2 + c * s, cy = y0 + s / 2 + l * s;
    o += ICONES[tipo](cx, cy, s * .9);
    if(i >= n - riscados) o += `<line x1="${cx - s * .38}" y1="${cy - s * .38}" x2="${cx + s * .38}" y2="${cy + s * .38}" stroke="#111" stroke-width="5" stroke-linecap="round"/><line x1="${cx + s * .38}" y1="${cy - s * .38}" x2="${cx - s * .38}" y2="${cy + s * .38}" stroke="#111" stroke-width="5" stroke-linecap="round"/>`;
  }
  const lin = Math.max(1, Math.ceil(n / porLinha));
  return { svg: o, w: Math.min(n, porLinha) * s, h: lin * s };
}

/* quadro de dez (2 × 5); cores: lista de cores das bolinhas preenchidas; riscar: quantas das últimas levam X */
function quadroDez(x0, y0, cel, cores, riscar = 0){
  let o = `<rect x="${x0}" y="${y0}" width="${cel * 5}" height="${cel * 2}" fill="#fff" stroke="#111" stroke-width="3"/>`;
  for(let i = 1; i < 5; i++) o += `<line x1="${x0 + i * cel}" y1="${y0}" x2="${x0 + i * cel}" y2="${y0 + cel * 2}" stroke="#111" stroke-width="2"/>`;
  o += `<line x1="${x0}" y1="${y0 + cel}" x2="${x0 + cel * 5}" y2="${y0 + cel}" stroke="#111" stroke-width="2"/>`;
  cores.forEach((c, i) => {
    const cx = x0 + cel / 2 + (i % 5) * cel, cy = y0 + cel / 2 + Math.floor(i / 5) * cel;
    o += `<circle cx="${cx}" cy="${cy}" r="${cel * .36}" fill="${c}" stroke="#111" stroke-width="2"/>`;
    if(i >= cores.length - riscar) o += `<line x1="${cx - cel * .32}" y1="${cy - cel * .32}" x2="${cx + cel * .32}" y2="${cy + cel * .32}" stroke="#111" stroke-width="4.5" stroke-linecap="round"/><line x1="${cx + cel * .32}" y1="${cy - cel * .32}" x2="${cx - cel * .32}" y2="${cy + cel * .32}" stroke="#111" stroke-width="4.5" stroke-linecap="round"/>`;
  });
  return o;
}

/* faixa numérica: valores (null = "?") */
function faixaNumerica(valores, destaque){
  const n = valores.length, b = Math.min(64, Math.floor(600 / n)), W = n * b + 20, H = b + 30;
  let o = '';
  valores.forEach((v, i) => {
    const x = 10 + i * b, q = v === null;
    o += `<rect x="${x + 2}" y="12" width="${b - 4}" height="${b - 4}" rx="8" fill="${q ? '#fde68a' : (i === destaque ? '#dbeafe' : '#f1f5f9')}" stroke="#111" stroke-width="3"/>`;
    o += T(x + b / 2, 12 + b / 2 + (b > 50 ? 10 : 8), q ? '?' : v, { fs: b > 50 ? 28 : 22 });
  });
  return SVG(W, H, o);
}

/* material dourado: c placas, d barras, u cubinhos */
function materialDourado(c, d, u){
  const q = 13;                              // lado do cubinho (px)
  let o = '', x = 12;
  const cub = (x, y) => `<rect x="${x}" y="${y}" width="${q}" height="${q}" fill="#fcd34d" stroke="#92400e" stroke-width="1"/>`;
  for(let i = 0; i < c; i++){ let s = ''; for(let a = 0; a < 10; a++) for(let b = 0; b < 10; b++) s += cub(x + a * q, 14 + b * q); o += s + `<rect x="${x}" y="14" width="${q * 10}" height="${q * 10}" fill="none" stroke="#92400e" stroke-width="2.5"/>`; x += q * 10 + 16; }
  if(c) x += 6;
  for(let i = 0; i < d; i++){ let s = ''; for(let b = 0; b < 10; b++) s += cub(x, 14 + b * q); o += s + `<rect x="${x}" y="14" width="${q}" height="${q * 10}" fill="none" stroke="#92400e" stroke-width="2"/>`; x += q + 9; }
  if(d) x += 10;
  const cols = Math.ceil(u / 5);
  for(let i = 0; i < u; i++){ const cc = Math.floor(i / 5), ll = i % 5; o += `<rect x="${x + cc * (q + 6)}" y="${14 + q * 10 - (ll + 1) * (q + 6) + 6}" width="${q + 1}" height="${q + 1}" fill="#fcd34d" stroke="#92400e" stroke-width="1.5"/>`; }
  x += cols * (q + 6);
  const W = Math.max(120, x + 8), H = q * 10 + 28;
  return SVG(W, H, o);
}

/* relógio de ponteiros */
function relogio(h, m){
  const R = 100, cx = 115, cy = 115;
  let o = `<circle cx="${cx}" cy="${cy}" r="${R}" fill="#fff" stroke="#111" stroke-width="6"/>`;
  for(let i = 0; i < 60; i++){
    const a = i * 6 * Math.PI / 180, g = i % 5 === 0;
    o += `<line x1="${cx + (R - (g ? 14 : 7)) * Math.sin(a)}" y1="${cy - (R - (g ? 14 : 7)) * Math.cos(a)}" x2="${cx + (R - 3) * Math.sin(a)}" y2="${cy - (R - 3) * Math.cos(a)}" stroke="#111" stroke-width="${g ? 3.5 : 1.5}"/>`;
  }
  for(let n = 1; n <= 12; n++){ const a = n * 30 * Math.PI / 180; o += T(cx + (R - 30) * Math.sin(a), cy - (R - 30) * Math.cos(a) + 9, n, { fs: 24 }); }
  const ah = ((h % 12) * 30 + m * 0.5) * Math.PI / 180, am = m * 6 * Math.PI / 180;
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + 52 * Math.sin(ah)}" y2="${cy - 52 * Math.cos(ah)}" stroke="#1d4ed8" stroke-width="10" stroke-linecap="round"/>`;
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + 82 * Math.sin(am)}" y2="${cy - 82 * Math.cos(am)}" stroke="#dc2626" stroke-width="6" stroke-linecap="round"/>`;
  o += `<circle cx="${cx}" cy="${cy}" r="8" fill="#111"/>`;
  return SVG(230, 230, o);
}

/* régua em cm com barras: barras = [{ini, fim, cor, rot}] */
function regua(maxCm, barras){
  const u = Math.min(38, Math.floor(560 / maxCm)), x0 = 24, W = maxCm * u + 48;
  const yR = 30 + barras.length * 34;
  let o = '';
  barras.forEach((b, i) => {
    const y = 16 + i * 34;
    o += `<rect x="${x0 + b.ini * u}" y="${y}" width="${(b.fim - b.ini) * u}" height="24" rx="4" fill="${b.cor || '#22c55e'}" stroke="#111" stroke-width="2"/>`;
    if(b.rot) o += T(x0 + b.ini * u - 12, y + 19, b.rot, { fs: 18, anc: 'end' });
  });
  o += `<rect x="${x0 - 14}" y="${yR}" width="${maxCm * u + 28}" height="62" rx="6" fill="#fef3c7" stroke="#92400e" stroke-width="2.5"/>`;
  for(let i = 0; i <= maxCm * 2; i++){
    const x = x0 + i * u / 2, g = i % 2 === 0;
    o += `<line x1="${x}" y1="${yR}" x2="${x}" y2="${yR + (g ? 24 : 13)}" stroke="#111" stroke-width="${g ? 2.5 : 1.3}"/>`;
    if(g) o += T(x, yR + 48, i / 2, { fs: 17 });
  }
  return SVG(W, yR + 72, o);
}

/* dinheiro com as imagens reais das cédulas e moedas (miniaturas embutidas) */
function dinheiro(itens){ // itens: ['n10','n2','m1', ...]
  const notas = itens.filter(i => i[0] === 'n'), moedas = itens.filter(i => i[0] === 'm');
  const nw = 168, nh = 88, mw = 64;
  const porLinha = 3;
  let o = '', x = 10, y = 10;
  notas.forEach((k, i) => {
    const im = IMG[k];
    x = 10 + (i % porLinha) * (nw + 10); y = 10 + Math.floor(i / porLinha) * (nh + 10);
    o += `<image href="${im}" x="${x}" y="${y}" width="${nw}" height="${nh}" preserveAspectRatio="xMidYMid meet"/>`;
  });
  const yM = 10 + Math.ceil(notas.length / porLinha) * (nh + 10);
  moedas.forEach((k, i) => {
    o += `<image href="${IMG[k]}" x="${10 + (i % 8) * (mw + 6)}" y="${yM + Math.floor(i / 8) * (mw + 6)}" width="${mw}" height="${mw}"/>`;
  });
  const W = Math.max(20 + Math.min(notas.length, porLinha) * (nw + 10), 20 + Math.min(moedas.length, 8) * (mw + 6), 200);
  const H = yM + (moedas.length ? Math.ceil(moedas.length / 8) * (mw + 6) : 0) + 4;
  return SVG(W, H, o);
}

/* formas planas */
function poligonoPts(n, cx, cy, R, rot = -90){
  const p = [];
  for(let i = 0; i < n; i++){ const a = (rot + 360 / n * i) * Math.PI / 180; p.push(`${(cx + R * Math.cos(a)).toFixed(1)},${(cy + R * Math.sin(a)).toFixed(1)}`); }
  return p.join(' ');
}
function formaSVG(forma, cor = '#60a5fa', giro = 0, tam = 120){
  const c = tam / 2, st = `fill="${cor}" stroke="#111" stroke-width="4" stroke-linejoin="round"`;
  let o;
  if(forma === 'circulo') o = `<circle cx="${c}" cy="${c}" r="${tam * .4}" ${st}/>`;
  else if(forma === 'quadrado') o = `<rect x="${tam * .15}" y="${tam * .15}" width="${tam * .7}" height="${tam * .7}" ${st}/>`;
  else if(forma === 'retangulo') o = `<rect x="${tam * .05}" y="${tam * .28}" width="${tam * .9}" height="${tam * .44}" ${st}/>`;
  else if(forma === 'triangulo') o = `<polygon points="${poligonoPts(3, c, c + tam * .08, tam * .46)}" ${st}/>`;
  else if(forma === 'pentagono') o = `<polygon points="${poligonoPts(5, c, c + tam * .04, tam * .44)}" ${st}/>`;
  else if(forma === 'hexagono') o = `<polygon points="${poligonoPts(6, c, c, tam * .44, 0)}" ${st}/>`;
  else if(forma === 'losango') o = `<polygon points="${c},${tam * .06} ${tam * .8},${c} ${c},${tam * .94} ${tam * .2},${c}" ${st}/>`;
  else o = `<polygon points="${poligonoPts(8, c, c, tam * .44, 22.5)}" ${st}/>`; // octogono
  if(giro) o = `<g transform="rotate(${giro} ${c} ${c})">${o}</g>`;
  return SVG(tam, tam, o);
}
function iconeSVG(tipo, tam = 110){ return SVG(tam, tam, ICONES[tipo](tam / 2, tam / 2, tam * .92)); }

/* imagens reais (miniaturas WebP das cédulas e moedas da pasta imagens do professor) */
const IMG = {};
