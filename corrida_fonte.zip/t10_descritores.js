
/* =========================================================================
   DESCRITORES DO PAEBES (acrescentado) — cada degrau ligado ao descritor
   da Matriz de Referência Paebes 2025 (5º e 9º ano; os anos iniciais contam
   como base do descritor do 5º). Aluno "domina" um descritor quando domina
   TODOS os degraus ativos ligados a ele.
   Onde aparece: botão "📊 Descritores" no cartão da Trilha e no relatório
   do fim da partida (tabela da turma + planilha CSV aluno × descritor).
   Funções originais intactas: só embrulhos (montarCartao, renderClassReport).
========================================================================= */
const DESCRITORES = {
  D002: 'Números naturais na reta numérica', D003: 'Adição e subtração com naturais', D004: 'Multiplicação e divisão com naturais',
  D005: 'Composição e decomposição de naturais', D009: 'Números racionais na reta numérica', D010: 'Cálculos com números racionais',
  D011: 'Fração e seus diferentes significados', D012: 'Frações equivalentes', D013: 'Diferentes representações de um racional',
  D014: 'Sistema de numeração decimal', D018: 'Valor numérico de expressão algébrica', D020: 'Cálculos com números inteiros',
  D021: 'Inteiros na reta numérica', D024: 'Problemas com racionais', D035: 'Problemas com números inteiros', D038: 'Porcentagem',
  D039: 'Proporcionalidade entre grandezas', D042: 'Princípio multiplicativo de contagem', D043: 'Pontos no plano cartesiano',
  D044: 'Localização e movimentação em mapas e malhas', D057: 'Perímetro', D058: 'Área', D059: 'Conversão de unidades de tempo',
  D060: 'Conversão de unidades de medida', D061: 'Horários e duração de eventos', D062: 'Volume', D064: 'Tabelas e gráficos em problemas',
  D065: 'Probabilidade', D081: 'Expressão que modela uma sequência', D106: 'Medição de grandezas', D108: 'Gráficos de colunas',
  D110: 'Sistema monetário com decimais', D111: 'Sólidos: planificações e vistas', D112: 'Figuras planas pelo número de lados',
  D113: 'Ampliação e redução de figuras', D114: 'Trocas entre cédulas e moedas', D116: 'Propriedades dos triângulos',
  D117: 'Quadriláteros e suas propriedades', D118: 'Propriedades dos polígonos', D120: 'Equação que expressa um problema',
  D121: 'Círculo e circunferência', D125: 'Vértices, faces e arestas', D144: 'Ângulos: giros, retos e não retos',
  D148: 'Problemas com naturais (significados das operações)', D153: 'Leitura de tabelas',
};
const DESC_DE = {
  soma10: ['D003'], sub10: ['D003'], faz10: ['D003'], soma20: ['D003'], sub20: ['D003'], soma100: ['D003'], sub100: ['D003'], p3_soma: ['D003'], p3_sub: ['D003'],
  contar100: ['D014'], cont20: ['D014'], seq20: ['D014'], centenas: ['D014'], numGrandes5: ['D014'], dezenas: ['D014', 'D005'], abaco: ['D014', 'D005'], p4_valor: ['D005', 'D014'],
  grupos1: ['D004', 'D148'], vezes2: ['D004'], dobro: ['D004'], disposicao: ['D004', 'D148'], p3_tab: ['D004'], pratos: ['D004', 'D148'], divResto: ['D004', 'D148'],
  p3_dobro: ['D004'], p4_tab: ['D004'], p4_div: ['D004'], propriedades4: ['D003', 'D004'], inversa4: ['D003', 'D004'], p3_termo: ['D003'], p5_termo: ['D004'],
  cedulas: ['D114'], dinheiro: ['D114'], troco3: ['D114', 'D148'], centavos: ['D110'], notaFiscal5: ['D110'], trocoDesc4: ['D110'],
  semana: ['D059'], calendario2: ['D059'], horasDig4: ['D059'], relDigital: ['D061'], relogio: ['D061'], duracao: ['D061'],
  compara1: ['D106'], regua: ['D106'], reguaMm: ['D106'], medidas2: ['D106'], instrumento3: ['D106'], jarra: ['D106'], balancaKg: ['D106'], termometro: ['D106'],
  formas: ['D112'], figPlanas3: ['D112'], poligonos: ['D112'], congruente3: ['D112'],
  setas2: ['D044'], mapa2: ['D044'], plano: ['D044'], vertices6: ['D043'], p6_coord: ['D043'], transf7: ['D043'],
  pictograma: ['D108'], colunas: ['D108'], barras: ['D108'], tabelaDupla: ['D153'], graficoTemp4: ['D064'], graficoLinha5: ['D064'], graficoDuplo6: ['D064'], p7_setores: ['D064'], p7_media: ['D064'],
  acaso1: ['D065'], provavel2: ['D065'], resultados3: ['D065'], roleta4: ['D065'], chance: ['D065'], potes: ['D065'], dado: ['D065'], urna7: ['D065'], doisDados: ['D065'],
  reta3: ['D002'], arredonda: ['D002'], fracReta4: ['D009'], decReta: ['D009'], p6_retaRac: ['D009'], racNeg7: ['D009'], decCompara6: ['D009', 'D013'],
  partes: ['D011'], pizza: ['D011'], fracfig: ['D011'], fracMista5: ['D011'], p5_fracao: ['D011', 'D024'], fracQtd: ['D011', 'D024'],
  fracEquiv: ['D012'], fracLacuna: ['D012'], fracCompara: ['D013'], decimos4: ['D013'], p6_equiv: ['D013', 'D038'], porcMalha: ['D013', 'D038'],
  p6_porc: ['D038'], p7_desc: ['D038'], decOps6: ['D010'], somaFrac: ['D010'], opsRac7: ['D010'],
  contagem: ['D042'], cardapio: ['D042'],
  propTabela5: ['D039'], partilha5: ['D039'], partilha6: ['D039'], p7_prop: ['D039'], inversa7: ['D039'], p7_receita: ['D039'], razao7: ['D039'], escala6: ['D039'],
  ampliacao: ['D113'], quadAmplia6: ['D113'], cubinhos: ['D062'], volume7: ['D062'], faces: ['D125'], prismas6: ['D125'], solidos: ['D111'], planif3: ['D111'],
  areaComp3: ['D058'], areaMalha: ['D058'], p6_areaFig: ['D058'], perimMalha: ['D057'], perimArea5: ['D057', 'D058'], conversao5: ['D060'], p7_conversao: ['D060'],
  anguloReto4: ['D144'], giro6: ['D144'], transferidor: ['D144'], p7_ang: ['D144'], triangulos: ['D116'], p7_triang: ['D116'], p7_existe: ['D116'], rigidez7: ['D116'],
  p7_poligono: ['D118'], quadrilateros: ['D117'], circunf7: ['D121'], p7_circ: ['D121'],
  p6_expr: ['D148'], p6_mmc: ['D148'], p7_int: ['D020'], p7_piramide: ['D020'], p7_reta: ['D021'], opostoModulo: ['D021'], tempCidades: ['D021'],
  variacaoTemp: ['D035'], elevador: ['D035'], p7_extrato: ['D035'], p7_valorNum: ['D018'], equivExpr7: ['D018'], p7_traduzir: ['D120'], p7_balanca: ['D120'], p7_equacao: ['D120'],
  p7_seq: ['D081'], tiposAng6: ['D144'], abreAng6: ['D144'], probTexto2: ['D148', 'D003'], probTexto3: ['D148', 'D004'], probTexto4: ['D148', 'D042'], probTexto5: ['D148', 'D039'], vistas5: ['D111'], vistas6: ['D111'],
};
/* situação de cada descritor para um aluno: 'dom' | 'and' (começou) | 'nao' */
function descritoresDe(rec, anoAte = 7){
  const res = {};
  Object.keys(DESCRITORES).forEach(code => {
    const degs = CAT.filter(d => ativo(d) && d.ano <= anoAte && (DESC_DE[d.id] || []).includes(code));
    if(!degs.length) return;
    const dom = degs.filter(d => rec && rec.deg[d.id] && rec.deg[d.id].dom).length;
    const mexeu = degs.some(d => rec && rec.deg[d.id] && (rec.deg[d.id].tot > 0 || rec.deg[d.id].dom));
    res[code] = { tot: degs.length, dom, st: dom === degs.length ? 'dom' : (dom || mexeu) ? 'and' : 'nao', degs: degs.map(d => d.id) };
  });
  return res;
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .ds-tab{width:100%;border-collapse:collapse;font-size:14px;margin-top:10px;background:var(--panel)}
  .ds-tab th,.ds-tab td{padding:8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
  .ds-tab th{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.8px;position:sticky;top:64px;background:#0f172a}
  .ds-bar{height:12px;border-radius:6px;background:#334155;overflow:hidden;min-width:90px}
  .ds-bar i{display:block;height:100%;background:#22c55e}
  .ds-cod{font-weight:900;color:#93c5fd;white-space:nowrap}
  .ds-falta{color:#fca5a5;font-size:13px}
  .ds-and{color:#fbbf24;font-size:13px}`;
  document.head.appendChild(st);

  function alunosTurma(){ return Object.values(estado.turma.alunos || {}).filter(r => r && r.nome).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')); }
  function abrirDescritores(){
    let box = $('dsBox'); if(box) box.remove();
    box = document.createElement('div'); box.id = 'dsBox'; box.className = 'cat-fundo';
    const ano = Math.min(estado.cfg.ano || 7, LIMITE.anoMax || 9);
    const al = alunosTurma(), por = al.map(r => ({ r, d: descritoresDe(r, ano) }));
    const base = descritoresDe(null, ano), codes = Object.keys(base);
    const linhas = codes.map(code => {
      const dom = por.filter(x => x.d[code] && x.d[code].st === 'dom'), and = por.filter(x => x.d[code] && x.d[code].st === 'and'), nao = por.filter(x => x.d[code] && x.d[code].st === 'nao');
      const pct = al.length ? Math.round(dom.length / al.length * 100) : 0;
      const degs = base[code].degs.map(id => { const d = POR_ID[id]; return `${d.ano}º ${d.nome}`; });
      return { code, pct, html: `<tr><td class="ds-cod">${code}</td><td><b>${esc(DESCRITORES[code])}</b><div style="color:var(--muted);font-size:12px">${esc(degs.join(' · '))}</div></td>
        <td><div class="ds-bar"><i style="width:${pct}%"></i></div><div style="font-weight:900;margin-top:3px">${dom.length} de ${al.length} (${pct}%)</div></td>
        <td>${and.length ? `<div class="ds-and">🟡 começaram: ${esc(and.map(x => x.r.nome).join(', '))}</div>` : ''}${nao.length ? `<div class="ds-falta">🔴 ainda não: ${esc(nao.map(x => x.r.nome).join(', '))}</div>` : ''}${!and.length && !nao.length && al.length ? '✅ todos' : ''}</td></tr>` };
    });
    linhas.sort((a, b) => a.pct - b.pct || a.code.localeCompare(b.code));
    box.innerHTML = `<div class="cat-topo"><h2>📊 Descritores do Paebes — turma ${esc(estado.turma.nome || '')}</h2>
        <div class="dir"><button class="ab" data-csv="1">💾 Planilha (CSV)</button><button class="ab" data-fechar="1">✕ Fechar</button></div></div>
      <div style="color:var(--muted);font-size:13px;margin:10px 4px">${al.length} aluno${al.length === 1 ? '' : 's'} com progresso · ${codes.length} descritores com atividade <b>até o ${ano}º ano</b> (ano da turma, escolhido no cartão da Trilha) · em cima, os descritores que a turma MENOS domina.
        O aluno domina o descritor quando domina todos os degraus ligados a ele até o ano da turma. Os descritores são os do Paebes (5º e 9º ano); nos anos iniciais eles valem como base.</div>
      ${al.length ? `<table class="ds-tab"><tr><th>Código</th><th>Descritor e degraus da trilha</th><th>Dominam</th><th>Quem falta</th></tr>${linhas.map(l => l.html).join('')}</table>` : '<div style="padding:20px;color:var(--muted)">Carregue ou jogue com uma turma para ver os descritores.</div>'}`;
    document.body.appendChild(box);
    box.onclick = e => {
      if(e.target.closest('[data-fechar]')) box.remove();
      if(e.target.closest('[data-csv]')) baixarCSV(codes, por);
    };
  }
  function baixarCSV(codes, por){
    const q = v => `"${String(v).replace(/"/g, '""')}"`;
    const cab = ['Aluno', 'Descritores dominados', ...codes.map(c => `${c} ${DESCRITORES[c]}`)];
    const txt = { dom: 'domina', and: 'em andamento', nao: 'não iniciado' };
    const rows = por.map(x => [x.r.nome, `${codes.filter(c => x.d[c] && x.d[c].st === 'dom').length} de ${codes.length}`, ...codes.map(c => x.d[c] ? `${txt[x.d[c].st]} (${x.d[c].dom}/${x.d[c].tot})` : '')]);
    const csv = '﻿' + [cab, ...rows].map(r => r.map(q).join(';')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })), a = document.createElement('a');
    a.href = url; a.download = `descritores-${(estado.turma.nome || 'turma').replace(/[^\w\-]+/g, '_')}-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  }
  window.abrirDescritores = abrirDescritores;
  function botaoCartao(){
    const ref = $('trVerMapa'); if(!ref || $('trDescritores')) return;
    const b = document.createElement('button'); b.className = 'ghost'; b.id = 'trDescritores'; b.textContent = '📊 Descritores (Paebes)';
    b.onclick = abrirDescritores; ref.after(b);
  }
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); botaoCartao(); return r; };
  botaoCartao();
  const renderClassReport0 = app.renderClassReport;
  app.renderClassReport = function(){
    const r = renderClassReport0.apply(this, arguments);
    const row = document.querySelector('#trRelatorio .tr-row');
    if(row && !$('trDescFim')){ const b = document.createElement('button'); b.className = 'ghost'; b.id = 'trDescFim'; b.textContent = '📊 Descritores do Paebes da turma'; b.style.width = 'auto'; b.onclick = abrirDescritores; row.appendChild(b); }
    return r;
  };
})();
