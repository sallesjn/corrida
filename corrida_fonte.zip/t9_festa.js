
/* =========================================================================
   FESTA DE DOMÍNIO (acrescentado): confete na tela toda + cartão grande.
   Dura ~4 s (toque para fechar antes). A próxima pergunta só aparece depois
   da festa, para o cronômetro da questão não correr por baixo.
   Funções originais intactas: só embrulho em nextLocalQuestion.
========================================================================= */
const festaEst = { ate: 0, pend: null };
function festa(titulo, sub){
  if(typeof document === 'undefined') return;
  document.querySelectorAll('.tr-festa').forEach(x => x.remove());
  const dur = 7000, trava = 3000, inicio = Date.now();       // 7 s de festa; nos 3 primeiros não fecha com toque (o aluno estava tocando nas respostas)
  festaEst.ate = Date.now() + dur;
  const box = document.createElement('div');
  box.className = 'tr-festa';
  box.innerHTML = `<canvas></canvas><div class="card"><div class="em">🏅</div><div class="t0">${app.playerName ? 'Parabéns, ' + esc(app.playerName) + '!' : 'Parabéns!'}</div><div class="t1">Você dominou!</div><div class="t2">${titulo}</div>${sub ? `<div class="t3">${sub}</div>` : ''}<div class="t4">toque para continuar</div><div class="estrelas">⭐ ⭐ ⭐</div></div>`;
  document.body.appendChild(box);
  const cv = box.querySelector('canvas'), cx = cv.getContext && cv.getContext('2d');
  const W = cv.width = window.innerWidth, H = cv.height = window.innerHeight;
  const cores = ['#f59e0b', '#ef4444', '#22c55e', '#3b82f6', '#a855f7', '#ec4899', '#facc15', '#14b8a6'];
  const P = [];
  const rajada = (x, n) => { for(let i = 0; i < n; i++){ const a = -Math.PI / 2 + (Math.random() - 0.5) * 1.3, v = 9 + Math.random() * 11;
    P.push({ x, y: H + 10, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 1.5, r: 5 + Math.random() * 6, c: cores[i % cores.length], g: Math.random() * 6, dg: (Math.random() - 0.5) * 0.35, f: Math.random() < 0.5 }); } };
  rajada(W * 0.2, 110); rajada(W * 0.8, 110);
  [[450, 0.5, 130], [1300, 0.3, 100], [1300, 0.7, 100], [2400, 0.5, 140], [3600, 0.15, 90], [3600, 0.85, 90], [4800, 0.5, 120]]
    .forEach(([t, x, n]) => setTimeout(() => { if(box.isConnected) rajada(W * x, n); }, t));
  const t0 = performance.now();
  const passo = t => {
    if(!box.isConnected || !cx) return;
    cx.clearRect(0, 0, W, H);
    P.forEach(p => { p.vy += 0.32; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.g += p.dg;
      cx.save(); cx.translate(p.x, p.y); cx.rotate(p.g); cx.fillStyle = p.c;
      if(p.f) cx.fillRect(-p.r, -p.r / 2, p.r * 2, p.r); else { cx.beginPath(); cx.arc(0, 0, p.r * 0.7, 0, 7); cx.fill(); }
      cx.restore(); });
    if(t - t0 < dur) requestAnimationFrame(passo);
  };
  requestAnimationFrame(passo);
  const fechar = () => { box.remove(); festaEst.ate = 0; if(festaEst.pend){ const f = festaEst.pend; festaEst.pend = null; f(); } };
  box.onclick = () => { if(Date.now() - inicio >= trava) fechar(); };
  setTimeout(() => box.classList.add('pode'), trava);
  setTimeout(() => { if(box.isConnected) fechar(); }, dur);
  try{ sndEnd(); [500, 800, 1300, 2400, 3600].forEach(t => setTimeout(() => { try{ if(box.isConnected) sndRight(); }catch(e){} }, t)); }catch(e){}
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .tr-festa{position:fixed;inset:0;z-index:600;background:rgba(2,6,23,.55);display:flex;align-items:center;justify-content:center;cursor:pointer}
  .tr-festa canvas{position:absolute;inset:0;pointer-events:none}
  .tr-festa .card{position:relative;background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;border-radius:26px;padding:40px 30px 26px;max-width:90vw;text-align:center;
    box-shadow:0 20px 60px rgba(0,0,0,.6);border:4px solid #fde68a;animation:trFesta .7s cubic-bezier(.2,1.6,.4,1)}
  .tr-festa .em{font-size:clamp(64px,16vw,110px);line-height:1;margin-bottom:18px;animation:trGira 1.2s ease-in-out infinite alternate}
  .tr-festa .t1{font-size:clamp(30px,8vw,52px);font-weight:900;margin-top:6px;text-shadow:0 3px 0 rgba(0,0,0,.25)}
  .tr-festa .t2{font-size:clamp(20px,5vw,32px);font-weight:900;margin-top:6px}
  .tr-festa .t3{font-size:clamp(18px,4.5vw,26px);font-weight:800;margin-top:8px;color:#fef3c7}
  .tr-festa .t0{font-size:clamp(20px,5vw,30px);font-weight:900;color:#fef3c7}
  .tr-festa .t4{font-size:15px;font-weight:800;margin-top:14px;opacity:0;transition:opacity .5s}
  .tr-festa.pode .t4{opacity:.9}
  .tr-festa .estrelas{font-size:clamp(28px,7vw,44px);margin-top:6px;animation:trPisca 0.8s ease-in-out infinite alternate}
  @keyframes trPisca{0%{transform:scale(.9);opacity:.7}100%{transform:scale(1.15);opacity:1}}
  @keyframes trFesta{0%{transform:scale(.3) rotate(-8deg);opacity:0}100%{transform:scale(1) rotate(0);opacity:1}}
  @keyframes trGira{0%{transform:rotate(-12deg) scale(1)}100%{transform:rotate(12deg) scale(1.15)}}`;
  document.head.appendChild(st);
  const nextLocalQuestion0 = app.nextLocalQuestion;
  app.nextLocalQuestion = function(){
    const falta = festaEst.ate - Date.now();
    if(falta > 0){ festaEst.pend = () => { if(this.player.phase === 'playing') nextLocalQuestion0.apply(this, arguments); }; return; }
    return nextLocalQuestion0.apply(this, arguments);
  };
})();
