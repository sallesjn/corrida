
/* =========================================================================
   ATIVIDADE FOCO DA AULA + SALVAR SOZINHO NO FIM + PROTEÇÃO OFFLINE
   (acrescentado)
   · Foco da aula (discreto): o professor escolhe 1 ou mais atividades (ex.:
     retas e tipos de ângulos) e a frequência (1 em cada 5, 4 ou 3). Elas
     aparecem no meio da trilha de TODOS, como uma pergunta qualquer (o aluno
     não sabe que é a "da aula"). Contam para subir e dominar normalmente.
     O professor vê o acerto de cada aluno e da turma no foco (acompanhamento,
     painel e relatório do fim).
   · Fim da partida: cada celular manda o que faltava e confirma; o arquivo
     da turma é baixado sozinho quando todos entregarem (ou em 25 s).
   · Offline: os pontos não se perdem (o pacote espera a conexão voltar), o
     progresso fica guardado no próprio celular e o aluno vê um aviso.
   Funções originais intactas: só embrulhos (getNextQuestion, pub,
   playerReceiveState, flushBatch, finishPlayerMatch, localAnswer,
   renderClassReport, onMessage) e a troca de escolherFonte por uma versão que
   chama a original.
========================================================================= */
const FOCO_FREQ = [[0.2, '1 em cada 5'], [0.25, '1 em cada 4'], [0.34, '1 em cada 3']];
if(!estado.cfg.foco) estado.cfg.foco = { ids: [], freq: 0.25, stamp: 0 };
const focoAtivo = () => estado.cfg.on && estado.cfg.foco && estado.cfg.foco.ids && estado.cfg.foco.ids.length ? estado.cfg.foco : null;

/* motor: de vez em quando, a pergunta vem do foco da aula */
const escolherFonteSemFoco = escolherFonte;
escolherFonte = function(rec, sorte){
  const f = escolherFonteSemFoco(rec, sorte);
  const fo = estado.focoAluno;
  if(!fo || !fo.ids || !fo.ids.length || f.tipo === 'diag') return f;
  if(Math.random() >= (fo.freq || 0.25)) return f;
  const ult = (rec.ultIds || []).slice(-2);
  const cands = fo.ids.filter(id => POR_ID[id] && !ult.every(x => x === id));
  if(!cands.length) return f;
  const id = pick(cands);
  return { tipo: 'foco', id, nivel: degDo(rec, id).n };
};

/* professor: escolher o foco */
function abrirFoco(){
  const fo = estado.cfg.foco;
  const est = { ids: new Set(fo.ids || []), freq: fo.freq || 0.25, aba: fo.ids && fo.ids.length && POR_ID[fo.ids[0]] ? POR_ID[fo.ids[0]].ano : (estado.cfg.ano || 6) };
  let box = $('focoBox'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'focoBox'; box.className = 'cat-fundo';
  document.body.appendChild(box);
  const desenhar = () => {
    const degs = CAT.filter(d => d.ano === est.aba && !d.retirada);
    box.innerHTML = `<div class="cat-topo"><h2>🎯 Atividade foco da aula</h2>
        <div class="dir"><button class="ab" data-salvar="1" style="background:#16a34a;border-color:#16a34a">✅ Salvar</button><button class="ab" data-limpar="1">Sem foco</button><button class="ab" data-fechar="1">✕ Cancelar</button></div></div>
      <div style="color:var(--muted);font-size:14px;margin:10px 4px;line-height:1.5">As atividades marcadas aparecem <b>no meio da trilha de todos os alunos</b>, como uma pergunta qualquer (o aluno não sabe que é a da aula). Contam para subir e dominar normalmente. Você acompanha o acerto de cada um no painel e no relatório do fim.</div>
      <div class="pl-op" style="margin:0 4px 8px"><b>Aparece</b> ${FOCO_FREQ.map(([v, t]) => `<label style="margin:0 10px 0 0;font-weight:800"><input type="radio" name="foFreq" value="${v}" ${Math.abs(v - est.freq) < 0.01 ? 'checked' : ''} style="width:20px;height:20px;vertical-align:middle"> ${t} perguntas</label>`).join('')}</div>
      <div class="cat-topo" style="position:static">
        ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<button class="ab ${a === est.aba ? 'on' : ''}" data-aba="${a}">${a}º ano${[...est.ids].some(id => POR_ID[id] && POR_ID[id].ano === a) ? ' •' : ''}</button>`).join('')}
        <span class="fo-cont" style="margin-left:auto;font-weight:900;color:#fbbf24">${est.ids.size} marcada${est.ids.size === 1 ? '' : 's'}</span></div>
      <div class="pl-grade">${degs.map(d => `<label class="pl-item ${est.ids.has(d.id) ? 'on' : ''}"><input type="checkbox" data-id="${d.id}" ${est.ids.has(d.id) ? 'checked' : ''}>
        <div class="pl-min">${miniaturaDegrau(d)}</div><div class="pl-nome">${esc(d.nome)}</div></label>`).join('')}</div>`;
  };
  desenhar();
  box.onchange = e => {
    if(e.target.name === 'foFreq'){ est.freq = +e.target.value; return; }
    const id = e.target.dataset && e.target.dataset.id;
    if(id){ if(e.target.checked) est.ids.add(id); else est.ids.delete(id); e.target.closest('.pl-item').classList.toggle('on', e.target.checked);
      const c = box.querySelector('.fo-cont'); if(c) c.textContent = `${est.ids.size} marcada${est.ids.size === 1 ? '' : 's'}`; }
  };
  box.onclick = e => {
    if(e.target.closest('[data-fechar]')){ box.remove(); return; }
    const aba = e.target.closest('button[data-aba]'); if(aba){ est.aba = +aba.dataset.aba; desenhar(); return; }
    const limpar = !!e.target.closest('[data-limpar]');
    if(limpar || e.target.closest('[data-salvar]')){
      estado.cfg.foco = limpar ? { ids: [], freq: est.freq, stamp: Date.now() } : { ids: CAT.filter(d => est.ids.has(d.id)).map(d => d.id), freq: est.freq, stamp: Date.now() };
      salvarCfg(); box.remove(); atualizarBotaoFoco();
      if(app.room && app.mode === 'teacher') try{ app.broadcastState(); }catch(e){}
      app.toast(estado.cfg.foco.ids.length ? `🎯 Foco da aula: <b>${estado.cfg.foco.ids.map(id => esc(POR_ID[id].nome)).join(', ')}</b>` : '🎯 Sem atividade foco', 'success');
    }
  };
}
function cartaoExtra(p){
  if(!focoAtivo()) return '';
  const f = focoDoAluno(estado.turma.alunos[normNome(p.name)]);
  return `<div class="ac-foco">🎯 foco: ${f.tot ? `${f.ac}/${f.tot}` : 'ainda não caiu'}</div>`;
}
function textoFoco(){
  const fo = focoAtivo(); if(!fo) return 'nenhuma';
  const f = FOCO_FREQ.find(([v]) => Math.abs(v - fo.freq) < 0.01);
  return fo.ids.map(id => POR_ID[id] ? POR_ID[id].nome : id).join(' · ') + ` (${f ? f[1] : ''})`;
}
function atualizarBotaoFoco(){ const el = $('trFocoTxt'); if(el) el.textContent = textoFoco(); }
/* acerto no foco: por aluno e da turma (só desta aula = mesmo "stamp") */
function focoDoAluno(r){
  const fo = focoAtivo(); if(!fo || !r || !r.focoHoje || r.focoHoje.stamp !== fo.stamp) return { ac: 0, tot: 0, por: {} };
  let ac = 0, tot = 0; Object.values(r.focoHoje.r || {}).forEach(([a, t]) => { ac += a; tot += t; });
  return { ac, tot, por: r.focoHoje.r || {} };
}
function focoTurma(){
  let ac = 0, tot = 0;
  app.host.players.filter(p => !p.isBot).forEach(p => { const f = focoDoAluno(estado.turma.alunos[normNome(p.name)]); ac += f.ac; tot += f.tot; });
  return { ac, tot };
}

/* ---------------- fim da partida: entrega e salvamento automático ---------------- */
const fimEst = { ativo: false, salvo: false, t0: 0, timer: null };
function acompanharEntrega(){
  const agora = Date.now();
  const alvo = app.host.players.filter(p => !p.isBot && (agora - (p._visto || 0) < 60000 || p._entregou));
  const faltam = alvo.filter(p => !p._entregou);
  const off = app.host.players.filter(p => !p.isBot && !alvo.includes(p));
  const el = $('trEntrega');
  if(el){
    el.innerHTML = fimEst.salvo
      ? `✅ Arquivo da turma salvo sozinho na pasta Downloads${faltam.length ? ` · ainda faltam ${faltam.length}: ${esc(faltam.map(p => p.name).join(', '))}` : ''}${off.length ? `<br><span style="color:var(--muted)">📡 sem conexão no fim (entregam quando voltarem, com esta tela aberta): ${esc(off.map(p => p.name).join(', '))}</span>` : ''}`
      : `⏳ Recebendo o final dos celulares… faltam <b>${faltam.length}</b>${faltam.length ? ': ' + esc(faltam.map(p => p.name).join(', ')) : ''}`;
  }
  if(!fimEst.salvo && (!faltam.length || agora - fimEst.t0 > 25000)){
    fimEst.salvo = true;
    try{ baixarTurma(); }catch(e){}
    acompanharEntrega();
  }
}

/* ---------------- aluno: guarda o progresso no próprio celular ---------------- */
const chaveLocal = () => 'cgm_prog_' + app.room + '_' + normNome(app.playerName || '');
function guardarLocal(){
  const pt = app.player.trilha; if(!pt || !pt.rec || !app.room) return;
  lsSet(chaveLocal(), { t: Date.now(), rec: pt.rec });
}
function recuperarLocal(){
  const pt = app.player.trilha; if(!pt || !pt.rec) return;
  const s = lsGet(chaveLocal(), null);
  if(s && s.rec && (s.rec.rev || 0) > (pt.rec.rev || 0)){ pt.rec = s.rec; pt.baseRev = 0; pt.env = {}; pt.sujo = true; }
}
try{ Object.keys(localStorage).filter(k => k.startsWith('cgm_prog_')).forEach(k => { const s = lsGet(k, null); if(!s || Date.now() - (s.t || 0) > 2 * 86400000) localStorage.removeItem(k); }); }catch(e){}

if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .fo-painel{margin:0 0 10px;background:rgba(251,191,36,.08);border:2px solid #f59e0b;border-radius:12px;padding:8px 12px;font-weight:800;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .ac-foco{font-size:13px;font-weight:900;color:#fbbf24;margin-top:3px}
  .of-aviso{position:fixed;left:50%;top:64px;transform:translateX(-50%);z-index:420;background:#78350f;color:#fef3c7;border:2px solid #f59e0b;border-radius:14px;padding:8px 14px;font-weight:800;font-size:15px;text-align:center;max-width:92vw;box-shadow:0 8px 30px rgba(0,0,0,.5)}
  #trEntrega{margin-top:10px;font-weight:800;line-height:1.5}`;
  document.head.appendChild(st);

  /* cartão da Trilha: botão do foco */
  function botaoFoco(){
    const opts = $('trOpts'); if(!opts || $('trFocoBox')) return;
    const b = document.createElement('div'); b.id = 'trFocoBox';
    b.style.cssText = 'margin-bottom:14px;padding:12px;border:2px solid #22c55e;border-radius:14px;background:rgba(34,197,94,.07)';
    b.innerHTML = `<label>🎯 Atividade foco da aula</label><div style="font-size:13px;margin:4px 0 8px">Agora: <b id="trFocoTxt"></b></div>
      <button class="ghost" id="trFocoBt" style="width:100%;padding:10px">Escolher as atividades que quero verificar hoje</button>`;
    const modo = $('trModoBox'); if(modo) modo.after(b); else opts.prepend(b);
    $('trFocoBt').onclick = abrirFoco; atualizarBotaoFoco();
  }
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); botaoFoco(); return r; };
  botaoFoco();

  /* professor: o foco vai junto com o estado da sala (chega sempre, até depois de recarregar) */
  const pub0 = app.pub;
  app.pub = function(topic, obj, retain){
    if(this.mode === 'teacher' && obj && obj.type === 'state' && /\/tostate$/.test(topic)) obj = Object.assign({}, obj, { foco: focoAtivo() });
    return pub0.call(this, topic, obj, retain);
  };
  /* professor: painel do treino e cartões mostram o foco */
  const acompanharHTML0 = acompanharHTML;
  acompanharHTML = function(){
    let h = acompanharHTML0.apply(this, arguments);
    const fo = focoAtivo(); if(!fo) return h;
    const t = focoTurma();
    h = `<div class="fo-painel">🎯 Foco da aula: ${esc(textoFoco())} · turma: <b>${t.tot ? Math.round(t.ac / t.tot * 100) + '%' : '—'}</b> (${t.ac}/${t.tot}) <button class="ghost" data-foco="1" style="width:auto;padding:4px 10px;font-size:12px;margin-left:auto">trocar</button></div>` + h;
    return h;
  };
  document.addEventListener('click', e => { if(e.target.closest('#ttPainel [data-foco]')) abrirFoco(); });

  /* aluno: recebe o foco pelo estado da sala e usa ao escolher a pergunta */
  const playerReceiveState0 = app.playerReceiveState;
  app.playerReceiveState = function(state){
    estado.focoSala = state && state.foco ? state.foco : null;
    return playerReceiveState0.apply(this, arguments);
  };
  const getNextQuestion0 = app.getNextQuestion;
  app.getNextQuestion = function(){
    estado.focoAluno = this.mode !== 'teacher' ? estado.focoSala : null;
    try{ return getNextQuestion0.apply(this, arguments); } finally { estado.focoAluno = null; }
  };
  const localAnswer0 = app.localAnswer;
  app.localAnswer = function(idx){
    const q = this.player.currentQuestion, bloq = this.player.questionBlocked;
    const r = localAnswer0.apply(this, arguments);
    const pt = this.player.trilha, fo = estado.focoSala;
    if(!bloq && q && pt && pt.rec){
      if(fo && fo.ids && q.trilha && fo.ids.includes(q.trilha.id)){
        const fh = (pt.rec.focoHoje && pt.rec.focoHoje.stamp === fo.stamp) ? pt.rec.focoHoje : (pt.rec.focoHoje = { stamp: fo.stamp, r: {} });
        const c = fh.r[q.trilha.id] || (fh.r[q.trilha.id] = [0, 0]); if(idx === q.correct) c[0]++; c[1]++;
        pt.sujo = true;
      }
      guardarLocal();
    }
    return r;
  };

  /* aluno: sem conexão, o pacote de pontos espera (antes ele era zerado e se perdia) */
  const flushBatch0 = app.flushBatch;
  app.flushBatch = function(){
    if(this.mode !== 'teacher' && !(this.mqtt && this.mqtt.connected)) return;
    return flushBatch0.apply(this, arguments);
  };
  /* aluno: recebeu a trilha do professor, mas tem progresso mais novo guardado no celular → usa o do celular */
  const onMessage0 = app.onMessage;
  app.onMessage = function(topic, msg){
    if(this.mode !== 'teacher' && msg && topic.endsWith(`/to/${this.playerId}`)){
      if(msg.type === 'fimOk'){ this.player._fimOk = true; return; }
      const r = onMessage0.call(this, topic, msg);
      if(msg.type === 'trilha') recuperarLocal();
      return r;
    }
    if(this.mode === 'teacher' && msg && msg.type === 'fim' && topic.endsWith('/tohost')){
      const p = this.host.players.find(x => x.id === msg.id); if(!p) return;
      p._visto = Date.now();
      const rec = estado.turma.alunos[normNome(p.name)];
      if(!estado.cfg.on || !msg.rev || (rec && (rec.rev || 0) >= msg.rev)){
        const novo = !p._entregou; p._entregou = true;
        this.pub(`${BASE}/${this.room}/to/${p.id}`, { type: 'fimOk' });
        if(novo && fimEst.salvo) app.toast(`📥 Chegou o final de <b>${esc(p.name)}</b> depois do salvamento — clique em 💾 Salvar de novo`, 'info');
        if(fimEst.ativo) acompanharEntrega();
      } else this.pub(`${BASE}/${this.room}/to/${p.id}`, { type: 'trilhaTudo' });
      return;
    }
    return onMessage0.call(this, topic, msg);
  };
  /* aluno: no fim, insiste em entregar até o professor confirmar */
  const finishPlayerMatch0 = app.finishPlayerMatch;
  app.finishPlayerMatch = function(){
    const jaAcabou = this.player.phase === 'done';
    const r = finishPlayerMatch0.apply(this, arguments);
    if(jaAcabou) return r;
    this.player._fimOk = false;
    let k = 0;
    clearInterval(this.player._fimT);
    this.player._fimT = setInterval(() => {
      if(this.player._fimOk || ++k > 200 || this.mode === 'teacher'){ clearInterval(this.player._fimT); return; }
      if(!(this.mqtt && this.mqtt.connected)) return;
      try{ this.flushBatch(); }catch(e){}
      const pt = this.player.trilha;
      this.pub(`${BASE}/${this.room}/tohost`, { type: 'fim', id: this.playerId, rev: pt && pt.rec ? pt.rec.rev || 0 : 0 });
    }, 2000);
    return r;
  };
  /* aluno: aviso de "sem internet" */
  let semNet = 0;
  setInterval(() => {
    const aviso = $('ofAviso');
    const jogando = app.mode !== 'teacher' && app.room && app.player.phase === 'playing';
    if(jogando && !(app.mqtt && app.mqtt.connected)) semNet++; else semNet = 0;
    if(semNet >= 5 && !aviso){ const d = document.createElement('div'); d.id = 'ofAviso'; d.className = 'of-aviso'; d.innerHTML = '📡 Sem internet — continue jogando: suas respostas estão guardadas e vão ser enviadas quando a conexão voltar.'; document.body.appendChild(d); }
    if(semNet === 0 && aviso) aviso.remove();
  }, 1000);

  /* professor: relatório do fim — foco da aula + entrega e salvamento automático */
  const renderClassReport0 = app.renderClassReport;
  app.renderClassReport = function(){
    const r = renderClassReport0.apply(this, arguments);
    const sec = $('trRelatorio');
    if(sec && estado.cfg.on && !this.host.isDemo){
      const fo = focoAtivo();
      if(fo){
        const linhas = this.host.players.filter(p => !p.isBot).map(p => ({ p, f: focoDoAluno(estado.turma.alunos[normNome(p.name)]) })).sort((a, b) => (a.f.tot ? a.f.ac / a.f.tot : 2) - (b.f.tot ? b.f.ac / b.f.tot : 2) || a.p.name.localeCompare(b.p.name, 'pt-BR'));
        const t = focoTurma();
        const div = document.createElement('div');
        div.innerHTML = `<h2 style="margin-top:18px">🎯 Foco da aula: ${esc(textoFoco())}</h2>
          <div style="font-weight:800">Turma: ${t.tot ? Math.round(t.ac / t.tot * 100) + '%' : '—'} de acerto (${t.ac} de ${t.tot}). Em cima, quem mais precisa de retomada.</div>
          <table class="tr-tab"><tr><th>Aluno</th>${fo.ids.map(id => `<th>${esc(POR_ID[id].nome)}</th>`).join('')}<th>Total</th></tr>` +
          linhas.map(({ p, f }) => `<tr class="${f.tot && f.ac / f.tot < 0.6 ? 'trav' : ''}"><td><b>${esc(p.name)}</b></td>${fo.ids.map(id => { const c = f.por[id]; return `<td>${c ? `${c[0]}/${c[1]}` : '—'}</td>`; }).join('')}<td><b>${f.tot ? Math.round(f.ac / f.tot * 100) + '%' : 'não caiu'}</b></td></tr>`).join('') + `</table>`;
        sec.appendChild(div);
      }
      const row = sec.querySelector('.tr-row');
      if(row && !$('trEntrega')){ const d = document.createElement('div'); d.id = 'trEntrega'; row.after(d); }
      fimEst.ativo = true; fimEst.salvo = false; fimEst.t0 = Date.now();
      clearInterval(fimEst.timer);
      fimEst.timer = setInterval(() => { if(app.host.phase !== 'end'){ clearInterval(fimEst.timer); fimEst.ativo = false; return; } acompanharEntrega(); }, 1000);
      acompanharEntrega();
    }
    return r;
  };
  /* lista de nomes ligada: só entra quem está na lista (o nome livre é recusado) */
  const naLista = nome => (estado.cfg.nomes || []).some(n => normNome(n) === normNome(nome));
  const hostPlayerJoinL = app.hostPlayerJoin;
  app.hostPlayerJoin = function(msg){
    if(estado.cfg.on && estado.cfg.lista && (estado.cfg.nomes || []).length && !this.host.isDemo && msg && !this.host.players.find(x => x.id === msg.id) && !naLista(msg.name)){
      this.pub(`${BASE}/${this.room}/to/${msg.id}`, { type: 'kick', reason: 'Nesta sala só se entra tocando no seu nome na lista. Se o seu nome não aparece, fale com o professor.' });
      this.notifyHost(msg.name || '(sem nome)', 'nome fora da lista da turma', 'kick');
      return;
    }
    return hostPlayerJoinL.apply(this, arguments);
  };
  /* professor: incluir um aluno novo na lista com a sala aberta */
  function incluirAluno(){
    const nome = (prompt('Nome do aluno novo (aparece na hora na lista dos celulares):') || '').trim();
    if(!nome) return;
    const ck = checkName(nome); if(!ck.ok){ alert(ck.reason); return; }
    if(naLista(nome)){ alert('Esse nome já está na lista.'); return; }
    estado.cfg.nomes = [...(estado.cfg.nomes || []), nome].sort((a, b) => a.localeCompare(b, 'pt-BR'));
    salvarCfg();
    if($('trNomes')) $('trNomes').value = estado.cfg.nomes.join('\n');
    publicarNomes();
    app.toast(`➕ <b>${esc(nome)}</b> incluído na lista`, 'success');
  }
  const acompanharHTML1 = acompanharHTML;
  acompanharHTML = function(){
    const h = acompanharHTML1.apply(this, arguments);
    if(!(estado.cfg.lista && (estado.cfg.nomes || []).length)) return h;
    return `<div class="fo-painel" style="border-color:#3b82f6;background:rgba(59,130,246,.08)">📋 Só entra quem está na lista (${estado.cfg.nomes.length} nomes) <button class="ghost" data-incluir="1" style="width:auto;padding:4px 10px;font-size:12px;margin-left:auto">➕ Incluir aluno</button></div>` + h;
  };
  document.addEventListener('click', e => { if(e.target.closest('#ttPainel [data-incluir]')) incluirAluno(); });

  const createRoom0 = app.createRoom;
  app.createRoom = function(isDemo){
    clearInterval(fimEst.timer); fimEst.ativo = false; fimEst.salvo = false;
    if(!isDemo && focoAtivo()){ estado.cfg.foco.stamp = Date.now(); salvarCfg(); }      // cada aula conta o foco do zero (mesmo com a configuração salva na turma)
    return createRoom0.apply(this, arguments);
  };
})();
