
/* =========================================================================
   LOTE 9º ANO — Currículo SEDU/ES 2026 (EFAF), na ordem dos trimestres.
   Usa os utilitários do lote do 8º (ev8, alt8, fr8, sup8, nD …).
========================================================================= */

/* ============================ 1º TRIMESTRE ============================ */

/* Potências de expoente negativo e fracionário; radicais (EF09MA03/ES) */
G.pot9 = n => {
  if(n === 1){
    const modo = pick(['dez', 'neg', 'dec']);
    if(modo === 'dez'){
      const e = rnd(1, 5), v = Math.pow(10, -e), expr = `10${sup8(-e)}`;
      const aa = alt8({ t: numTxt8(v), v }, [{ t: numTxt8(Math.pow(10, -(e + 1))), v: Math.pow(10, -(e + 1)), erro: 'pôs um zero a mais' }, { t: e > 1 ? numTxt8(Math.pow(10, -(e - 1))) : '1', v: e > 1 ? Math.pow(10, -(e - 1)) : 1, erro: 'pôs um zero a menos' }, { t: '−' + numTxt8(Math.pow(10, e)), v: -Math.pow(10, e), erro: 'achou que expoente negativo deixa o número negativo' }, { t: nD(-10 * e), v: -10 * e, erro: 'multiplicou a base pelo expoente' }]);
      return { ...aa, text: `Quanto vale ${expr}?`, meta: { expr, tipo: 'dec' }, chave: 'p9d' + e };
    }
    if(modo === 'neg'){
      const b = pick([2, 3, 4, 5]), e = pick([2, 3]), expr = `(−${b})${sup8(-e)}`, P = Math.pow(-b, e);
      const aa = alt8({ t: fr8(1, P), v: 1 / P }, [{ t: fr8(-1, P), v: -1 / P, erro: 'errou o sinal (base negativa com expoente par dá positivo)' }, { t: nD(P), v: P, erro: 'não inverteu' }, { t: nD(-P), v: -P, erro: 'achou que o expoente negativo muda o sinal' }, { t: fr8(1, b * e), v: 1 / (b * e), erro: 'multiplicou base pelo expoente' }]);
      return { ...aa, text: `Quanto vale ${expr}?`, meta: { expr, tipo: 'val' }, chave: 'p9n' + expr };
    }
    const d = pick([2, 4, 5]), e = pick([1, 2]), base = nD(1 / d), v = Math.pow(d, e);
    const aa = alt8(nv8(v), [{ t: numTxt8(Math.pow(1 / d, e)), v: Math.pow(1 / d, e), erro: 'não inverteu (expoente negativo inverte a base)' }, { t: nD(-v), v: -v, erro: 'achou que o resultado fica negativo' }, { t: nD(d * e), v: d * e, erro: 'multiplicou em vez de elevar' }], viz8(v));
    return { ...aa, text: `Quanto vale (${base})${sup8(-e)}?`, meta: { expr: `(${base})${sup8(-e)}`, tipo: 'val' }, chave: 'p9x' + d + e };
  }
  if(n === 2){
    const opc = [[16, 3, 4], [16, 1, 4], [27, 2, 3], [8, 2, 3], [64, 2, 3], [64, 5, 6], [32, 3, 5], [32, 2, 5], [81, 3, 4], [25, 3, 2], [4, 3, 2], [9, 3, 2], [100, 3, 2], [125, 2, 3], [49, 1, 2], [1000, 2, 3]];
    const [B, p, r] = pick(opc), raiz = Math.round(Math.pow(B, 1 / r)), v = Math.pow(raiz, p);
    const aa = alt8(nv8(v), [{ t: nD(raiz), v: raiz, erro: `tirou a raiz e esqueceu de elevar a ${p}` }, { t: fr8(B * p, r), v: B * p / r, erro: 'multiplicou a base pela fração' }, Math.pow(B, p) <= 1e6 && { t: nD(Math.pow(B, p)), v: Math.pow(B, p), erro: 'elevou e esqueceu a raiz' }, Number.isInteger(Math.round(Math.pow(B, r / p) * 1e6) / 1e6) && Math.pow(B, r / p) < 1e6 && { t: nD(Math.round(Math.pow(B, r / p))), v: Math.round(Math.pow(B, r / p)), erro: 'inverteu a fração do expoente' }, { t: nD(raiz * p), v: raiz * p, erro: `tirou a raiz e multiplicou por ${p} em vez de elevar` }], viz8(v));
    return { ...aa, text: `Quanto vale a potência da figura? (expoente ${p}/${r} = raiz de índice ${r}${p > 1 ? `, elevada a ${p}` : ''})`, image: svgURI(potFracSVG(B, p, r)), meta: { expr: `${B}^(${p}/${r})`, tipo: 'val' }, chave: 'p9f' + B + p + r };
  }
  // n === 3: simplificar radicais e propriedades
  if(Math.random() < .55){
    const a = rnd(2, 7), b = pick([2, 3, 5, 6, 7]), k = a * a * b;
    const cert = `${a}√${b}`;
    const aa = alt8({ t: cert, v: a * Math.sqrt(b) }, [{ t: `${b}√${a}`, v: b * Math.sqrt(a), erro: 'trocou o que sai com o que fica na raiz' }, { t: `${a * a}√${b}`, v: a * a * Math.sqrt(b), erro: 'tirou da raiz sem extrair (a² sai como a)' }, { t: `${a}√${b * a}`, v: a * Math.sqrt(a * b), erro: 'deixou um fator sobrando dentro' }, { t: `√${a + b}`, v: Math.sqrt(a + b), erro: 'somou os fatores' }, { t: nD(k / 2), v: k / 2, erro: 'dividiu por 2' }]);
    return { ...aa, text: `Simplifique √${k}.`, meta: { k, modo: 'simp' }, chave: 'p9s' + k };
  }
  const x = pick([2, 3, 5, 6, 7, 10]), y = x * pick([4, 9]);
  const r = Math.sqrt(x * y);
  const aa = alt8(nv8(r), [{ t: nD(x * y), v: x * y, erro: 'multiplicou e esqueceu a raiz' }, { t: `√${x + y}`, v: Math.sqrt(x + y), erro: 'somou em vez de multiplicar' }, { t: nD(x + y), v: x + y, erro: 'somou os números' }], viz8(r));
  return { ...aa, text: `Calcule √${x} · √${y}. (√a · √b = √(a · b))`, meta: { expr: `√${x} · √${y}`, tipo: 'val' }, chave: 'p9m' + x + y };
};
C.pot9 = m => {
  if(m.modo === 'simp'){ let a = 1; for(let q = 2; q * q <= m.k; q++) if(m.k % (q * q) === 0) a = q; return `${a}√${m.k / (a * a)}`; }
  const v = ev8(m.expr);
  if(m.tipo === 'dec') return numTxt8(v);
  if(Math.abs(v - Math.round(v)) < 1e-9) return nD(Math.round(v));
  return fracDeVal8(v);
};

/* Notação científica em problemas (EF09MA04) */
const cn9 = (m, e) => `${nD(m)} × 10${sup8(e)}`;
G.cient9 = n => {
  const mant = () => pick([1.2, 1.5, 2, 2.5, 3, 4, 1.1, 2.2, 3.5]);
  if(n < 3){
    const op = n === 1 ? 'mult' : pick(['div', 'mult']);
    let a, b, e1, e2;
    if(op === 'mult'){ do{ a = mant(); b = pick([2, 3, 4]); } while(a * b >= 10 || !Number.isInteger(Math.round(a * b * 100))); e1 = n === 1 ? rnd(2, 8) : sortearAte(() => rnd(-6, 8), v => v !== 0); e2 = n === 1 ? rnd(2, 7) : sortearAte(() => rnd(-6, 6), v => v !== 0 && v !== -e1); }
    else { b = pick([2, 4, 5]); a = sortearAte(() => pick([2, 4, 5, 6, 8, 9]) * 1, v => v > b && Number.isInteger(v / b * 10)); e1 = rnd(3, 12); e2 = rnd(-4, 6); }
    const m = op === 'mult' ? Math.round(a * b * 100) / 100 : Math.round(a / b * 100) / 100, e = op === 'mult' ? e1 + e2 : e1 - e2;
    const expr = op === 'mult' ? `(${cn9(a, e1)}) × (${cn9(b, e2)})` : `(${cn9(a, e1)}) ÷ (${cn9(b, e2)})`;
    const val = m * Math.pow(10, e);
    const aa = alt8({ t: cn9(m, e), v: val }, [{ t: cn9(m, op === 'mult' ? e1 * e2 : e1 + e2), v: m * Math.pow(10, op === 'mult' ? e1 * e2 : e1 + e2), erro: op === 'mult' ? 'multiplicou os expoentes (na multiplicação, soma)' : 'somou os expoentes (na divisão, subtrai)' }, { t: cn9(op === 'mult' ? Math.round((a + b) * 100) / 100 : Math.round((a - b) * 100) / 100 || 1, e), v: (op === 'mult' ? a + b : (a - b) || 1) * Math.pow(10, e), erro: op === 'mult' ? 'somou os números da frente' : 'subtraiu os números da frente' }, { t: cn9(m, op === 'mult' ? e1 - e2 : e2 - e1), v: m * Math.pow(10, op === 'mult' ? e1 - e2 : e2 - e1), erro: 'errou a conta dos expoentes' }], [{ t: cn9(m, e + 1), v: val * 10, erro: 'errou a conta dos expoentes' }, { t: cn9(m, e - 1), v: val / 10, erro: 'errou a conta dos expoentes' }]);
    return { ...aa, text: `Calcule: ${expr}`, meta: { expr, m, e }, chave: 'cn9' + expr };
  }
  const ctx = pick([
    { t: (a, e1, q) => `Uma bactéria mede ${cn9(a, e1)} m. Enfileirando ${q} delas, qual o comprimento total, em metros?`, a: [2, 3, 4, 5], e1: [-6, -5, -4], q: [[2000, 2, 3], [3000, 3, 3], [2 * 10000, 2, 4]] },
    { t: (a, e1, q) => `Um grão de areia tem massa de ${cn9(a, e1)} g. Qual a massa de ${q} grãos, em gramas?`, a: [1.5, 2, 3], e1: [-4, -3], q: [[2000, 2, 3], [3000, 3, 3], [20000, 2, 4]] },
  ]);
  const a = pick(ctx.a), e1 = pick(ctx.e1), [q, qm, qe] = pick(ctx.q);
  let m = a * qm, e = e1 + qe; if(m >= 10){ m /= 10; e += 1; }
  m = Math.round(m * 100) / 100;
  const val = m * Math.pow(10, e);
  const qTxt = String(q).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const aa = alt8({ t: cn9(m, e), v: val }, [{ t: cn9(m, e1 * qe), v: m * Math.pow(10, e1 * qe), erro: 'multiplicou os expoentes' }, { t: cn9(m, e1 - qe), v: m * Math.pow(10, e1 - qe), erro: 'subtraiu os expoentes' }, { t: cn9(m, e + 1), v: val * 10, erro: 'errou a quantidade de zeros' }, { t: cn9(m, e - 1), v: val / 10, erro: 'errou a quantidade de zeros' }]);
  return { ...aa, text: ctx.t(a, e1, qTxt), meta: { expr: `${nD(a)} × 10^(${e1}) × ${q}`, m, e }, chave: 'cn9p' + a + e1 + q };
};
C.cient9 = m => { const v = ev8(m.expr), e = Math.floor(Math.log10(Math.abs(v)) + 1e-9), mt = Math.round(v / Math.pow(10, e) * 100) / 100; return cn9(mt, e); };

/* Porcentagens sucessivas (EF09MA05/ES) */
G.porcSuc9 = n => {
  const P = rnd(2, 40) * 50, p = pick([10, 20, 25, 30, 40, 50]), q = pick([10, 20, 25, 50]);
  if(n === 1){
    const f = P * (1 + p / 100) * (1 + q / 100);
    if(!Number.isInteger(f * 100)) return G.porcSuc9(n);
    const aa = alt8({ t: fmtR(Math.round(f * 100)), v: f }, [{ t: fmtR(Math.round(P * (1 + (p + q) / 100) * 100)), v: P * (1 + (p + q) / 100), erro: `somou ${p}% + ${q}% sobre o preço inicial (o 2º aumento é sobre o novo preço)` }, { t: fmtR(Math.round(P * (1 + p / 100) * 100)), v: P * (1 + p / 100), erro: 'fez só o primeiro aumento' }, { t: fmtR(Math.round((P + p + q) * 100)), v: P + p + q, erro: 'somou reais em vez de porcentagem' }], [10, -10, 5].map(k => ({ t: fmtR(Math.round((f + k) * 100)), v: f + k, erro: 'errou a conta' })));
    return { ...aa, text: `Um produto custava ${fmtR(P * 100)}. Teve aumento de ${p}% e, depois, outro aumento de ${q}% sobre o novo preço. Quanto passou a custar?`, meta: { expr: `${P} × (1 + ${p}/100) × (1 + ${q}/100)`, rs: 1 }, chave: `ps9a${P},${p},${q}` };
  }
  if(n === 2){
    const f = P * (1 + p / 100) * (1 - p / 100);
    const aa = alt8({ t: fmtR(Math.round(f * 100)), v: f }, [{ t: fmtR(P * 100), v: P, erro: 'achou que aumento e desconto iguais se anulam' }, { t: fmtR(Math.round(P * (1 + p / 100) * 100)), v: P * (1 + p / 100), erro: 'esqueceu o desconto' }, { t: fmtR(Math.round(P * (1 - p / 100) * 100)), v: P * (1 - p / 100), erro: 'esqueceu o aumento' }], [10, -10].map(k => ({ t: fmtR(Math.round((f + k) * 100)), v: f + k, erro: 'errou a conta' })));
    return { ...aa, text: `Um produto de ${fmtR(P * 100)} teve aumento de ${p}% e, no mês seguinte, desconto de ${p}% sobre o novo preço. Qual é o preço final?`, meta: { expr: `${P} × (1 + ${p}/100) × (1 − ${p}/100)`, rs: 1 }, chave: `ps9b${P},${p}` };
  }
  const tipo = pick(['aum', 'jur']);
  if(tipo === 'aum'){
    const tot = Math.round(((1 + p / 100) * (1 + q / 100) - 1) * 10000) / 100;
    const aa = alt8({ t: nD(tot) + '%', v: tot }, [{ t: (p + q) + '%', v: p + q, erro: 'somou as porcentagens' }, { t: nD(p * q / 100) + '%', v: p * q / 100, erro: 'multiplicou as porcentagens' }, { t: nD(Math.max(p, q)) + '%', v: Math.max(p, q), erro: 'ficou só com o maior aumento' }], [1, -1, 5].map(k => ({ t: nD(tot + k) + '%', v: tot + k, erro: 'errou a conta' })));
    return { ...aa, text: `Um preço teve dois aumentos seguidos: ${p}% e depois ${q}%. Qual foi o aumento TOTAL, em porcentagem?`, meta: { expr: `((1 + ${p}/100) × (1 + ${q}/100) − 1) × 100`, suf: '%' }, chave: `ps9c${p},${q}` };
  }
  const C0 = rnd(2, 20) * 100, j = pick([10, 20]), t = 2;
  const M = C0 * Math.pow(1 + j / 100, t);
  const aa = alt8({ t: fmtR(Math.round(M * 100)), v: M }, [{ t: fmtR(Math.round(C0 * (1 + j * t / 100) * 100)), v: C0 * (1 + j * t / 100), erro: 'fez juros simples (os juros do 2º mês são sobre o novo valor)' }, { t: fmtR(Math.round(C0 * (1 + j / 100) * 100)), v: C0 * (1 + j / 100), erro: 'calculou só um mês' }, { t: fmtR(Math.round(C0 * j * t / 100 * 100)), v: C0 * j * t / 100, erro: 'deu só os juros' }]);
  return { ...aa, text: `Uma dívida de ${fmtR(C0 * 100)} cresce ${j}% ao mês, sempre sobre o valor do mês anterior (juros compostos). Quanto será depois de 2 meses?`, meta: { expr: `${C0} × (1 + ${j}/100)²`, rs: 1 }, chave: `ps9j${C0},${j}` };
};
C.porcSuc9 = m => { const v = ev8(m.expr); return m.rs ? fmtR(Math.round(v * 100)) : nD(Math.round(v * 100) / 100) + m.suf; };

/* Razão entre grandezas diferentes: velocidade, densidade (EF09MA07) */
G.razao9 = n => {
  if(n === 1){
    const v = rnd(4, 24) * 5, t = rnd(2, 6), d = v * t;
    const aa = alt8({ t: v + ' km/h', v }, [{ t: nD(d * t) + ' km/h', v: d * t, erro: 'multiplicou em vez de dividir' }, { t: nD(d + t) + ' km/h', v: d + t, erro: 'somou' }, { t: nD(d - t) + ' km/h', v: d - t, erro: 'subtraiu' }], viz8(v, ' km/h', 5));
    return { ...aa, text: `Um ônibus percorreu ${d} km em ${t} horas. Qual foi a velocidade média? (velocidade = distância ÷ tempo)`, meta: { expr: `${d} / ${t}`, suf: ' km/h' }, chave: `rz9v${d},${t}` };
  }
  if(n === 2){
    const modo = pick(['tempo', 'dist', 'consumo']);
    if(modo === 'consumo'){
      const kmL = rnd(8, 16), L = rnd(3, 40), d = kmL * L;
      const aa = alt8({ t: kmL + ' km/L', v: kmL }, [{ t: nD(Math.round(L / d * 1000) / 1000) + ' km/L', v: Math.round(L / d * 1000) / 1000, erro: 'dividiu ao contrário' }, { t: nD(d * L) + ' km/L', v: d * L, erro: 'multiplicou' }, { t: nD(d - L) + ' km/L', v: d - L, erro: 'subtraiu' }], viz8(kmL, ' km/L'));
      return { ...aa, text: `Um carro rodou ${d} km gastando ${L} litros de combustível. Quantos km ele faz por litro?`, meta: { expr: `${d} / ${L}`, suf: ' km/L' }, chave: `rz9c${d},${L}` };
    }
    const v = rnd(4, 20) * 5, t = rnd(2, 8), d = v * t;
    if(modo === 'tempo'){
      const aa = alt8({ t: t + ' h', v: t }, [{ t: nD(d * v) + ' h', v: d * v, erro: 'multiplicou' }, { t: nD(Math.round(v / d * 100) / 100) + ' h', v: Math.round(v / d * 100) / 100, erro: 'dividiu ao contrário' }, { t: nD(d - v) + ' h', v: d - v, erro: 'subtraiu' }], viz8(t, ' h'));
      return { ...aa, text: `Um carro anda a ${v} km/h (velocidade constante). Quantas horas leva para percorrer ${d} km?`, meta: { expr: `${d} / ${v}`, suf: ' h' }, chave: `rz9t${d},${v}` };
    }
    const aa = alt8({ t: nD(d) + ' km', v: d }, [{ t: nD(v + t) + ' km', v: v + t, erro: 'somou' }, { t: nD(Math.round(v / t * 100) / 100) + ' km', v: Math.round(v / t * 100) / 100, erro: 'dividiu em vez de multiplicar' }, { t: nD(d * 10) + ' km', v: d * 10, erro: 'errou a conta' }], viz8(d, ' km', v));
    return { ...aa, text: `Um trem anda a ${v} km/h durante ${t} horas. Quantos km ele percorre?`, meta: { expr: `${v} × ${t}`, suf: ' km' }, chave: `rz9d${v},${t}` };
  }
  if(Math.random() < .5){
    const dens = rnd(2, 60) * 10, area = rnd(3, 90) * 10, pop = dens * area;
    const cidade = pick(['Vila Azul', 'Pedra Alta', 'Rio Claro', 'Monte Verde']);
    const aa = alt8({ t: nD(dens) + ' hab/km²', v: dens }, [{ t: nD(Math.round(area / pop * 10000) / 10000) + ' hab/km²', v: Math.round(area / pop * 10000) / 10000, erro: 'dividiu a área pela população' }, { t: nD(pop - area) + ' hab/km²', v: pop - area, erro: 'subtraiu' }, { t: nD(dens * 10) + ' hab/km²', v: dens * 10, erro: 'errou os zeros' }, { t: nD(dens / 10) + ' hab/km²', v: dens / 10, erro: 'errou os zeros' }]);
    return { ...aa, text: `A cidade de ${cidade} tem ${nD(pop)} habitantes e área de ${nD(area)} km². Qual é a densidade demográfica? (habitantes ÷ área)`, meta: { expr: `${pop} / ${area}`, suf: ' hab/km²' }, chave: `rz9h${pop},${area}` };
  }
  const d = pick([0.8, 1, 1.2, 2.5, 2.7, 7.8, 11.3, 19.3]), V = rnd(2, 20) * 5, m = Math.round(d * V * 10) / 10;
  const aa = alt8({ t: nD(d) + ' g/cm³', v: d }, [{ t: nD(Math.round(m * V)) + ' g/cm³', v: Math.round(m * V), erro: 'multiplicou' }, { t: nD(Math.round(V / m * 1000) / 1000) + ' g/cm³', v: Math.round(V / m * 1000) / 1000, erro: 'dividiu o volume pela massa' }, { t: nD(Math.round((m - V) * 10) / 10) + ' g/cm³', v: Math.round((m - V) * 10) / 10, erro: 'subtraiu' }].filter(e => e.v > 0), [{ t: nD(d * 10) + ' g/cm³', v: d * 10, erro: 'errou a vírgula' }, { t: nD(Math.round(d * 100) / 1000) + ' g/cm³', v: Math.round(d * 100) / 1000, erro: 'errou a vírgula' }, { t: nD(Math.round((d + 1) * 10) / 10) + ' g/cm³', v: Math.round((d + 1) * 10) / 10, erro: 'errou a conta' }]);
  return { ...aa, text: `Um objeto tem massa de ${nD(m)} g e volume de ${V} cm³. Qual é a densidade dele? (densidade = massa ÷ volume)`, meta: { expr: `${nD(m)} / ${V}`, suf: ' g/cm³' }, chave: `rz9m${m},${V}` };
};
C.razao9 = m => nD(Math.round(ev8(m.expr) * 1000) / 1000) + m.suf;

/* Escala e divisão em partes proporcionais (EF09MA08) */
G.escala9 = n => {
  if(n === 1){
    const esc = pick([1000, 5000, 10000, 20000, 50000, 100000]), cm = rnd(2, 12), real = cm * esc;     // cm
    const m = real / 100;
    const fmtD = cmv => cmv >= 100000 ? nD(cmv / 100000) + ' km' : nD(cmv / 100) + ' m';
    const aa = alt8({ t: fmtD(real), v: real }, [{ t: fmtD(real * 10), v: real * 10, erro: 'errou a conversão de unidades' }, { t: fmtD(real / 10), v: real / 10, erro: 'errou a conversão de unidades' }, { t: fmtD(real * 100), v: real * 100, erro: 'errou a conversão de unidades' }, { t: fmtD(real / 100), v: real / 100, erro: 'errou a conversão de unidades' }, { t: fmtD(esc), v: esc, erro: 'deu só o valor de 1 cm do mapa' }].filter(e => e.v > 0 && e.v !== real));
    return { ...aa, text: `Num mapa com escala 1 : ${nD(esc)}, dois pontos estão a ${cm} cm um do outro. Qual é a distância real? (1 cm no mapa = ${nD(esc)} cm no real)`, meta: { cm, esc }, chave: `es9${esc},${cm}` };
  }
  const partes = n === 2 ? [rnd(1, 4), rnd(2, 6)] : [rnd(1, 3), rnd(2, 4), rnd(3, 6)];
  if(new Set(partes).size < partes.length) return G.escala9(n);
  const soma = partes.reduce((a, b) => a + b, 0), total = soma * rnd(3, 40) * 10, qual = rnd(0, partes.length - 1);
  const certa = total / soma * partes[qual];
  const nomes = ['Ana', 'Beto', 'Caio'].slice(0, partes.length);
  const aa = alt8({ t: fmtR(certa * 100), v: certa }, [{ t: fmtR(Math.round(total / partes.length * 100)), v: total / partes.length, erro: 'dividiu em partes iguais' }, { t: fmtR(Math.round(total / partes[qual] * 100)), v: total / partes[qual], erro: 'dividiu pelo número da parte' }, { t: fmtR(total / soma * 100), v: total / soma, erro: 'deu o valor de UMA parte só' }, { t: fmtR(total * partes[qual] / 10 * 100), v: total * partes[qual] / 10, erro: 'errou a conta' }].filter(e => Math.abs(e.v * 100 - Math.round(e.v * 100)) < 1e-9), [10, -10, 20].map(k => ({ t: fmtR((certa + k) * 100), v: certa + k, erro: 'errou a conta' })));
  return { ...aa, text: `${nomes.join(', ').replace(/, ([^,]*)$/, ' e $1')} vão dividir ${fmtR(total * 100)} em partes proporcionais a ${partes.join(', ').replace(/, ([^,]*)$/, ' e $1')}, nessa ordem. Quanto recebe ${nomes[qual]}?`, meta: { partes, total, qual }, chave: `es9p${partes.join()}${total}${qual}` };
};
C.escala9 = m => {
  if(m.esc){ const real = m.cm * m.esc; return real >= 100000 ? nD(real / 100000) + ' km' : nD(real / 100) + ' m'; }
  // outro caminho: procura o valor de "uma parte" que fecha o total
  const soma = m.partes.reduce((a, b) => a + b, 0); for(let u = 1; u <= m.total; u++) if(u * soma === m.total) return fmtR(u * m.partes[m.qual] * 100); return null;
};

/* Ângulos entre paralelas cortadas por transversal (EF09MA10) */
const QUAD9 = ['TL', 'TR', 'BL', 'BR'];
const valAng9 = (q, th) => (q === 'TR' || q === 'BL') ? th : 180 - th;
function relacao9(p1, p2){                       // p = [i, q]; i = 0 (reta r, em cima) ou 1 (reta s)
  const [i1, q1] = p1, [i2, q2] = p2;
  if(i1 === i2) return q1[0] !== q2[0] && q1[1] !== q2[1] ? 'opostos pelo vértice' : 'adjacentes (suplementares)';
  const [a, b] = i1 === 0 ? [q1, q2] : [q2, q1];                 // a: em r ; b: em s
  if(a === b) return 'correspondentes';
  const intA = a[0] === 'B', intB = b[0] === 'T';               // internos: entre as retas
  if(intA && intB) return a[1] !== b[1] ? 'alternos internos' : 'colaterais internos';
  if(!intA && !intB) return a[1] !== b[1] ? 'alternos externos' : 'colaterais externos';
  return 'nenhuma relação especial';
}
function paralSVG9(th, marcas){
  const W = 480, H = 330, yr = 110, ys = 240, dx = (ys - yr) / Math.tan(th * Math.PI / 180), x1 = 250 + dx / 2, x2 = x1 - dx;
  const L = 95, c = Math.cos(th * Math.PI / 180), s = Math.sin(th * Math.PI / 180);
  let o = `<line x1="20" y1="${yr}" x2="${W - 30}" y2="${yr}" stroke="#1d4ed8" stroke-width="4"/><line x1="20" y1="${ys}" x2="${W - 30}" y2="${ys}" stroke="#1d4ed8" stroke-width="4"/>` + T(W - 14, yr + 7, 'r', { fs: 22, cor: '#1d4ed8' }) + T(W - 14, ys + 7, 's', { fs: 22, cor: '#1d4ed8' });
  o += `<line x1="${x2 - L * c}" y1="${ys + L * s}" x2="${x1 + L * c}" y2="${yr - L * s}" stroke="#111" stroke-width="3.5"/>` + T(x1 + L * c + 12, yr - L * s + 4, 't', { fs: 22 });
  const dir = { TR: th / 2, TL: (th + 180) / 2, BL: 180 + th / 2, BR: (180 + th + 360) / 2 };
  marcas.forEach(m => { const [xi, yi] = m.i === 0 ? [x1, yr] : [x2, ys], a = dir[m.q] * Math.PI / 180, R = m.q === 'TR' || m.q === 'BL' ? 46 : 36;
    o += `<circle cx="${xi}" cy="${yi}" r="5" fill="#111"/>` + T(xi + R * Math.cos(a), yi - R * Math.sin(a) + 8, m.txt, { fs: 22, cor: m.cor || '#b91c1c', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' }); });
  return SVG(W, H, o);
}
G.paral9 = n => {
  const th = rnd(35, 80), dado = [rnd(0, 1), pick(QUAD9)];
  let pede; do pede = [rnd(0, 1), pick(QUAD9)]; while((pede[0] === dado[0] && pede[1] === dado[1]) || relacao9(dado, pede) === 'nenhuma relação especial');
  const rel = relacao9(dado, pede);
  if(n === 1){
    const vd = valAng9(dado[1], th), vp = valAng9(pede[1], th);
    const aa = alt8({ t: vp + '°', v: vp }, [{ t: (180 - vp) + '°', v: 180 - vp, erro: vp === vd ? 'achou que são suplementares, mas são iguais' : 'achou que são iguais, mas somam 180°' }, { t: Math.abs(90 - vp) + '°', v: Math.abs(90 - vp), erro: 'usou 90° em vez de 180°' }, { t: (360 - vp) + '°', v: 360 - vp, erro: 'usou 360°' }], [{ t: (vp + 10) + '°', v: vp + 10, erro: 'mediu no olho' }, { t: (vp - 10) + '°', v: vp - 10, erro: 'mediu no olho' }]);
    return { ...aa, text: `As retas r e s são paralelas. Quanto mede o ângulo x?`, image: svgURI(paralSVG9(th, [{ i: dado[0], q: dado[1], txt: vd + '°', cor: '#1e3a8a' }, { i: pede[0], q: pede[1], txt: 'x' }])), meta: { th, dado, pede, modo: 'val' }, chave: `pa9${th}${dado}${pede}` };
  }
  if(n === 2){
    const nomes = ['correspondentes', 'alternos internos', 'alternos externos', 'colaterais internos', 'colaterais externos', 'opostos pelo vértice'];
    if(!nomes.includes(rel)) return G.paral9(n);
    const aa = alt8({ t: rel, v: null }, nomes.filter(x => x !== rel).map(x => ({ t: x, v: null, erro: 'confundiu os nomes: internos ficam entre as paralelas; alternos ficam em lados opostos da transversal' })));
    return { ...aa, text: 'As retas r e s são paralelas. Os ângulos marcados com a e b são:', image: svgURI(paralSVG9(th, [{ i: dado[0], q: dado[1], txt: 'a' }, { i: pede[0], q: pede[1], txt: 'b' }])), meta: { dado, pede, modo: 'nome' }, chave: `pa9n${dado}${pede}` };
  }
  // álgebra: os dois ângulos em função de x
  const vd = valAng9(dado[1], th), vp = valAng9(pede[1], th), iguais = vd === vp;
  const x = rnd(5, 30), a1 = rnd(2, 5), a2 = sortearAte(() => rnd(1, 6), v => v !== a1);
  const b1 = vd - a1 * x, b2 = vp - a2 * x;
  const ex = (a, b) => `${a}x ${b < 0 ? '−' : '+'} ${Math.abs(b)}`;
  if(Math.abs(b1) > 150 || Math.abs(b2) > 150 || b1 === 0 || b2 === 0) return G.paral9(n);
  const errX = iguais ? (180 - b1 - b2) / (a1 + a2) : (b2 - b1) / (a1 - a2);
  const aa = alt8(nv8(x), [Number.isInteger(errX) && errX > 0 && { t: nD(errX), v: errX, erro: iguais ? 'somou os ângulos como se fossem suplementares' : 'igualou ângulos que somam 180°' }, { t: nD(vd), v: vd, erro: 'deu a medida do ângulo, não o x' }, { t: nD(vp), v: vp, erro: 'deu a medida do ângulo, não o x' }], viz8(x));
  return { ...aa, text: `As retas r e s são paralelas. Qual é o valor de x?`, image: svgURI(paralSVG9(th, [{ i: dado[0], q: dado[1], txt: ex(a1, b1), cor: '#1e3a8a' }, { i: pede[0], q: pede[1], txt: ex(a2, b2) }])), meta: { dado, pede, e1: ex(a1, b1), e2: ex(a2, b2), modo: 'alg' }, chave: `pa9a${ex(a1, b1)}${ex(a2, b2)}${dado}${pede}` };
};
C.paral9 = m => {
  if(m.modo === 'nome') return relacao9(m.dado, m.pede);
  // valor / álgebra: iguais se (TR/BL) nos dois ou (TL/BR) nos dois; senão somam 180
  const grupo = q => (q === 'TR' || q === 'BL') ? 1 : 2, iguais = grupo(m.dado[1]) === grupo(m.pede[1]);
  if(m.modo === 'val'){ const raios = { TR: [0, m.th], TL: [m.th, 180], BL: [180, 180 + m.th], BR: [180 + m.th, 360] }[m.pede[1]]; return (raios[1] - raios[0]) + '°'; }
  if(m.modo === 'alg'){ for(let x = 0; x <= 200; x++){ const u = ev8(m.e1, { x }), w = ev8(m.e2, { x }); if(iguais ? u === w : u + w === 180) return nD(x); } return null; }
  return null;
};

/* Teorema de Tales (EF09MA14/ES) */
function talesSVG9(labs, g1, g2){                // labs: [a, b, c, d] textos; g1, g2: tamanhos relativos dos vãos
  const y0 = 50, k = 200 / (g1 + g2), y1 = y0 + g1 * k, y2 = y1 + g2 * k;
  const L = (y, x0, x2) => x0 + (x2 - x0) * (y - y0) / (y2 - y0);
  const ax0 = 90, ax2 = 150, bx0 = 300, bx2 = 420;
  let o = '';
  [y0, y1, y2].forEach((y, i) => { o += `<line x1="20" y1="${y}" x2="480" y2="${y}" stroke="#1d4ed8" stroke-width="3.5"/>` + T(495, y + 7, ['a', 'b', 'c'][i], { fs: 20, cor: '#1d4ed8' }); });
  o += `<line x1="${ax0 - 10}" y1="${y0 - 25}" x2="${ax2 + 10}" y2="${y2 + 25}" stroke="#111" stroke-width="3"/><line x1="${bx0 - 15}" y1="${y0 - 25}" x2="${bx2 + 15}" y2="${y2 + 25}" stroke="#111" stroke-width="3"/>`;
  const lab = (x, y, t) => T(x, y, t, { fs: 22, cor: '#b91c1c', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' });
  o += lab(L((y0 + y1) / 2, ax0, ax2) - 30, (y0 + y1) / 2 + 8, labs[0]) + lab(L((y1 + y2) / 2, ax0, ax2) - 30, (y1 + y2) / 2 + 8, labs[1]);
  o += lab(L((y0 + y1) / 2, bx0, bx2) + 40, (y0 + y1) / 2 + 8, labs[2]) + lab(L((y1 + y2) / 2, bx0, bx2) + 40, (y1 + y2) / 2 + 8, labs[3]);
  return SVG(520, y2 + 50, o);
}
G.tales9 = n => {
  let a, b, c, d;
  do{ a = rnd(2, 9); b = rnd(2, 12); c = rnd(2, 12); d = b * c / a; } while(!Number.isInteger(d) || a === b || d > 40);
  if(n < 3){
    const seg = [a, b, c, d], pos = n === 1 ? 3 : rnd(0, 3), certa = seg[pos];
    const labs = seg.map((v, i) => i === pos ? 'x' : v + ' cm');
    // erros: proporção montada errada
    const outros = seg.filter((_, i) => i !== pos);
    const e1 = pos === 3 ? a * c / b : pos === 2 ? d * b / a : pos === 1 ? a * d / c : b * c / d;       // "cruzou" errado
    const e2 = pos === 3 ? c + (b - a) : null;
    const aa = alt8(nv8(certa, ' cm'), [Number.isInteger(e1) && e1 !== certa && { t: nD(e1) + ' cm', v: e1, erro: 'montou a proporção trocando os segmentos' }, e2 !== null && e2 > 0 && { t: nD(e2) + ' cm', v: e2, erro: 'somou a diferença em vez de usar a proporção' }, { t: nD(outros[0]) + ' cm', v: outros[0], erro: 'copiou outro segmento' }], viz8(certa, ' cm'));
    return { ...aa, text: 'As retas a, b e c são paralelas. Quanto mede x? (Tales: os segmentos são proporcionais)', image: svgURI(talesSVG9(labs, a, b)), meta: { seg: labs, modo: 'seg' }, chave: `ta9${seg}${pos}` };
  }
  // álgebra: a/b = x/(x + m)
  let x, m; do{ a = rnd(2, 8); b = rnd(a + 1, 14); m = rnd(1, 8); x = a * m / (b - a); } while(!Number.isInteger(x) || x < 2 || x > 30);
  const labs = [a + ' cm', b + ' cm', 'x', `x + ${m}`];
  const aa = alt8(nv8(x), [{ t: nD(x + m), v: x + m, erro: 'deu a medida do segmento x + ' + m }, { t: nD(b - a), v: b - a, erro: 'subtraiu os segmentos' }, Number.isInteger(b * m / (b - a)) && { t: nD(b * m / (b - a)), v: b * m / (b - a), erro: 'montou a proporção trocando os segmentos' }], viz8(x));
  return { ...aa, text: 'As retas a, b e c são paralelas. Qual é o valor de x?', image: svgURI(talesSVG9(labs, a, b)), meta: { seg: labs, modo: 'alg' }, chave: `ta9a${a},${b},${m}` };
};
C.tales9 = m => {
  const L = m.seg.map(s => s.replace(' cm', ''));
  for(let x = 1; x <= 400; x++){ const v = L.map(s => ev8(s, { x })); if(Math.abs(v[0] * v[3] - v[1] * v[2]) < 1e-9) return m.modo === 'alg' ? nD(x) : nD(x) + ' cm'; }
  return null;
};

/* ============================ 2º TRIMESTRE ============================ */

/* Gráfico de colunas: leitura, média e porcentagem (EF09MA22 · EF09MA23) */
function barras9(cats, vals, titulo, passo){
  const top = Math.ceil(Math.max(...vals) / passo) * passo, H = 340, base = 290, alt = 230, cw = 70, X0 = 70, W = X0 + 20 + cats.length * (cw + 22);
  const Y = v => base - v / top * alt;
  let o = T(W / 2, 28, titulo, { fs: 20 });
  for(let v = 0; v <= top; v += passo) o += `<line x1="${X0}" y1="${Y(v)}" x2="${W - 10}" y2="${Y(v)}" stroke="#d4d4d8" stroke-width="1.5"/>` + T(X0 - 8, Y(v) + 7, v, { fs: 18, anc: 'end' });
  o += `<line x1="${X0}" y1="${base}" x2="${W - 10}" y2="${base}" stroke="#111" stroke-width="3"/><line x1="${X0}" y1="${base}" x2="${X0}" y2="${Y(top)}" stroke="#111" stroke-width="3"/>`;
  cats.forEach((c, i) => { const x = X0 + 18 + i * (cw + 22); o += `<rect x="${x}" y="${Y(vals[i])}" width="${cw}" height="${base - Y(vals[i])}" fill="#3b82f6" stroke="#111" stroke-width="2"/>` + T(x + cw / 2, base + 26, c, { fs: 18 }); });
  return SVG(W, H, o);
}
G.graf9 = n => {
  const ctx = pick([{ t: 'Livros lidos por turma', c: ['9ºA', '9ºB', '9ºC', '9ºD', '9ºE'] }, { t: 'Vendas da cantina (lanches)', c: ['Seg', 'Ter', 'Qua', 'Qui', 'Sex'] }, { t: 'Chuva por mês (mm)', c: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai'] }]);
  const k = n === 1 ? 4 : 5, passo = pick([5, 10]), cats = ctx.c.slice(0, k);
  let vals;
  if(n === 3){ const tot = pick([50, 100, 200]) * (passo / 5); vals = sortearAte(() => { const v = cats.map(() => rnd(1, 8) * passo); return v; }, v => v.reduce((a, b) => a + b) === tot || false, 400); if(vals.reduce((a, b) => a + b) !== tot){ vals = [2, 3, 4, 5, 6].slice(0, k).map(x => x * passo); } }
  else vals = sortearAte(() => cats.map(() => rnd(1, 9) * passo), v => new Set(v).size === v.length && (n !== 2 || Number.isInteger(v.reduce((a, b) => a + b) / v.length)));
  const img = svgURI(barras9(cats, vals, ctx.t, passo)), soma = vals.reduce((a, b) => a + b), mx = Math.max(...vals), mn = Math.min(...vals);
  if(n === 1){
    const aa = alt8(nv8(mx - mn), [{ t: nD(mx), v: mx, erro: 'deu só o maior valor' }, { t: nD(mx + mn), v: mx + mn, erro: 'somou' }, { t: nD(vals[vals.length - 1] - vals[0] > 0 ? vals[vals.length - 1] - vals[0] : vals[0] - vals[vals.length - 1]), v: Math.abs(vals[vals.length - 1] - vals[0]), erro: 'usou a última e a primeira coluna' }], viz8(mx - mn, '', passo));
    return { ...aa, text: 'Qual é a diferença entre o maior e o menor valor do gráfico?', image: img, meta: { vals, modo: 'dif' }, chave: 'gf9d' + vals };
  }
  if(n === 2){
    const md = soma / vals.length;
    const aa = alt8(nv8(md), [{ t: nD(soma), v: soma, erro: 'somou e esqueceu de dividir' }, { t: nD(Math.round(soma / (vals.length - 1) * 10) / 10), v: Math.round(soma / (vals.length - 1) * 10) / 10, erro: 'dividiu pela quantidade errada' }, { t: nD(mediana8(vals)), v: mediana8(vals), erro: 'calculou a mediana' }, { t: nD((mx + mn) / 2), v: (mx + mn) / 2, erro: 'fez a média só do maior e do menor' }], viz8(md, '', passo / 5));
    return { ...aa, text: 'Qual é a MÉDIA dos valores do gráfico?', image: img, meta: { vals, modo: 'media' }, chave: 'gf9m' + vals };
  }
  const i = rnd(0, k - 1), pc = vals[i] * 100 / soma;
  const aa = alt8({ t: nD(Math.round(pc * 10) / 10) + '%', v: Math.round(pc * 10) / 10 }, [{ t: nD(vals[i]) + '%', v: vals[i], erro: 'deu o valor, não a porcentagem' }, { t: nD(Math.round(100 / k * 10) / 10) + '%', v: Math.round(100 / k * 10) / 10, erro: 'dividiu 100% igualmente entre as colunas' }, { t: nD(Math.round(vals[i] * 100 / mx * 10) / 10) + '%', v: Math.round(vals[i] * 100 / mx * 10) / 10, erro: 'comparou com a maior coluna, não com o total' }], [5, -5, 10].map(q => pc + q > 0 && { t: nD(Math.round((pc + q) * 10) / 10) + '%', v: Math.round((pc + q) * 10) / 10, erro: 'errou a conta' }));
  return { ...aa, text: `O total do gráfico é ${soma}. Que porcentagem do total é o valor de ${cats[i]}?`, image: img, meta: { vals, i, modo: 'pct' }, chave: 'gf9p' + vals + i };
};
C.graf9 = m => {
  const v = m.vals; let s = 0; v.forEach(x => s += x);
  if(m.modo === 'dif'){ let a = v[0], b = v[0]; v.forEach(x => { if(x > a) a = x; if(x < b) b = x; }); return nD(a - b); }
  if(m.modo === 'media') return nD(s / v.length);
  return nD(Math.round(v[m.i] / s * 1000) / 10) + '%';
};

/* Eventos dependentes e independentes (EF09MA20) */
G.prob9 = n => {
  const az = rnd(2, 6), vm = rnd(2, 6), tot = az + vm;
  const cor1 = n === 3 ? 'AZUL' : 'AZUL', cor2 = n === 3 ? 'VERMELHA' : 'AZUL';
  const rep = n === 1;
  const p1 = az / tot, p2 = rep ? (cor2 === 'AZUL' ? az / tot : vm / tot) : (cor2 === 'AZUL' ? (az - 1) / (tot - 1) : vm / (tot - 1));
  const certa = p1 * p2;
  const semRep = cor2 === 'AZUL' ? az * (az - 1) / (tot * (tot - 1)) : az * vm / (tot * (tot - 1));
  const comRep = cor2 === 'AZUL' ? az * az / (tot * tot) : az * vm / (tot * tot);
  const aa = alt8({ t: fracDeVal8(certa), v: certa }, [{ t: fracDeVal8(rep ? semRep : comRep), v: rep ? semRep : comRep, erro: rep ? 'tirou uma bola da urna, mas ela foi devolvida (independentes)' : 'esqueceu que a 1ª bola NÃO volta (a urna fica com uma a menos)' }, { t: fracDeVal8(Math.min(p1 + p2, 2)), v: Math.min(p1 + p2, 2), erro: 'somou as chances em vez de multiplicar' }, { t: fracDeVal8(p1), v: p1, erro: 'calculou só a 1ª retirada' }, { t: fracDeVal8((cor2 === 'AZUL' ? 2 * az : az + vm) / (2 * tot)), v: (cor2 === 'AZUL' ? 2 * az : az + vm) / (2 * tot), erro: 'somou as bolas em vez de multiplicar as chances' }].filter(e => e.v <= 1), [{ t: fracDeVal8(1 - certa), v: 1 - certa, erro: 'calculou a chance do contrário' }, { t: fracDeVal8(az / (tot * tot)), v: az / (tot * tot), erro: 'errou o numerador' }]);
  const txt = `Uma urna tem ${az} bolas azuis e ${vm} vermelhas. Tiramos uma bola ${rep ? 'e DEVOLVEMOS' : 'e NÃO devolvemos'}; depois tiramos outra. Qual a chance de a 1ª ser ${cor1} e a 2ª ser ${cor2}?`;
  return { ...aa, text: txt, meta: { az, vm, rep, cor2 }, chave: `pb9${az},${vm},${rep}${cor2}` };
};
C.prob9 = m => {                                 // força bruta: todas as retiradas ordenadas
  const bolas = [...Array(m.az).fill('A'), ...Array(m.vm).fill('V')]; let f = 0, t = 0;
  bolas.forEach((b1, i) => bolas.forEach((b2, j) => { if(!m.rep && i === j) return; t++; if(b1 === 'A' && b2 === (m.cor2 === 'AZUL' ? 'A' : 'V')) f++; }));
  return fr8(f, t);
};

/* Produtos notáveis (EF08MA06/ES) */
G.prodNot9 = n => {
  const a = rnd(1, 9), X = 1.37;
  const pX = (c2, c1, c0) => { let s = (c2 === 1 ? '' : nD(c2)) + 'x²'; if(c1) s += ` ${c1 < 0 ? '−' : '+'} ${Math.abs(c1) === 1 ? '' : Math.abs(c1)}x`; if(c0) s += ` ${c0 < 0 ? '−' : '+'} ${Math.abs(c0)}`; return s; };
  const mk = (t, e) => ({ t, v: ev8(t, { x: X }), erro: e });
  let expr, cert, err;
  if(n === 1){ expr = `(x + ${a})²`; cert = pX(1, 2 * a, a * a); err = [mk(pX(1, 0, a * a), 'esqueceu o termo do meio (2 · x · a)'), mk(pX(1, a, a * a), 'fez o termo do meio sem o 2'), mk(pX(1, 2 * a, 2 * a), 'dobrou o último termo em vez de elevar ao quadrado'), mk(pX(1, 0, -a * a), 'confundiu com o produto da soma pela diferença')]; }
  else if(n === 2){
    if(Math.random() < .5){ expr = `(x − ${a})²`; cert = pX(1, -2 * a, a * a); err = [mk(pX(1, 0, -a * a), 'confundiu com o produto da soma pela diferença'), mk(pX(1, 2 * a, a * a), 'errou o sinal do termo do meio'), mk(pX(1, -2 * a, -a * a), 'errou o sinal do último termo (a² é sempre positivo)'), mk(pX(1, 0, a * a), 'esqueceu o termo do meio')]; }
    else { expr = `(x + ${a})(x − ${a})`; cert = pX(1, 0, -a * a); err = [mk(pX(1, 0, a * a), 'errou o sinal: (x + a)(x − a) = x² − a²'), mk(pX(1, 2 * a, -a * a), 'inventou um termo do meio'), mk(pX(1, -2 * a, a * a), 'fez como (x − a)²'), mk(`x² − ${2 * a}`, 'multiplicou por 2 em vez de elevar')]; }
  } else {
    const k = rnd(2, 5), b = rnd(1, 7), sn = pick([1, -1]);
    expr = `(${k}x ${sn > 0 ? '+' : '−'} ${b})²`; cert = pX(k * k, 2 * k * b * sn, b * b);
    err = [mk(pX(k, 2 * k * b * sn, b * b), `esqueceu de elevar o ${k} ao quadrado`), mk(pX(k * k, 0, b * b), 'esqueceu o termo do meio'), mk(pX(k * k, k * b * sn, b * b), 'fez o termo do meio sem o 2'), mk(pX(k * k, 2 * b * sn, b * b), `esqueceu o ${k} no termo do meio`)];
  }
  const aa = alt8({ t: cert, v: ev8(cert, { x: X }) }, err);
  return { ...aa, text: `Desenvolva: ${expr}`, meta: { expr, opts: aa.options }, chave: 'pn9' + expr };
};
C.prodNot9 = m => m.opts.find(t => [0.7, 1.3, 2.9].every(x => Math.abs(ev8(t, { x }) - ev8(m.expr, { x })) < 1e-9)) || null;

/* Fatoração (EF09MA09) */
G.fator9 = n => {
  const X = [1.37, 2.41];
  const mk = (t, e) => ({ t, v: ev8(t, { x: X[0] }), erro: e });
  let expr, cert, err;
  if(n === 1 && Math.random() < .4){ const k = rnd(2, 3), a = sortearAte(() => rnd(1, 9), v => v % k !== 0); expr = `${k * k}x² − ${a * a}`; cert = `(${k}x + ${a})(${k}x − ${a})`; err = [mk(`(${k * k}x + ${a})(${k * k}x − ${a})`, `não tirou a raiz de ${k * k}`), mk(`(${k}x − ${a})²`, 'confundiu com o quadrado da diferença'), mk(`(${k}x + ${a * a})(${k}x − 1)`, `não tirou a raiz de ${a * a}`), mk(`(${k}x + ${a})²`, 'confundiu com o quadrado da soma')]; }
  else if(n === 1){ const a = rnd(2, 12); expr = `x² − ${a * a}`; cert = `(x + ${a})(x − ${a})`; err = [mk(`(x − ${a})²`, 'confundiu com o quadrado da diferença'), mk(`(x + ${a})²`, 'confundiu com o quadrado da soma'), mk(`(x − ${a * a})(x + 1)`, 'não tirou a raiz de ' + a * a), mk(`x(x − ${a})`, 'colocou x em evidência sem ele estar nos dois termos')]; }
  else if(n === 2){ const a = rnd(1, 9), sn = pick([1, -1]); expr = `x² ${sn > 0 ? '+' : '−'} ${2 * a}x + ${a * a}`; cert = `(x ${sn > 0 ? '+' : '−'} ${a})²`; err = [mk(`(x ${sn > 0 ? '−' : '+'} ${a})²`, 'errou o sinal'), mk(`(x + ${a})(x − ${a})`, 'confundiu com a diferença de quadrados'), mk(`(x ${sn > 0 ? '+' : '−'} ${2 * a})²`, 'usou o termo do meio em vez da raiz do último'), mk(`x(x ${sn > 0 ? '+' : '−'} ${2 * a}) + ${a * a}`, 'fatorou só uma parte')]; }
  else {
    let r1, r2; do{ r1 = rnd(1, 9) * pick([1, -1]); r2 = rnd(1, 9) * pick([1, -1]); } while(r1 === r2 || r1 === -r2);
    const S = -(r1 + r2), P = r1 * r2;                         // x² + Sx + P = (x − r1)(x − r2)
    const f = r => `(x ${-r < 0 ? '−' : '+'} ${Math.abs(r)})`;
    expr = `x²${S ? ` ${S < 0 ? '−' : '+'} ${Math.abs(S) === 1 ? '' : Math.abs(S)}x` : ''} ${P < 0 ? '−' : '+'} ${Math.abs(P)}`;
    cert = f(r1) + f(r2);
    err = [mk(f(-r1) + f(-r2), 'errou os sinais'), mk(f(r1) + f(-r2), 'errou um dos sinais'), mk(f(-r1) + f(r2), 'errou um dos sinais'), mk(`(x ${S < 0 ? '−' : '+'} ${Math.abs(S)})(x ${P < 0 ? '−' : '+'} ${Math.abs(P)})`, 'usou a soma e o produto direto nos parênteses')];
  }
  const aa = alt8({ t: cert, v: ev8(cert, { x: X[0] }) }, err);
  return { ...aa, text: `Fatore: ${expr}`, meta: { expr, opts: aa.options }, chave: 'ft9' + expr };
};
C.fator9 = m => m.opts.find(t => /^\(/.test(t) && !/\) \+/.test(t) && [0.7, 1.3, 2.9].every(x => Math.abs(ev8(t, { x }) - ev8(m.expr, { x })) < 1e-9)) || null;

/* Equação do 2º grau (EF09MA26/ES) */
const raizesTxt9 = (r1, r2) => { const [a, b] = [r1, r2].sort((p, q) => p - q); return a === b ? `x = ${nD(a)}` : `x = ${nD(a)} e x = ${nD(b)}`; };
G.eq2g9 = n => {
  if(n === 1){
    const a = rnd(1, 3), r = sortearAte(() => rnd(-9, 9), v => v !== 0);
    const forma = `${a === 1 ? '' : a}x² ${-a * r < 0 ? '−' : '+'} ${Math.abs(a * r) === 1 ? '' : Math.abs(a * r)}x = 0`;
    const aa = alt8({ t: raizesTxt9(0, r), v: null }, [{ t: `x = ${nD(r)}`, v: null, erro: 'dividiu por x e perdeu a raiz x = 0' }, { t: raizesTxt9(0, -r), v: null, erro: 'errou o sinal' }, { t: raizesTxt9(0, a * r), v: null, erro: `esqueceu de dividir por ${a}` }, { t: raizesTxt9(r, -r), v: null, erro: 'resolveu como x² = r²' }].filter(e => e.t !== raizesTxt9(0, r)), [{ t: raizesTxt9(0, r + 1), v: null, erro: 'errou a conta' }]);
    return { ...aa, text: `Resolva: ${forma}  (coloque x em evidência)`, meta: { forma }, chave: 'e29a' + forma };
  }
  if(n === 2){
    let r1, r2; do{ r1 = rnd(-8, 9); r2 = rnd(-8, 9); } while(r1 === r2 || !r1 || !r2 || r1 === -r2);
    const S = r1 + r2, P = r1 * r2;
    const forma = `x² ${-S < 0 ? '−' : '+'} ${Math.abs(S) === 1 ? '' : Math.abs(S)}x ${P < 0 ? '−' : '+'} ${Math.abs(P)} = 0`;
    const aa = alt8({ t: raizesTxt9(r1, r2), v: null }, [{ t: raizesTxt9(-r1, -r2), v: null, erro: 'trocou os sinais das raízes (soma = −b/a)' }, { t: raizesTxt9(r1, -r2), v: null, erro: 'errou o sinal de uma raiz' }, { t: raizesTxt9(-r1, r2), v: null, erro: 'errou o sinal de uma raiz' }, { t: raizesTxt9(S, P), v: null, erro: 'deu a soma e o produto em vez das raízes' }].filter(e => e.t !== raizesTxt9(r1, r2)));
    return { ...aa, text: `Resolva: ${forma}  (procure dois números com soma ${nD(S)} e produto ${nD(P)})`, meta: { forma }, chave: 'e29b' + forma };
  }
  if(Math.random() < .5){
    const x = rnd(3, 15), m = rnd(1, 8), A = x * (x + m);
    const aa = alt8({ t: `${x} m`, v: x }, [{ t: `${x + m} m`, v: x + m, erro: 'deu o comprimento, não a largura' }, { t: `${nD(Math.round(Math.sqrt(A) * 10) / 10)} m`, v: Math.round(Math.sqrt(A) * 10) / 10, erro: 'tirou a raiz da área (como se fosse quadrado)' }, { t: `${nD(A / 2)} m`, v: A / 2, erro: 'dividiu a área por 2' }, { t: `${x + 1} m`, v: x + 1, erro: 'errou a conta' }]);
    return { ...aa, text: `Um terreno retangular tem área de ${A} m². O comprimento tem ${m} m a mais que a largura. Qual é a largura? (x · (x + ${m}) = ${A})`, meta: { forma: `x² + ${m}x = ${A}`, pos: ' m' }, chave: `e29t${x},${m}` };
  }
  const tipo = pick([0, 1, 2]);                   // 0: Δ > 0 ; 1: Δ = 0 ; 2: Δ < 0
  let b, c; do{ b = rnd(-8, 8); c = rnd(-9, 16); } while(tipo === 0 ? b * b - 4 * c <= 0 : tipo === 1 ? b * b - 4 * c !== 0 : b * b - 4 * c >= 0);
  const D = b * b - 4 * c;
  const forma = `x²${b ? ` ${b < 0 ? '−' : '+'} ${Math.abs(b) === 1 ? '' : Math.abs(b)}x` : ''}${c ? ` ${c < 0 ? '−' : '+'} ${Math.abs(c)}` : ''} = 0`;
  const R = ['Duas raízes reais diferentes', 'Uma raiz real (duas iguais)', 'Nenhuma raiz real'];
  const aa = alt8({ t: R[tipo], v: null }, R.filter((_, i) => i !== tipo).map(t => ({ t, v: null, erro: 'errou o sinal do delta (Δ = b² − 4ac): Δ > 0 duas raízes, Δ = 0 uma, Δ < 0 nenhuma' })).concat([{ t: 'Três raízes reais', v: null, erro: 'equação do 2º grau tem no máximo 2 raízes' }]));
  return { ...aa, text: `Quantas raízes reais tem ${forma}? (Δ = b² − 4ac = ${nD(D)})`, meta: { forma, delta: 1 }, chave: 'e29d' + forma };
};
C.eq2g9 = m => {                                 // procura as raízes por tentativa numérica fina
  const [l, r] = m.forma.split('='), f = x => ev8(l, { x }) - ev8(r, { x });
  if(m.delta){ const f0 = f(0), f1 = f(1), fm = f(-1), a2 = (f1 + fm - 2 * f0) / 2, a1 = (f1 - fm) / 2, mn = f0 - a1 * a1 / (4 * a2); return mn < -1e-6 ? 'Duas raízes reais diferentes' : mn > 1e-6 ? 'Nenhuma raiz real' : 'Uma raiz real (duas iguais)'; }
  const raizes = []; for(let x = -60; x <= 60; x += 0.5) if(Math.abs(f(x)) < 1e-9) raizes.push(x);
  if(m.pos) return raizes.filter(x => x > 0).map(x => nD(x) + m.pos)[0];
  return raizes.length === 1 ? `x = ${nD(raizes[0])}` : `x = ${nD(raizes[0])} e x = ${nD(raizes[1])}`;
};

/* Semelhança de triângulos (EF09MA12) */
function triPts9(a, b, c, esc, x0, y0){           // lados a (base), b (esquerdo), c (direito); base horizontal
  const cosA = (a * a + b * b - c * c) / (2 * a * b), ang = Math.acos(cosA);
  return [[x0, y0], [x0 + a * esc, y0], [x0 + b * esc * Math.cos(ang), y0 - b * esc * Math.sin(ang)]];
}
function semelhSVG9(lados, k, labsP, labsG){
  const [a, b, c] = lados, esc = Math.min(110 / (a), 90 / (Math.max(b, c)));
  const P = triPts9(a, b, c, esc, 50, 200), G2 = triPts9(a, b, c, esc * Math.min(k, 2.2), 250, 200);
  const poly = (p, cor) => `<polygon points="${p.map(q => q.map(v => v.toFixed(1)).join(',')).join(' ')}" fill="${cor}" stroke="#111" stroke-width="3"/>`;
  let o = poly(P, '#fde68a') + poly(G2, '#bfdbfe');
  [[P, labsP], [G2, labsG]].forEach(([p, l]) => {
    const gx = (p[0][0] + p[1][0] + p[2][0]) / 3, gy = (p[0][1] + p[1][1] + p[2][1]) / 3;
    [[0, 1, l[0]], [0, 2, l[1]], [1, 2, l[2]]].forEach(([i, j, t]) => { const mx = (p[i][0] + p[j][0]) / 2, my = (p[i][1] + p[j][1]) / 2, d = Math.hypot(mx - gx, my - gy) || 1;
      o += T(mx + (mx - gx) / d * 24, my + (my - gy) / d * 24 + 7, t, { fs: 20, cor: '#b91c1c', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' }); });
  });
  const W = Math.max(...G2.map(q => q[0])) + 50;
  return SVG(Math.max(W, 440), 240, o);
}
const TRI9 = [[5, 4, 3], [6, 4, 5], [6, 5, 5], [5, 5, 4], [8, 6, 5], [7, 5, 5], [6, 6, 5], [4, 4, 3], [6, 5, 4]];
G.semelh9 = n => {
  if(n === 3 && Math.random() < .5){
    const h = rnd(1, 3) + pick([0, 0.5]), s = pick([1, 1.5, 2, 2.5, 3]), S = s * rnd(3, 12), H = h * S / s;
    if(!Number.isInteger(H * 10) || H > 60) return G.semelh9(n);
    const aa = alt8({ t: nD(H) + ' m', v: H }, [{ t: nD(Math.round(S * s / h * 10) / 10) + ' m', v: Math.round(S * s / h * 10) / 10, erro: 'montou a proporção ao contrário' }, { t: nD(S + (h - s)) + ' m', v: S + (h - s), erro: 'somou a diferença' }, { t: nD(S) + ' m', v: S, erro: 'achou que altura = sombra' }], viz8(H, ' m'));
    return { ...aa, text: `No mesmo horário, um poste de ${nD(h)} m faz sombra de ${nD(s)} m, e um prédio faz sombra de ${nD(S)} m. Qual é a altura do prédio? (os triângulos são semelhantes)`, meta: { expr: `${nD(h)} × ${nD(S)} / ${nD(s)}`, suf: ' m' }, chave: `sm9s${h},${s},${S}` };
  }
  const L = pick(TRI9), k = n === 1 ? rnd(2, 3) : pick([1.5, 2.5, 2, 3, 4]);
  const G3 = L.map(v => v * k);
  if(!G3.every(v => Number.isInteger(v * 10))) return G.semelh9(n);
  const pos = rnd(0, 2);
  const labsP = L.map(v => v + ' cm'), labsG = G3.map((v, i) => i === pos ? 'x' : nD(v) + ' cm');
  if(n === 3){                                     // pergunta a razão ou o perímetro
    if(Math.random() < .5){
      const pP = L.reduce((a, b) => a + b), pG = pP * k;
      const aa = alt8({ t: nD(pG) + ' cm', v: pG }, [{ t: nD(pP + k) + ' cm', v: pP + k, erro: 'somou a razão' }, { t: nD(pP * k * k) + ' cm', v: pP * k * k, erro: 'multiplicou pela razão ao quadrado (isso é da área)' }, { t: nD(pP) + ' cm', v: pP, erro: 'deu o perímetro do menor' }], viz8(pG, ' cm'));
      return { ...aa, text: `Os triângulos são semelhantes e a razão de semelhança (grande ÷ pequeno) é ${nD(k)}. O pequeno tem lados ${L.join(', ')} cm. Qual é o perímetro do grande?`, meta: { expr: `(${L.join(' + ')}) × ${nD(k)}`, suf: ' cm' }, chave: `sm9p${L},${k}` };
    }
  }
  const outro = (pos + 1) % 3;
  const aa = alt8({ t: nD(G3[pos]) + ' cm', v: G3[pos] }, [{ t: nD(L[pos] + (G3[outro] - L[outro])) + ' cm', v: L[pos] + (G3[outro] - L[outro]), erro: 'somou a diferença em vez de multiplicar pela razão' }, { t: nD(Math.round(L[pos] * L[outro] / G3[outro] * 10) / 10) + ' cm', v: Math.round(L[pos] * L[outro] / G3[outro] * 10) / 10, erro: 'montou a proporção ao contrário' }, { t: nD(G3[outro]) + ' cm', v: G3[outro], erro: 'pegou o lado errado' }, { t: nD(L[pos]) + ' cm', v: L[pos], erro: 'copiou o lado do triângulo pequeno' }], viz8(G3[pos], ' cm'));
  return { ...aa, text: 'Os dois triângulos são semelhantes (mesmos ângulos). Quanto mede x?', image: svgURI(semelhSVG9(L, k, labsP, labsG)), meta: { L, labsG }, chave: `sm9${L},${k},${pos}` };
};
C.semelh9 = m => {
  if(m.expr) return nD(Math.round(ev8(m.expr) * 100) / 100) + m.suf;
  const i = m.labsG.findIndex(t => t === 'x'), j = (i + 1) % 3, kk = ev8(m.labsG[j].replace(' cm', '')) / m.L[j];
  return nD(Math.round(m.L[i] * kk * 100) / 100) + ' cm';
};

/* Teorema de Pitágoras e relações métricas (EF09MA13) */
const TERNOS9 = [[3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [7, 24, 25], [9, 12, 15], [12, 16, 20], [20, 21, 29], [9, 40, 41], [15, 20, 25], [10, 24, 26], [12, 35, 37]];
function pitSVG9(a, b, labs){
  const esc = Math.min(260 / b, 170 / a), A = a * esc, B = b * esc, x0 = 60, y0 = 30 + A;
  let o = `<polygon points="${x0},${y0} ${x0 + B},${y0} ${x0},${y0 - A}" fill="#bbf7d0" stroke="#111" stroke-width="3"/><rect x="${x0}" y="${y0 - 16}" width="16" height="16" fill="none" stroke="#111" stroke-width="2"/>`;
  const lab = (x, y, t, anc = 'middle') => T(x, y, t, { fs: 22, cor: '#b91c1c', anc, extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' });
  o += lab(x0 - 10, y0 - A / 2 + 8, labs[0], 'end') + lab(x0 + B / 2, y0 + 28, labs[1]) + lab(x0 + B / 2 + 18, y0 - A / 2 - 6, labs[2], 'start');
  return SVG(x0 + B + 110, y0 + 45, o);
}
G.pitag9 = n => {
  const [a, b, c] = pick(TERNOS9);
  if(n < 3){
    const pede = n === 1 ? 2 : pick([0, 1]);
    const labs = [a, b, c].map((v, i) => i === pede ? 'x' : v + ' cm');
    const certa = [a, b, c][pede];
    const erros = pede === 2 ? [{ t: nD(a + b) + ' cm', v: a + b, erro: 'somou os catetos sem elevar ao quadrado' }, { t: nD(a * a + b * b) + ' cm', v: a * a + b * b, erro: 'esqueceu de tirar a raiz' }, { t: nD(Math.round(Math.sqrt(b * b - a * a) * 10) / 10) + ' cm', v: Math.round(Math.sqrt(b * b - a * a) * 10) / 10, erro: 'subtraiu em vez de somar' }]
      : [{ t: nD(Math.round(Math.sqrt(c * c + [a, b][1 - pede] ** 2) * 10) / 10) + ' cm', v: Math.round(Math.sqrt(c * c + [a, b][1 - pede] ** 2) * 10) / 10, erro: 'somou os quadrados (para achar cateto, subtrai da hipotenusa²)' }, { t: nD(c - [a, b][1 - pede]) + ' cm', v: c - [a, b][1 - pede], erro: 'subtraiu os lados sem elevar ao quadrado' }, { t: nD(c * c - [a, b][1 - pede] ** 2) + ' cm', v: c * c - [a, b][1 - pede] ** 2, erro: 'esqueceu de tirar a raiz' }];
    const aa = alt8(nv8(certa, ' cm'), erros, viz8(certa, ' cm'));
    return { ...aa, text: `Quanto mede x no triângulo retângulo? (a² = b² + c²: hipotenusa² = soma dos quadrados dos catetos)`, image: svgURI(pitSVG9(a, b, labs)), meta: { labs }, chave: `pi9${a},${b},${pede}` };
  }
  if(Math.random() < .5){
    const ctx = pick([['Uma escada de', 'm está encostada num muro, com o pé a', 'm do muro. A que altura ela toca o muro?', 1], ['Uma TV tem tela de', 'polegadas de diagonal e', 'polegadas de largura. Qual é a altura da tela?', 1], ['Um terreno retangular tem', 'm de comprimento e', 'm de largura. Quanto mede a diagonal?', 0]]);
    const [x, y, z] = [a, b, c], cmp = ctx[3] ? [z, y, x] : [y, x, z];
    const certa = ctx[3] ? x : z;
    const un = ctx[1].startsWith('polegadas') ? ' pol' : ' m';
    const aa = alt8(nv8(certa, un), [{ t: nD(ctx[3] ? z - y : x + y) + un, v: ctx[3] ? z - y : x + y, erro: 'somou ou subtraiu sem elevar ao quadrado' }, { t: nD(ctx[3] ? z * z - y * y : x * x + y * y) + un, v: ctx[3] ? z * z - y * y : x * x + y * y, erro: 'esqueceu de tirar a raiz' }, { t: nD(Math.round(Math.sqrt(ctx[3] ? z * z + y * y : Math.abs(y * y - x * x)) * 10) / 10) + un, v: Math.round(Math.sqrt(ctx[3] ? z * z + y * y : Math.abs(y * y - x * x)) * 10) / 10, erro: ctx[3] ? 'somou os quadrados em vez de subtrair' : 'subtraiu os quadrados em vez de somar' }], viz8(certa, un));
    return { ...aa, text: `${ctx[0]} ${cmp[0]} ${ctx[1]} ${cmp[1]} ${ctx[2]}`, meta: { c1: cmp[0], c2: cmp[1], hip: !!ctx[3], un }, chave: `pi9c${cmp}${ctx[0].slice(0, 6)}` };
  }
  const [m1, n1] = pick([[4, 9], [1, 16], [2, 8], [4, 16], [9, 16], [3, 12], [4, 25], [1, 9], [8, 18], [9, 25], [16, 25]]), h = Math.sqrt(m1 * n1);
  const aa = alt8(nv8(h, ' cm'), [{ t: nD(m1 * n1) + ' cm', v: m1 * n1, erro: 'esqueceu de tirar a raiz (h² = m · n)' }, { t: nD((m1 + n1) / 2) + ' cm', v: (m1 + n1) / 2, erro: 'fez a média das projeções' }, { t: nD(m1 + n1) + ' cm', v: m1 + n1, erro: 'somou as projeções' }], viz8(h, ' cm'));
  return { ...aa, text: `Num triângulo retângulo, a altura relativa à hipotenusa divide a hipotenusa em partes de ${m1} cm e ${n1} cm. Quanto mede essa altura? (h² = m · n)`, meta: { m1, n1 }, chave: `pi9h${m1},${n1}` };
};
C.pitag9 = m => {
  if(m.m1) return nD(Math.sqrt(m.m1 * m.n1)) + ' cm';
  if(m.un) return nD(m.hip ? Math.sqrt(m.c1 * m.c1 - m.c2 * m.c2) : Math.sqrt(m.c1 * m.c1 + m.c2 * m.c2)) + m.un;
  const v = m.labs.map(t => t === 'x' ? null : +t.replace(' cm', '')), i = v.indexOf(null);
  return nD(i === 2 ? Math.hypot(v[0], v[1]) : Math.sqrt(v[2] * v[2] - v[1 - i] * v[1 - i])) + ' cm';
};

/* ============================ 3º TRIMESTRE ============================ */

/* Ângulo central e ângulo inscrito (EF07MA22 · EF09MA11) */
function circSVG9(aA, aB, aP, labCentral, labInscrito, diam){
  const R = 120, cx = 160, cy = 150, P = a => [cx + R * Math.cos(a * Math.PI / 180), cy - R * Math.sin(a * Math.PI / 180)];
  const [A, B, Pp] = [P(aA), P(aB), P(aP)];
  let o = `<circle cx="${cx}" cy="${cy}" r="${R}" fill="#f8fafc" stroke="#111" stroke-width="3"/>`;
  if(labCentral !== null) o += `<line x1="${cx}" y1="${cy}" x2="${A[0]}" y2="${A[1]}" stroke="#1d4ed8" stroke-width="3"/><line x1="${cx}" y1="${cy}" x2="${B[0]}" y2="${B[1]}" stroke="#1d4ed8" stroke-width="3"/>` + T(cx + 32 * Math.cos((aA + aB) / 2 * Math.PI / 180), cy - 32 * Math.sin((aA + aB) / 2 * Math.PI / 180) + 8, labCentral, { fs: 20, cor: '#1d4ed8', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' });
  if(diam) o += `<line x1="${A[0]}" y1="${A[1]}" x2="${B[0]}" y2="${B[1]}" stroke="#1d4ed8" stroke-width="3"/>`;
  o += `<line x1="${Pp[0]}" y1="${Pp[1]}" x2="${A[0]}" y2="${A[1]}" stroke="#b91c1c" stroke-width="3"/><line x1="${Pp[0]}" y1="${Pp[1]}" x2="${B[0]}" y2="${B[1]}" stroke="#b91c1c" stroke-width="3"/>`;
  const dirIn = Math.atan2(cy - Pp[1], cx - Pp[0]);
  o += T(Pp[0] + 42 * Math.cos(dirIn), Pp[1] + 42 * Math.sin(dirIn) + 8, labInscrito, { fs: 20, cor: '#b91c1c', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' });
  [[A, 'A'], [B, 'B'], [Pp, 'P']].forEach(([q, t]) => { const d = Math.atan2(q[1] - cy, q[0] - cx); o += `<circle cx="${q[0]}" cy="${q[1]}" r="5" fill="#111"/>` + T(q[0] + 20 * Math.cos(d), q[1] + 20 * Math.sin(d) + 7, t, { fs: 20 }); });
  o += `<circle cx="${cx}" cy="${cy}" r="4" fill="#111"/>` + T(cx - 14, cy + 22, 'O', { fs: 18 });
  return SVG(330, 300, o);
}
G.circ9 = n => {
  const modo = n === 1 ? 'ci' : n === 2 ? pick(['ic', 'semi']) : pick(['mesmo', 'arco', 'semi', 'ic']);
  const central = rnd(20, 80) * 2, meio = rnd(-60, 60) + 270, aA = meio - central / 2, aB = meio + central / 2, aP = meio + 180 + rnd(-40, 40);
  const g = v => nD(v) + '°';
  if(modo === 'semi'){
    const aa = alt8({ t: '90°', v: 90 }, [{ t: '180°', v: 180, erro: 'deu a medida do arco (meia volta), não do ângulo inscrito' }, { t: '45°', v: 45, erro: 'dividiu por 4' }, { t: '60°', v: 60, erro: 'achou que é triângulo equilátero' }]);
    return { ...aa, text: 'AB é um diâmetro da circunferência. Quanto mede o ângulo APB (inscrito)?', image: svgURI(circSVG9(200, 20, 290 + rnd(-40, 40), null, '?', true)), meta: { modo }, chave: 'ci9s' + rnd(0, 9) };
  }
  if(modo === 'ci'){
    const aa = alt8(nv8(central / 2, '°'), [{ t: g(central), v: central, erro: 'achou que o inscrito é igual ao central' }, { t: g(central * 2), v: central * 2, erro: 'dobrou em vez de dividir' }, { t: g(180 - central / 2), v: 180 - central / 2, erro: 'calculou o suplemento' }], viz8(central / 2, '°', 5));
    return { ...aa, text: 'O ângulo central AOB e o ângulo inscrito APB "enxergam" o mesmo arco AB. Quanto mede o ângulo inscrito?', image: svgURI(circSVG9(aA, aB, aP, g(central), '?')), meta: { central, modo }, chave: 'ci9c' + central + meio };
  }
  if(modo === 'ic'){
    const aa = alt8(nv8(central, '°'), [{ t: g(central / 2), v: central / 2, erro: 'achou que o central é igual ao inscrito' }, { t: g(central / 4), v: central / 4, erro: 'dividiu em vez de dobrar' }, { t: g(360 - central), v: 360 - central, erro: 'pegou o arco maior' }], viz8(central, '°', 5));
    return { ...aa, text: 'O ângulo inscrito APB e o ângulo central AOB "enxergam" o mesmo arco AB. Quanto mede o ângulo central?', image: svgURI(circSVG9(aA, aB, aP, '?', g(central / 2))), meta: { central, modo }, chave: 'ci9i' + central + meio };
  }
  if(modo === 'arco'){
    const aa = alt8(nv8(central / 2, '°'), [{ t: g(central), v: central, erro: 'achou que o inscrito é igual ao arco' }, { t: g(360 - central), v: 360 - central, erro: 'pegou o arco maior' }, { t: g(central * 2), v: central * 2, erro: 'dobrou em vez de dividir' }], viz8(central / 2, '°', 5));
    return { ...aa, text: `O arco AB mede ${central}°. Quanto mede um ângulo inscrito que enxerga esse arco?`, meta: { central, modo }, chave: 'ci9a' + central };
  }
  const ins = central / 2;
  const aa = alt8(nv8(ins, '°'), [{ t: g(central), v: central, erro: 'dobrou (achou que é o central)' }, { t: g(180 - ins), v: 180 - ins, erro: 'calculou o suplemento' }, { t: g(ins / 2), v: ins / 2, erro: 'dividiu por 2 de novo' }], viz8(ins, '°', 5));
  return { ...aa, text: `Dois ângulos inscritos, APB e AQB, enxergam o mesmo arco AB. Se APB mede ${ins}°, quanto mede AQB?`, meta: { central, modo }, chave: 'ci9m' + ins };
};
C.circ9 = m => m.modo === 'semi' ? '90°' : m.modo === 'ic' ? m.central + '°' : (m.central / 2) + '°';

/* Números irracionais: reconhecer, diagonal do quadrado, reta (EF09MA01 · EF09MA02) */
const IRR9 = ['√2', '√3', '√5', '√7', 'π', '√10', '√11', '0,1010010001…', '√15', '√20'];
const RAC9 = [['√9', 'é 3 (raiz exata)'], ['√16', 'é 4 (raiz exata)'], ['√25', 'é 5 (raiz exata)'], ['0,333…', 'dízima periódica é racional (1/3)'], ['0,121212…', 'dízima periódica é racional'], ['3/4', 'fração é racional'], ['−4', 'inteiro é racional'], ['0,25', 'decimal exato é racional'], ['1,5', 'decimal exato é racional'], ['√(4/9)', 'é 2/3 (raiz exata)'], ['√0,36', 'é 0,6 (raiz exata)']];
G.irrac9 = n => {
  if(n === 1){
    const certa = pick(IRR9);
    const aa = alt8({ t: certa, v: null }, shuffle(RAC9).slice(0, 3).map(([t, e]) => ({ t, v: null, erro: e })));
    return { ...aa, text: 'Qual destes números é IRRACIONAL (decimal infinito e NÃO periódico)?', meta: { opts: aa.options, modo: 'qual' }, chave: 'ir9q' + aa.options.join('|') };
  }
  if(n === 2){
    const L = rnd(2, 15), tri = Math.random() < .3 && L % 2 === 0;
    if(tri){
      const aa = alt8({ t: `${L / 2}√3 cm`, v: L / 2 * Math.sqrt(3) }, [{ t: `${L}√3 cm`, v: L * Math.sqrt(3), erro: 'esqueceu de dividir por 2' }, { t: `${L / 2}√2 cm`, v: L / 2 * Math.sqrt(2), erro: 'usou √2 (isso é da diagonal do quadrado)' }, { t: `${L / 2} cm`, v: L / 2, erro: 'deu a metade do lado' }]);
      return { ...aa, text: `Um triângulo equilátero tem lado ${L} cm. Quanto mede a altura? (altura = lado · √3 ÷ 2)`, meta: { L, modo: 'alt' }, chave: 'ir9a' + L };
    }
    const aa = alt8({ t: `${L}√2 cm`, v: L * Math.sqrt(2) }, [{ t: `${2 * L} cm`, v: 2 * L, erro: 'somou dois lados' }, { t: `${L * L} cm`, v: L * L, erro: 'calculou a área' }, { t: `${L}√3 cm`, v: L * Math.sqrt(3), erro: 'usou √3' }, { t: `√${2 * L} cm`, v: Math.sqrt(2 * L), erro: 'pôs o lado dentro da raiz' }]);
    return { ...aa, text: `Um quadrado tem lado ${L} cm. Quanto mede a diagonal? (d² = ${L}² + ${L}²)`, meta: { L, modo: 'diag' }, chave: 'ir9d' + L };
  }
  let k; do k = rnd(2, 40); while(Number.isInteger(Math.sqrt(k)) || Math.abs(Math.sqrt(k) % 1 - .5) < .2 || Math.sqrt(k) % 1 < .12 || Math.sqrt(k) % 1 > .88);
  const s = Math.sqrt(k), a = Math.floor(s);
  let cand = [[s, null], [s + 1, 'contou uma unidade a mais'], [a + 1 - (s - a), 'pôs do lado errado do inteiro'], [s - 1 > 0.3 ? s - 1 : k / 2 <= 6.5 ? k / 2 : s + 2, s - 1 > 0.3 ? 'contou uma unidade a menos' : 'dividiu por 2']];
  cand = cand.filter(c => c[0] > 0.2 && c[0] < 6.8);
  if(cand.length < 4 || cand.some((c, i) => cand.some((d, j) => i < j && Math.abs(c[0] - d[0]) < .3))) return G.irrac9(n);
  const ord = cand.slice().sort((p, q) => p[0] - q[0]), letras = ['A', 'B', 'C', 'D'];
  let o = `<line x1="20" y1="80" x2="620" y2="80" stroke="#111" stroke-width="3"/>`;
  const X = v => 40 + v * 85;
  for(let i = 0; i <= 6; i++) o += `<line x1="${X(i)}" y1="70" x2="${X(i)}" y2="90" stroke="#111" stroke-width="3"/>` + T(X(i), 118, i, { fs: 22 });
  ord.forEach(([v], i) => { o += `<circle cx="${X(v)}" cy="80" r="7" fill="#dc2626"/>` + T(X(v), 55, letras[i], { fs: 22, cor: '#dc2626' }); });
  const itens = ord.map(([v, e], i) => ({ t: letras[i], v: null, erro: e }));
  const iC = itens.findIndex(i => i.erro === null);
  const sh = { options: letras, correct: iC, erros: itens.map(i => i.erro), answer: letras[iC] };
  return { ...sh, text: `Qual ponto da reta representa √${k}?`, image: svgURI(SVG(640, 135, o)), meta: { k, pos: ord.map(c => c[0]), modo: 'reta' }, chave: 'ir9r' + k + ord.map(c => c[0].toFixed(2)).join() };
};
C.irrac9 = m => {
  if(m.modo === 'qual') return m.opts.find(t => IRR9.includes(t));
  if(m.modo === 'diag') return `${m.L}√2 cm`;
  if(m.modo === 'alt') return `${m.L / 2}√3 cm`;
  let best = 0; m.pos.forEach((v, i) => { if(Math.abs(v * v - m.k) < Math.abs(m.pos[best] ** 2 - m.k)) best = i; }); return 'ABCD'[best];
};

/* Vistas ortogonais (EF09MA17) — mesmo desenho das pilhas de cubos, mais difícil */
G.vistas9 = n => vistasItem(Math.min(3, n + 1), 9);
C.vistas9 = m => C.vistas6(m);

/* Volume de prisma e cilindro (EF09MA19) */
function prismaTriSVG9(b, h, H){
  const k = Math.min(180 / b, 110 / h, 22), B = b * k, HH = h * k, P = Math.min(H * k * .6, 200), x0 = 40, y0 = 60 + HH;
  const f = [[x0, y0], [x0 + B, y0], [x0 + B * .4, y0 - HH]], g2 = f.map(([x, y]) => [x + P, y - P * .35]);
  const pl = p => p.map(q => q.join(',')).join(' ');
  let o = `<polygon points="${pl(g2)}" fill="#dbeafe" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6,4"/>`;
  [[0, 1], [1, 2], [2, 0]].forEach(([i, j]) => { o += `<polygon points="${pl([f[i], f[j], g2[j], g2[i]])}" fill="#93c5fd" fill-opacity=".55" stroke="#111" stroke-width="2"/>`; });
  o += `<polygon points="${pl(f)}" fill="#60a5fa" stroke="#111" stroke-width="3"/><line x1="${f[2][0]}" y1="${f[2][1]}" x2="${f[2][0]}" y2="${y0}" stroke="#111" stroke-dasharray="5,4" stroke-width="2"/>`;
  const lab = (x, y, t, anc = 'middle') => T(x, y, t, { fs: 20, cor: '#b91c1c', anc, extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' });
  o += lab(x0 + B / 2, y0 + 26, b + ' cm') + lab(f[2][0] + 6, y0 - HH / 2, h + ' cm', 'start') + lab((f[1][0] + g2[1][0]) / 2 + 30, (f[1][1] + g2[1][1]) / 2 + 20, H + ' cm');
  return SVG(x0 + B + P + 110, y0 + 45, o);
}
function cilindroSVG9(r, h, un){
  const R = 70, HH = 160, rx = R, ry = 20, cx = 150, top = 70;
  let o = `<path d="M${cx - rx},${top} L${cx - rx},${top + HH} A${rx},${ry} 0 0 0 ${cx + rx},${top + HH} L${cx + rx},${top}" fill="#93c5fd" stroke="#111" stroke-width="3"/><ellipse cx="${cx}" cy="${top}" rx="${rx}" ry="${ry}" fill="#dbeafe" stroke="#111" stroke-width="3"/>`;
  o += `<line x1="${cx}" y1="${top}" x2="${cx + rx}" y2="${top}" stroke="#b91c1c" stroke-width="3"/><circle cx="${cx}" cy="${top}" r="4" fill="#111"/>` + T(cx + rx / 2, top - 30, `r = ${nD(r)} ${un}`, { fs: 19, cor: '#b91c1c', extra: ' stroke="#fff" stroke-width="5" paint-order="stroke"' });
  o += `<line x1="${cx + rx + 18}" y1="${top}" x2="${cx + rx + 18}" y2="${top + HH}" stroke="#b91c1c" stroke-width="2.5"/>` + T(cx + rx + 26, top + HH / 2 + 7, `${nD(h)} ${un}`, { fs: 20, cor: '#b91c1c', anc: 'start' });
  return SVG(340, top + HH + 40, o);
}
G.volPC9 = n => {
  if(n === 1){
    let b, h, H; do{ b = rnd(3, 12); h = rnd(2, 10); H = rnd(4, 20); } while((b * h) % 2);
    const V = b * h / 2 * H;
    const aa = alt8(nv8(V, ' cm³'), [{ t: nD(b * h * H) + ' cm³', v: b * h * H, erro: 'esqueceu de dividir a área do triângulo por 2' }, { t: nD(b * h / 2) + ' cm³', v: b * h / 2, erro: 'calculou só a área da base' }, { t: nD(b + h + H) + ' cm³', v: b + h + H, erro: 'somou as medidas' }], viz8(V, ' cm³'));
    return { ...aa, text: 'Qual é o volume do prisma de base triangular? (volume = área da base × altura do prisma)', image: svgURI(prismaTriSVG9(b, h, H)), meta: { expr: `${b} × ${h} / 2 × ${H}`, suf: ' cm³' }, chave: `vp9${b},${h},${H}` };
  }
  const r = rnd(1, 10), h = rnd(2, 20), V = Math.round(3.14 * r * r * h * 100) / 100;
  if(n === 2){
    const aa = alt8({ t: nD(V) + ' cm³', v: V }, [{ t: nD(Math.round(3.14 * 2 * r * h * 100) / 100) + ' cm³', v: Math.round(3.14 * 2 * r * h * 100) / 100, erro: 'usou 2 · π · r (comprimento) em vez da área da base' }, { t: nD(Math.round(3.14 * r * h * 100) / 100) + ' cm³', v: Math.round(3.14 * r * h * 100) / 100, erro: 'esqueceu de elevar o raio ao quadrado' }, { t: nD(Math.round(3.14 * 4 * r * r * h * 100) / 100) + ' cm³', v: Math.round(3.14 * 4 * r * r * h * 100) / 100, erro: 'usou o diâmetro no lugar do raio' }, { t: nD(Math.round(3.14 * r * r * 100) / 100) + ' cm³', v: Math.round(3.14 * r * r * 100) / 100, erro: 'calculou só a área da base' }], [{ t: nD(Math.round(3 * r * r * h * 100) / 100) + ' cm³', v: 3 * r * r * h, erro: 'usou π = 3' }, { t: nD(Math.round(3.14 * r * r * h * 10)) + ' cm³', v: Math.round(3.14 * r * r * h * 10), erro: 'errou a vírgula' }]);
    return { ...aa, text: 'Qual é o volume do cilindro? (use π = 3,14; volume = π · r² · altura)', image: svgURI(cilindroSVG9(r, h, 'cm')), meta: { expr: `3,14 × ${r}² × ${h}`, suf: ' cm³' }, chave: `vc9${r},${h}` };
  }
  let R2, H2; do{ R2 = rnd(1, 5) * 5; H2 = rnd(2, 12) * 10; } while(!Number.isInteger(Math.round(3.14 * R2 * R2 * H2) / 10));
  const L = Math.round(3.14 * R2 * R2 * H2) / 1000;
  const aa = alt8({ t: nD(L) + ' L', v: L }, [{ t: nD(Math.round(3.14 * R2 * R2 * H2)) + ' L', v: Math.round(3.14 * R2 * R2 * H2), erro: 'esqueceu de converter (1000 cm³ = 1 L)' }, { t: nD(L * 10) + ' L', v: L * 10, erro: 'dividiu por 100 (1000 cm³ = 1 L)' }, { t: nD(Math.round(3.14 * 2 * R2 * H2) / 1000) + ' L', v: Math.round(3.14 * 2 * R2 * H2) / 1000, erro: 'usou 2 · π · r em vez da área da base' }, { t: nD(Math.round(L * 400) / 100) + ' L', v: Math.round(L * 400) / 100, erro: 'usou o diâmetro no lugar do raio' }]);
  return { ...aa, text: 'Quantos litros cabem nesta lata cilíndrica? (π = 3,14; 1000 cm³ = 1 L)', image: svgURI(cilindroSVG9(R2, H2, 'cm')), meta: { expr: `3,14 × ${R2}² × ${H2} / 1000`, suf: ' L' }, chave: `vl9${R2},${H2}` };
};
C.volPC9 = m => nD(Math.round(ev8(m.expr) * 1000) / 1000) + m.suf;

/* Função afim e quadrática (EF09MA06) */
function parabolaSVG9(r1, r2, lim = 7){
  const s = 26, c = 20 + lim * s, X = v => c + v * s, Y = v => c - v * s;
  let o = '';
  for(let i = -lim; i <= lim; i++){ o += `<line x1="${X(i)}" y1="${Y(-lim)}" x2="${X(i)}" y2="${Y(lim)}" stroke="#e2e8f0" stroke-width="1.2"/><line x1="${X(-lim)}" y1="${Y(i)}" x2="${X(lim)}" y2="${Y(i)}" stroke="#e2e8f0" stroke-width="1.2"/>`; if(i) o += T(X(i), c + 18, i < 0 ? '−' + (-i) : i, { fs: 13, cor: '#475569' }); }
  o += `<line x1="${X(-lim)}" y1="${c}" x2="${X(lim)}" y2="${c}" stroke="#111" stroke-width="2.5"/><line x1="${c}" y1="${Y(-lim)}" x2="${c}" y2="${Y(lim)}" stroke="#111" stroke-width="2.5"/>` + T(X(lim) - 8, c - 8, 'x', { fs: 18 }) + T(c + 12, Y(lim) + 14, 'y', { fs: 18 });
  const pts = []; for(let x = -lim; x <= lim; x += .05){ const y = (x - r1) * (x - r2); if(y >= -lim && y <= lim) pts.push(`${X(x).toFixed(1)},${Y(y).toFixed(1)}`); }
  o += `<polyline points="${pts.join(' ')}" fill="none" stroke="#7c3aed" stroke-width="4"/>` + `<circle cx="${X(r1)}" cy="${c}" r="6" fill="#dc2626"/><circle cx="${X(r2)}" cy="${c}" r="6" fill="#dc2626"/>`;
  return SVG(2 * c, 2 * c, o);
}
G.funcao9 = n => {
  if(n === 1){
    const a = sortearAte(() => rnd(-6, 8), v => v !== 0 && v !== 1), b = rnd(-9, 12), k = sortearAte(() => rnd(-5, 10), v => v !== 0 && v !== 1);
    const lei = `f(x) = ${pol8(a, b)}`, v = a * k + b;
    const aa = alt8(nv8(v), [{ t: nD(a + k + b), v: a + k + b, erro: 'somou em vez de multiplicar' }, { t: nD(a * k), v: a * k, erro: 'esqueceu o termo independente' }, { t: nD(a * (k + b)), v: a * (k + b), erro: 'somou antes de multiplicar' }, { t: nD(-a * k + b), v: -a * k + b, erro: 'errou o sinal' }], viz8(v));
    return { ...aa, text: `Dada a função ${lei}, quanto vale f(${k < 0 ? '−' + (-k) : k})?`, meta: { lei, k, modo: 'val' }, chave: `fn9${a},${b},${k}` };
  }
  if(n === 2){
    const mm = sortearAte(() => rnd(-3, 3), v => v !== 0), b = sortearAte(() => rnd(-4, 4), v => v !== 0 && Math.abs(2 * mm + v) <= 6 && Math.abs(mm + v) <= 6);
    const f = (m1, b1) => `f(x) = ${pol8(m1, b1)}`;
    const cand = [[mm, b, null], [-mm, b, 'errou a inclinação (a reta sobe ou desce?)'], [mm, -b, 'errou onde a reta corta o eixo y'], [b, mm, 'trocou a inclinação com o ponto do eixo y'], [mm, b + 1, 'errou onde a reta corta o eixo y'], [2 * mm, b, 'contou errado quanto sobe para cada 1 à direita']];
    const itens = [], vis = new Set();
    cand.forEach(([m1, b1, e]) => { const kk = m1 + ',' + b1; if(m1 !== 0 && !vis.has(kk)){ vis.add(kk); itens.push({ t: f(m1, b1), v: null, erro: e }); } });
    const aa = alt8(itens[0], itens.slice(1));
    return { ...aa, text: 'Qual função afim tem este gráfico? (os pontos vermelhos estão em x = 0, 1 e 2)', image: svgURI(retaSVG8(mm, b)), meta: { mm, b, opts: itens.map(i => i.t), modo: 'graf' }, chave: `fn9g${mm},${b}` };
  }
  if(Math.random() < .5){
    let r1, r2; do{ r1 = rnd(-5, 5); r2 = rnd(-5, 5); } while(r1 >= r2 || Math.abs((r1 + r2) / 2 - r1) * Math.abs((r1 + r2) / 2 - r2) > 7);
    const txt = (a, b) => `x = ${a < 0 ? '−' + (-a) : a} e x = ${b < 0 ? '−' + (-b) : b}`;
    const aa = alt8({ t: txt(r1, r2), v: null }, [{ t: txt(-r2, -r1), v: null, erro: 'trocou os sinais' }, { t: txt(Math.min(r1, r1 * r2), Math.max(r2, r1 * r2)), v: null, erro: 'leu o ponto onde corta o eixo y' }, { t: txt(r1 - 1, r2 + 1), v: null, erro: 'leu a escala errado' }, { t: txt(r1 + 1, r2 + 1), v: null, erro: 'leu a escala errado' }].filter(e => e.t !== txt(r1, r2) && !/x = (\S+) e x = \1$/.test(e.t)), [{ t: txt(r1 - 1, r2 - 1), v: null, erro: 'leu a escala errado' }, { t: txt(r1, r2 + 1), v: null, erro: 'leu a escala errado' }, { t: txt(r1 - 1, r2), v: null, erro: 'leu a escala errado' }]);
    return { ...aa, text: 'O gráfico é de uma função quadrática. Em quais valores de x ela vale zero (onde a parábola corta o eixo x)?', image: svgURI(parabolaSVG9(r1, r2)), meta: { r1, r2, modo: 'zeros' }, chave: `fn9z${r1},${r2}` };
  }
  const a = pick([1, 1, 2, -1]), b = rnd(-6, 6), c = rnd(-9, 9), k = sortearAte(() => rnd(-4, 4), v => v !== 0 && v !== 1);
  const lei = `f(x) = ${a === 1 ? '' : a === -1 ? '−' : a}x²${b ? ` ${b < 0 ? '−' : '+'} ${Math.abs(b) === 1 ? '' : Math.abs(b)}x` : ''}${c ? ` ${c < 0 ? '−' : '+'} ${Math.abs(c)}` : ''}`;
  const v = a * k * k + b * k + c;
  const aa = alt8(nv8(v), [{ t: nD(-a * k * k + b * k + c), v: -a * k * k + b * k + c, erro: 'errou o sinal do quadrado' }, { t: nD(a * 2 * k + b * k + c), v: a * 2 * k + b * k + c, erro: 'fez x² como 2x' }, { t: nD(a * k * k + b + c), v: a * k * k + b + c, erro: 'esqueceu de multiplicar b por x' }], viz8(v));
  return { ...aa, text: `Dada a função ${lei}, quanto vale f(${k < 0 ? '−' + (-k) : k})?`, meta: { lei, k, modo: 'val' }, chave: `fn9q${a},${b},${c},${k}` };
};
C.funcao9 = m => {
  if(m.modo === 'val') return nD(ev8(m.lei.slice(7), { x: m.k }));
  if(m.modo === 'graf') return m.opts.find(t => [0, 1, 2].every(x => Math.abs(ev8(t.slice(7), { x }) - (m.mm * x + m.b)) < 1e-9));
  const z = []; for(let x = -7; x <= 7; x++) if((x - m.r1) * (x - m.r2) === 0) z.push(x);
  return `x = ${z[0] < 0 ? '−' + (-z[0]) : z[0]} e x = ${z[1] < 0 ? '−' + (-z[1]) : z[1]}`;
};
