const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../'+(process.argv[2]||'work.html'),'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
// aluno sabe tudo até o degrau alvo, e acerta só 25% dele (ou do que vem depois)
for(const alvo of ['divResto','fracEquiv','p7_equacao']){
  let maxRun=0,runs=[],tot=0;
  for(let s=0;s<120;s++){
    const rec=T.novoRegistro('x'); T.iniciar(rec,{diag:'inicio',ano:1});
    const ia=T.POR_ID[alvo].i; T.CAT.forEach(c=>{ if(c.i<ia){ const g=rec.deg[c.id]||(rec.deg[c.id]={n:1,cnt:0,h:[],dom:0,domPor:'',tot:0,ac:0,totA:0,err:{},quedas:0,seqErr:0,revInt:8,revUlt:0,revErr:0}); g.dom=1; g.domPor='ano'; }});
    rec.atual=alvo; rec.diag='feito';
    let run=0, last=null, seq=[];
    for(let k=0;k<40;k++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel);
      const ok = T.POR_ID[f.id].i>=ia ? Math.random()<0.25 : Math.random()<0.9;
      T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,0.3);
      if(f.id===alvo) { run = last===alvo? run+1:1; } else run=0; last=f.id; maxRun=Math.max(maxRun,run); if(f.id===alvo) tot++; }
    runs.push(maxRun);
  }
  console.log(alvo,'maior sequência seguida do mesmo degrau (pior caso em 120 alunos):',maxRun,'| % das 40 perguntas no degrau travado:',Math.round(tot/(120*40)*100)+'%');
}
