const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); const C=T.CAT.filter(c=>!c.retirada);
const t={Frações:/fra[cç]|pizza|partes|meio|metade|terç/i, Decimais:/decim|centavo|vírgula/i, Porcentagem:/porc|%|desconto/i, 'Multiplicação e divisão':/multipl|divis|tabuada|pratos|grupos|vezes|dobro/i, Geometria:/ângul|triâng|quadril|polígon|figura|sólid|prism|retas|circun|vista/i, Medidas:/medida|área|perímetro|volume|litro|régua|conversão|tempo|hora|relógio/i, Álgebra:/equa|expressão|algébr|sequênc|balança|valor numérico|fator|produto/i, Estatística:/gráfico|tabela|média|moda|probab|chance|pictograma|colunas/i};
for(const [k,re] of Object.entries(t)){ const l=C.filter(c=>re.test(c.nome)); console.log(k, l.length, l.map(c=>c.ano+'º '+c.nome).join(' | ').slice(0,400)); }
process.exit(0);
