const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:1100}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.goto('file:///home/claude/cm/work.html');
await p.click('#navTeacher'); await p.click('#trOn button[data-v="1"]');
// acelera só no teste: bots respondem a cada 0,3–0,6 s
await p.evaluate(()=>{ const o=Math.random; window.__rnd=rnd; });
await p.click('#demoBtn'); await p.waitForTimeout(1500);
await p.evaluate(()=>{ app.scheduleNextBotAnswer = function(bot){ bot._tela={q:this.perguntaDoBot(bot),inicio:Date.now(),prazo:rnd(4000,9000),escolha:null,acertou:null}; this.renderBotScreen(bot);
  const t=setTimeout(()=>{ if(this.host.phase!=='playing')return; this.botAnswer(bot); this.scheduleNextBotAnswer(bot); }, 60); this.host.demoTimeouts.push(t); };
  app.host.demoTimeouts.forEach(clearTimeout); app.host.players.forEach(b=>app.scheduleNextBotAnswer(b)); });
await p.waitForTimeout(30000);
const r=await p.evaluate(()=>app.host.players.map(b=>{const rs=TRILHA.resumo(b._rec);return `${b.name}: ${b._rec.resp} resp · ${rs.degrau} (${['','fácil','médio','difícil'][rs.nivel]}) · ${rs.dominados} dominados · ${b.score} pts`}).join('\n'));
console.log(r);
console.log('alertas:', await p.evaluate(()=>Object.keys(TRILHA.estado.alertas).length));
await p.screenshot({path:'/home/claude/cm/e_demo2.png'});
console.log('erros',errs);await b.close();})();
