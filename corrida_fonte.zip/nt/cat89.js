const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1366,height:900}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.goto('file:///home/claude/cm/work.html'); await p.click('#navTeacher');
console.log('até:', await p.$$eval('#trAnoMax option', o=>o.map(x=>x.textContent+(x.selected?'*':'')).join(' | ')));
console.log('ano:', await p.$$eval('#trAno option', o=>o.map(x=>x.textContent).join(' | ')));
await p.click('#trCatalogo'); await p.waitForTimeout(400);
for(const a of [8,9]){ await p.click(`[data-ano="${a}"]`); await p.waitForTimeout(300); console.log(a+'º ano:', await p.$$eval('.cat-deg', x=>x.length), 'degraus'); await p.screenshot({path:`/home/claude/cm/cat${a}.png`}); }
console.log('erros', errs); await b.close();})();
