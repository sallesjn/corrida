const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
for(const [max,ano,diag,taxa] of [[3,1,'inicio',1],[3,3,'saltos',1],[3,5,'saltos',1],[1,1,'saltos',.9],[5,2,'ano',1],[7,1,'inicio',1]]){
  T.LIMITE.anoMax=max; const rec=T.novoRegistro('x'); T.iniciar(rec,{ano,diag});
  const anos={}; let fora=0;
  for(let i=0;i<6000;i++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel); const a=T.POR_ID[f.id].ano; anos[a]=(anos[a]||0)+1; if(a>max) fora++;
    T.registrar(rec,f,q,q.correct,Math.random()<taxa,0.2); }
  const dom=T.CAT.filter(x=>rec.deg[x.id]&&rec.deg[x.id].dom).length, ativos=T.CAT.filter(x=>x.ano<=max).length;
  console.log(`até ${max}º, turma ${ano}º, ${diag}: fora do limite=${fora} | por ano ${JSON.stringify(anos)} | dominados ${dom}/${ativos} ativos | atual=${rec.atual}`);
}
process.exit(0);
