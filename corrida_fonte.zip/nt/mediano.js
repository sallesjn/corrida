const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
function sim(pNivel, cfg, max=40000){
  T.LIMITE.anoMax=7; T.LIMITE.pRev=cfg.rev||0.2;
  const rec=T.novoRegistro('x'); T.iniciar(rec,cfg); let n=0; const marcos={};
  for(;n<max;n++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel);
    const ok=Math.random()<pNivel[f.nivel]; const frac=Math.min(1,Math.max(.15,0.45+(Math.random()-.5)*.4));
    T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,frac);
    const at=rec.atual?T.POR_ID[rec.atual].ano:8; for(let a=2;a<=8;a++) if(at>=a && !marcos[a]) marcos[a]=n+1;
    if(!rec.atual && rec.diag==='feito') break; }
  return {n, marcos};
}
const perfis={ 'mediano (85/75/65%)':{1:.85,2:.75,3:.65}, 'bom (92/85/78%)':{1:.92,2:.85,3:.78}, 'fraco (75/62/50%)':{1:.75,2:.62,3:.50} };
for(const [nome,p] of Object.entries(perfis)) for(const cfg of [{diag:'inicio',ano:1},{diag:'ano',ano:7}]) {
  const rs=[...Array(5)].map(()=>sim(p,cfg)); const med=k=>{const v=rs.map(r=>k(r)).filter(x=>x).sort((a,b)=>a-b); return v.length? v[Math.floor(v.length/2)]:'—';};
  console.log(nome, cfg.diag==='inicio'?'do 1º degrau':'começando no 7º', '| fim da trilha:', med(r=>r.marcos[8]||null), 'respostas | chega no 4º:', med(r=>r.marcos[4]), '| chega no 7º:', med(r=>r.marcos[7]));
}
process.exit(0);
