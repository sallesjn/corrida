const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},(window.__lento&&/emqx/.test(U))?window.__lento:50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){const era=cli.connected;cli.connected=false;cli._fim=true;window.__unsub(window.__cid);setTimeout(()=>(h.close||[]).forEach(f=>f()),30)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }


  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  // 1) configurar a turma 6º M01 SEM jogar e salvar
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.selectOption('#trAno', '6');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trTempo button[data-v="0"]');
  await prof.click('#trRank button[data-v="1"]');
  await prof.click('#trLista button[data-v="1"]');
  await prof.fill('#trNomes', 'Ana\nBeto\nCaio'); await prof.dispatchEvent('#trNomes', 'input');
  await prof.fill('#trTurmaNome', '6º M01'); await prof.dispatchEvent('#trTurmaNome', 'input');
  await prof.click('#trFocoBt'); await prof.click('#focoBox button[data-aba="6"]');
  await prof.click('#focoBox input[data-id="tiposAng6"]'); await prof.click('#focoBox [data-salvar]');
  const [dl] = await Promise.all([prof.waitForEvent('download'), prof.click('#trSalvar')]);
  const pth = '/home/claude/cm/turma_6M01.json'; await dl.saveAs(pth);
  const t = JSON.parse(fs.readFileSync(pth, 'utf8'));
  ok(t.nome === '6º M01' && t.cfg.modo === 'treino' && t.cfg.foco.ids.join() === 'tiposAng6' && t.cfg.lista && t.cfg.nomes.length === 3 && t.cfg.ano === 6 && t.cfg.rank === 1 && t.cfg.treinoMin === 0, 'salvou a turma sem jogar, com as configurações: ' + dl.suggestedFilename() + ' ' + JSON.stringify({ modo: t.cfg.modo, foco: t.cfg.foco.ids, lista: t.cfg.lista, nomes: t.cfg.nomes, ano: t.cfg.ano, rank: t.cfg.rank, tempo: t.cfg.treinoMin }));
  // 2) outro dia, outro navegador com outra turma: carrega o arquivo e está tudo lá
  const p2 = await nova('prof2');
  await p2.click('#navTeacher');
  await p2.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await p2.reload(); await p2.click('#navTeacher');
  await p2.click('#trOn button[data-v="1"]');
  await p2.fill('#trNomes', 'Outro\nTurma7'); await p2.dispatchEvent('#trNomes', 'input');
  await p2.setInputFiles('#trArquivo', pth); await p2.waitForTimeout(800);
  const c = await p2.evaluate(() => ({ modo: document.querySelector('#trModo button.on').dataset.v, foco: document.getElementById('trFocoTxt').textContent, lista: document.querySelector('#trLista button.on').dataset.v, nomes: document.getElementById('trNomes').value.split('\n'), ano: document.getElementById('trAno').value, turma: document.getElementById('trTurmaNome').value, tempo: document.querySelector('#trTempo button.on').dataset.v }));
  ok(c.modo === 'treino' && /Tipos de ângulos/.test(c.foco) && c.lista === '1' && c.nomes.join() === 'Ana,Beto,Caio' && c.ano === '6' && c.turma === '6º M01' && c.tempo === '0', 'ao carregar, tudo volta (e só os nomes desta turma): ' + JSON.stringify(c));
  // 3) ficha do aluno a partir de um arquivo com progresso
  await p2.setInputFiles('#trArquivo', '/home/claude/cm/turma_foco.json'); await p2.waitForTimeout(800);
  await p2.click('#trFichas'); await p2.waitForTimeout(500);
  const f = await p2.evaluate(() => ({ nome: document.querySelector('#fichaBox .fi-cab h2').textContent, secoes: [...document.querySelectorAll('#fichaBox .fi-sec h3')].map(h => h.textContent.trim()), unidades: document.querySelectorAll('#fichaBox .fi-un').length, ds: document.querySelectorAll('#fichaBox .fi-ds').length }));
  ok(f.secoes.length >= 2 && f.unidades >= 1 && f.ds >= 1, 'ficha do aluno: ' + JSON.stringify(f));
  await p2.screenshot({ path: '/home/claude/cm/ficha1.png' });
  await p2.click('#fichaBox [data-prox]'); await p2.waitForTimeout(300);
  await p2.screenshot({ path: '/home/claude/cm/ficha2.png', fullPage: false });
  await p2.emulateMedia({ media: 'print' });
  await p2.evaluate(() => document.body.classList.add('fi-imprimindo'));
  await p2.pdf({ path: '/home/claude/cm/ficha.pdf', format: 'A4', printBackground: true }).catch(() => {});
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
