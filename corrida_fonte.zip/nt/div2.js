const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); const achados={};
const num=s=>+String(s).replace(/\./g,'').replace(',','.');
for(const c of T.CAT) for(let n=1;n<=3;n++) for(let k=0;k<400;k++){
  let q; try{ q=T.gerarQuestao(c.id,n); }catch(e){ continue; }
  const dica=T.dicaDe(q)||''; const txt=q.text+' || '+dica;
  const pats=[/[Mm]etade de (\d[\d.]*)/g, /(\d[\d.]*) ?÷ ?(\d+)/g, /[Dd]ivid\w* (\d[\d.]*) por (\d+)/g, /(\d[\d.]*) dividid\w* (?:igualmente )?(?:entre|por|em) (\d+)/g];
  for(const p of pats){ let m; p.lastIndex=0; while((m=p.exec(txt))){ const a=num(m[1]), b=m[2]?num(m[2]):2; if(b && Number.isFinite(a) && Math.abs(a/b-Math.round(a/b))>1e-9){ const key=c.id+' N'+n+' '+p.source.slice(0,12); if(!achados[key]) achados[key]=txt.slice(0,220); } } }
}
console.log(Object.entries(achados).map(([k,v])=>k+' → '+v).join('\n')||'nada'); process.exit(0);
