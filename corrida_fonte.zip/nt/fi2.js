const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const ok = (c, m) => console.log((c ? 'OK    ' : 'FALHA ') + m);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1280, height: 1000 } });
  await ctx.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.mqtt={connect(){return{on(){},subscribe(){},publish(){},end(){}}}}' }));
  await ctx.route('https://securetoken.googleapis.com/**', r => r.fulfill({ status: 200, contentType: 'application/json', body: '{"id_token":"X","refresh_token":"R","expires_in":"3600"}' }));
  await ctx.route('https://matematica-3df86-default-rtdb.firebaseio.com/**', r => r.fulfill({ status: 200, contentType: 'application/json', body: r.request().method() === 'GET' ? 'null' : '{}' }));
  const errs = []; const p = await ctx.newPage(); p.on('dialog', d => d.accept()); p.on('pageerror', e => errs.push(e.message));
  await p.goto('file:///home/claude/cm/work.html'); await p.evaluate(() => { localStorage.clear(); localStorage.setItem('cgm_nuvem', JSON.stringify({ rt: 'R', uid: 'U', email: 'f' })); });
  await p.reload(); await p.click('#navTeacher'); await p.waitForTimeout(500);
  await p.click('#nvNova'); await p.fill('#nvNome', '7º M01'); await p.selectOption('#nvAno', '7'); await p.click('#nvCriar'); await p.waitForTimeout(600);
  await p.click('#mxAlunos'); await p.click('#teColarBt'); await p.fill('#teCola', 'Ana Beatriz Lima\nBruno Henrique Dias\nCarlos Eduardo Souza\nDavi Lucas Rocha'); await p.click('#teColarOk'); await p.click('[data-tfecha]'); await p.waitForTimeout(300);
  ok(/aparece aqui depois da primeira aula/.test(await p.textContent('#ulAula')), 'linha "última aula" antes de ter dados');
  // simula aulas: cada aluno com um perfil
  const res = await p.evaluate(() => {
    const T = TRILHA, E = T.estado, perf = { 'ana b': a => a <= 6 ? 0.95 : 0.8, 'bruno h': a => a <= 3 ? 0.9 : a <= 5 ? 0.45 : 0.25, 'carlos e': a => a <= 4 ? 0.92 : 0.6, 'davi l': a => a <= 3 ? 0.9 : a <= 5 ? 0.45 : 0.25 };
    const out = {};
    for(const [k, P] of Object.entries(perf)){
      const rec = T.novoRegistro(E.cfg.nomes.find(n => n.toLowerCase().startsWith(k.split(' ')[0]))); T.iniciar(rec, { diag: 'saltos', ano: 7 });
      // "aprende": a chance de acerto de cada atividade sobe com a prática
      const pr = {};
      for(let i = 0; i < 300; i++){
        const f = T.escolherFonte(rec); const a = T.POR_ID[f.id].ano;
        pr[f.id] = (pr[f.id] || 0) + 1;
        const chance = Math.min(0.97, P(a) + (k === 'carlos e' ? pr[f.id] * 0.02 : 0));
        const okk = Math.random() < chance;
        T.registrar(rec, f, { erros: ['soma tudo', 'troca a ordem', 'esquece o resto', 'x'] }, okk ? 0 : 1 + (i % 3), okk, 0.3);
      }
      E.turma.alunos[rec.chave] = rec;
      out[k] = {};
      T.CAT.forEach(d => { const s = E.classificar(rec, d); out[k][s.st] = (out[k][s.st] || 0) + 1; });
    }
    return out;
  }).catch(e => 'ERRO ' + e.message);
  console.log(JSON.stringify(res));
  await p.evaluate(() => TRILHA.estado.abrirEditorTurma && 0);
  await p.waitForTimeout(3500);
  const ul = await p.textContent('#ulAula').catch(() => 'sem');
  ok(/3 presentes · 1 faltaram/.test(ul), 'última aula: ' + ul.replace(/\s+/g, ' '));
  await p.evaluate(() => { ['bruno h', 'davi l'].forEach(k => { const r = TRILHA.estado.turma.alunos[k]; r.deg.p4_div = { n: 1, dom: 0, tot: 20, ac: 5, totA: 20, h: Array.from({ length: 20 }, (_, i) => [1, i % 4 === 0 ? 1 : 0, 0.3]), err: { 'esqueceu o resto': 6 }, quedas: 0 }; }); });
  await p.waitForTimeout(8500);
  const sug = await p.textContent('#trFocoBox .mn-sug').catch(() => 'sem sugestão');
  console.log('sugestão:', sug.replace(/\s+/g, ' '));
  if(/Sugestão/.test(sug)){ await p.click('#trFocoBox [data-sugid]'); await p.waitForTimeout(300); console.log(await p.evaluate(() => TRILHA.estado.cfg.foco.ids.length === 1) ? 'OK    usar a sugestão define o foco: ' + await p.textContent('#trFocoTxt') : 'FALHA foco'); }
  await p.screenshot({ path: '/home/claude/cm/sug.png' });
  await p.click('#ulAula'); await p.waitForTimeout(300);
  ok(/Davi/.test(await p.textContent('#ulBox')), 'detalhe mostra quem faltou (nome completo)');
  await p.screenshot({ path: '/home/claude/cm/ul_box.png' });
  await p.click('#ulBox [data-ulfi]'); await p.waitForTimeout(400);
  ok(await p.isVisible('#fichaBox'), 'ficha abre pelo nome na lista da aula');
  const secs = await p.$$eval('#fichaBox .fi-sec h3', hs => hs.map(h => h.textContent.trim()));
  console.log('seções:', secs.join(' | '));
  ok(/Evolução por aula/.test(await p.textContent('#fichaBox')) && /\d+%/.test(await p.textContent('#fichaBox .fi-aulas')), 'evolução por aula preenchida');
  await p.screenshot({ path: '/home/claude/cm/ficha1.png', fullPage: false });
  await p.evaluate(() => { const b = document.getElementById('fichaBox'); b.scrollTop = 600; }); await p.waitForTimeout(200); await p.screenshot({ path: '/home/claude/cm/ficha2.png' });
  await p.click('#fichaBox [data-fechar]');
  await p.evaluate(() => TRILHA.estado.abrirEditorTurma()); await p.waitForTimeout(300);
  await p.click('#teBox .te-al .nm.te-ficha'); await p.waitForTimeout(400);
  ok(await p.isVisible('#fichaBox'), 'ficha abre tocando no nome no Editar turma');
  console.log('erros:', errs);
  await b.close();
})();
