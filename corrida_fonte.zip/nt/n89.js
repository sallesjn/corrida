const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
const ids=process.argv[2].split(','); const N=+process.argv[3]||2000; const amostra=+process.argv[4]||2;
const faltam=ids.filter(i=>!T.POR_ID[i]); if(faltam.length) console.log('NÃO ESTÃO NO CATÁLOGO:',faltam);
const keep=T.CAT.filter(c=>ids.includes(c.id)); T.CAT.splice(0,T.CAT.length,...keep);
d.window.console.table=()=>{}; d.window.console.log=()=>{};
const r=T.testarTrilha(N);
console.log(r.tabela.map(t=>`${t.degrau} N${t.nivel}: falhas ${t.falhas}, diferentes ${t.diferentes}`).join('\n'));
{const vis=new Set();r.exemplos.forEach(e=>{const k=e.degrau+e.nivel+e.problema.slice(0,25);if(vis.has(k))return;vis.add(k);console.log("FALHA",e.degrau,e.nivel,e.problema,"|",e.q&&e.q.text,"|",e.q&&e.q.options.join(" ; "),"|",JSON.stringify(e.q&&e.q.meta));});}
// avaliador independente (cópia própria do teste)
function ev(s){
  const SUP={'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁻':'-'};
  let t=String(s).replace(/R\$\s*/,'').replace(/\s*(cm²|cm³|m²|m³|dm³|km\/h|km|cm|mm|kg|g|L|mL|m|h|min|°|%|pessoas|alunos|dias|horas|peças)$/,'').replace(/[−–]/g,'-').replace(/[×·]/g,'*').replace(/[÷:]/g,'/').replace(/(\d)\.(?=\d)/g,'$1').replace(/(\d),(\d)/g,'$1.$2').replace(/\s+/g,'');
  t=t.replace(/[⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+/g,m=>'^('+m.split('').map(c=>SUP[c]).join('')+')');
  if(!/^[-+*/^().\d√∛x]+$/.test(t)) return null;
  let i=0;const pk=()=>t[i];
  const E=()=>{let v=Tm();while(pk()==='+'||pk()==='-'){const o=t[i++];const w=Tm();v=o==='+'?v+w:v-w;}return v;};
  const Tm=()=>{let v=U();for(;;){const c=pk();if(c==='*'||c==='/'){i++;const w=U();v=c==='*'?v*w:v/w;}else if(c&&/[\d.x(√∛]/.test(c))v*=P();else break;}return v;};
  const U=()=>{if(pk()==='-'){i++;return -U();}return P();};
  const P=()=>{const b=A();if(pk()==='^'){i++;return Math.pow(b,U());}return b;};
  const A=()=>{const c=pk();if(c==='('){i++;const v=E();i++;return v;}if(c==='√'){i++;return Math.sqrt(P());}if(c==='∛'){i++;return Math.cbrt(P());}if(c==='x'){i++;return 1.37;}const m=t.slice(i).match(/^\d*\.?\d+/);if(!m)throw 0;i+=m[0].length;return +m[0];};
  try{const v=E();return i>=t.length&&Number.isFinite(v)?v:null;}catch(e){return null;}
}
let eq=0, qt=0;
for(const id of ids) for(let n=1;n<=3;n++) for(let k=0;k<N/2;k++){
  const q=T.gerarQuestao(id,n); qt++;
  const uni=q.options.map(o=>(String(o).match(/\s(cm²|cm³|m²|m³|dm³|km\/h|km|cm|mm|kg|g|L|mL|m|h|min)$/)||[''])[0]); const vs=q.options.map(ev); if(new Set(uni).size===1 && vs.every(v=>v!==null)){ const ks=new Set(vs.map(v=>v.toPrecision(9))); if(ks.size<4){ eq++; if(eq<6) console.log('EQUIVALENTES',id,n,q.text,q.options); } }
  const txtAll=q.options.join(' ; ')+' | '+q.text; if(/\d\.\d{1,2}(?!\d)|\d\.\d{4,}|\d,\d+\.\d/.test(txtAll)){ eq++; if(eq<8) console.log('PONTO DECIMAL',id,n,txtAll); }
  if(q.text.length>260 && k===0) console.log('TEXTO LONGO',id,n,q.text.length);
}
console.log(`equivalência (teste próprio): ${eq} de ${qt}`);
for(const id of ids) for(let n=1;n<=3;n++) for(let k=0;k<amostra;k++){ const q=T.gerarQuestao(id,n); console.log(`[${id} N${n}] ${q.text} | ${q.options.join(' ; ')} | ✔ ${q.options[q.correct]} | erros: ${q.erros.filter(Boolean).join(' / ')}`); }
process.exit(0);
