const fs=require('fs'); const t=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const S={};
for(const r of Object.values(t.alunos)) for(const [id,d] of Object.entries(r.deg||{})){ if(!d.tot) continue; const s=S[id]||(S[id]={tot:0,ac:0,al:0,dom:0,err:{}}); s.tot+=d.tot; s.ac+=d.ac||0; s.al++; if(d.dom&&d.domPor!=='diag'&&d.domPor!=='ano') s.dom++; for(const [e,n] of Object.entries(d.err||{})) s.err[e]=(s.err[e]||0)+n; }
const L=Object.entries(S).filter(([k,s])=>s.tot>=60).map(([k,s])=>({k,tot:s.tot,acc:Math.round(s.ac/s.tot*100),al:s.al,dom:s.dom,err:Object.entries(s.err).sort((a,b)=>b[1]-a[1]).slice(0,2).map(([e,n])=>e+' ('+n+')').join('; ')}));
L.sort((a,b)=>a.acc-b.acc); console.log(L.map(x=>`${x.k.padEnd(14)} ${String(x.tot).padStart(5)} resp | ${x.acc}% | ${x.al} alunos, ${x.dom} dominaram | ${x.err}`).join('\n'));
