const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},(window.__lento&&/emqx/.test(U))?window.__lento:50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){const era=cli.connected;cli.connected=false;cli._fim=true;window.__unsub(window.__cid);setTimeout(()=>(h.close||[]).forEach(f=>f()),30)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }

  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.selectOption('#trAno', '1');
  await prof.click('#trDiag button[data-v="inicio"]');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trTempo button[data-v="0"]');
  await prof.click('#createRoomBtn');
  await prof.waitForTimeout(1200);
  const sala = (await prof.textContent('#hRoomCode')).trim();
  await prof.evaluate(() => { window.__ACOMP.PARADO_MS = 8000; window.__ACOMP.OFFLINE_MS = 22000; });
  const entrar = async nm => { const a = await nova(nm); await a.fill('#joinRoom', sala); await a.fill('#joinName', nm); await a.click('#joinBtn'); await a.waitForFunction(() => app.player.phase === 'playing' && app.player.trilha && app.player.trilha.rec, null, { timeout: 15000 }); return a; };
  const ana = await entrar('Ana'), beto = await entrar('Beto'), caio = await entrar('Caio'), duda = await entrar('Duda');
  const responde = async (pg, certo) => { if(await pg.$('#vjBox')){ await pg.waitForTimeout(2200); await pg.click('#vjBox .vj-ok'); await pg.waitForTimeout(300); } await pg.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked && !document.getElementById('vjBox') && ![...document.querySelectorAll('#ppOptions button')].some(b => b.disabled), null, { timeout: 15000 }); const c = await pg.evaluate(() => app.player.currentQuestion.correct); await pg.click(`#ppOptions button:nth-child(${(certo ? c : (c + 1) % 4) + 1})`); await pg.waitForTimeout(800); };
  // Beto erra 2 seguidas da mesma atividade -> "Vamos ver juntos"
  let viu = false;
  for(let i = 0; i < 6 && !viu; i++){ await responde(beto, false); viu = !!(await beto.$('#vjBox')); }
  ok(viu, 'Beto errou 2 seguidas: apareceu "Vamos ver juntos"');
  if(viu){
    await beto.screenshot({ path: '/home/claude/cm/a_verjuntos.png' });
    const info = await beto.evaluate(() => ({ certa: !!document.querySelector('#vjBox .vj-alt.certa'), errada: !!document.querySelector('#vjBox .vj-alt.errada'), dica: document.querySelector('#vjBox .vj-dica').textContent.length > 20, bloq: document.querySelector('#vjBox .vj-ok').disabled }));
    ok(info.certa && info.errada && info.dica && info.bloq, 'mostra a certa, a que ele marcou e como fazer; botão espera 2 s ' + JSON.stringify(info));
    await beto.waitForTimeout(2200); await beto.click('#vjBox .vj-ok'); await beto.waitForTimeout(500);
    ok(!(await beto.$('#vjBox')) && await beto.evaluate(() => !!app.player.currentQuestion && !app.player.questionBlocked), 'depois de "Entendi" vem a próxima pergunta');
  }
  // freio: 3 erros rápidos seguidos
  let freio = false;
  for(let i = 0; i < 8 && !freio; i++){
    await beto.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 15000 });
    if(await beto.$('#vjBox')){ await beto.waitForTimeout(2200); await beto.click('#vjBox .vj-ok'); await beto.waitForTimeout(400); }
    freio = !!(await beto.$('#frAviso'));
    if(!freio) await responde(beto, false);
    else break;
    if(await beto.$('#vjBox')){ await beto.waitForTimeout(2200); await beto.click('#vjBox .vj-ok'); await beto.waitForTimeout(400); }
    freio = !!(await beto.$('#frAviso'));
  }
  const fr = await beto.evaluate(() => ({ aviso: (document.getElementById('frAviso') || {}).textContent, travadas: [...document.querySelectorAll('#ppOptions button')].every(b => b.disabled) }));
  ok(freio && fr.travadas, 'chute: "Calma!" e alternativas travadas ' + JSON.stringify(fr));
  await beto.screenshot({ path: '/home/claude/cm/a_freio.png' });
  await beto.waitForTimeout(5600);
  ok(await beto.evaluate(() => [...document.querySelectorAll('#ppOptions button')].every(b => !b.disabled) && !document.getElementById('frAviso')), 'depois de 5 s as alternativas liberam');
  for(let i = 0; i < 4; i++){ if(await beto.$('#vjBox')){ await beto.waitForTimeout(2200); await beto.click('#vjBox .vj-ok'); } await responde(beto, false); }
  for(let i = 0; i < 6; i++) await responde(ana, true);
  // Duda sai (fecha o celular)
  await duda.close();
  for(let i = 0; i < 8; i++) await responde(beto, false);
  await prof.waitForTimeout(16000);
  await prof.click('#ttPainel [data-det]');
  for(let i = 0; i < 2; i++) await responde(ana, true);
  await prof.waitForTimeout(3500);
  const cards = await prof.evaluate(() => [...document.querySelectorAll('#ttPainel .ac-card')].map(c => c.querySelector('.ac-nome').textContent + ' = ' + c.querySelector('.ac-st').textContent));
  console.log('   cartões (em ordem):', cards.join(' | '));
  ok(/^Beto.* = (🔴|🎲)/.test(cards[0]) && cards.some(c => /Caio = 🟡 parado/.test(c)) && cards.some(c => /Duda = 📡/.test(c)) && cards.some(c => /Ana = 🟢/.test(c)), 'acompanhar: Beto em cima (errando/chutando), Caio parado, Duda offline, Ana respondendo');
  await prof.screenshot({ path: '/home/claude/cm/a_painel.png' });
  // plano do Caio: só Soma até 10 e Soma até 20
  const caioId = await caio.evaluate(() => app.playerId);
  await prof.click(`#ttPainel [data-aluno="${caioId}"]`); await prof.click('#acMenu [data-a="plano"]');
  await prof.click('#plBox input[value="lista"]');
  await prof.waitForTimeout(300);
  await prof.screenshot({ path: '/home/claude/cm/a_plano.png' });
  await prof.click('#plBox input[data-id="soma10"]'); await prof.click('#plBox input[data-id="soma20"]');
  await prof.click('#plBox [data-salvar]');
  await caio.waitForFunction(() => app.player.trilha.rec.plano, null, { timeout: 15000 }).catch(() => {});
  await caio.waitForTimeout(400);
  const tipos = new Set();
  for(let i = 0; i < 14; i++){ await caio.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked && !document.getElementById('vjBox'), null, { timeout: 15000 }); tipos.add(await caio.evaluate(() => app.player.currentQuestion.type)); await responde(caio, true); }
  ok([...tipos].every(t => ['soma10', 'soma20'].includes(t)), 'plano do Caio: só caem as atividades marcadas → ' + [...tipos].join(', '));
  // plano "até o 1º ano" para a Ana e depois sem adaptação
  const anaId = await ana.evaluate(() => app.playerId);
  await prof.click(`#ttPainel [data-aluno="${anaId}"]`); await prof.click('#acMenu [data-a="plano"]');
  await prof.click('#plBox input[value="ano"]'); await prof.selectOption('#plAno', '1'); await prof.click('#plBox [data-salvar]');
  await ana.waitForFunction(() => app.player.trilha.rec.plano, null, { timeout: 15000 }).catch(() => {});
  await ana.waitForTimeout(400);
  const anos = new Set();
  for(let i = 0; i < 10; i++){ await ana.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 15000 }); anos.add(await ana.evaluate(() => { const q = app.player.currentQuestion; return q.trilha ? q.trilha.ano : 'x'; })); await responde(ana, true); }
  ok([...anos].every(a => a === 1), 'plano da Ana "até o 1º ano": só 1º ano → ' + [...anos].join(','));
  ok(await prof.evaluate(() => /📌/.test(document.getElementById('ttPainel').textContent)), 'o cartão mostra o 📌 do plano');
  // corrida continua sem essas ajudas (e sem erro)
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
