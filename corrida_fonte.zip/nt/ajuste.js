const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1300,height:1400}});
  const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('dialog', d => d.accept());
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.evaluate(()=>localStorage.clear()); await p.reload();
  await p.click('#navTeacher'); await p.click('#trCatalogo'); await p.click('button[data-ano="3"]');
  await p.uncheck('[data-usar="reguaMm"]');
  await p.selectOption('[data-mudaano="divResto"]', '4');
  await p.waitForTimeout(300);
  const r1 = await p.evaluate(()=>({ no3: TRILHA.CAT.filter(d=>d.ano===3).map(d=>d.id).includes('divResto'), no4: TRILHA.CAT.filter(d=>d.ano===4).map(d=>d.id).slice(-2), regua: TRILHA.POR_ID.reguaMm.off, cfg: JSON.parse(localStorage.getItem('cgm_trilha_cfg')).aj }));
  console.log('depois de mudar:', JSON.stringify(r1));
  await p.click('button[data-ano="4"]'); await p.waitForTimeout(200);
  const el = await p.$('[data-cd="divResto"]'); await el.screenshot({path:'/home/claude/cm/aj_div.png'});
  await p.click('button[data-ano="3"]'); await p.waitForTimeout(200);
  const el2 = await p.$('[data-cd="reguaMm"]'); await el2.screenshot({path:'/home/claude/cm/aj_regua.png'});
  await p.reload(); await p.click('#navTeacher');
  const r2 = await p.evaluate(()=>{ const T=TRILHA; T.LIMITE.anoMax=7; const rec=T.novoRegistro('x'); T.iniciar(rec,{ano:1,diag:'inicio'}); let viu=0; const ids=new Set();
    for(let i=0;i<8000;i++){ const f=T.escolherFonte(rec); ids.add(f.id); if(f.id==='reguaMm') viu++; const q=T.gerarQuestao(f.id,f.nivel); T.registrar(rec,f,q,q.correct,true,.2); }
    return { regua_off: T.POR_ID.reguaMm.off, divResto_ano: T.POR_ID.divResto.ano, vezes_regua: viu, divResto_visto: ids.has('divResto') }; });
  console.log('depois de recarregar + 8000 respostas:', JSON.stringify(r2), 'erros', errs);
  await b.close();
})();
