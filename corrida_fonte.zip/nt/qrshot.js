const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1280,height:800}});
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){const h={};const c={connected:false,on(e,f){(h[e]=h[e]||[]).push(f);if(e==="connect")setTimeout(()=>{c.connected=true;f()},50)},subscribe(){},publish(){},end(){}};return c}}'}));
await p.goto('file:///home/claude/cm/work.html'); await p.click('#navTeacher');
await p.click('#trOn button[data-v="1"]'); await p.click('#trModo button[data-v="treino"]'); await p.click('#trLista button[data-v="1"]');
await p.click('#createRoomBtn'); await p.waitForTimeout(1200); await p.screenshot({path:'/home/claude/cm/qr.png'}); await b.close();})();
