const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const w=d.window; const r=w.testarTrilha(400);
r.exemplos.filter(e=>/urna|chance|pizza|fracfig/.test(e.degrau)).slice(0,10).forEach(e=>console.log(e.degrau,e.nivel,e.problema,'|',e.q.text,JSON.stringify(e.q.options),e.q.answer));
process.exit(0);
