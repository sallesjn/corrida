const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true }); await ctx.addInitScript(() => { setInterval(() => { const d = document.getElementById('mxDet'); if(d && !d.open) d.open = true; }, 50); });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},(window.__lento&&/emqx/.test(U))?window.__lento:50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){const era=cli.connected;cli.connected=false;cli._fim=true;window.__unsub(window.__cid);setTimeout(()=>(h.close||[]).forEach(f=>f()),30)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }
  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.selectOption('#trAno', '1');
  await prof.click('#trDiag button[data-v="inicio"]');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trRank button[data-v="1"]');
  await prof.screenshot({ path: '/home/claude/cm/t_card.png', clip: await (await prof.$('#trilhaCard')).boundingBox() });
  await prof.click('#createRoomBtn');
  await prof.waitForTimeout(600);
  const sala = (await prof.textContent('#roomCodeDisplay')).trim();
  ok(/TREINO/.test(await prof.textContent('#hModeLabel')), 'rótulo da sala: ' + (await prof.textContent('#hModeLabel')));
  const pSala = await nova('Link');
  await pSala.goto('file:///home/claude/cm/work.html?sala=' + sala);
  ok((await pSala.inputValue('#joinRoom')) === sala, 'abrir pelo link do QR já preenche o código da sala');
  await pSala.close();
  const ana = await nova('Ana');
  await ana.fill('#joinRoom', sala); await ana.fill('#joinName', 'Ana'); await ana.click('#joinBtn');
  await ana.waitForTimeout(700);
  ok(await prof.evaluate(() => app.host.phase === 'playing'), 'treino começou sozinho (sem apertar Começar); jogadores: ' + await prof.evaluate(() => app.host.players.map(p => p.name).join(',')));
  await prof.waitForTimeout(1200);
  const vis = sel => ana.evaluate(s => { const e = document.querySelector(s); return !!e && getComputedStyle(e).display !== 'none'; }, sel);
  ok(await ana.evaluate(() => document.body.classList.contains('cgm-treino')), 'aluno em modo treino');
  ok(!(await vis('#ppTime')) && !(await vis('#ppQuestionCard .qtimer')) && !(await vis('.pp-stats .item.score')), 'sem relógio, sem cronômetro da questão, sem pontos');
  ok(await vis('#ppTreinoTag'), 'etiqueta: ' + await ana.textContent('#ppTreinoTag'));
  await ana.screenshot({ path: '/home/claude/cm/t_aluno.png' });
  // cronômetro não corre: prazo já vencido e mesmo assim não estoura
  await ana.evaluate(() => { app.player.questionDeadline = performance.now() - 1; });
  await ana.waitForTimeout(1500);
  ok(await ana.evaluate(() => app.player.stats.timeouts === 0 && !app.player.questionBlocked), 'questão não estoura o tempo');
  // Ana acerta tudo DEVAGAR (10 min por questão): no treino deve dominar mesmo assim
  let dom = 0;
  for(let i = 0; i < 60; i++){
    await ana.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 });
    const c = await ana.evaluate(() => { app.player.questionStart = performance.now() - 600000; return app.player.currentQuestion.correct; });
    await ana.click(`#ppOptions button:nth-child(${c + 1})`);
    await ana.waitForTimeout(760);
    if(await ana.$('.tr-festa') && !dom){ dom = 1; await ana.waitForTimeout(700); await ana.screenshot({ path: '/home/claude/cm/t_festa.png' });
      const q0 = await ana.evaluate(() => app.player.questionBlocked); console.log('   festa na tela; pergunta seguinte ainda não apareceu:', q0);
      await ana.click('.tr-festa'); const aindaAberta = !!(await ana.$('.tr-festa')); console.log('   toque no 1º segundo não fecha:', aindaAberta); await ana.waitForTimeout(6600); console.log('   festa fechou sozinha:', !(await ana.$('.tr-festa')), '| nova pergunta:', await ana.evaluate(() => !app.player.questionBlocked)); }
  }
  const recA = await ana.evaluate(() => Object.entries(app.player.trilha.rec.deg).filter(([k, d]) => d.dom).map(([k, d]) => k + '/' + d.domPor));
  ok(recA.length >= 1 && recA.every(x => x.endsWith('/treino')), 'Ana dominou devagar: ' + recA.join(', '));
  // atrasado
  const beto = await nova('Beto');
  await beto.fill('#joinRoom', sala); await beto.fill('#joinName', 'Beto'); await beto.click('#joinBtn');
  await beto.waitForTimeout(1500);
  ok(await beto.evaluate(() => app.player.phase === 'playing' && document.body.classList.contains('cgm-treino')), 'Beto entrou atrasado e está jogando');
  for(let i = 0; i < 3; i++){ if(await beto.$('#vjBox')){ await beto.waitForTimeout(2200); await beto.click('#vjBox .vj-ok'); } await beto.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 }); const c = await beto.evaluate(() => app.player.currentQuestion.correct); await beto.click(`#ppOptions button:nth-child(${c + 1})`); await beto.waitForTimeout(760); }
  // aluno numa rede que bloqueia o servidor principal: deve passar para o reserva sozinho
  const caio = await nova('Caio');
  await caio.evaluate(() => { window.__bloqueia = true; });
  await caio.fill('#joinRoom', sala); await caio.fill('#joinName', 'Caio'); await caio.click('#joinBtn');
  const t0 = Date.now();
  await caio.waitForFunction(() => app.player.phase === 'playing', null, { timeout: 30000 }).catch(() => {});
  await caio.waitForTimeout(2500);
  const cs = await caio.evaluate(() => ({ fase: app.player.phase, srv: app._srv, selo: (document.getElementById('netStatus') || {}).textContent }));
  ok(cs.fase === 'playing' && cs.srv > 0 && /^online/.test(cs.selo), `rede bloqueada: Caio entrou pelo servidor reserva em ${Math.round((Date.now() - t0) / 1000)} s (${JSON.stringify(cs)})`);
  for(let i = 0; i < 6; i++){ await caio.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 15000 }); const c = await caio.evaluate(() => app.player.currentQuestion.correct); await caio.click(`#ppOptions button:nth-child(${c + 1})`); await caio.waitForTimeout(760); }
  await caio.waitForTimeout(3500);
  const pc = await prof.evaluate(() => { const p = app.host.players.find(x => x.name === 'Caio'); const r = TRILHA.estado.turma.alunos.caio; return { resp: p && (p.correct + p.wrong), rec: r && r.resp }; });
  // servidor principal lento (12 s): o aluno não pode ficar preso trocando de servidor
  const duda = await nova('Duda');
  await duda.evaluate(() => { window.__lento = 12000; });
  await duda.fill('#joinRoom', sala); await duda.fill('#joinName', 'Duda'); await duda.click('#joinBtn');
  const t1 = Date.now();
  await duda.waitForFunction(() => app.player.phase === 'playing', null, { timeout: 40000 }).catch(() => {});
  await duda.waitForTimeout(6000);
  const ds = await duda.evaluate(() => ({ fase: app.player.phase, srv: app._srv, ligados: (window.__clis || []).filter(c => c.connected && !/cgm_n_/.test(c._id || '')).length }));
  ok(ds.fase === 'playing', `servidor lento: Duda entrou em ${Math.round((Date.now() - t1) / 1000 - 6)} s pelo servidor ${ds.srv + 1}; conexões abertas: ${ds.ligados}`);
  // trocar o nome: professor clica no nome do Beto; o celular dele fica obrigado a trocar (Zé já tinha progresso: junta)
  await prof.evaluate(() => { const r = JSON.parse(JSON.stringify(TRILHA.estado.turma.alunos.ana)); r.nome = 'Zé'; r.chave = 'ze'; TRILHA.estado.turma.alunos.ze = r; });
  if(!(await prof.evaluate(() => TRILHA.estado.treinoDet))) await prof.click('#ttPainel [data-det]');
  const betoId = await beto.evaluate(() => app.playerId);
  await prof.click(`#ttPainel [data-aluno="${betoId}"]`); await prof.click('#acMenu [data-a="nome"]');
  await beto.waitForSelector('#trocaNomeBox', { timeout: 5000 });
  await beto.screenshot({ path: '/home/claude/cm/t_trocanome.png' });
  await beto.fill('#tnNome', 'Ana'); await beto.click('#tnOk');
  await beto.waitForSelector('#trocaNomeBox .tn-erro', { timeout: 5000 });
  ok(/já está sendo usado/.test(await beto.textContent('#trocaNomeBox .tn-erro')), 'nome já usado na sala é recusado e a tela continua travada');
  await beto.fill('#tnNome', 'Zé'); await beto.click('#tnOk');
  await beto.waitForTimeout(2000);
  const ren = await prof.evaluate(() => ({ nome: app.host.players.find(p => p.name === 'Zé') ? 'Zé' : '?', temBeto: !!TRILHA.estado.turma.alunos.beto, zeDom: Object.values(TRILHA.estado.turma.alunos.ze.deg).filter(d => d.dom).length }));
  const nomeCel = await beto.evaluate(() => ({ nome: app.playerName, tela: !!document.getElementById('trocaNomeBox') }));
  ok(ren.nome === 'Zé' && !ren.temBeto && ren.zeDom >= 1 && nomeCel.nome === 'Zé' && !nomeCel.tela, 'aluno trocou o nome: ' + JSON.stringify({ ...ren, celular: nomeCel }));
  await beto.waitForTimeout(16500);
  ok(await prof.evaluate(() => !!app.host.players.find(p => p.name === 'Zé')), 'depois de 16 s o nome continua Zé (o celular não desfaz)');
  ok(await beto.evaluate(() => !!(app.player.trilha && app.player.trilha.rec && Object.values(app.player.trilha.rec.deg).some(d => d.dom))), 'o celular do Zé recebeu o progresso juntado');
  // remover a Duda
  const dudaId = await duda.evaluate(() => app.playerId);
  await prof.click(`#ttPainel [data-aluno="${dudaId}"]`); await prof.click('#acMenu [data-a="rem"]');
  await prof.waitForTimeout(1500);
  ok(!(await prof.evaluate(id => !!app.host.players.find(p => p.id === id), dudaId)) && /removido/i.test(await duda.textContent('#playerWait')), 'remover aluno no treino');
  prof.removeAllListeners('dialog'); prof.on('dialog', d => d.accept());
  // registro do professor = registro do aluno (envio só do que mudou)
  await ana.waitForTimeout(3500);
  const iguais = await (async () => { const a = await ana.evaluate(() => JSON.stringify(app.player.trilha.rec.deg)); const p = await prof.evaluate(() => JSON.stringify(TRILHA.estado.turma.alunos.ana.deg)); return a === p; })();
  ok(iguais, 'professor tem exatamente o mesmo progresso que o celular da Ana (envio parcial)');
  // trilha perdida: o aluno pede de novo sozinho
  await caio.evaluate(() => { app.player.trilha = null; });
  await caio.waitForTimeout(6000);
  ok(await caio.evaluate(() => !!(app.player.trilha && app.player.trilha.rec)), 'Caio perdeu a trilha e recebeu de novo sozinho');
  ok(pc.resp >= 5 && pc.rec >= 5, 'professor recebe as respostas do Caio pelo reserva: ' + JSON.stringify(pc));
  await prof.waitForTimeout(3500);
  ok(await prof.evaluate(() => document.body.classList.contains('cgm-treino-prof') && !!document.getElementById('ttPainel')), 'professor vê o painel do treino');
  ok(await prof.evaluate(() => app.host.matchDurationMs === 30 * 60000 + 7), 'treino com tempo definido: ' + await prof.evaluate(() => (app.host.matchDurationMs - 7) / 60000 + ' min'));
  ok(await ana.evaluate(() => !document.body.innerText.match(/\dº ano/)), 'aluno não vê o ano da atividade');
  console.log('   painel:', (await prof.textContent('#ttPainel')).replace(/\s+/g, ' ').trim());
  await prof.screenshot({ path: '/home/claude/cm/t_prof_rank.png' });
  await prof.evaluate(() => { TRILHA.estado.cfg.rank = 0; });
  await prof.click('#ttPainel [data-det]');
  await prof.waitForTimeout(300);
  await prof.screenshot({ path: '/home/claude/cm/t_prof_semrank.png' });
  console.log('   sem ranking:', (await prof.textContent('#ttPainel')).replace(/\s+/g, ' ').trim().slice(0, 300));
  // professor recarrega e retoma
  await prof.reload(); await prof.waitForTimeout(800);
  await prof.click('#retomarSim'); await prof.waitForTimeout(3800);
  ok(await prof.evaluate(() => document.body.classList.contains('cgm-treino-prof') && !!document.getElementById('ttPainel') && app.host.phase === 'playing'), 'retomada continua em treino');
  for(let i = 0; i < 2; i++){ await ana.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 }); const c = await ana.evaluate(() => app.player.currentQuestion.correct); await ana.click(`#ppOptions button:nth-child(${c + 1})`); await ana.waitForTimeout(760); }
  await prof.waitForTimeout(3500);
  // encerra
  await prof.evaluate(() => { app.host.matchEndTime = Date.now() + 1500; });
  await prof.waitForTimeout(3500);
  ok(/Fim do treino/.test(await prof.textContent('#hEndSub')), 'fim: ' + (await prof.textContent('#hEndSub')));
  ok(await prof.evaluate(() => app.host.matchDurationMs === 15 * 60000 && app.host.sprintEnabled === true), 'duração/sprint voltaram ao normal: ' + await prof.evaluate(() => app.host.matchDurationMs / 60000 + ' min, sprint ' + app.host.sprintEnabled));
  ok(/Treino encerrado/.test(await ana.textContent('#pdSub')), 'aluno: ' + await ana.textContent('#pdSub'));
  await prof.screenshot({ path: '/home/claude/cm/t_prof_fim.png', fullPage: true });
  await ana.screenshot({ path: '/home/claude/cm/t_aluno_fim.png' });
  const [dl] = await Promise.all([prof.waitForEvent('download'), prof.click('#trSalvarFim')]);
  const pth = '/home/claude/cm/turma_treino.json'; await dl.saveAs(pth);
  const t = JSON.parse(fs.readFileSync(pth, 'utf8'));
  ok(t.alunos.ana && Object.values(t.alunos.ana.deg).some(d => d.dom && d.domPor === 'treino') && t.alunos.ze && !t.alunos.beto, 'arquivo da turma tem Ana (com degraus do treino) e Zé (ex-Beto)');
  // próxima aula: carrega o arquivo, cria CORRIDA; Ana continua de onde parou
  const prof2 = await nova('prof2');
  await prof2.click('#navTeacher');
  await prof2.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof2.reload(); await prof2.waitForTimeout(500); await prof2.click('#navTeacher');
  await prof2.setInputFiles('#trArquivo', pth); await prof2.waitForTimeout(600);
  ok(await prof2.evaluate(() => TRILHA.estado.cfg.modo === 'treino'), 'o arquivo da turma trouxe as configurações (tipo de sala = treino)');
  await prof2.click('#trModo button[data-v="corrida"]');
  await prof2.click('#createRoomBtn'); await prof2.waitForTimeout(600);
  const sala2 = (await prof2.textContent('#roomCodeDisplay')).trim();
  const ana2 = await nova('Ana2');
  await ana2.fill('#joinRoom', sala2); await ana2.dispatchEvent('#joinRoom', 'input'); await ana2.waitForSelector('#trNomesAluno button[data-n="Ana"]'); await ana2.click('#trNomesAluno button[data-n="Ana"]'); await ana2.click('#apEntrar');
  await ana2.waitForTimeout(700);
  const beto2 = await nova('Beto2');
  await beto2.fill('#joinRoom', sala2); await beto2.dispatchEvent('#joinRoom', 'input'); await beto2.waitForSelector('#trNomesAluno button:not([disabled])'); console.log('lista aula 2:', await beto2.$$eval('#trNomesAluno button', bs => bs.map(b => b.textContent).join(', '))); await beto2.click('#trNomesAluno button:not([disabled])'); await beto2.click('#apEntrar');
  await beto2.waitForTimeout(700);
  await prof2.click('#startGameBtn'); await prof2.waitForTimeout(1500);
  const r2 = await ana2.evaluate(() => ({ treino: document.body.classList.contains('cgm-treino'), timer: getComputedStyle(document.querySelector('#ppTime')).display !== 'none', atual: app.player.trilha && app.player.trilha.rec.atual, dom: Object.values(app.player.trilha.rec.deg).filter(d => d.dom).length, ms: app.player.matchTotalMs / 60000 }));
  ok(!r2.treino && r2.timer && r2.dom === recA.length + 0 || r2.dom >= recA.length, `corrida normal na aula seguinte, Ana continua: ${JSON.stringify(r2)}`);
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
