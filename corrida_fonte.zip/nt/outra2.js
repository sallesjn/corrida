const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1300,height:1400}});
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.click('#navTeacher'); await p.click('#trCatalogo'); await p.click('button[data-ano="3"]');
  const sel = '[data-deg="divResto"][data-n="2"]';
  let ant = await p.$eval(sel, e => e.textContent), mud = 0;
  for(let i=0;i<6;i++){ await p.click(sel + ' [data-outra]'); const t = await p.$eval(sel, e => e.textContent); if(t !== ant) mud++; ant = t; }
  console.log('outra (divResto):', mud, 'de 6');
  await b.close();
})();
