const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1400,height:2400}});
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  const ids = process.argv[2].split(',');
  await p.evaluate((ids)=>{
    document.body.innerHTML = '<div id="g" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:10px;background:#0f172a;color:#fff;font-family:Arial"></div>';
    for(const id of ids) for(let n=1;n<=3;n++){
      const q = TRILHA.gerarQuestao(id,n);
      const d=document.createElement('div'); d.style.cssText='background:#1e293b;padding:8px;border-radius:10px';
      d.innerHTML = `<div style="font-size:12px;color:#93c5fd">${id} N${n}</div><div style="font-size:20px;font-weight:bold">${renderMath(q.text)}</div><div style="font-size:12px;color:#fde68a">💡 ${TRILHA.dicaDe(q)}</div>`+
        (q.image?`<img src="${q.image}" style="max-width:100%;max-height:230px;background:#fff;border-radius:8px">`:'')+
        `<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:6px">`+q.options.map((o,i)=>`<div style="background:${i===q.correct?'#166534':'#334155'};padding:4px;font-size:15px">${q.optImgs?`<img src="${q.optImgs[i]}" style="height:50px;background:#fff">`:''}${renderMath(TRILHA.fracEmPe(o))} <small style="color:#fca5a5">${q.erros&&q.erros[i]||''}</small></div>`).join('')+`</div><div style="font-size:11px;color:#a3a3a3">🔊 ${q.fala}</div>`;
      document.getElementById('g').appendChild(d);
    }
  }, ids);
  await p.waitForTimeout(500);
  await p.screenshot({path: process.argv[3], fullPage:true});
  await b.close();
})();
