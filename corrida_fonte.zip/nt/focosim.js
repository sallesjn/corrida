const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
T.estado.focoAluno={ids:['tiposAng6','paralPerp6'],freq:0.34,stamp:1};
const rec=T.novoRegistro('x'); T.iniciar(rec,{diag:'inicio',ano:1});
let foco=0,n=2000;
for(let k=0;k<n;k++){ const f=T.escolherFonte(rec); if(f.tipo==='foco') foco++; const q=T.gerarQuestao(f.id,f.nivel); T.registrar(rec,f,q,q.correct,true,0.3); }
console.log('foco', (foco/n*100).toFixed(1)+'%', 'dominados', Object.values(rec.deg).filter(x=>x.dom).length, 'tiposAng6', JSON.stringify(rec.deg.tiposAng6 && {n:rec.deg.tiposAng6.n,dom:rec.deg.tiposAng6.dom}));
process.exit(0);
