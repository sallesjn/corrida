const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
const rec=T.novoRegistro('x'); T.iniciar(rec,{diag:'inicio',ano:1});
for(let k=1;k<=2400;k++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel); const ok=Math.random()<0.8; T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,0.3);
 if(k%400===0) console.log(k,'respostas:',Object.values(rec.deg).filter(x=>x.dom).length,'dominados, rec =',Math.round(JSON.stringify(rec).length/1024),'KB'); }
process.exit(0);
