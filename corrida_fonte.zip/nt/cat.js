const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1366,height:768}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.goto('file:///home/claude/cm/work.html');
await p.evaluate(()=>localStorage.setItem('cgm_trilha_cfg', JSON.stringify({on:false,ano:1})));
await p.reload(); await p.click('#navTeacher');
console.log('ligada por padrão (mesmo com "desligada" salva antes):', await p.$eval('#trOn .on', e=>e.textContent), '| opções visíveis:', await p.$eval('#trOpts', e=>!e.classList.contains('hidden')));
await p.click('#trCatalogo'); await p.waitForTimeout(400);
await p.screenshot({path:'/home/claude/cm/cat1.png'});
const n1 = await p.$$eval('.cat-deg', x=>x.length), q1 = await p.$$eval('.cat-q', x=>x.length);
const antes = await p.$eval('.cat-q .enun', e=>e.textContent); await p.click('.cat-q [data-outra]'); 
console.log('1º ano:', n1, 'degraus,', q1, 'exemplos | outra:', antes, '→', await p.$eval('.cat-q .enun', e=>e.textContent));
for(const a of [2,3,7]){ await p.click(`[data-ano="${a}"]`); await p.waitForTimeout(200); console.log(a+'º ano:', await p.$$eval('.cat-deg', x=>x.length), 'degraus'); }
await p.click('[data-ano="2"]'); await p.waitForTimeout(300); await p.screenshot({path:'/home/claude/cm/cat2.png'});
await p.keyboard.press('Escape'); console.log('Esc fecha:', !(await p.$('#trCatalogoBox')));
console.log('erros', errs); await b.close();})();
