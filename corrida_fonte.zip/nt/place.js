const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const w=d.window, T=w.eval('TRILHA'); let amb=0, tot=0, ex='';
for(let n=1;n<=3;n++) for(let k=0;k<5000;k++){ const q=T.gerarQuestao('p4_valor',n); tot++; const m=/Valor do algarismo (\d) em (\d+)/.exec(q.text); if(m && m[2].split(m[1]).length-1>1){amb++; ex=q.text;} if(m){ const s=m[2], i=s.indexOf(m[1]); const v=(+m[1])*Math.pow(10,s.length-1-i); if(String(v)!==String(q.options[q.correct]).replace(/\./g,'')) {amb++; ex='RESP '+q.text+' '+q.options[q.correct];} } }
for(let lv=1;lv<=5;lv++) for(let k=0;k<3000;k++){ const g=w.generateQuestion({allowed:null},lv,'place'); tot++; const m=/Valor do algarismo (\d) em (\d+)/.exec(g.text); if(m && m[2].split(m[1]).length-1>1){amb++; ex=g.text;} }
console.log('ambíguas/erradas:', amb, 'de', tot, ex); process.exit(0);
