const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:390,height:780},deviceScaleFactor:1});
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.goto('file:///home/claude/cm/work.html');
const ids=process.argv[2].split(',');
for(const [k,id] of ids.entries()){
 await p.evaluate(([id])=>{app.showPlayerScreen('Play');app.player.trilha={on:true,cfg:{voz:'nunca'},rec:null,evs:[]};const q=TRILHA.gerarQuestao(id.split(':')[0],+id.split(':')[1]);q.fonte={tipo:'atual'};app.player.questionLimit=45;app.renderPlayerQuestion(q);},[id]);
 await p.waitForTimeout(200); await p.screenshot({path:`/home/claude/cm/m${k}.png`});
}
await b.close();})();
