const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
for(const c of T.CAT.filter(c=>/div|÷|Divis/i.test(c.id+c.nome))) for(let n=1;n<=3;n++){ const s=[]; for(let k=0;k<5;k++) s.push(T.gerarQuestao(c.id,n).text.slice(0,50)); console.log(c.ano+'º '+c.id+' N'+n+': '+s.join(' | ')); }
process.exit(0);
