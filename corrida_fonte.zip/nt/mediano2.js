const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
function porDegrau(p, regra, reps=300){
  Object.assign(T.REGRA, regra); let tot=0, trav=0, nunca=0;
  for(let r=0;r<reps;r++){ const rec=T.novoRegistro('x'); rec.atual='soma10'; rec.diag='pulado'; rec.deg.soma10={ n: 1, cnt: 0, h: [], dom: 0, domPor: '', domEm: '', tot: 0, ac: 0, totA: 0, err: {}, quedas: 0, seqErr: 0, revInt: 8, revUlt: 0, revErr: 0 }; const f={tipo:'atual',id:'soma10'}; let n=0;
    for(;n<600;n++){ const d=rec.deg.soma10||(T.registrar,{n:1});  f.nivel=d.n; const ok=Math.random()<p[d.n]; const ev=T.registrar(rec,f,{erros:null},ok?0:1,ok,.45); if(ev.travou) trav++; if(ev.dominou) break; }
    if(n>=600) nunca++; tot+=n+1; }
  return { media: Math.round(tot/reps), nunca: Math.round(nunca/reps*100)+'%', travou: Math.round(trav/reps*100)+'%' };
}
const perf={ 'mediano 85/75/65': {1:.85,2:.75,3:.65}, 'bom 92/85/78': {1:.92,2:.85,3:.78}, 'fraco 75/62/50':{1:.75,2:.62,3:.5} };
for(const [nome,p] of Object.entries(perf)){
  console.log(nome, '| regra atual 8/10:', JSON.stringify(porDegrau(p,{acertosDominio:8})), '| 7/10:', JSON.stringify(porDegrau(p,{acertosDominio:7})), '| 6/10:', JSON.stringify(porDegrau(p,{acertosDominio:6})));
}
process.exit(0);
