const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); const ex={};
for(const c of T.CAT) for(let n=1;n<=3;n++) for(let k=0;k<150;k++){ const q=T.gerarQuestao(c.id,n);
  const all=[q.text,...q.options.map(String), T.dicaDe(q)];
  for(const s of all){ const m=s.match(/[^\s]*\d\/\d[^\s]*/g); if(m) m.forEach(x=>{ (ex[c.id]=ex[c.id]||new Set()).add(x); }); } }
for(const k in ex) console.log(k, [...ex[k]].slice(0,6).join('  '));
process.exit(0);
