const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1300,height:1400}});
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.click('#navTeacher'); await p.click('#trCatalogo'); await p.click('button[data-ano="3"]');
  const t0 = await p.$eval('[data-deg="planif3"][data-n="2"] .enun', e => e.closest('.cat-q').innerHTML.length + e.closest('.cat-q').querySelector('img').src.slice(-40));
  let mud = 0; for(let i=0;i<6;i++){ await p.click('[data-deg="planif3"][data-n="2"] [data-outra]'); const t = await p.$eval('[data-deg="planif3"][data-n="2"] .enun', e => e.closest('.cat-q').querySelector('img').src.slice(-40)); if(t !== t0.slice(-40)) mud++; }
  console.log('botão outra trocou a questão em', mud, 'de 6 cliques');
  await b.close();
})();
