const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
const p={1:.85,2:.75,3:.65};
function sim(cfg, revNivel, dom, max=30000){
  T.REGRA.acertosDominio=dom; T.LIMITE.anoMax=7; T.LIMITE.pRev=0.2;
  const rec=T.novoRegistro('x'); T.iniciar(rec,cfg); let n=0, esq=0; const ini7=T.CAT.filter(x=>x.ano===7).length;
  for(;n<max;n++){ const f=T.escolherFonte(rec); if(f.tipo==='rev' && revNivel) f.nivel=revNivel; const q=T.gerarQuestao(f.id,f.nivel);
    const ok=Math.random()<p[f.nivel]; const ev=T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,.45); if(ev.esqueceu) esq++;
    const k=T.CAT.filter(x=>x.ano===7 && rec.deg[x.id] && rec.deg[x.id].dom).length; if(k>=Math.ceil(ini7/2) && !rec.meio) rec.meio=n+1; if(k===ini7){ rec.fim7=n+1; break; } }
  return { n, meio: rec.meio||'—', fim: rec.fim7||'—', esq, dom7: T.CAT.filter(x=>x.ano===7 && rec.deg[x.id] && rec.deg[x.id].dom).length + '/' + ini7 };
}
for(const [nome,cfg,rn,dm] of [['regra atual, começa no 7º',{diag:'ano',ano:7},0,8],['revisão no nível médio',{diag:'ano',ano:7},2,8],['revisão médio + domínio 7 de 10',{diag:'ano',ano:7},2,7]]){
  const rs=[...Array(4)].map(()=>sim(cfg,rn,dm)); rs.sort((a,b)=>a.n-b.n);
  console.log(nome,'→ metade do 7º:', rs.map(r=>r.meio).join(' '), '| 7º inteiro:', rs.map(r=>r.fim).join(' '), '| degraus do 7º dominados:', rs.map(r=>r.dom7).join(' '), '| voltou por esquecer:', rs.map(r=>r.esq).join(' '));
}
process.exit(0);
