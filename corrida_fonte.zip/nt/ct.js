const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }


  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.fill('#trTurmaNome', '6º M01'); await prof.dispatchEvent('#trTurmaNome', 'input');
  async function entra(nm, sala){ const a = await nova(nm); await a.fill('#joinRoom', sala); await a.dispatchEvent('#joinRoom', 'input'); await a.fill('#joinName', nm); await a.click('#joinBtn'); await a.waitForTimeout(700); return a; }
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(800);
  const s2 = (await prof.textContent('#roomCodeDisplay')).trim();
  console.log('botão na tela inicial?', await prof.evaluate(() => !document.getElementById('ctBtn').classList.contains('hidden')));
  const a1 = await entra('Ana', s2), a2 = await entra('Neymar', s2);
  await prof.waitForTimeout(1200);
  console.log('botão no lobby:', await prof.textContent('#ctBtn'));
  await prof.click('#startGameBtn'); await prof.waitForTimeout(1500);
  await prof.click('#ctBtn'); await prof.waitForTimeout(400);
  console.log('cartões:', await prof.$$eval('#ctBox .ac-card .ac-nome', x => x.map(e => e.textContent).join(', ')));
  await prof.screenshot({ path: '/home/claude/cm/ct1.png' });
  await prof.click('#ctBox .ac-card:has-text("Neymar")'); await prof.waitForTimeout(300);
  await prof.click('#acMenu [data-a="nome"]'); await prof.waitForTimeout(800);
  console.log('Neymar vê troca de nome:', !!(await a2.$('#trocaNomeBox')));
  await a2.fill('#tnNome', 'Bruno'); await a2.click('#tnOk'); await a2.waitForTimeout(1200);
  console.log('nomes agora:', await prof.evaluate(() => app.host.players.map(p => p.name).join(', ')), '| turma:', await prof.evaluate(() => Object.keys(TRILHA.estado.turma.alunos).join(',')));
  await prof.keyboard.press('Escape');
  await prof.click('#endMatchBtn'); await prof.waitForTimeout(1500);
  await prof.reload(); await prof.waitForTimeout(800);
  await prof.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /Descartar/.test(x.textContent) && x.offsetParent); if(b) b.click(); });
  await prof.click('#navTeacher').catch(()=>{}); await prof.waitForTimeout(400);
  console.log('botão do cartão:', await prof.textContent('#trNova'));
  await prof.click('#trNova'); await prof.waitForTimeout(300);
  console.log('guardados:', await prof.$$eval('#lmBox .lm-al b', x => x.map(e => e.textContent).join(', ')));
  await prof.screenshot({ path: '/home/claude/cm/ct2.png' });
  await prof.click('#lmBox [data-apaga="bruno"]'); await prof.waitForTimeout(300);
  console.log('após apagar Bruno:', await prof.$$eval('#lmBox .lm-al b', x => x.map(e => e.textContent).join(', ')));
  await prof.click('#lmBox [data-limpar="direto"]'); await prof.waitForTimeout(500);
  console.log('após limpar: turma', await prof.evaluate(() => JSON.stringify({ n: TRILHA.estado.turma.nome, a: Object.keys(TRILHA.estado.turma.alunos), nomes: TRILHA.estado.cfg.nomes, foco: TRILHA.estado.cfg.foco.ids })), '| campo turma:', await prof.inputValue('#trTurmaNome'), '| LS:', await prof.evaluate(() => localStorage.getItem('cgm_trilha_turma').slice(0, 80)));
  console.log('erros', log);
  await b.close();
})();
