const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const vc=new VirtualConsole();
const html=fs.readFileSync('../work.html','utf8');
const d=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const w=d.window, T=w.eval('TRILHA');
T.estado.cfg.ano=7; T.estado.cfg.anoMax=9; T.LIMITE.anoMax=9;
const PERFIS={
  forte:a=>a<=6?0.95:a===7?0.8:0.3,
  medio:a=>a<=4?0.92:a<=6?0.6:0.3,
  fraco:a=>a<=2?0.9:a===3?0.55:0.28,
};
const N=+process.argv[2]||120, RESP=+process.argv[3]||400;
function roda(perfil, rapido){
  T.REGRA.rapidoSeguidos = rapido ? 5 : 999;
  const P=PERFIS[perfil]; let out={dom:0, falsos:0, rapidos:0, rapidoAnoAlto:0, chegou6:[], anoAtual:0};
  for(let s=0;s<N;s++){
    const rec=T.novoRegistro('x'+s); T.iniciar(rec,{diag:'saltos',ano:7});
    let cheg=null;
    for(let k=0;k<RESP;k++){
      const f=T.escolherFonte(rec); if(!f||!T.POR_ID[f.id]) break;
      const ano=T.POR_ID[f.id].ano, ok=Math.random()<P(ano);
      const ev=T.registrar(rec,f,{},ok?0:1,ok,0.3);
      if(ev&&ev.dominou){ out.dom++; if(P(T.POR_ID[ev.dominou].ano)<0.6) out.falsos++; if(ev.rapido){ out.rapidos++; if(T.POR_ID[ev.dominou].ano>5) out.rapidoAnoAlto++; } }
      if(cheg===null && rec.atual && T.POR_ID[rec.atual].ano>=6) cheg=k;
    }
    out.chegou6.push(cheg===null?RESP:cheg);
    out.anoAtual += rec.atual ? T.POR_ID[rec.atual].ano : 9;
  }
  const med=a=>{const s=a.slice().sort((x,y)=>x-y);return s[Math.floor(s.length/2)];};
  return `dominados/aluno ${(out.dom/N).toFixed(1)} · falsos ${(out.falsos/N).toFixed(2)} · rápidos ${(out.rapidos/N).toFixed(1)} (ano>5: ${out.rapidoAnoAlto}) · resp. até chegar no 6º ano (mediana) ${med(out.chegou6)} · ano médio do degrau atual no fim ${(out.anoAtual/N).toFixed(2)}`;
}
for(const p of Object.keys(PERFIS)) for(const r of [false,true]) console.log(p.padEnd(5), r?'NOVA ':'ANTIGA', roda(p,r));
// refazer diagnóstico: aluno forte que ficou preso no 1º ano (turma criada com ano 1)
T.REGRA.rapidoSeguidos=5; const P=PERFIS.forte; let antes=0, depois=0, mantidos=0, M=100;
for(let s=0;s<M;s++){
  const rec=T.novoRegistro('y'+s); T.iniciar(rec,{diag:'saltos',ano:1});
  for(let k=0;k<150;k++){ const f=T.escolherFonte(rec); const ok=Math.random()<P(T.POR_ID[f.id].ano); T.registrar(rec,f,{},0,ok,0.3); }
  antes += rec.atual ? T.POR_ID[rec.atual].ano : 9;
  const conq = Object.entries(rec.deg).filter(([id,d])=>d.dom && d.domPor==='trilha').map(([id])=>id);
  T.estado.turma.alunos['y'+s]=rec; T.estado.refazerDiagnostico('y'+s);
  mantidos += conq.every(id=>rec.deg[id].dom) ? 1 : 0;
  T.iniciar(rec,{diag:'saltos',ano:7});
  for(let k=0;k<40;k++){ const f=T.escolherFonte(rec); const ok=Math.random()<P(T.POR_ID[f.id].ano); T.registrar(rec,f,{},0,ok,0.3); }
  depois += rec.atual ? T.POR_ID[rec.atual].ano : 9;
}
console.log(`refazer diagnóstico (forte preso no 1º ano): degrau médio antes ${(antes/M).toFixed(2)}º ano → 40 respostas depois ${(depois/M).toFixed(2)}º ano · conquistas mantidas em ${mantidos}/${M}`);
process.exit(0);
