const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); T.estado.cfg.ano=7;
for(const [nome,P] of [['forte',a=>a<=6?0.95:0.8],['médio (sabe até 4º)',a=>a<=4?0.92:a<=6?0.55:0.3]]){
  const rec=T.novoRegistro('x'); T.iniciar(rec,{diag:'saltos',ano:7}); const seq=[];
  for(let i=0;i<30;i++){ const f=T.escolherFonte(rec); const a=T.POR_ID[f.id].ano; const ok=Math.random()<P(a); T.registrar(rec,f,{},0,ok,0.3); seq.push(`${a}º${f.tipo==='diag'?'🔎':f.tipo==='rev'?'🔁':f.tipo==='previa'?'👀':f.tipo==='desafio'?'⭐':''}${ok?'✓':'✗'}`); }
  console.log(nome+':', seq.join(' '), '→ degrau', rec.atual && T.POR_ID[rec.atual].ano+'º');
}
process.exit(0);
