const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1000,height:400}});
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.evaluate(()=>{ const t=['cone','cilindro','piramide','cubo','prismaTri','paralelepipedo']; let q; document.body.innerHTML='<div id=g style="display:flex;gap:8px;flex-wrap:wrap;background:#ccc"></div>';
    for(const k of t){ for(let i=0;i<60;i++){ q=TRILHA.gerarQuestao('planif3',3); if(q.meta.alvo===k) break; } document.getElementById('g').insertAdjacentHTML('beforeend',`<img src="${q.image}" style="height:180px;background:#fff">`); } });
  await p.screenshot({path:'/home/claude/cm/cone.png'}); await b.close();
})();
