const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1366,height:900}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.goto('file:///home/claude/cm/work.html'); await p.click('#navTeacher');
await p.selectOption('#trAno','9'); await p.waitForTimeout(200);
await p.evaluate(()=>abrirDescritores()); await p.waitForTimeout(300);
console.log('descritores (sem alunos):', await p.$eval('#dsBox', e=>e.innerText.slice(0,300)));
// simula um aluno do 9º com progresso e abre de novo
await p.evaluate(()=>{ const T=TRILHA; const r=T.novoRegistro('Teste'); T.iniciar(r,{diag:'ano',ano:9}); for(let i=0;i<300;i++){ const f=T.escolherFonte(r); const q=T.gerarQuestao(f.id,f.nivel); T.registrar(r,f,q,q.correct,true,0.2);} T.estado.turma.alunos[r.chave]=r; document.getElementById('dsBox').remove(); abrirDescritores(); });
await p.waitForTimeout(300);
console.log(await p.$$eval('.ds-tab tr', t=>t.slice(0,8).map(x=>x.innerText.replace(/\s+/g,' ').slice(0,110)).join('\n')));
console.log('erros', errs); await b.close();})();
