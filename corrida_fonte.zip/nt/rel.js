const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true }); await ctx.addInitScript(() => { setInterval(() => { const d = document.getElementById('mxDet'); if(d && !d.open) d.open = true; }, 50); });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }


  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(800);
  const sala = (await prof.textContent('#roomCodeDisplay')).trim();
  async function entra(nm){ const a = await nova(nm); await a.addInitScript(() => {}); await a.fill('#joinRoom', sala); await a.dispatchEvent('#joinRoom', 'input'); await a.fill('#joinName', nm); await a.click('#joinBtn'); return a; }
  const a0 = await entra('Ana'); await a0.waitForTimeout(1200);
  if(await prof.isVisible('#startGameBtn')) await prof.click('#startGameBtn'); await prof.waitForTimeout(1500);
  // aluno que chega atrasado (treino já começou): é aqui que a pergunta de reserva aparecia
  const b1 = await nova('Beto');
  await b1.evaluate(() => { window.__vis = []; setInterval(() => { const q = app.player && app.player.currentQuestion; if(app.player && app.player.phase === 'playing' && q) window.__vis.push([!!q.trilha, document.body.classList.contains('tr-esperando')]); }, 30); });
  await b1.fill('#joinRoom', sala); await b1.dispatchEvent('#joinRoom', 'input'); await b1.fill('#joinName', 'Beto'); await b1.click('#joinBtn');
  await b1.waitForTimeout(5000);
  const vis = await b1.evaluate(() => window.__vis);
  const reservaVisivel = vis.filter(([tr, esp]) => !tr && !esp).length, reserva = vis.filter(([tr]) => !tr).length;
  console.log(`amostras ${vis.length} · com pergunta de reserva ${reserva} · reserva VISÍVEL ${reservaVisivel} · trilha visível ${vis.filter(([tr, esp]) => tr && !esp).length}`);
  console.log(reservaVisivel === 0 && vis.some(([tr]) => tr) ? 'OK    pergunta de reserva não aparece' : 'FALHA pergunta de reserva apareceu');
  for(let i = 0; i < 4; i++){ await b1.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked && !document.body.classList.contains('tr-esperando'), null, { timeout: 8000 }); const c = await b1.evaluate(() => app.player.currentQuestion.correct); await b1.click(`#ppOptions button:nth-child(${(i === 1 ? (c + 1) % 4 : c) + 1})`); await b1.waitForTimeout(600); }
  await b1.click('#ppHistBt'); await b1.waitForTimeout(300);
  const n = await b1.$$eval('#ppHistBox .hs-card', x => x.length);
  console.log(n === 4 ? 'OK    histórico do aluno mostra 4 questões' : 'FALHA histórico: ' + n);
  await b1.screenshot({ path: '/home/claude/cm/hist_aluno.png' });
  console.log('erros', log);
  await b.close();
})();
