const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true }); await ctx.addInitScript(() => { setInterval(() => { const d = document.getElementById('mxDet'); if(d && !d.open) d.open = true; }, 50); });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }


  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.fill('#trTurmaNome', '6º M01'); await prof.dispatchEvent('#trTurmaNome', 'input');
  await prof.selectOption('#trAno', '6'); await prof.selectOption('#trTema', 'fracoes'); await prof.waitForTimeout(300);
  await prof.screenshot({ path: '/home/claude/cm/tema_card.png' });
  async function entra(nm, sala){ const a = await nova(nm); await a.fill('#joinRoom', sala); await a.dispatchEvent('#joinRoom', 'input'); await a.fill('#joinName', nm); await a.click('#joinBtn'); await a.waitForTimeout(700); return a; }
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(800);
  const s2 = (await prof.textContent('#roomCodeDisplay')).trim();
  console.log('botão na tela inicial?', await prof.evaluate(() => !document.getElementById('ctBtn').classList.contains('hidden')));
  const a1 = await entra('Ana', s2), a2 = await entra('Neymar', s2);
  await prof.waitForTimeout(1200);
  console.log('botão no lobby:', await prof.textContent('#ctBtn'));
  await prof.click('#startGameBtn'); await prof.waitForTimeout(1500);
  const reg = [];
  for(let i = 0; i < 60; i++){
    await a1.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 });
    const c = await a1.evaluate(() => app.player.currentQuestion.correct);
    await a1.click(`#ppOptions button:nth-child(${(i % 7 === 6 ? (c + 1) % 4 : c) + 1})`); await a1.waitForTimeout(550);
    if(i % 15 === 14) reg.push(await a1.evaluate(() => { const b = document.querySelector('#ppTrilhaInfo .fg-box'); const r = app.player.trilha.rec; return (b ? b.textContent.replace(/\s+/g, ' ').trim() : 'SEM CAIXA') + ' | xp=' + r.xp; }));
  }
  reg.forEach(x => console.log('fogueira:', x));
  console.log('2ª chama?', await a1.evaluate(() => document.querySelectorAll('#ppTrilhaInfo .ch-svg').length));
  await a1.screenshot({ path: '/home/claude/cm/fg_aluno.png' });
  console.log('xp no professor:', await prof.evaluate(() => { const r = TRILHA.estado.turma.alunos['ana']; return r && r.xp; }));
  console.log('erros', log);
  await b.close();
})();
