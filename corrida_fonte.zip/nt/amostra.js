const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); for(const id of process.argv[2].split(',')) for(let n=1;n<=3;n++) for(let k=0;k<3;k++){const q=T.gerarQuestao(id,n); console.log(id,n,'|',q.text.replace(/<[^>]+>/g,'').slice(0,90),'|',JSON.stringify(q.options), q.image?'IMG':'');}
process.exit(0);
