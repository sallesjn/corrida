const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 390, height: 780 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(){const h={};const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(t);window.__sub(window.__cid,t);},publish(t,p,o){window.__pub(t,p,!!(o&&o.retain));},end(){cli.connected=false;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(t,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(t))c._emit(t,p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }
  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.selectOption('#trAno', '1');
  await prof.click('#trDiag button[data-v="inicio"]');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trRank button[data-v="1"]');
  await prof.screenshot({ path: '/home/claude/cm/t_card.png', clip: await (await prof.$('#trilhaCard')).boundingBox() });
  await prof.click('#createRoomBtn');
  await prof.waitForTimeout(600);
  const sala = (await prof.textContent('#roomCodeDisplay')).trim();
  ok(/TREINO/.test(await prof.textContent('#hModeLabel')), 'rótulo da sala: ' + (await prof.textContent('#hModeLabel')));
  const ana = await nova('Ana');
  await ana.fill('#joinRoom', sala); await ana.fill('#joinName', 'Ana'); await ana.click('#joinBtn');
  await ana.waitForTimeout(700);
  console.log('   lobby:', await prof.textContent('#playerCount'), await prof.evaluate(() => app.host.players.map(p => p.name).join(',')), await prof.textContent('#startGameBtn'));
  await prof.click('#startGameBtn');
  await prof.waitForTimeout(1200);
  const vis = sel => ana.evaluate(s => { const e = document.querySelector(s); return !!e && getComputedStyle(e).display !== 'none'; }, sel);
  ok(await ana.evaluate(() => document.body.classList.contains('cgm-treino')), 'aluno em modo treino');
  ok(!(await vis('#ppTime')) && !(await vis('#ppQuestionCard .qtimer')) && !(await vis('.pp-stats .item.score')), 'sem relógio, sem cronômetro da questão, sem pontos');
  ok(await vis('#ppTreinoTag'), 'etiqueta: ' + await ana.textContent('#ppTreinoTag'));
  await ana.screenshot({ path: '/home/claude/cm/t_aluno.png' });
  // cronômetro não corre: prazo já vencido e mesmo assim não estoura
  await ana.evaluate(() => { app.player.questionDeadline = performance.now() - 1; });
  await ana.waitForTimeout(1500);
  ok(await ana.evaluate(() => app.player.stats.timeouts === 0 && !app.player.questionBlocked), 'questão não estoura o tempo');
  // Ana acerta tudo DEVAGAR (10 min por questão): no treino deve dominar mesmo assim
  let dom = 0;
  for(let i = 0; i < 40; i++){
    await ana.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 });
    const c = await ana.evaluate(() => { app.player.questionStart = performance.now() - 600000; return app.player.currentQuestion.correct; });
    await ana.click(`#ppOptions button:nth-child(${c + 1})`);
    await ana.waitForTimeout(760);
  }
  const recA = await ana.evaluate(() => Object.entries(app.player.trilha.rec.deg).filter(([k, d]) => d.dom).map(([k, d]) => k + '/' + d.domPor));
  ok(recA.length >= 1 && recA.every(x => x.endsWith('/treino')), 'Ana dominou devagar: ' + recA.join(', '));
  // atrasado
  const beto = await nova('Beto');
  await beto.fill('#joinRoom', sala); await beto.fill('#joinName', 'Beto'); await beto.click('#joinBtn');
  await beto.waitForTimeout(1500);
  ok(await beto.evaluate(() => app.player.phase === 'playing' && document.body.classList.contains('cgm-treino')), 'Beto entrou atrasado e está jogando');
  for(let i = 0; i < 3; i++){ await beto.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 }); await beto.click('#ppOptions button:nth-child(1)'); await beto.waitForTimeout(760); }
  await prof.waitForTimeout(3500);
  ok(await prof.evaluate(() => document.body.classList.contains('cgm-treino-prof') && !!document.getElementById('ttPainel')), 'professor vê o painel do treino');
  console.log('   painel:', (await prof.textContent('#ttPainel')).replace(/\s+/g, ' ').trim());
  await prof.screenshot({ path: '/home/claude/cm/t_prof_rank.png' });
  await prof.evaluate(() => { TRILHA.estado.cfg.rank = 0; });
  await prof.click('#ttPainel [data-det]');
  await prof.waitForTimeout(300);
  await prof.screenshot({ path: '/home/claude/cm/t_prof_semrank.png' });
  console.log('   sem ranking:', (await prof.textContent('#ttPainel')).replace(/\s+/g, ' ').trim().slice(0, 300));
  // professor recarrega e retoma
  await prof.reload(); await prof.waitForTimeout(800);
  await prof.click('#retomarSim'); await prof.waitForTimeout(3800);
  ok(await prof.evaluate(() => document.body.classList.contains('cgm-treino-prof') && !!document.getElementById('ttPainel') && app.host.phase === 'playing'), 'retomada continua em treino');
  for(let i = 0; i < 2; i++){ await ana.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 }); const c = await ana.evaluate(() => app.player.currentQuestion.correct); await ana.click(`#ppOptions button:nth-child(${c + 1})`); await ana.waitForTimeout(760); }
  await prof.waitForTimeout(3500);
  // encerra
  await prof.click('#endMatchBtn');
  await prof.waitForTimeout(1500);
  ok(/Fim do treino/.test(await prof.textContent('#hEndSub')), 'fim: ' + (await prof.textContent('#hEndSub')));
  ok(await prof.evaluate(() => app.host.matchDurationMs === 15 * 60000 && app.host.sprintEnabled === true), 'duração/sprint voltaram ao normal: ' + await prof.evaluate(() => app.host.matchDurationMs / 60000 + ' min, sprint ' + app.host.sprintEnabled));
  ok(/Treino encerrado/.test(await ana.textContent('#pdSub')), 'aluno: ' + await ana.textContent('#pdSub'));
  await prof.screenshot({ path: '/home/claude/cm/t_prof_fim.png', fullPage: true });
  await ana.screenshot({ path: '/home/claude/cm/t_aluno_fim.png' });
  const [dl] = await Promise.all([prof.waitForEvent('download'), prof.click('#trSalvarFim')]);
  const pth = '/home/claude/cm/turma_treino.json'; await dl.saveAs(pth);
  const t = JSON.parse(fs.readFileSync(pth, 'utf8'));
  ok(t.alunos.ana && Object.values(t.alunos.ana.deg).some(d => d.dom && d.domPor === 'treino') && t.alunos.beto, 'arquivo da turma tem Ana (com degraus do treino) e Beto');
  // próxima aula: carrega o arquivo, cria CORRIDA; Ana continua de onde parou
  const prof2 = await nova('prof2');
  await prof2.click('#navTeacher');
  await prof2.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof2.reload(); await prof2.waitForTimeout(500); await prof2.click('#navTeacher');
  await prof2.setInputFiles('#trArquivo', pth); await prof2.waitForTimeout(600);
  ok(await prof2.evaluate(() => TRILHA.estado.cfg.modo === 'corrida'), 'navegador novo começa em Corrida');
  await prof2.click('#createRoomBtn'); await prof2.waitForTimeout(600);
  const sala2 = (await prof2.textContent('#roomCodeDisplay')).trim();
  const ana2 = await nova('Ana2');
  await ana2.fill('#joinRoom', sala2); await ana2.fill('#joinName', 'Ana'); await ana2.click('#joinBtn');
  await ana2.waitForTimeout(700);
  const beto2 = await nova('Beto2');
  await beto2.fill('#joinRoom', sala2); await beto2.fill('#joinName', 'Beto'); await beto2.click('#joinBtn');
  await beto2.waitForTimeout(700);
  await prof2.click('#startGameBtn'); await prof2.waitForTimeout(1500);
  const r2 = await ana2.evaluate(() => ({ treino: document.body.classList.contains('cgm-treino'), timer: getComputedStyle(document.querySelector('#ppTime')).display !== 'none', atual: app.player.trilha && app.player.trilha.rec.atual, dom: Object.values(app.player.trilha.rec.deg).filter(d => d.dom).length, ms: app.player.matchTotalMs / 60000 }));
  ok(!r2.treino && r2.timer && r2.dom === recA.length + 0 || r2.dom >= recA.length, `corrida normal na aula seguinte, Ana continua: ${JSON.stringify(r2)}`);
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
