const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:390,height:844}});
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.evaluate(()=>{ app.player.trilha={on:true,rec:TRILHA.novoRegistro('x'),cfg:{},evs:[]}; document.querySelectorAll('.screen, [id^=ps]').forEach(x=>x); 
    const q=TRILHA.gerarQuestao('somaFrac',3); q.fonte={tipo:'atual'}; app.player.currentQuestion=q; app.switchMode('student'); app.showPlayerScreen('Play'); app.renderPlayerQuestion(q); });
  await p.waitForTimeout(300);
  await p.screenshot({path:'/home/claude/cm/fracui.png', fullPage:true});
  console.log(await p.evaluate(()=>document.getElementById('ppOptions').innerHTML.slice(0,300)), errs);
  await b.close();
})();
