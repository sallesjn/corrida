const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
const DIV=new Set(['pratos','divResto','p3_div','p4_div','vezes2','partes','fracQtd','p5_fracao','p5_termo']);   // aluno que não sabe dividir
function sim(p, cfg, semDividir, max=12000){
  T.LIMITE.anoMax=7; T.LIMITE.pRev=0.2;
  const rec=T.novoRegistro('x'); T.iniciar(rec,cfg);
  let n=0, ac=0, seq=0, maxSeq=0, apoio=0, voltou=0, esq=0, fim=null, desistiu=0; const ini7=T.CAT.filter(x=>x.ano===7).length; const vol=[];
  for(;n<max;n++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel);
    let pr=Math.min(.97, p[f.nivel] + (7 - T.POR_ID[f.id].ano) * 0.04);   // conteúdo de anos anteriores é mais fácil para ele if(semDividir && DIV.has(f.id)) pr = rec.deg[f.id] && rec.deg[f.id].totA > 40 ? pr : .2;   // aprende a dividir depois de treinar ~40
    const ok=Math.random()<pr; if(ok){ac++; seq=0;} else { seq++; maxSeq=Math.max(maxSeq,seq); }
    const ev=T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,.45);
    if(ev.apoio==='entrou') apoio++; if(ev.voltou){ voltou++; if(vol.length<4) vol.push(ev.voltou.de+'→'+ev.voltou.para); } if(ev.esqueceu) esq++;
    const k=T.CAT.filter(x=>x.ano===7 && rec.deg[x.id] && rec.deg[x.id].dom).length; if(k===ini7){ fim=n+1; break; } }
  const at=rec.atual?T.POR_ID[rec.atual]:null; return { onde: at? at.ano+'º '+at.nome : 'fim', fim, acerto: Math.round(ac/n*100)+'%', maxSeq, apoio, voltou, esq, vol };
}
const perf=[['bom (92/85/78)',{1:.92,2:.85,3:.78},false],['mediano (85/75/65)',{1:.85,2:.75,3:.65},false],['fraco (75/62/50)',{1:.75,2:.62,3:.50},false],['não sabe dividir (mediano no resto)',{1:.85,2:.75,3:.65},true]];
for(const [nome,p,div] of perf){
  const rs=[...Array(4)].map(()=>sim(p,{diag:'ano',ano:7},div));
  console.log(nome,'| terminou o 7º em:',rs.map(r=>r.fim||'>12000').join(' '),'| acerto geral:',rs.map(r=>r.acerto).join(' '),'| maior sequência de erros:',rs.map(r=>r.maxSeq).join(' '),'| entrou em apoio:',rs.map(r=>r.apoio).join(' '),'| voltou a pré-requisito:',rs.map(r=>r.voltou).join(' '),'| esqueceu (revisão):',rs.map(r=>r.esq).join(' '), '| onde parou:', rs.map(r=>r.onde).join(' / '), div? '| ex.: '+rs[0].vol.join(', '):'');
}
process.exit(0);
