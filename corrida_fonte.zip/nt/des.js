const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
function sim(pAc, lim, N=600){
  const rec=T.novoRegistro('x'); T.iniciar(rec,{diag:'ano',ano:6}); let des=0, ok=0, apoio=0, distAt=[];
  for(let k=0;k<N;k++){ T.estado.desafioAluno=lim; const f=T.escolherFonte(rec); T.estado.desafioAluno=0; const q=T.gerarQuestao(f.id,f.nivel); const acerto=Math.random()<(f.tipo==='desafio'?pAc*0.6:pAc);
    if(f.tipo==='desafio'){ des++; if(acerto) ok++; distAt.push(T.POR_ID[f.id].i - T.POR_ID[rec.atual].i); }
    T.registrar(rec,f,q,acerto?q.correct:(q.correct+1)%4,acerto,0.3); if(rec.apoio) apoio++; }
  return { des, ok, por10: (des/N*10).toFixed(2), apoioResps: apoio, dist: [Math.min(...distAt), Math.max(...distAt)], dom: Object.values(rec.deg).filter(x=>x.dom).length, reg: rec.desafios };
}
console.log('bom (90%), limite 80%:', JSON.stringify(sim(0.9,0.8)));
console.log('médio (70%), limite 80%:', JSON.stringify(sim(0.7,0.8)));
console.log('médio (75%), limite 70%:', JSON.stringify(sim(0.75,0.7)));
console.log('desligado:', JSON.stringify(sim(0.95,0)));
process.exit(0);
