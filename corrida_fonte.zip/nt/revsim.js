const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); T.estado.cfg.ano=7; if(process.argv[2]==='antigo') T.REGRA.revAnosAbaixo=99;
const P=a=>a<=6?0.95:0.8; let rev=0, revBaixa=0, revBaixaBase=0, tot=0, ruins=[];
const BASE=new Set(['p3_tab','p4_tab','p4_div','pratos','divResto','disposicao','vezes2','fracfig','pizza','fracReta4','decimos4','p5_fracao','fracEquiv','fracLacuna','fracMista5','decReta','porcMalha','p5_termo','propTabela5','notaFiscal5','fracCompara','fracQtd','somaFrac','decOps6','p6_equiv','p6_porc','p6_mmc','primos','p6_expr','p6_potencia']);
for(let s=0;s<100;s++){ const rec=T.novoRegistro('x'+s); T.iniciar(rec,{diag:'saltos',ano:7});
  for(let i=0;i<300;i++){ const f=T.escolherFonte(rec); const a=T.POR_ID[f.id].ano; const ok=Math.random()<P(a); T.registrar(rec,f,{},0,ok,0.3); tot++;
    if(f.tipo==='rev'){ rev++; const dd=rec.deg[f.id]; if(a<5){ if(BASE.has(f.id)) revBaixaBase++; else if(!(dd.domPor==='trilha'||dd.domPor==='treino')){ revBaixa++; ruins.push(f.id); } } } } }
console.log(`respostas ${tot} · revisões ${rev} (${(rev/tot*100).toFixed(1)}%) · revisões de presente abaixo do 5º ano (fora da base): ${revBaixa} · da base (tabuada, frações…): ${revBaixaBase}`, ruins.slice(0,5));
process.exit(0);
