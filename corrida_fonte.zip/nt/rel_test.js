const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const ok = (c, m) => console.log((c ? 'OK    ' : 'FALHA ') + m);
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1280, height: 1000 } });
  await ctx.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: 'window.mqtt={connect(){return{on(){},subscribe(){},publish(){},end(){}}}}' }));
  await ctx.route('https://securetoken.googleapis.com/**', r => r.fulfill({ status: 200, contentType: 'application/json', body: '{"id_token":"X","refresh_token":"R","expires_in":"3600"}' }));
  await ctx.route('https://matematica-3df86-default-rtdb.firebaseio.com/**', r => r.fulfill({ status: 200, contentType: 'application/json', body: r.request().method() === 'GET' ? 'null' : '{}' }));
  const errs = []; const p = await ctx.newPage(); p.on('dialog', d => d.type() === 'prompt' && globalThis.__resp ? d.accept(globalThis.__resp) : d.accept()); p.on('pageerror', e => errs.push(e.message));
  await p.goto('file:///home/claude/cm/work.html'); await p.evaluate(() => { localStorage.clear(); localStorage.setItem('cgm_nuvem', JSON.stringify({ rt: 'R', uid: 'U', email: 'f' })); });
  await p.reload(); await p.click('#navTeacher'); await p.waitForTimeout(500);
  await p.click('#nvNova'); await p.fill('#nvNome', '7º M01'); await p.selectOption('#nvAno', '7'); await p.click('#nvCriar'); await p.waitForTimeout(600);
  await p.click('#mxAlunos'); await p.click('#teColarBt'); await p.fill('#teCola', 'Ana Beatriz Lima\nBruno Henrique Dias\nCarlos Eduardo Souza\nDavi Lucas Rocha'); await p.click('#teColarOk'); await p.click('[data-tfecha]'); await p.waitForTimeout(300);
  ok(/aparece aqui depois da primeira aula/.test(await p.textContent('#ulAula')), 'linha "última aula" antes de ter dados');
  // simula aulas: cada aluno com um perfil
  const res = await p.evaluate(() => {
    const T = TRILHA, E = T.estado, perf = { 'ana b': a => a <= 6 ? 0.95 : 0.8, 'bruno h': a => a <= 3 ? 0.9 : a <= 5 ? 0.45 : 0.25, 'carlos e': a => a <= 4 ? 0.92 : 0.6, 'davi l': a => a <= 3 ? 0.9 : a <= 5 ? 0.45 : 0.25 };
    const out = {};
    for(const [k, P] of Object.entries(perf)){
      const rec = T.novoRegistro(E.cfg.nomes.find(n => n.toLowerCase().startsWith(k.split(' ')[0]))); T.iniciar(rec, { diag: 'saltos', ano: 7 });
      // "aprende": a chance de acerto de cada atividade sobe com a prática
      const pr = {};
      for(let i = 0; i < 300; i++){
        const f = T.escolherFonte(rec); const a = T.POR_ID[f.id].ano;
        pr[f.id] = (pr[f.id] || 0) + 1;
        const chance = Math.min(0.97, P(a) + (k === 'carlos e' ? pr[f.id] * 0.02 : 0));
        const okk = Math.random() < chance;
        T.registrar(rec, f, { erros: ['soma tudo', 'troca a ordem', 'esquece o resto', 'x'] }, okk ? 0 : 1 + (i % 3), okk, 0.3);
      }
      E.turma.alunos[rec.chave] = rec;
      out[k] = {};
      T.CAT.forEach(d => { const s = E.classificar(rec, d); out[k][s.st] = (out[k][s.st] || 0) + 1; });
    }
    return out;
  }).catch(e => 'ERRO ' + e.message);
  console.log(JSON.stringify(res));
  await p.evaluate(() => TRILHA.estado.abrirEditorTurma && 0);
  await p.waitForTimeout(3500);
  const ul = await p.textContent('#ulAula').catch(() => 'sem');
  ok(/3 presentes · 1 faltaram/.test(ul), 'última aula: ' + ul.replace(/\s+/g, ' '));
  await p.evaluate(() => { ['bruno h', 'davi l'].forEach(k => { const r = TRILHA.estado.turma.alunos[k]; r.deg.p4_div = { n: 1, dom: 0, tot: 20, ac: 5, totA: 20, h: Array.from({ length: 20 }, (_, i) => [1, i % 4 === 0 ? 1 : 0, 0.3]), err: { 'esqueceu o resto': 6 }, quedas: 0 }; }); });
  await p.waitForTimeout(8500);
  const sug = await p.textContent('#trFocoBox .mn-sug').catch(() => 'sem sugestão');
  console.log('sugestão:', sug.replace(/\s+/g, ' '));
  if(/Sugestão/.test(sug)){ await p.click('#trFocoBox [data-sugid]'); await p.waitForTimeout(300); console.log(await p.evaluate(() => TRILHA.estado.cfg.foco.ids.length === 1) ? 'OK    usar a sugestão define o foco: ' + await p.textContent('#trFocoTxt') : 'FALHA foco'); }
  await p.screenshot({ path: '/home/claude/cm/sug.png' });
  await p.evaluate(() => TRILHA.estado.abrirEditorTurma()); await p.waitForTimeout(600);
  await p.click('#teRelBt'); await p.waitForTimeout(400);
  const linhas = await p.$$eval('#relBox .rel-tab tbody tr', x => x.length), cols = await p.$$eval('#relBox .rel-tab thead th', x => x.length);
  console.log(linhas === 4 ? 'OK    tabela com 4 alunos, ' + (cols - 5) + ' atividades' : 'FALHA linhas ' + linhas);
  console.log('colunas aplicadas por padrão:', (await p.textContent('label:has([data-soapl])')).trim());
  console.log('rodapé:', await p.$$eval('#relBox tfoot td', x => x.slice(2, 6).map(t => t.textContent).join(' | ')));
  await p.click('[data-ordem="critica"]'); await p.waitForTimeout(200);
  const pncs = await p.$$eval('#relBox tfoot td', x => x.slice(2).map(t => +((t.textContent.match(/(\d+)% NC/) || [0, 0])[1])));
  console.log(pncs.every((v, i) => i === 0 || v <= pncs[i - 1] + 0) ? 'OK    ordem mais críticas: ' + pncs.slice(0, 6).join(',') : 'FALHA ordem ' + pncs.slice(0, 10));
  await p.click('[data-aba="grupos"]'); await p.waitForTimeout(200);
  const g = await p.$$eval('#relBox .rg-card', x => x.map(c => c.querySelector('h4').textContent + ' → ' + [...c.querySelectorAll('li')].map(l => l.textContent).join('; ')));
  console.log(g.length ? 'OK    grupos: ' + g.length : 'FALHA grupos'); g.slice(0, 3).forEach(x => console.log('   ', x));
  await p.screenshot({ path: '/home/claude/cm/rel_grupos.png' });
  await p.click('[data-aba="tabela"]'); await p.click('[data-ordem="trilha"]'); await p.waitForTimeout(200);
  await p.click('[data-soapl]'); await p.click('[data-visao="bncc"]'); await p.click('[data-tri="3"]'); await p.waitForTimeout(200);
  const c3 = await p.$$eval('#relBox .rel-tab thead th', x => x.slice(5).map(t => t.childNodes[0].textContent));
  console.log('3º tri (BNCC):', c3.join(' '));
  console.log('sem jogo:', await p.textContent('#relBox').then(t => (t.match(/Sem atividade no jogo[^\n]*?: ([^C]*)/) || ['', '—'])[1].slice(0, 120)));
  await p.click('[data-visao="atividade"]'); await p.waitForTimeout(200);
  console.log('3º tri (atividades):', (await p.$$eval('#relBox .rel-tab thead th', x => x.length)) - 5);
  globalThis.__resp = 'Plano: EF07MA02 (porcentagem), EF07MA17 e ef07ma18; EF06MA24';
  await p.click('[data-tri="plano"]'); await p.waitForTimeout(300);
  console.log('meu plano (atividades):', (await p.$$eval('#relBox .rel-tab thead th', x => x.slice(5).map(t => t.childNodes[0].textContent))).join(' | '));
  console.log('salvo na turma:', JSON.stringify(await p.evaluate(() => TRILHA.estado.turma.planoCodigos)));
  await p.click('[data-tri="0"]'); await p.click('[data-soapl]'); await p.click('[data-visao="atividade"]'); await p.waitForTimeout(200);
  console.log('legenda:', (await p.textContent('#relBox .rel-leg')).replace(/\s+/g, ' ').slice(-70));
  await p.screenshot({ path: '/home/claude/cm/rel1.png' });
  for(const v of ['bncc', 'descritor']){ await p.click(`[data-visao="${v}"]`); await p.waitForTimeout(200); console.log(v, 'colunas:', (await p.$$eval('#relBox .rel-tab thead th', x => x.length)) - 5); }
  await p.click('[data-ano="1"]'); await p.waitForTimeout(200); console.log('só o 7º, descritores:', (await p.$$eval('#relBox .rel-tab thead th', x => x.length)) - 5);
  await p.click('[data-visao="bncc"]'); await p.click('[data-ano="0"]');
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-baixar]')]);
  const pth = '/tmp/claude-0/rel.csv'; await dl.saveAs(pth);
  const txt = require('fs').readFileSync(pth, 'utf8');
  console.log('arquivo:', dl.suggestedFilename(), '·', txt.split('\r\n').length, 'linhas');
  console.log(txt.split('\r\n').slice(0, 4).map(l => l.slice(0, 110)).join('\n'));
  console.log('erros:', errs);
  await b.close();
})();
