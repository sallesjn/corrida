const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const FILE = 'file:///home/claude/cm/work.html';
const DB = {}; let offline = false; const reqs = [];
function getP(path){ let o = DB; for(const k of path){ if(o == null) return null; o = o[k]; } return o === undefined ? null : o; }
function setP(path, v){ let o = DB; for(let i = 0; i < path.length - 1; i++){ o = o[path[i]] = o[path[i]] || {}; } if(v === null) delete o[path[path.length - 1]]; else o[path[path.length - 1]] = v; }
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 } }); await ctx.addInitScript(() => { setInterval(() => { const d = document.getElementById('mxDet'); if(d && !d.open) d.open = true; }, 50); });
  const mqttFake = `window.mqtt={connect(){const h={};const c={connected:true,on(e,f){(h[e]=h[e]||[]).push(f);if(e==='connect')setTimeout(f,20)},subscribe(){},publish(){},end(){}};return c}};`;
  await ctx.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
  await ctx.route('https://identitytoolkit.googleapis.com/**', async r => {
    if(offline) return r.abort();
    const j = JSON.parse(r.request().postData());
    if(j.email === 'prof@x.com' && j.password === 'certa') return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ idToken: 'ID1', refreshToken: 'RT1', localId: 'UID9', email: j.email, expiresIn: '3600' }) });
    return r.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({ error: { message: 'INVALID_LOGIN_CREDENTIALS' } }) });
  });
  await ctx.route('https://securetoken.googleapis.com/**', r => offline ? r.abort() : r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ id_token: 'ID2', refresh_token: 'RT1', user_id: 'UID9', expires_in: '3600' }) }));
  await ctx.route('https://matematica-3df86-default-rtdb.firebaseio.com/**', async r => {
    if(offline) return r.abort();
    const u = new URL(r.request().url()); const m = r.request().method();
    reqs.push(m + ' ' + u.pathname);
    if(!/^ID[12]$/.test(u.searchParams.get('auth'))) return r.fulfill({ status: 401, contentType: 'application/json', body: '{"error":"Permission denied"}' });
    const path = u.pathname.replace(/\.json$/, '').split('/').filter(Boolean);
    if(path[0] !== 'prof' || path[1] !== 'UID9') return r.fulfill({ status: 401, body: '{"error":"Permission denied"}' });
    if(m === 'GET') return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(getP(path)) });
    if(m === 'PATCH'){ const body = JSON.parse(r.request().postData()); for(const k in body) setP(path.concat(k.split('/')), body[k]); return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(body) }); }
    return r.fulfill({ status: 400 });
  });
  const errs = [];
  const p = await ctx.newPage();
  p.on('dialog', d => { if(d.type() === 'prompt') d.accept('APAGAR'); else d.accept(); });
  p.on('pageerror', e => errs.push(e.message));
  await p.goto(FILE); await p.click('#navTeacher'); await p.waitForTimeout(500);
  const abreLista = async () => { if(await p.isVisible('#mnTrocar') && !(await p.isVisible('.nv-lista'))) await p.click('#mnTrocar'); };
  const ok = (c, m) => console.log((c ? 'OK  ' : 'FALHA ') + m);
  ok(await p.isVisible('#nvEmail'), 'formulário de login aparece');
  await p.fill('#nvEmail', 'prof@x.com'); await p.fill('#nvSenha', 'errada'); await p.click('#nvEntrar'); await p.waitForTimeout(300);
  ok(/errados/.test(await p.textContent('#nvMsg')), 'senha errada mostra mensagem: ' + await p.textContent('#nvMsg'));
  await p.fill('#nvEmail', 'prof@x.com'); await p.fill('#nvSenha', 'certa'); await p.click('#nvEntrar'); await p.waitForTimeout(500);
  ok(/Nenhuma turma/.test(await p.textContent('#nvBox')), 'logado, lista vazia');
  // nova turma
  await abreLista(); await p.click('#nvNova'); await p.fill('#nvNome', '6º M01'); await p.selectOption('#nvAno', '6'); await p.click('#nvCriar'); await p.waitForTimeout(800);
  const l = getP(['prof', 'UID9', 'lista']);
  ok(l && Object.values(l)[0].nome === '6º M01' && Object.values(l)[0].ano === 6, 'turma criada na nuvem: ' + JSON.stringify(l));
  ok(await p.evaluate(() => document.getElementById('trAno').value) === '6', 'ano do cartão = 6');
  ok(/Aberta: 6º M01/.test(await p.textContent('#nvBox')), 'cartão mostra turma aberta');
  // simula progresso: registro de aluno
  await p.evaluate(() => { window.__nv; }); 
  await p.evaluate(() => { const t = JSON.parse(localStorage.getItem('cgm_trilha_turma')); });
  // muda foco/tema e nome para ver se sobe
  await p.selectOption('#trTema', 'fracoes'); await p.waitForTimeout(200);
  await p.evaluate(() => { __nv.ultEnvio = 0; });
  await p.waitForTimeout(5500);
  const id1 = Object.keys(l)[0];
  let t = JSON.parse(getP(['prof', 'UID9', 'turmas', id1, 'json']));
  ok(t.cfg.aj.tema === 'fracoes', 'tema subiu automático');
  // segunda turma
  await abreLista(); await p.click('#nvNova'); await p.fill('#nvNome', '7º M02'); await p.selectOption('#nvAno', '7'); await p.click('#nvCriar'); await p.waitForTimeout(800);
  ok(Object.keys(getP(['prof', 'UID9', 'lista'])).length === 2, '2 turmas na lista');
  ok(await p.evaluate(() => !__nvt.est().cfg.aj.tema), 'turma nova sem tema herdado');
  // adiciona aluno na 7º
  await p.evaluate(() => { __nvt.registroDe('Ana Clara'); }); await p.evaluate(() => { __nv.ultEnvio = 0; }); await p.waitForTimeout(5500);
  const id2 = Object.keys(getP(['prof', 'UID9', 'lista'])).find(k => k !== id1);
  ok(getP(['prof', 'UID9', 'lista', id2]).n === 1, 'aluno da 7º subiu (n=1)');
  // troca para 6º
  await abreLista(); await p.click(`[data-nvabre="${id1}"]`); await p.waitForTimeout(800);
  ok(await p.evaluate(() => __nvt.est().turma.nome === '6º M01' && __nvt.est().cfg.ano === 6 && __nvt.est().cfg.aj.tema === 'fracoes' && !__nvt.est().turma.alunos['ana clara']), 'trocou para 6º com ano e tema certos, sem aluno da 7º');
  // offline
  offline = true;
  await p.evaluate(() => { __nvt.registroDe('Bruno'); __nv.ultEnvio = 0; }); await p.waitForTimeout(5500);
  ok(/sem conex|Sem internet/.test(await p.textContent('#nvSelo')), 'selo sem conexão: ' + await p.textContent('#nvSelo'));
  offline = false; await p.waitForTimeout(5500);
  ok(getP(['prof', 'UID9', 'lista', id1]).n === 1, 'voltou a internet e subiu Bruno');
  // recarrega a página: continua logado e com a turma
  await p.reload(); await p.click('#navTeacher'); await p.waitForTimeout(800);
  ok(/Aberta: 6º M01/.test(await p.textContent('#nvBox')), 'após recarregar: logado e turma 6º aberta');
  // outro computador mudou a 7º; abrir 7º puxa
  // simula outro computador alterando a 6º na nuvem
  const tt = JSON.parse(getP(['prof', 'UID9', 'turmas', id1, 'json'])); tt.alunos['carla'] = Object.assign({}, tt.alunos['bruno'], { nome: 'Carla', chave: 'carla' });
  const at = new Date(Date.now() + 60000).toISOString();
  setP(['prof', 'UID9', 'turmas', id1], { json: JSON.stringify(tt), atualizado: at }); setP(['prof', 'UID9', 'lista', id1, 'atualizado'], at);
  await p.reload(); await p.click('#navTeacher'); await p.waitForTimeout(1200);
  ok(await p.evaluate(() => !!__nvt.est().turma.alunos['carla']), 'versão mais nova da nuvem foi puxada ao abrir');
  // guardar turma vinda de arquivo
  await p.evaluate(() => { __nvt.limparTudo(); }); await p.setInputFiles('#trArquivo', '/home/claude/cm/turma_teste.json'); await p.waitForTimeout(600);
  const nArq = Object.keys(JSON.parse(require('fs').readFileSync('/home/claude/cm/turma_teste.json','utf8')).alunos).length;
  ok(!(await p.isVisible('#nvSubir')) && !(await p.isVisible('#trCarregar')), 'carregar arquivo / guardar turma do arquivo ocultos');
  await p.evaluate(() => document.getElementById('nvSubir').style.setProperty('display', 'block', 'important'));
  await p.click('#nvSubir'); await p.fill('#nvNome', '8º A'); await p.click('#nvCriar'); await p.waitForTimeout(800);
  const l3 = getP(['prof', 'UID9', 'lista']); const id3 = Object.keys(l3).find(k => l3[k].nome === '8º A');
  ok(id3 && l3[id3].n >= 1, 'turma do arquivo guardada com 2 alunos');
  // arquivo baixado com nuvemId não liga na nuvem
  await p.evaluate(() => { const t = __nvt.est().turma; t.nuvemId = 'tFALSO'; localStorage.setItem('x', JSON.stringify(t)); });
  require('fs').writeFileSync('/tmp/claude-0/arq_nv.json', await p.evaluate(() => localStorage.getItem('x')));
  await p.setInputFiles('#trArquivo', '/tmp/claude-0/arq_nv.json'); await p.waitForTimeout(600);
  ok(await p.evaluate(() => !__nvt.est().turma.nuvemId), 'arquivo com nuvemId abre desligado da nuvem');
  // apagar
  await abreLista(); await p.click(`[data-nvdel="${id3}"]`); await p.waitForTimeout(500);
  ok(!getP(['prof', 'UID9', 'lista', id3]) && !getP(['prof', 'UID9', 'turmas', id3]), 'turma apagada');
  await p.screenshot({ path: '/home/claude/cm/nv1.png', clip: { x: 0, y: 0, width: 1280, height: 900 } });
  console.log('erros:', errs);
  console.log('reqs:', reqs.length);
  await b.close();
})();
