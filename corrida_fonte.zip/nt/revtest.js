const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
for(const pr of [0.2,0.4,0.5]){ T.LIMITE.anoMax=7; T.LIMITE.pRev=pr;
  const rec=T.novoRegistro('x'); T.iniciar(rec,{ano:7,diag:'ano'});
  const c={atual:0,rev:0,previa:0}, anos={}; let base=0;
  for(let i=0;i<1000;i++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel); c[f.tipo]++; if(f.tipo==='rev'){ const a=T.POR_ID[f.id].ano; anos[a]=(anos[a]||0)+1; if(['p3_tab','p4_tab','p4_div','decOps6','fracCompara','somaFrac','p6_porc'].includes(f.id)) base++; }
    const ok = f.tipo==='rev' ? Math.random()<.7 : Math.random()<.9; T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,.3); }
  console.log('revisão',pr,JSON.stringify(c),'revisões por ano',JSON.stringify(anos),'lacunas:',T.lacunas(rec).slice(0,3).map(x=>x.id).join(','));
}
process.exit(0);
