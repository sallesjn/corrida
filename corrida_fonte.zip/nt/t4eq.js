const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.goto('file:///home/claude/cm/work.html'); await p.click('#navTeacher');
console.log('equipes na tela:', await p.$$eval('#teamInputs input', x=>x.map(i=>i.value).join(', ')), '| botão ativo:', await p.$eval('#teamCount .on', e=>e.textContent));
await p.click('#teamCount button[data-n="3"]'); console.log('trocando p/ 3:', await p.$$eval('#teamInputs input', x=>x.length));
await p.click('#teamCount button[data-n="4"]'); await p.click('#demoBtn'); await p.waitForTimeout(2500);
console.log('pistas na demo:', await p.$$eval('.race-lane', x=>x.length), 'bots:', await p.evaluate(()=>app.host.players.length), 'erros:', errs);
await b.close();})();
