const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage();
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  const r = await p.evaluate(()=>{
    const ruins={}; const dp=new DOMParser(); let tot=0;
    for(const d of TRILHA.CAT) for(let n=1;n<=3;n++) for(let k=0;k<150;k++){
      const q=TRILHA.gerarQuestao(d.id,n); const imgs=[q.image,...(q.optImgs||[])].filter(Boolean);
      for(const u of imgs){ if(!u.startsWith('data:image/svg')) continue; tot++;
        const s=decodeURIComponent(u.replace(/^data:image\/svg\+xml(;charset=utf-8)?,/,''));
        const doc=dp.parseFromString(s,'image/svg+xml'); if(doc.querySelector('parsererror')||/NaN|undefined/.test(s)) ruins[d.id]=(ruins[d.id]||0)+1; }
    }
    return {tot,ruins, comImg: TRILHA.CAT.filter(d=>d.ano>=3).map(d=>d.id)};
  });
  console.log(JSON.stringify(r)); await b.close();
})();
