const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
for(const [id,n] of [['transf7',1],['transf7',2]]){ const q=T.G[id](n); console.log(id,n,q.text,JSON.stringify(q.options),q.answer,'C=',T.C[id](q.meta)); }
process.exit(0);
