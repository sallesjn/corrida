const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
console.log('carregou');
const T=d.window.eval('TRILHA');
for(const id of ['probTexto2','probTexto3','probTexto4','probTexto5']) for(let n=1;n<=3;n++){ const t0=Date.now(); for(let k=0;k<200;k++){ const q=T.gerarQuestao(id,n); } console.log(id,n,Date.now()-t0,'ms'); }
