const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
const ids=process.argv[2].split(',');
const keep=T.CAT.filter(c=>ids.includes(c.id)); T.CAT.splice(0,T.CAT.length,...keep);
d.window.console.table=()=>{}; d.window.console.log=()=>{};
const r=T.testarTrilha(+process.argv[3]||3000);
console.log(r.tabela.map(t=>`${t.degrau} N${t.nivel}: falhas ${t.falhas}, diferentes ${t.diferentes}`).join('\n'));
if(r.exemplos.length) console.log(JSON.stringify(r.exemplos.slice(0,5).map(e=>({d:e.degrau,n:e.nivel,p:e.problema,t:e.q&&e.q.text,o:e.q&&e.q.options})),null,1));
// amostra de textos
for(const id of ids) for(let n=1;n<=3;n++){ const q=T.gerarQuestao(id,n); console.log(`[${id} N${n}] ${q.text} | ${q.options.join(' ; ')} | certa: ${q.options[q.correct]}`); }
// o texto traz os números do meta? (a conta usa o que o aluno lê)
let inc=0;
for(const id of ids.filter(i=>i.startsWith('probTexto'))) for(let n=1;n<=3;n++) for(let k=0;k<800;k++){
  const q=T.gerarQuestao(id,n); const nums=(q.text.match(/\d[\d.]*/g)||[]).map(x=>+x.replace(/\./g,'')); const m=q.meta;
  const precisa=['a','b','c','q','u','p','q2','u2'].filter(k=>m[k]!==undefined).map(k=>k==='u'&&m.tipo==='prop'?m.q*m.u:k==='a'&&['parcelas'].includes(m.tipo)?m.a:m[k]);
  const falta=precisa.filter(v=>!nums.includes(v)); if(falta.length && m.tipo!=='vezes' && !(m.tipo==='caber'&&falta.every(v=>v===m.b)) ){ inc++; if(inc<4) console.log('TEXTO x META', id, q.text, JSON.stringify(m)); }
}
console.log('inconsistências texto/meta:', inc);
process.exit(0);
