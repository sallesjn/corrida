const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},(window.__lento&&/emqx/.test(U))?window.__lento:50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){const era=cli.connected;cli.connected=false;cli._fim=true;window.__unsub(window.__cid);setTimeout(()=>(h.close||[]).forEach(f=>f()),30)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }

  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.selectOption('#trAno', '1');
  await prof.click('#trDiag button[data-v="inicio"]');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trTempo button[data-v="0"]');
  // foco da aula: tipos de ângulos + retas, 1 em cada 3
  await prof.click('#trFocoBt');
  await prof.click('#focoBox button[data-aba="6"]');
  await prof.click('#focoBox input[data-id="tiposAng6"]'); await prof.click('#focoBox input[data-id="paralPerp6"]');
  await prof.click('#focoBox input[name="foFreq"][value="0.34"]');
  await prof.screenshot({ path: '/home/claude/cm/f_escolha.png' });
  await prof.click('#focoBox [data-salvar]');
  ok(/Tipos de ângulos/.test(await prof.textContent('#trFocoTxt')), 'cartão mostra o foco: ' + await prof.textContent('#trFocoTxt'));
  await prof.click('#createRoomBtn');
  await prof.waitForTimeout(1200);
  const sala = (await prof.textContent('#hRoomCode')).trim();
  const entrar = async nm => { const a = await nova(nm); await a.fill('#joinRoom', sala); await a.fill('#joinName', nm); await a.click('#joinBtn'); await a.waitForFunction(() => app.player.phase === 'playing' && app.player.trilha && app.player.trilha.rec, null, { timeout: 15000 }); return a; };
  const ana = await entrar('Ana'), beto = await entrar('Beto');
  const responde = async (pg, certo) => { if(await pg.$('#vjBox')){ await pg.waitForTimeout(2200); await pg.click('#vjBox .vj-ok'); await pg.waitForTimeout(300); } await pg.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked && !document.getElementById('vjBox') && ![...document.querySelectorAll('#ppOptions button')].some(b => b.disabled) && !document.querySelector('.tr-festa'), null, { timeout: 20000 }); const q = await pg.evaluate(() => ({ c: app.player.currentQuestion.correct, t: app.player.currentQuestion.type, rot: document.getElementById('ppTrilhaInfo') ? document.getElementById('ppTrilhaInfo').textContent : '' })); await pg.click(`#ppOptions button:nth-child(${(certo ? q.c : (q.c + 1) % 4) + 1})`); await pg.waitForTimeout(760); return q; };
  const tiposAna = [];
  for(let i = 0; i < 36; i++) tiposAna.push(await responde(ana, true));
  const nf = tiposAna.filter(q => ['tiposAng6', 'paralPerp6'].includes(q.t)).length;
  ok(nf >= 6 && nf <= 20, `foco apareceu ${nf} vezes em 36 perguntas da Ana (esperado ~1/3)`);
  const rot = tiposAna.find(q => q.t === 'tiposAng6' || q.t === 'paralPerp6');
  ok(rot && !/foco|aula|🎯/.test(rot.rot), 'discreto: o aluno não vê que é a atividade da aula → "' + (rot ? rot.rot.trim() : '') + '"');
  for(let i = 0; i < 20; i++) await responde(beto, i % 2 === 0);
  // offline: Beto perde a conexão e continua respondendo
  const antes = await prof.evaluate(() => { const p = app.host.players.find(x => x.name === 'Beto'); return (p.correct || 0) + (p.wrong || 0); });
  await beto.evaluate(() => { app.mqtt.end(true); });
  const respOff = [];
  for(let i = 0; i < 6; i++) respOff.push(await responde(beto, true));
  await beto.waitForTimeout(1500);
  ok(!!(await beto.$('#ofAviso')), 'aluno sem internet vê o aviso "suas respostas estão guardadas"');
  await beto.waitForFunction(() => app.mqtt && app.mqtt.connected, null, { timeout: 30000 });
  await beto.waitForTimeout(7000);
  const cel = await beto.evaluate(() => app.player.stats.correct + app.player.stats.wrong);
  const depois = await prof.evaluate(() => { const p = app.host.players.find(x => x.name === 'Beto'); return (p.correct || 0) + (p.wrong || 0); });
  ok(depois === cel, `respostas do período offline chegaram ao professor: celular ${cel}, professor ${depois} (antes ${antes})`);
  ok(!(await beto.$('#ofAviso')), 'o aviso some quando a internet volta');
  // recarregar a página: continua do progresso guardado no celular
  const r1 = await beto.evaluate(() => ({ rev: app.player.trilha.rec.rev, resp: app.player.trilha.rec.resp }));
  await beto.reload(); await beto.waitForFunction(() => app.player.phase === 'playing' && app.player.trilha && app.player.trilha.rec, null, { timeout: 30000 });
  await beto.waitForTimeout(1500);
  const r2 = await beto.evaluate(() => ({ rev: app.player.trilha.rec.rev, resp: app.player.trilha.rec.resp }));
  ok(r2.rev >= r1.rev && r2.resp >= r1.resp, `Beto recarregou e manteve o progresso: antes ${JSON.stringify(r1)} depois ${JSON.stringify(r2)}`);
  for(let i = 0; i < 3; i++) await responde(beto, true);
  // professor: painel com o foco
  await prof.waitForTimeout(3500);
  await prof.click('#ttPainel [data-det]'); await prof.waitForTimeout(3500);
  const pn = await prof.evaluate(() => ({ topo: (document.querySelector('#ttPainel .fo-painel') || {}).textContent, cards: [...document.querySelectorAll('#ttPainel .ac-foco')].map(x => x.textContent) }));
  ok(/turma/.test(pn.topo || '') && pn.cards.length === 2, 'acompanhar mostra o foco: ' + JSON.stringify(pn));
  await prof.screenshot({ path: '/home/claude/cm/f_painel.png' });
  // fim: entrega e salvamento automático
  const dl = prof.waitForEvent('download', { timeout: 40000 });
  await prof.click('#endMatchBtn');
  const d = await dl;
  await prof.waitForTimeout(1500);
  const ent = await prof.textContent('#trEntrega');
  ok(/salvo sozinho/.test(ent), 'arquivo baixado sozinho no fim: ' + d.suggestedFilename() + ' | ' + ent.trim());
  const pth = '/home/claude/cm/turma_foco.json'; await d.saveAs(pth);
  const t = JSON.parse(fs.readFileSync(pth, 'utf8'));
  const celAna = await ana.evaluate(() => app.player.trilha.rec.rev), celBeto = await beto.evaluate(() => app.player.trilha.rec.rev);
  ok(t.alunos.ana.rev === celAna && t.alunos.beto.rev === celBeto, `arquivo tem o final de todos (rev arquivo/celular: Ana ${t.alunos.ana.rev}/${celAna}, Beto ${t.alunos.beto.rev}/${celBeto})`);
  const rel = await prof.textContent('#trRelatorio');
  ok(/Foco da aula/.test(rel), 'relatório do fim tem a tabela do foco da aula');
  await prof.screenshot({ path: '/home/claude/cm/f_fim.png', fullPage: true });
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
