const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1300,height:1400}});
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.click('#navTeacher'); await p.click('#trCatalogo'); await p.click('[data-ano="3"]');
  const antes = await p.$$eval('[data-mais="planif3"]', x => x[0].parentElement.querySelectorAll('.cat-q').length);
  await p.click('[data-mais="planif3"]'); await p.click('[data-mais="planif3"]');
  const depois = await p.$$eval('[data-mais="planif3"]', x => x[0].parentElement.querySelectorAll('.cat-q').length);
  console.log('cartões planif3:', antes, '→', depois, errs);
  const el = await p.$('[data-mais="planif3"]'); const box = await el.evaluateHandle(x => x.parentElement);
  await p.evaluate(()=>{ document.querySelectorAll('[data-deg="planif3"]').forEach(()=>{}); });
  await box.asElement().screenshot({ path: '/home/claude/cm/catmais.png' });
  await b.close();
})();
