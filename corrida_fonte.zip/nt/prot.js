const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p._acao='accept'; p.on('dialog', d => { const a = p._acao; p._acao='accept'; (a==='dismiss'?d.dismiss():d.accept()).catch(()=>{}); });
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }

  const dlg = [];
  // ---------- 1. professor abre sala, aluno entra, partida começa ----------
  let prof = await nova('prof');
  prof.on('dialog', d => dlg.push('prof:' + d.type() + ':' + d.message().slice(0, 60)));
  await prof.click('#navTeacher');
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(600);
  const sala = (await prof.textContent('#roomCodeDisplay')).trim();
  const ana = await nova('Ana');
  await ana.fill('#joinRoom', sala); await ana.fill('#joinName', 'Ana'); await ana.click('#joinBtn'); await ana.waitForTimeout(600);
  const beto = await nova('Beto');
  await beto.fill('#joinRoom', sala); await beto.fill('#joinName', 'Beto'); await beto.click('#joinBtn'); await beto.waitForTimeout(600);
  await prof.click('#startGameBtn'); await prof.waitForTimeout(1000);
  async function responder(pg, n){ for(let i = 0; i < n; i++){ await pg.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 }); const c = await pg.evaluate(() => app.player.currentQuestion.correct); await pg.click(`#ppOptions button:nth-child(${c + 1})`); await pg.waitForTimeout(760); } }
  await responder(ana, 5); await prof.waitForTimeout(3500);
  const antes = await prof.evaluate(() => app.host.players.map(p => p.name + '=' + p.score).join(' '));
  console.log('1) placar antes:', antes);
  // ---------- 2. professor clica em "Sou Aluno" por engano ----------
  prof._acao = 'dismiss';
  await prof.click('#navStudent'); await prof.waitForTimeout(300);
  console.log('2) clicou Sou Aluno e cancelou → continua professor?', await prof.evaluate(() => app.mode === 'teacher' && app.host.phase === 'playing' && !!app.mqtt));
  // ---------- 3. confirmação ao fechar/voltar ----------
  const tipos = [];
  const h1 = d => tipos.push(d.type());
  prof.on('dialog', h1); ana.on('dialog', h1);
  const bu = await prof.evaluate(() => { const e = new Event('beforeunload', { cancelable: true }); window.dispatchEvent(e); return e.defaultPrevented; });
  const bu2 = await ana.evaluate(() => { const e = new Event('beforeunload', { cancelable: true }); window.dispatchEvent(e); return e.defaultPrevented; });
  console.log('3) sair da página pede confirmação — professor:', bu, '| aluno:', bu2);
  // ---------- 4. página do professor recarrega (fechou sem querer) ----------
  await prof.evaluate(() => new Promise(r => setTimeout(r, 2200)));
  await prof.reload(); await prof.waitForTimeout(900);
  const temBox = await prof.$('#retomarBox');
  console.log('4) depois de recarregar, aparece "Retomar"?', !!temBox, temBox ? (await temBox.innerText()).replace(/\s+/g, ' ') : '');
  await prof.click('#retomarSim'); await prof.waitForTimeout(800);
  await responder(ana, 4); await prof.waitForTimeout(3500);
  console.log('   placar após retomar e Ana responder mais 4:', await prof.evaluate(() => app.host.players.map(p => p.name + '=' + p.score).join(' ')), '| tela:', await prof.evaluate(() => !document.querySelector('#hostGame').classList.contains('hidden')), '| tempo:', await prof.textContent('#hMatchTime'));
  // ---------- 5. aluno recarrega ----------
  const scoreAna = await ana.evaluate(() => app.player.stats.score);
  await ana.reload(); await ana.waitForTimeout(2500);
  const st = await ana.evaluate(() => ({ modo: app.mode, sala: app.room, nome: app.playerName, fase: app.player.phase, pontos: app.player.stats.score }));
  console.log('5) aluna recarregou (tinha ' + scoreAna + '):', JSON.stringify(st));
  await responder(ana, 2); await prof.waitForTimeout(3500);
  console.log('   professor vê:', await prof.evaluate(() => app.host.players.map(p => p.name + '=' + p.score + ' (' + p.totalAnswers + ' resp.)').join(' | ')), '| jogadores:', await prof.evaluate(() => app.host.players.length));
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
