const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  if(TRILHA_ON){
    await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
    await prof.click('#trOn button[data-v="1"]');
    await prof.selectOption('#trAno', '1');
    await prof.click('#trDiag button[data-v="saltos"]');
    await prof.click('#trLista button[data-v="1"]');
    await prof.fill('#trNomes', 'Ana\nBeto\nCaio');
    await prof.dispatchEvent('#trNomes', 'input');
    await prof.fill('#trTurmaNome', '1º ano A');
    await prof.dispatchEvent('#trTurmaNome', 'input');
  }
  await prof.click('#createRoomBtn');
  await prof.waitForTimeout(600);
  const sala = (await prof.textContent('#roomCodeDisplay')).trim();
  console.log('sala', sala, 'modo', await prof.textContent('#hModeLabel'));
  const alunos = [];
  for(const nm of ['Ana', 'Beto']){
    const a = await nova(nm);
    await a.fill('#joinRoom', sala); await a.dispatchEvent('#joinRoom', 'input');
    if(TRILHA_ON){
      await a.waitForSelector(`#trNomesAluno button[data-n="${nm}"]`, { timeout: 5000 });
      if(nm === 'Ana') await a.screenshot({ path: '/home/claude/cm/e_lista.png' });
      await a.click(`#trNomesAluno button[data-n="${nm}"]`);
    } else { await a.fill('#joinName', nm); await a.click('#joinBtn'); }
    alunos.push(a);
    await a.waitForTimeout(500);
  }
  await prof.waitForTimeout(500);
  console.log('lobby', await prof.textContent('#playerCount'));
  if(TRILHA_ON){
    const a3 = await nova('Caio'); await a3.fill('#joinRoom', sala); await a3.dispatchEvent('#joinRoom', 'input');
    await a3.waitForSelector('#trNomesAluno button', { timeout: 5000 });
    const dis = await a3.$$eval('#trNomesAluno button', bs => bs.map(b => b.textContent + (b.disabled ? '(usado)' : '')));
    console.log('lista vista pelo 3º:', dis.join(', '));
    await a3.close(); subs.delete(a3);
  }
  await prof.click('#startGameBtn');
  await prof.waitForTimeout(1200);
  const [ana, beto] = alunos;
  await ana.screenshot({ path: '/home/claude/cm/e_ana1.png' });
  // Ana acerta tudo rápido; Beto erra tudo
  const vistos = { ana: new Set(), beto: new Set() };
  async function responder(pg, certo, n, tag){
    for(let i = 0; i < n; i++){
      await pg.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 });
      const info = await pg.evaluate(() => { const q = app.player.currentQuestion; return { id: q.type, f: q.fonte && q.fonte.tipo, n: q.trilha && q.trilha.nivel, c: q.correct, img: !!q.optImgs, btnImg: document.querySelectorAll('#ppOptions img').length }; });
      vistos[tag].add(`${info.id}:${info.f}`);
      if(info.img && !vistos[tag].has('SHOT')){ vistos[tag].add('SHOT'); await pg.screenshot({ path: `/home/claude/cm/e_${tag}_img.png` }); if(info.btnImg !== 4) log.push('botões sem imagem!'); }
      const alvo = certo ? info.c : (info.c + 1) % 4;
      await pg.click(`#ppOptions button:nth-child(${alvo + 1})`);
      await pg.waitForTimeout(760);
    }
  }
  await responder(ana, true, 30, 'ana'); await ana.evaluate(() => [...document.querySelectorAll('div')].filter(d => /Há uma partida aberta/.test(d.textContent) && d.children.length < 6 && getComputedStyle(d).position === 'fixed').forEach(d => d.remove())); await ana.waitForTimeout(400); await ana.screenshot({ path: '/home/claude/cm/ch_ana.png' }); await beto.screenshot({ path: '/home/claude/cm/ch_beto.png' });
  await prof.waitForTimeout(3500);
  console.log('após ~9 s de jogo — pista:', (await prof.$$eval('[data-role=score]', e => e.map(x => x.textContent))).join(' / '), '| Top 5:', (await prof.textContent('#hRankLive')).replace(/\s+/g, ' ').trim());
  await Promise.all([responder(ana, true, 64, 'ana'), responder(beto, false, 14, 'beto')]);
  if(TRILHA_ON){   // AJUDAS: Beto usa ajuda e acerta; cada acerto com ajuda deve valer ~50
    for(let i = 0; i < 4; i++){
      await beto.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 });
      const antes = await beto.evaluate(() => ({ s: app.player.stats.score, aj: app.player.trilha.rec.ajudas, tem: !!document.getElementById('ppAjudaBtn'), dis: document.getElementById('ppAjudaBtn') && document.getElementById('ppAjudaBtn').disabled, f: app.player.currentQuestion.fonte.tipo }));
      if(antes.tem && !antes.dis){ await beto.click('#ppAjudaBtn'); await beto.waitForTimeout(200); if(i === 0) await beto.screenshot({ path: '/home/claude/cm/e_ajuda.png' }); }
      const c = await beto.evaluate(() => app.player.currentQuestion.correct);
      await beto.click(`#ppOptions button:nth-child(${c + 1})`);
      await beto.waitForTimeout(300);
      const dep = await beto.evaluate(() => ({ s: app.player.stats.score, aj: app.player.trilha.rec.ajudas }));
      console.log(`ajuda ${i + 1}: botão=${antes.tem ? (antes.dis ? 'desativado' : 'ativo') : 'não'} fonte=${antes.f} ajudas ${antes.aj}→${dep.aj} pontos +${dep.s - antes.s}`);
      await beto.waitForTimeout(500);
    }
  }
  await prof.waitForTimeout(3500);
  await prof.screenshot({ path: '/home/claude/cm/e_prof_jogo.png' });
  console.log('Ana viu:', [...vistos.ana].join(' '));
  console.log('Beto viu:', [...vistos.beto].join(' '));
  const est = await prof.evaluate(() => ({ players: app.host.players.map(p => ({ n: p.name, s: p.score, c: p.correct, w: p.wrong, lvl: p.level })),
    alertas: document.querySelector('#trAlertas') ? document.querySelector('#trAlertas').innerText : 'sem painel',
    turma: TRILHA ? Object.values(TRILHA.estado.turma.alunos).map(r => ({ n: r.nome, atual: r.atual, rev: r.rev, diag: typeof r.diag === 'object' ? 'ativo' : r.diag, dom: Object.entries(r.deg).filter(([k, d]) => d.dom).map(([k, d]) => k + '/' + d.domPor).join(',') })) : null }));
  console.log(JSON.stringify(est, null, 1));
  const anaStats = await ana.evaluate(() => ({ score: app.player.stats.score, falas: window.__falas.slice(0, 4), qtdFalas: window.__falas.length }));
  console.log('Ana', JSON.stringify(anaStats));
  // encerra
  await prof.click('#endMatchBtn');
  await prof.waitForTimeout(800);
  await prof.screenshot({ path: '/home/claude/cm/e_prof_fim.png', fullPage: true });
  if(TRILHA_ON){
    const [dl] = await Promise.all([prof.waitForEvent('download'), prof.click('#trSalvarFim')]);
    const pth = '/home/claude/cm/turma_teste.json'; await dl.saveAs(pth);
    const t = JSON.parse(fs.readFileSync(pth, 'utf8'));
    console.log('arquivo:', dl.suggestedFilename(), 'alunos:', Object.keys(t.alunos).join(','), 'cfg:', JSON.stringify(t.cfg));
  }
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
