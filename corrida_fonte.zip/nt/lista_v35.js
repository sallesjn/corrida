const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true }); await ctx.addInitScript(() => { setInterval(() => { const d = document.getElementById('mxDet'); if(d && !d.open) d.open = true; }, 50); });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},(window.__lento&&/emqx/.test(U))?window.__lento:50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){const era=cli.connected;cli.connected=false;cli._fim=true;window.__unsub(window.__cid);setTimeout(()=>(h.close||[]).forEach(f=>f()),30)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }


  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trTempo button[data-v="0"]');

  await prof.fill('#trNomes', 'Ana\nBeto'); await prof.dispatchEvent('#trNomes', 'input');
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(1500);
  const sala = (await prof.textContent('#hRoomCode')).trim();
  const a = await nova('Ana');
  await a.fill('#joinRoom', sala); await a.dispatchEvent('#joinRoom', 'input');
  await a.waitForSelector('#trNomesAluno button[data-n="Ana"]', { timeout: 8000 });
  const escondido = await a.evaluate(() => getComputedStyle(document.getElementById('joinName').closest('.join-field')).display === 'none' && getComputedStyle(document.getElementById('joinBtn')).display === 'none');
  ok(escondido, 'com a lista, o campo de digitar o nome e o botão Entrar somem');
  await a.screenshot({ path: '/home/claude/cm/l_entrada.png' });
  await a.click('#trNomesAluno button[data-n=\"Ana\"]'); await a.waitForSelector('#apEntrar'); await a.click('#apEntrar');
  await a.waitForFunction(() => app.player.phase === 'playing', null, { timeout: 15000 });
  ok(true, 'Ana entrou tocando no nome');
  // alguém forçando um nome livre (celular com versão antiga / link direto)
  const z = await nova('Ze');
  await z.evaluate(([s]) => { document.getElementById('joinRoom').value = s; document.getElementById('joinName').value = 'neymar.jr'; app.playerJoin(); }, [sala]);
  await z.waitForTimeout(2500);
  const zt = await z.evaluate(() => document.getElementById('playerWait').textContent);
  ok(/lista/.test(zt) && await prof.evaluate(() => !app.host.players.some(p => p.name === 'neymar.jr')), 'nome fora da lista é recusado: ' + zt.replace(/\s+/g, ' ').trim().slice(0, 90));
  // professor inclui um aluno novo
  await prof.click('#ttPainel [data-det]'); await prof.waitForTimeout(3500);
  prof.removeAllListeners('dialog'); prof.on('dialog', d => d.type() === 'prompt' ? d.accept('Caio') : d.accept());
  await prof.click('#ttPainel [data-incluir]'); await prof.waitForTimeout(800);
  const c = await nova('Caio');
  await c.fill('#joinRoom', sala); await c.dispatchEvent('#joinRoom', 'input');
  await c.waitForSelector('#trNomesAluno button[data-n="Caio"]', { timeout: 8000 });
  const usado = await c.evaluate(() => document.querySelector('#trNomesAluno button[data-n="Ana"]').disabled);
  await c.click('#trNomesAluno button[data-n=\"Caio\"]'); await c.waitForSelector('#apEntrar'); await c.click('#apEntrar');
  await c.waitForFunction(() => app.player.phase === 'playing', null, { timeout: 15000 });
  ok(usado, 'aluno novo incluído com a sala aberta aparece na lista e entra; o nome da Ana aparece como já usado');
  // troca de nome com lista: só nomes da lista
  const cid = await c.evaluate(() => app.playerId);
  prof.removeAllListeners('dialog'); prof.on('dialog', d => d.accept());
  await prof.click(`#ttPainel [data-aluno="${cid}"]`); await prof.click('#acMenu [data-a="nome"]');
  await c.waitForSelector('#trocaNomeBox', { timeout: 6000 });
  const tn = await c.evaluate(() => ({ campo: getComputedStyle(document.querySelector('#trocaNomeBox .tn-linha')).display, nomes: [...document.querySelectorAll('#trocaNomeBox .tn-lista button')].map(b => b.textContent) }));
  ok(tn.campo === 'none' && tn.nomes.join() === 'Beto', 'troca de nome com lista: só os nomes livres da lista, sem campo de digitar ' + JSON.stringify(tn));
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
