const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../orig.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
for(const t of process.argv[2].split(',')) for(let n=1;n<=5;n+=2){const q=d.window.eval(`generateQuestion({allowed:null},${n},'${t}')`); console.log(t,n,'|',q.text.slice(0,120),'|',JSON.stringify(q.options), q.image?'IMG':'');}
process.exit(0);
