const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); T.CAT.forEach(c=>{ if(c.i+1>=45) console.log(c.i+1,c.ano,c.id,c.nome)}); process.exit(0);
