const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'); const out={};
for(const c of T.CAT) for(let n=1;n<=3;n++) for(let k=0;k<300;k++){
  let q; try{ q=T.gerarQuestao(c.id,n); }catch(e){ continue; }
  const a=String(q.options[q.correct]);
  if(/\d,\d/.test(a) && !/\d,\d/.test(q.text) && c.ano<=7){ const key=c.id+' N'+n; out[key]=(out[key]||0)+1; if(out[key]===1) out[key+'_ex']=q.text.slice(0,150)+' → '+a; }
}
console.log(JSON.stringify(out,null,1)); process.exit(0);
