const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},(window.__lento&&/emqx/.test(U))?window.__lento:50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){const era=cli.connected;cli.connected=false;cli._fim=true;window.__unsub(window.__cid);setTimeout(()=>(h.close||[]).forEach(f=>f()),30)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }


  const ok = (cond, msg) => console.log((cond ? '✅ ' : '❌ ') + msg);
  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  await prof.click('#trOn button[data-v="1"]');
  await prof.click('#trDiag button[data-v="inicio"]');
  await prof.click('#trModo button[data-v="treino"]');
  await prof.click('#trTempo button[data-v="0"]');
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(1200);
  const sala = (await prof.textContent('#hRoomCode')).trim();
  const a = await nova('Ana'); await a.fill('#joinRoom', sala); await a.fill('#joinName', 'Ana'); await a.click('#joinBtn');
  await a.waitForFunction(() => app.player.phase === 'playing' && app.player.trilha && app.player.trilha.rec, null, { timeout: 15000 });
  const pid = await a.evaluate(() => app.playerId);
  await prof.click('#ttPainel [data-det]'); await prof.waitForTimeout(3500);
  await prof.click(`#ttPainel [data-aluno="${pid}"]`); await prof.click('#acMenu [data-a="plano"]');
  await prof.click('#plBox input[value="lista"]'); await prof.click('#plBox button[data-aba="6"]');
  await prof.click('#plBox input[data-id="abreAng6"]'); await prof.click('#plBox [data-salvar]');
  await a.waitForFunction(() => app.player.trilha.rec.plano, null, { timeout: 15000 }); await a.waitForTimeout(500);
  const pos = async g => { const bb = await (await a.$('#ivBox .iv-svg svg')).boundingBox(); const tr = await a.evaluate(() => app.player.currentQuestion.interativo.transferidor); const W = 460, H = tr ? 250 : 240, cx = 230, cy = tr ? 230 : 205, R = 150; const t = g * Math.PI / 180; return [bb.x + (cx + R * Math.cos(t)) * bb.width / W, bb.y + (cy - R * Math.sin(t)) * bb.height / H]; };
  let certos = 0, feitos = 0, shot = false;
  for(let i = 0; i < 8; i++){
    await a.waitForFunction(() => document.getElementById('ivBox') && !app.player.questionBlocked, null, { timeout: 15000 });
    const q = await a.evaluate(() => ({ meta: app.player.currentQuestion.meta, opts: getComputedStyle(document.getElementById('ppOptions')).display }));
    const alvo = q.meta.graus || { agudo: 40, reto: 90, obtuso: 130, raso: 180 }[q.meta.alvo];
    const errar = i === 3;
    const g = errar ? (alvo > 90 ? 30 : 150) : alvo;
    // arrasta: aperta perto do 0°, move até o ângulo
    const [x0, y0] = await pos(0), [x1, y1] = await pos(Math.min(g, 179.5));
    await a.mouse.move(x0, y0); await a.mouse.down(); await a.mouse.move((x0 + x1) / 2, Math.min(y0, y1) - 10, { steps: 5 }); await a.mouse.move(x1, y1, { steps: 8 }); await a.mouse.up();
    if(g === 180){ await a.click('#ivBox .iv-bts button[data-d="5"]'); }
    const aberto = await a.evaluate(() => document.querySelector('#ivBox').textContent);
    if(!shot){ await a.screenshot({ path: '/home/claude/cm/iv_antes.png' }); }
    await a.click('#ivBox .iv-ok');
    await a.waitForTimeout(300);
    const res = await a.evaluate(() => ({ cls: document.getElementById('ivBox').className, txt: document.querySelector('#ivBox .iv-dica').textContent }));
    if(!shot){ await a.screenshot({ path: '/home/claude/cm/iv_depois.png' }); shot = true; }
    if(errar){ await a.screenshot({ path: '/home/claude/cm/iv_errado.png' }); }
    feitos++; if(/certo/.test(res.cls)) certos++;
    console.log(`   ${JSON.stringify(q.meta)} opções escondidas=${q.opts === 'none'} → ${res.txt}`);
    if(await a.$('#vjBox')){ await a.waitForTimeout(2200); await a.click('#vjBox .vj-ok'); }
    await a.waitForTimeout(900);
    if(await a.$('.tr-festa')) await a.waitForTimeout(7200);
  }
  ok(certos === 7, `arrastar: ${certos} de ${feitos} certos (1 errado de propósito)`);
  await a.waitForTimeout(3500);
  const host = await prof.evaluate(() => { const p = app.host.players[0]; return { c: p.correct, w: p.wrong }; });
  ok(host.c === 7 && host.w === 1, 'professor recebeu: ' + JSON.stringify(host));
  console.log('erros de página:', log.length ? log : 'nenhum');
  await b.close();
})();
