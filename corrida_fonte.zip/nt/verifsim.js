const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync('../work.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA'), E=T.estado; E.cfg.ano=7;
if(process.argv[2]==='off') T.REGRA.pVerif=0; if(process.argv[4]) T.REGRA.pVerif=+process.argv[4];
const N=100, R=+process.argv[3]||400;
let ini={c:0,cs:0}, fim={c:0,cs:0,nc:0}, buracosAchados=0, buracosTot=0, falsos=0, verifs=0, tot=0;
for(let s=0;s<N;s++){
  // aluno forte com 3 "buracos" no 6º/7º ano que o diagnóstico não vê
  const deg6=T.CAT.filter(x=>x.ano>=6&&x.ano<=7); const buracos=new Set(); while(buracos.size<3) buracos.add(deg6[Math.floor(Math.random()*deg6.length)].id);
  const P=id=>buracos.has(id)?0.25:(T.POR_ID[id].ano<=7?0.95:0.6);
  const rec=T.novoRegistro('x'+s); T.iniciar(rec,{diag:'saltos',ano:7});
  let diagFeito=false;
  for(let k=0;k<R;k++){
    const f=T.escolherFonte(rec); const ok=Math.random()<P(f.id); tot++; if(f.tipo==='verif') verifs++;
    const ev=T.registrar(rec,f,{},0,ok,0.3);
    if(!diagFeito && rec.diag==='feito'){ diagFeito=true; T.CAT.forEach(x=>{const st=E.classificar?null:null; const dd=rec.deg[x.id]; if(dd&&dd.dom&&x.ano>=6&&x.ano<=7){ if(dd.domPor==='diag'||dd.domPor==='ano') ini.cs++; else ini.c++; }}); }
  }
  T.CAT.forEach(x=>{ if(x.ano<6||x.ano>7) return; const dd=rec.deg[x.id]; if(!dd) return;
    if(dd.dom){ if(dd.domPor==='diag'||dd.domPor==='ano') fim.cs++; else fim.c++; } else if(dd.tot) fim.nc++;
    if(buracos.has(x.id)){ if((dd.domPor==='diag'||dd.domPor==='ano')&&dd.dom) {} ; }
  });
  buracos.forEach(id=>{ const dd=rec.deg[id]; buracosTot++; if(!(dd&&dd.dom)) buracosAchados++; });
  T.CAT.forEach(x=>{ const dd=rec.deg[x.id]; if(dd&&dd.verifFalhou&&!buracos.has(x.id)) falsos++; });
}
console.log(`${process.argv[2]||'on'}: verificações ${(verifs/tot*100).toFixed(1)}% das perguntas · 6º–7º ano por aluno: C* ${(fim.cs/N).toFixed(1)} · C ${(fim.c/N).toFixed(1)} · NC ${(fim.nc/N).toFixed(1)} · buracos não marcados como sabidos: ${buracosAchados}/${buracosTot} · degraus sabidos derrubados por engano: ${falsos}`);
process.exit(0);
