const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const FILE = 'file:///home/claude/cm/work.html';
const DB = {}; const allPub = [];
function getP(path){ let o = DB; for(const k of path){ if(o == null) return null; o = o[k]; } return o === undefined ? null : o; }
function setP(path, v){ let o = DB; for(let i = 0; i < path.length - 1; i++){ o = o[path[i]] = o[path[i]] || {}; } if(v === null) delete o[path[path.length - 1]]; else o[path[path.length - 1]] = v; }
const ok = (c, m) => console.log((c ? 'OK    ' : 'FALHA ') + m);
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 } }); await ctx.addInitScript(() => { setInterval(() => { const d = document.getElementById('mxDet'); if(d && !d.open) d.open = true; }, 50); });
  const retained = {}; const subs = new Map();
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  await ctx.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
  await ctx.route('https://securetoken.googleapis.com/**', r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ id_token: 'ID2', refresh_token: 'RT1', user_id: 'UID9', expires_in: '3600' }) }));
  await ctx.route('https://matematica-3df86-default-rtdb.firebaseio.com/**', async r => {
    const u = new URL(r.request().url()); const m = r.request().method();
    const path = u.pathname.replace(/\.json$/, '').split('/').filter(Boolean);
    if(m === 'GET') return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(getP(path)) });
    const body = JSON.parse(r.request().postData()); for(const k in body) setP(path.concat(k.split('/')), body[k]);
    return r.fulfill({ status: 200, contentType: 'application/json', body: '{}' });
  });
  const pages = []; const log = [];
  async function nova(nome, desloc){
    const p = await ctx.newPage(); p._nome = nome; subs.set(p, new Set()); pages.push(p);
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] ${e.message}`));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      allPub.push(payload);
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', t => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    if(desloc) await p.addInitScript(d => { const n0 = Date.now; Date.now = () => n0() + d; }, desloc);
    await p.goto(FILE);
    return p;
  }
  // ---------- professor ----------
  const prof = await nova('prof');
  await prof.evaluate(() => { localStorage.clear(); localStorage.setItem('cgm_nuvem', JSON.stringify({ rt: 'RT1', uid: 'UID9', email: 'f@x.com' })); });
  await prof.reload(); await prof.click('#navTeacher'); await prof.waitForTimeout(700);
  await prof.click('#nvNova'); await prof.fill('#nvNome', '6º M01'); await prof.selectOption('#nvAno', '6'); await prof.click('#nvCriar'); await prof.waitForTimeout(700);
  const cod = await prof.evaluate(() => __ent.est().turma.codigo);
  ok(/^[A-Z0-9]{4}$/.test(cod), 'código fixo gerado: ' + cod);
  ok(await prof.evaluate(() => __ent.est().cfg.lista === true), 'turma nova já com lista ligada');
  const NOMES = ['Ana Clara Souza', 'Ana Beatriz Lima', 'Bruno Henrique Dias', 'Carlos', 'Maria de Fátima Alves', 'Ana Clara Santos'];
  await prof.fill('#trNomes', NOMES.join('\n')); await prof.dispatchEvent('#trNomes', 'input'); await prof.click('#nvBox h4'); await prof.waitForTimeout(300);
  const rot = await prof.evaluate(() => __ent.est().cfg.nomes);
  ok(JSON.stringify(rot) === JSON.stringify(['Ana B.', 'Ana C. Sa.', 'Ana C. So.', 'Bruno H.', 'Carlos', 'Maria F.'].sort((a, b) => a.localeCompare(b, 'pt-BR'))) || rot.length === 6, 'rótulos: ' + JSON.stringify(rot));
  ok(new Set(rot.map(x => x.toLowerCase())).size === 6, 'rótulos únicos');
  ok((await prof.inputValue('#trNomes')).includes('Ana Clara Souza'), 'caixa do professor mostra nomes completos');
  await (await prof.$('#trilhaCard')).screenshot({ path: '/home/claude/cm/ent_card.png' });
  await prof.click('#createRoomBtn'); await prof.waitForTimeout(900);
  ok((await prof.textContent('#roomCodeDisplay')).trim() === cod, 'sala abriu com o código fixo');
  // ---------- alunos ----------
  async function aluno(nm, tocar, apelido){
    const a = await nova(nm); await a.fill('#joinRoom', cod); await a.dispatchEvent('#joinRoom', 'input'); await a.waitForTimeout(500);
    await a.click(`#trNomesAluno button[data-n="${tocar}"]`); await a.waitForTimeout(150);
    if(apelido !== undefined){ await a.fill('#apNome', apelido); }
    await a.click('#apEntrar'); await a.waitForTimeout(700);
    return a;
  }
  const s1 = await nova('s1'); await s1.fill('#joinRoom', cod); await s1.dispatchEvent('#joinRoom', 'input'); await s1.waitForTimeout(500);
  const btns = await s1.$$eval('#trNomesAluno button[data-n]', bs => bs.map(b => b.textContent));
  ok(btns.length === 6 && btns.every(t => !/Souza|Lima|Henrique|Fátima|Santos/.test(t)), 'aluno vê só rótulos: ' + btns.join(', '));
  await s1.screenshot({ path: '/home/claude/cm/ent_lista.png' });
  await s1.click('#trNomesAluno button[data-n="Ana B."]'); await s1.waitForTimeout(150);
  await s1.fill('#apNome', 'Furacão'); await s1.screenshot({ path: '/home/claude/cm/ent_apelido.png' });
  ok(await s1.isVisible('#apNome'), 'tela de apelido aparece');
  await s1.fill('#apNome', 'Furacão'); await s1.click('#apEntrar'); await s1.waitForTimeout(800);
  const p1 = await prof.evaluate(() => app.host.players.map(p => ({ n: p.name, a: p.apelido })));
  ok(p1.length === 1 && p1[0].n === 'Ana B.' && p1[0].a === 'Furacão', 'professor: Ana B. com apelido Furacão ' + JSON.stringify(p1));
  ok(await prof.evaluate(() => document.getElementById('hostLobby').textContent.includes('Furacão')), 'saguão mostra o apelido');
  // aluno 2: tenta apelido repetido e nome de colega
  const s2 = await nova('s2'); await s2.fill('#joinRoom', cod); await s2.dispatchEvent('#joinRoom', 'input'); await s2.waitForTimeout(600);
  ok(await s2.$eval('#trNomesAluno button[data-n="Ana B."]', b => b.disabled), 'nome em uso fica bloqueado');
  await s2.click('#trNomesAluno button[data-n="Bruno H."]'); await s2.waitForTimeout(100);
  await s2.fill('#apNome', 'furacao'); await s2.click('#apEntrar'); await s2.waitForTimeout(100);
  ok(/colega/.test(await s2.textContent('#apErro')), 'apelido repetido recusado: ' + await s2.textContent('#apErro'));
  await s2.fill('#apNome', 'Carlos'); await s2.click('#apEntrar'); await s2.waitForTimeout(100);
  ok(/colega/.test(await s2.textContent('#apErro')), 'apelido = nome de colega recusado');
  await s2.fill('#apNome', 'Bruninho'); await s2.click('#apEntrar'); await s2.waitForTimeout(800);
  const s3 = await aluno('s3', 'Carlos');
  const ps = await prof.evaluate(() => app.host.players.map(p => p.name + '|' + (p.apelido || '')));
  ok(ps.sort().join(',') === 'Ana B.|Furacão,Bruno H.|Bruninho,Carlos|', 'três na sala: ' + ps.join(','));
  // nada de nome completo na rede
  const vaz = allPub.filter(x => /Souza|Beatriz|Lima|Henrique|Dias|Fátima|Alves|Santos/.test(x));
  ok(vaz.length === 0, 'nenhum nome completo publicado na rede (' + allPub.length + ' mensagens) ' + (vaz[0] || '').slice(0, 200));
  // professor apaga apelido do Bruno
  await prof.evaluate(() => { const p = app.host.players.find(x => x.name === 'Bruno H.'); __apaga = p.id; });
  await prof.click('#ctBtn'); await prof.waitForTimeout(400);
  await prof.screenshot({ path: '/home/claude/cm/ent_gaveta.png' });
  ok(await prof.evaluate(() => document.getElementById('gvBox').textContent.includes('Bruninho (Bruno H.)')), 'gaveta mostra "Bruninho (Bruno H.)"');
  await prof.click(`#gvBox [data-troca="${await prof.evaluate(() => __apaga)}"]`); await prof.waitForTimeout(500);
  ok(await prof.evaluate(() => !app.host.players.find(x => x.name === 'Bruno H.').apelido && !__ent.est().turma.apelidos['bruno h']), 'professor apagou o apelido');
  ok(await s2.evaluate(() => app.apelidoEsc === ''), 'aluno soube que o apelido foi apagado');
  await s2.evaluate(() => app.pub(`${BASE}/${app.room}/tohost`, { type: 'join', id: app.playerId, name: app.playerName, apelido: 'Bruninho' })); await prof.waitForTimeout(300);
  ok(await prof.evaluate(() => !app.host.players.find(x => x.name === 'Bruno H.').apelido), 'join repetido com o apelido vetado não volta');
  // joga um pouco
  await prof.click('#startGameBtn'); await prof.waitForTimeout(1500);
  for(let i = 0; i < 6; i++){
    await s1.waitForFunction(() => app.player.currentQuestion && !app.player.questionBlocked, null, { timeout: 8000 });
    const c = await s1.evaluate(() => app.player.currentQuestion.correct);
    await s1.click(`#ppOptions button:nth-child(${c + 1})`); await s1.waitForTimeout(600);
  }
  await prof.waitForTimeout(2500);
  ok(await prof.evaluate(() => !!__ent.est().turma.alunos['ana b'] && Object.keys(__ent.est().turma.alunos).every(k => !/souza|lima|beatriz/.test(k))), 'progresso guardado no rótulo: ' + await prof.evaluate(() => Object.keys(__ent.est().turma.alunos).join(',')));
  ok(await prof.evaluate(() => document.getElementById('hostGame').textContent.includes('Furacão')), 'corrida mostra o apelido');
  await prof.evaluate(() => { __nv.ultEnvio = 0; }); await prof.waitForTimeout(5500);
  const nuvem = JSON.parse(Object.values(getP(['prof', 'UID9', 'turmas']))[0].json);
  console.log('  local:', await prof.evaluate(() => JSON.stringify({ ap: __ent.est().turma.apelidos, re: __ent.est().turma.reais, id: __ent.est().turma.nuvemId, env: __nv.status + __nv.erro })), Object.keys(getP(['prof','UID9','turmas'])));
  console.log('  nuvem:', JSON.stringify({ ap: nuvem.apelidos, re: nuvem.reais }));
  ok(nuvem.apelidos && nuvem.apelidos['ana b'] === 'Furacão' && nuvem.reais && nuvem.reais['Ana B.'] === 'Ana Beatriz Lima', 'nuvem tem apelidos e nomes completos');
  // ---------- aula seguinte: aluno com relógio 1 h na frente vê lista retida antiga, professor ainda não abriu ----------
  await prof.evaluate(() => app.endGame()); await prof.waitForTimeout(500);
  for(const p of [s1, s2, s3]) await p.close();
  await prof.close();
  const s4 = await nova('s4', 3600 * 1000);
  await s4.fill('#joinRoom', cod); await s4.dispatchEvent('#joinRoom', 'input'); await s4.waitForTimeout(600);
  ok(!(await s4.$eval('#trNomesAluno button[data-n="Ana B."]', b => b.disabled)), 'lista antiga: nome não fica bloqueado');
  await s4.click('#trNomesAluno button[data-n="Ana B."]'); await s4.waitForTimeout(150);
  ok(await s4.inputValue('#apNome') === 'Furacão', 'apelido guardado vem pronto');
  await s4.click('#apEntrar'); await s4.waitForTimeout(4500);
  ok(/Aguardando o professor/.test(await s4.textContent('#playerWait')), 'aguardando o professor (sem "sala não encontrada"): ' + (await s4.textContent('#playerWait')).trim().slice(0, 80));
  const prof2 = await nova('prof2');
  await prof2.click('#navTeacher'); await prof2.waitForTimeout(1500);
  await s4.screenshot({ path: '/home/claude/cm/ent_espera.png' });
  ok(/Aberta: 6º M01/.test(await prof2.textContent('#nvBox')), 'professor abre o jogo: turma 6º M01 já aberta');
  await prof2.click('#createRoomBtn'); await prof2.waitForTimeout(5000);
  const pp = await prof2.evaluate(() => app.host.players.map(p => p.name + '|' + p.apelido));
  ok(pp.join() === 'Ana B.|Furacão', 'aluno entrou sozinho quando o professor abriu: ' + pp.join());
  ok(await s4.evaluate(() => app.player.gotState), 'aluno recebeu o estado (mesmo com relógio adiantado)');
  // refazer diagnóstico com o aluno na sala
  await prof2.evaluate(() => { const r = __ent.est().turma.alunos['ana b']; r.deg.soma10 = { dom: 1, domPor: 'diag', h: [] }; r.deg.faz10 = { dom: 1, domPor: 'trilha', h: [] }; r.diag = 'feito'; r.atual = 'dobro'; });
  await prof2.evaluate(() => __ent.est().abrirEditorTurma()); await prof2.waitForTimeout(200);
  ok(await prof2.isVisible('[data-tdiag="Ana B."]') && await prof2.isVisible('#teDiagTodos'), 'botões 🔎 no editor da turma');
  await prof2.click('[data-tdiag="Ana B."]'); await prof2.waitForTimeout(1500);
  const rr = await prof2.evaluate(() => { const r = __ent.est().turma.alunos['ana b']; return [r.diag, r.atual, r.deg.soma10.dom, r.deg.faz10.dom, r.rev >= 1000]; });
  ok(rr[0] === null && rr[1] === null && rr[2] === 0 && rr[3] === 1 && rr[4], 'professor: diagnóstico zerado, conquista mantida ' + JSON.stringify(rr));
  const ra = await s4.evaluate(() => { const r = app.player.trilha && app.player.trilha.rec; return r ? [r.diag === null || typeof r.diag === 'object', r.deg.faz10 && r.deg.faz10.dom] : null; });
  ok(ra && ra[0] && ra[1] === 1, 'Chromebook do aluno recebeu na hora: ' + JSON.stringify(ra));
  await prof2.click('[data-tfecha]'); await prof2.waitForTimeout(300);
  // migração de progresso antigo (nome completo) para o rótulo
  const mig = await prof2.evaluate(() => { const E = __ent.est(); E.turma.alunos['joao pedro silva'] = { nome: 'Joao Pedro Silva', deg: { x: 1 } }; E.cfg.nomes = E.cfg.nomes.concat(['João Pedro Silva']); __ent.normalizarNomes(); return [Object.keys(E.turma.alunos).includes('joao p'), !E.turma.alunos['joao pedro silva'], E.cfg.nomes.includes('João P.')]; });
  ok(mig.every(Boolean), 'progresso antigo migrado para "João P." ' + mig);
  console.log('erros:', log);
  await b.close();
})();
