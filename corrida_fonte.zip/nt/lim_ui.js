const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{
  const b = await chromium.launch(); const p = await b.newPage({viewport:{width:1300,height:1600}});
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
  await p.goto('file:///home/claude/cm/work.html');
  await p.click('#navTeacher');
  await p.selectOption('#trAno','5');
  await p.selectOption('#trAnoMax','3');
  const r1 = await p.evaluate(()=>({ano:$('trAno').value, opcoes:[...$('trAno').options].map(o=>o.value), ls:localStorage.getItem('cgm_trilha_cfg'), status:$('trStatus').innerText}));
  console.log(JSON.stringify(r1));
  await p.reload(); await p.click('#navTeacher');
  const r2 = await p.evaluate(()=>({max:$('trAnoMax').value, ano:$('trAno').value}));
  console.log('depois de recarregar', JSON.stringify(r2));
  const card = await p.$('#trilhaCard'); await card.screenshot({path:'/home/claude/cm/lim_card.png'});
  await p.click('#trCatalogo'); await p.click('[data-ano="5"]'); await p.waitForTimeout(300);
  await p.screenshot({path:'/home/claude/cm/lim_cat.png'});
  console.log('erros', errs); await b.close();
})();
