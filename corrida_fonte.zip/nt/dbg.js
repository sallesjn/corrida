const { chromium } = require('/opt/node22/lib/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage();
p.on('console',m=>console.log('C',m.type(),m.text()));
await p.route('**/unpkg.com/**', r => r.fulfill({status:200, contentType:'application/javascript', body:'window.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}}'}));
await p.addInitScript(()=>{window.__falas=[];Object.defineProperty(window,'speechSynthesis',{configurable:true,value:{speak(u){window.__falas.push(u.text)},cancel(){},getVoices(){return[]}}});window.SpeechSynthesisUtterance=function(t){this.text=t};});
await p.goto('file:///home/claude/cm/work.html');
const r=await p.evaluate(()=>{app.player.trilha={on:true,cfg:{voz:'auto'},rec:null,evs:[]};const q=TRILHA.gerarQuestao('soma10',1);q.fonte={tipo:'atual'};app.player.questionLimit=45;app.renderPlayerQuestion(q);return {f:window.__falas, ss: typeof window.speechSynthesis, u: typeof SpeechSynthesisUtterance}});
console.log(JSON.stringify(r));await b.close();})();
