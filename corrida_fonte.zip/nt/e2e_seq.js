const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const fs = require('fs');
const FILE = 'file:///home/claude/cm/' + (process.argv[2] || 'work.html');
const TRILHA_ON = process.argv[3] !== 'off';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true });
  const pages = []; const retained = {}; const subs = new Map(); // page -> Set(topics)
  const mqttFake = `window.mqtt={connect(url){const h={};const U=url||'';const cli={connected:false,_subs:new Set(),on(ev,fn){(h[ev]=h[ev]||[]).push(fn);if(ev==='connect')setTimeout(()=>{if(window.__bloqueia&&/emqx/.test(U))return;if(cli._fim)return;cli.connected=true;fn()},50);},
    subscribe(t){cli._subs.add(U+'|'+t);window.__sub(window.__cid,U+'|'+t);},publish(t,p,o){if(!cli.connected)return;window.__pub(U+'|'+t,p,!!(o&&o.retain));},end(){cli.connected=false;cli._fim=true;window.__unsub(window.__cid)},_emit(t,p){(h.message||[]).forEach(f=>f(t,{toString:()=>p}))}};
    window.__clis=window.__clis||[];window.__clis.push(cli);window.__cid=(window.__cid||'')+'';return cli}};
    window.__deliver=(k,p)=>{(window.__clis||[]).forEach(c=>{if(c.connected&&c._subs.has(k))c._emit(k.split('|').slice(1).join('|'),p)})};`;
  const log = [];
  async function nova(nome){
    const p = await ctx.newPage(); p._nome = nome; pages.push(p); subs.set(p, new Set());
    p.on('dialog', d => d.accept());
    p.on('pageerror', e => log.push(`[${nome}] pageerror ${e.message}`));
    p.on('console', m => { if(m.type() === 'error') log.push(`[${nome}] console ${m.text()}`); });
    await p.route('**/unpkg.com/**', r => r.fulfill({ status: 200, contentType: 'application/javascript', body: mqttFake }));
    await p.exposeFunction('__pub', (t, payload, retain) => {
      if(retain) retained[t] = payload;
      for(const [pg, set] of subs) if(set.has(t)) pg.evaluate(([t, pl]) => window.__deliver(t, pl), [t, payload]).catch(()=>{});
    });
    await p.exposeFunction('__sub', (cid, t) => { subs.get(p).add(t); if(retained[t]) setTimeout(() => p.evaluate(([t, pl]) => window.__deliver(t, pl), [t, retained[t]]).catch(()=>{}), 30); });
    await p.exposeFunction('__unsub', () => {});
    await p.addInitScript(() => {
      window.__falas = [];
      Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u){ window.__falas.push(u.text); }, cancel(){}, getVoices(){ return [{ lang: 'pt-BR', name: 'x' }]; }, onvoiceschanged: null } });
      window.SpeechSynthesisUtterance = function(t){ this.text = t; };
    });
    await p.goto(FILE);
    return p;
  }

  const prof = await nova('prof');
  await prof.click('#navTeacher');
  await prof.evaluate(() => { try{ localStorage.clear(); }catch(e){} });
  await prof.reload(); await prof.click('#navTeacher');
  const modo = process.argv[4] || 'treino-depois-corrida';
  async function entra(nm, sala){ const a = await nova(nm); await a.fill('#joinRoom', sala); await a.dispatchEvent('#joinRoom', 'input'); await a.fill('#joinName', nm); await a.click('#joinBtn'); await a.waitForTimeout(600); return a; }
  if(modo.startsWith('treino')){
    await prof.click('#trModo button[data-v="treino"]');
    await prof.click('#createRoomBtn'); await prof.waitForTimeout(800);
    const s1 = (await prof.textContent('#roomCodeDisplay')).trim();
    const a = await entra('Ana', s1); await prof.waitForTimeout(1500);
    console.log('treino: classe', await prof.evaluate(() => document.body.className), 'fase', await prof.evaluate(() => app.host.phase));
    await prof.click('#endMatchBtn'); await prof.waitForTimeout(800);
    await prof.screenshot({ path: '/home/claude/cm/s_fim_treino.png' });
    // volta para a tela inicial e cria corrida
    const novo = await prof.$('#newRoomBtn, #hNewRoom, [data-act=nova]');
    console.log('botão nova sala?', !!novo);
    await prof.reload(); await prof.waitForTimeout(800);
    console.log('depois do reload: tela', await prof.evaluate(() => [...document.querySelectorAll('section')].filter(s => !s.classList.contains('hidden')).map(s => s.id).join(',')));
    if(await prof.$('#navTeacher:visible')) await prof.click('#navTeacher').catch(()=>{});
    await prof.waitForTimeout(500);
    await prof.screenshot({ path: '/home/claude/cm/s_volta.png' });
    await prof.click('#trModo button[data-v="corrida"]').catch(e => console.log('sem trModo visível', e.message.slice(0, 80)));
  }
  await prof.click('#createRoomBtn').catch(e => console.log('createRoom', e.message.slice(0, 80)));
  await prof.waitForTimeout(800);
  const s2 = (await prof.textContent('#roomCodeDisplay')).trim();
  const b1 = await entra('Beto', s2), b2 = await entra('Caio', s2);
  await prof.waitForTimeout(500);
  await prof.click('#startGameBtn'); await prof.waitForTimeout(2500);
  console.log('corrida: classe', await prof.evaluate(() => document.body.className), 'dur', await prof.evaluate(() => app.host.matchDurationMs), 'pista visível', await prof.evaluate(() => { const e = document.querySelector('#hostGame .hg-players'); return e ? getComputedStyle(e).display : 'sem'; }));
  await prof.screenshot({ path: '/home/claude/cm/s_corrida.png' });
  await prof.waitForTimeout(2500);
  await prof.reload(); await prof.waitForTimeout(1500);
  const bts = await prof.$$eval('button', b => b.filter(x => x.offsetParent).map(x => x.textContent.trim()).slice(0, 12));
  console.log('botões após reload:', bts.join(' | '));
  await prof.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /Retomar/.test(x.textContent) && x.offsetParent); if(b) b.click(); });
  await prof.waitForTimeout(2000);
  console.log('retomada: lanes', await prof.$$eval('#hPlayers .race-lane', x => x.length), 'classe', await prof.evaluate(() => document.body.className));
  await prof.screenshot({ path: '/home/claude/cm/s_retomada.png' });
  console.log('erros', log);
  await b.close();
})();
