const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const vc=new VirtualConsole();
const html=fs.readFileSync('../orig.html','utf8');
const d=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const w=d.window;
const tipos=Object.keys(w.eval('TYPE_LABELS'));
for(const t of tipos){ let c=0,ex=''; for(let n=1;n<=5;n++){ for(let k=0;k<10;k++){ try{const q=w.eval(`generateQuestion({allowed:null},${n},'${t}')`); if(q.image){c++; ex=q.text.slice(0,70);} }catch(e){} } } console.log(t, c+'/50', ex); }
