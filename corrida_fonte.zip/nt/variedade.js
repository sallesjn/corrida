const {JSDOM,VirtualConsole}=require('jsdom');const fs=require('fs');
const d=new JSDOM(fs.readFileSync(process.argv[2],'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:new VirtualConsole(),url:'http://localhost/x.html',beforeParse(w){w.mqtt={connect(){return {on(){},subscribe(){},publish(){},end(){},connected:false}}};}});
const T=d.window.eval('TRILHA');
const pAc = f => { const a=T.POR_ID[f.id].ano; return Math.random() < [0,.9,.88,.85,.8,.75,.7,.65][a]; };   // aluno mediano
let runs=[], topShare=[], doms=[];
for(let s=0;s<30;s++){
  const rec=T.novoRegistro('x'); T.iniciar(rec,{diag:'inicio',ano:1});
  const ids=[];
  for(let k=0;k<900;k++){ const f=T.escolherFonte(rec); const q=T.gerarQuestao(f.id,f.nivel); const ok=pAc(f); T.registrar(rec,f,q,ok?q.correct:(q.correct+1)%4,ok,0.3); ids.push(f.id); }
  let mx=1,r=1; for(let i=1;i<ids.length;i++){ r = ids[i]===ids[i-1]? r+1:1; mx=Math.max(mx,r);} runs.push(mx);
  for(let i=0;i+20<=ids.length;i+=20){ const c={}; ids.slice(i,i+20).forEach(x=>c[x]=(c[x]||0)+1); topShare.push(Math.max(...Object.values(c))); }
  doms.push(Object.values(rec.deg).filter(x=>x.dom).length);
}
const med=a=>a.slice().sort((x,y)=>x-y)[Math.floor(a.length/2)];
console.log(process.argv[2].split('/').pop(), '| maior sequência igual (mediana/pior):', med(runs), '/', Math.max(...runs), '| em cada 20 perguntas, a atividade que mais aparece (média):', (topShare.reduce((a,b)=>a+b,0)/topShare.length).toFixed(1), '| degraus dominados em 900 respostas (mediana):', med(doms));
process.exit(0);
