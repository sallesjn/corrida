
/* =========================================================================
   TRILHA POR TEMA (acrescentado)
   O professor escolhe um tema (ex.: Frações) e a trilha passa a andar só
   pelas atividades daquele assunto, do 1º ao 9º ano, na ordem de subida.
   · Cada aluno tem um "marcador" próprio dentro de cada tema; o marcador da
     trilha normal fica guardado e volta quando o tema é desligado.
   · O que for dominado no tema vale para a trilha normal (e vice‑versa).
   · Começo no tema: o primeiro degrau do tema ainda não dominado, a partir
     de 1 ano antes do ano da turma; se o aluno travar, o apoio volta para o
     degrau anterior do MESMO tema.
   · Revisão, prévia e desafios também ficam dentro do tema.
   · O tema vai junto com o arquivo da turma (dentro dos ajustes).
   Funções originais intactas: só embrulhos (aplicarAjustes, registrar,
   getNextQuestion, app.pub, playerReceiveState, situacaoAluno, montarCartao).
========================================================================= */
const TEMAS = {
  sistema: ['🔢 Sistema de numeração', 'contar100 cont20 seq20 dezenas centenas saltos abaco reta3 p4_valor decimos4 numGrandes5 arredonda romanos6'],
  adsub: ['➕ Adição e subtração', 'soma10 sub10 faz10 soma20 sub20 soma100 sub100 probTexto2 p3_soma p3_sub p3_termo troco3 dinheiro probTexto3 propriedades4 inversa4'],
  multdiv: ['✖️ Multiplicação e divisão', 'grupos1 dobro vezes2 disposicao p3_tab pratos divResto p3_dobro p4_tab p4_div restos4 propriedades4 inversa4 probTexto4 p5_termo partilha5 primos p6_mmc p6_expr'],
  fracoes: ['🍕 Frações', 'dobro pratos p3_dobro partes pizza fracfig fracReta4 p5_fracao fracMista5 fracEquiv fracLacuna fracCompara fracQtd somaFrac p6_equiv p6_retaRac racNeg7 opsRac7 razao7 probRac8'],
  decimais: ['💰 Decimais e dinheiro', 'cedulas dinheiro troco3 centavos trocoDesc4 decimos4 decReta notaFiscal5 decCompara6 decOps6 p6_equiv p6_retaRac racNeg7 opsRac7 probRac8'],
  porc: ['💯 Porcentagem e proporção', 'porcMalha trocoDesc4 propTabela5 partilha5 p6_equiv p6_porc partilha6 escala6 razao7 p7_desc p7_prop inversa7 p7_receita urna7 porc8 propTipo8 regra3_8 porcSuc9 razao9 escala9'],
  inteiros: ['🌡️ Números negativos', 'termometro graficoTemp4 p7_reta tempCidades opostoModulo p7_int variacaoTemp elevador p7_extrato p7_piramide racNeg7 opsRac7'],
  potencias: ['² Potências e raízes', 'p6_potencia p6_expr pot8 raiz8 pot9 cient9 irrac9'],
  algebra: ['🔤 Álgebra e equações', 'padrao saltos p3_termo igualdade3 igualdade4 p5_termo fluxograma6 balanca6 p7_balanca p7_valorNum p7_traduzir p7_seq equivExpr7 p7_equacao seq8 alg8 retaEq8 sistema8 eq2_8 prodNot9 fator9 eq2g9 funcao9'],
  angulos: ['📐 Ângulos e retas', 'anguloReto4 pontoReta4 tiposAng6 abreAng6 transferidor giro6 paralPerp6 p7_ang p7_paral p7_triang p7_poligono geo8 paral9 circ9'],
  figuras: ['🔺 Figuras planas', 'formas figPlanas3 congruente3 simetria4 ampliacao poligonos triangulos quadrilateros p7_existe rigidez7 rotacao7 circunf7 quadProp8 tales9 semelh9 pitag9'],
  espacial: ['🧊 Sólidos e vistas', 'solidos planif3 faces cubinhos vistas5 prismas6 vistas6 vistas9'],
  coord: ['🗺️ Localização e coordenadas', 'setas2 mapa2 plano vertices6 p6_coord transf7 retaEq8'],
  medidas: ['📏 Medidas', 'compara1 regua medidas2 reguaMm jarra balancaKg instrumento3 conversao5 p7_conversao volume7 vol8 volPC9 razao9'],
  tempo: ['⏰ Tempo e calendário', 'semana relDigital relogio calendario2 duracao horasDig4'],
  area: ['⬛ Área e perímetro', 'areaComp3 areaMalha perimMalha perimArea5 quadAmplia6 escala6 p6_areaFig p7_circ area8 volPC9'],
  graficos: ['📊 Gráficos e tabelas', 'pictograma colunas tabelaDupla barras graficoTemp4 propTabela5 graficoLinha5 graficoDuplo6 p7_media p7_setores censo7 classes8 grafAdeq8 medidas8 graf9'],
  prob: ['🎲 Probabilidade e contagem', 'acaso1 provavel2 resultados3 contagem roleta4 chance potes cardapio dado urna7 doisDados contagem8 prob8 prob9'],
};
Object.keys(TEMAS).forEach(k => { TEMAS[k] = { nome: TEMAS[k][0], ids: new Set(TEMAS[k][1].split(/\s+/).filter(id => POR_ID[id])) }; });
const temaProf = () => { const t = estado.cfg.aj && estado.cfg.aj.tema; return t && TEMAS[t] ? t : null; };

/* aluno: tira da trilha o que não é do tema (só enquanto o tema vale) */
const aplicarAjustesSemTema = aplicarAjustes;
aplicarAjustes = function(aj){
  const r = aplicarAjustesSemTema.apply(this, arguments);
  const t = estado.temaAluno;
  if(t && TEMAS[t]) CAT.forEach(d => { if(!TEMAS[t].ids.has(d.id)) d.off = true; });
  return r;
};
/* troca o marcador do aluno: normal ↔ tema */
function entraTema(rec, t, anoTurma){
  const sv = { atual: rec.atual, diag: rec.diag };
  const tm = rec.temaAt || (rec.temaAt = {});
  let at = tm[t] && POR_ID[tm[t]] ? tm[t] : null;
  if(!at){
    const lista = CAT.filter(d => ativo(d) && TEMAS[t].ids.has(d.id));
    const livre = d => !(rec.deg[d.id] && rec.deg[d.id].dom);
    const ini = lista.find(d => livre(d) && d.ano >= Math.max(1, (anoTurma || 1) - 1)) || lista.find(livre);
    at = ini ? ini.id : null;
    if(at) degDo(rec, at);
  }
  rec.atual = at; rec.diag = 'pulado';
  return sv;
}
function saiTema(rec, t, sv){ (rec.temaAt || (rec.temaAt = {}))[t] = rec.atual; rec.temaInfo = { t, id: rec.atual }; rec.atual = sv.atual; rec.diag = sv.diag; }

const registrarSemTema = registrar;
registrar = function(rec, fonte){
  const t = estado.temaEmUso;
  if(!t || !rec || !TEMAS[t] || rec.plano) return registrarSemTema.apply(this, arguments);
  const sv = entraTema(rec, t, estado.temaAno);
  try{ return registrarSemTema.apply(this, arguments); } finally { saiTema(rec, t, sv); }
};

if(typeof window !== 'undefined') (() => {
  /* professor: escolher o tema no cartão da Trilha */
  const ajusta = () => {
    const ref = $('trFocoBox') || $('trOpts'); if(!ref || $('trTemaBox')) return;
    const b = document.createElement('div'); b.id = 'trTemaBox';
    b.style.cssText = 'margin-bottom:14px;padding:12px;border:2px solid #a855f7;border-radius:14px;background:rgba(168,85,247,.08)';
    const t = temaProf();
    b.innerHTML = `<label>📚 Trilha por tema (só o assunto que quero trabalhar)</label>
      <select id="trTema" style="width:100%;font-weight:800;margin-top:6px"><option value="">Todos os temas (trilha normal)</option>${Object.entries(TEMAS).map(([k, v]) => `<option value="${k}" ${k === t ? 'selected' : ''}>${v.nome} (${v.ids.size} atividades)</option>`).join('')}</select>
      <div id="trTemaInfo" style="color:var(--muted);font-size:12px;margin-top:6px"></div>`;
    if(ref.id === 'trFocoBox') ref.after(b); else ref.prepend(b);
    const info = () => { const k = temaProf(); $('trTemaInfo').innerHTML = k ? `Os alunos vão andar só por: ${[...TEMAS[k].ids].map(id => `${POR_ID[id].ano}º ${esc(POR_ID[id].nome)}`).join(' · ')}. O progresso vale para a trilha normal.` : 'Cada aluno segue a trilha completa, do degrau em que está.'; };
    info();
    $('trTema').onchange = e => {
      const aj = estado.cfg.aj || (estado.cfg.aj = { off: [], anos: {} });
      if(e.target.value) aj.tema = e.target.value; else delete aj.tema;
      salvarCfg(); info();
      try{ if(app.room && app.mode === 'teacher') app.broadcastState(); }catch(err){}
      app.toast(e.target.value ? `📚 Trilha por tema: <b>${esc(TEMAS[e.target.value].nome)}</b>` : '📚 Trilha normal (todos os temas)', 'success');
    };
  };
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); ajusta(); return r; };
  ajusta();

  /* professor → aluno: o tema vai com o estado da sala */
  const pub0 = app.pub;
  app.pub = function(topic, obj, retain){
    if(this.mode === 'teacher' && obj && obj.type === 'state' && /\/tostate$/.test(topic)) obj = Object.assign({}, obj, { tema: estado.cfg.on ? temaProf() : null, temaAno: estado.cfg.ano || 1 });
    return pub0.call(this, topic, obj, retain);
  };
  const playerReceiveState0 = app.playerReceiveState;
  app.playerReceiveState = function(state){ estado.temaSala = state && state.tema && TEMAS[state.tema] ? state.tema : null; estado.temaAnoSala = state && state.temaAno; return playerReceiveState0.apply(this, arguments); };

  /* aluno: escolhe a pergunta dentro do tema */
  const getNextQuestion0 = app.getNextQuestion;
  app.getNextQuestion = function(){
    const pt = this.player && this.player.trilha, t = this.mode !== 'teacher' ? estado.temaSala : null;
    const rec = pt && pt.rec;
    if(estado.temaAluno !== (t && rec && !rec.plano ? t : null)){ estado.temaAluno = t && rec && !rec.plano ? t : null; estado.ajAluno = null; }   // força reaplicar os ajustes
    if(!t || !pt || !pt.on || !rec || rec.plano){ estado.temaEmUso = null; return getNextQuestion0.apply(this, arguments); }
    estado.temaEmUso = t; estado.temaAno = estado.temaAnoSala || (pt.cfg && pt.cfg.ano) || 1;
    // aplica já o filtro do tema antes de entrar (o embrulho de baixo pode não reaplicar)
    const sv = entraTema(rec, t, estado.temaAno);
    try{ return getNextQuestion0.apply(this, arguments); } finally { saiTema(rec, t, sv); }
  };

  /* professor: o cartão do aluno mostra o degrau dentro do tema */
  const situacaoAluno0 = situacaoAluno;
  situacaoAluno = function(p){
    const s = situacaoAluno0.apply(this, arguments);
    const t = temaProf(), r = estado.turma.alunos[normNome(p.name)];
    if(t && r && r.temaAt && r.temaAt[t] && POR_ID[r.temaAt[t]]){ const d = r.deg[r.temaAt[t]]; s.at = POR_ID[r.temaAt[t]]; s.nivel = d ? ['', 'fácil', 'médio', 'difícil'][d.n] : ''; }
    return s;
  };
})();
