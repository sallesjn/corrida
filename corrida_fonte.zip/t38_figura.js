/* =========================================================================
   GRÁFICO DO PLANO CARTESIANO MAIOR NA TELA DO ALUNO (Chromebook deitado)
   · Nas perguntas de par ordenado / plano cartesiano o gráfico é quadrado e
     ficava limitado pela altura (≈160 px num Chromebook) e as alternativas
     ficavam abaixo da dobra.
   · Agora, só nessas perguntas e só em tela larga deitada (≥ 1000 px), o gráfico
     vai para uma coluna à esquerda, ocupando quase toda a altura da tela (≈465 px num Chromebook), e a
     pergunta + alternativas ficam à direita. Celular em pé: nada muda.
   Bloco novo: wrapper de app.renderPlayerQuestion (por fora dos outros) e CSS.
========================================================================= */
if(typeof window !== 'undefined') (() => {
  const LARGA = window.matchMedia ? window.matchMedia('(min-width:1000px) and (orientation:landscape)') : { matches: false };
  const IDS_PLANO = new Set(['plano', 'p6_coord', 'vertices6', 'transf7', 'retaEq8', 'funcao9']);
  const st = document.createElement('style');
  st.textContent = `
  @media (min-width:1000px) and (orientation:landscape){
    #playerPlay.tr-lado{display:grid;grid-template-columns:auto minmax(0,1fr);column-gap:18px;row-gap:12px;max-width:min(1240px,96vw);align-content:start}
    #playerPlay.tr-lado>*{grid-column:1/-1}
    #playerPlay.tr-lado>#ppQImage{grid-column:1;grid-row:span 3;align-self:start;height:calc(100vh - 160px);max-height:640px;min-height:220px;width:auto;max-width:48vw;
      object-fit:contain;background:#fff;border-radius:14px;box-shadow:0 4px 16px rgba(0,0,0,.5)}
    #playerPlay.tr-lado>#ppQuestionCard,#playerPlay.tr-lado>#ppOptions,#playerPlay.tr-lado>.pp-stats{grid-column:2}
  }`;
  document.head.appendChild(st);

  function ehPlano(q){
    if(!q || !q.image) return false;
    if(q.trilha && IDS_PLANO.has(q.trilha.id)) return true;
    return q.type === 'coordenadas';                              // jogo normal (fora da trilha)
  }
  function arrumar(q){
    const pp = $('playerPlay'), img = $('ppQImage'), card = $('ppQuestionCard'), txt = $('ppQuestion');
    if(!pp || !img || !card) return;
    const lado = LARGA.matches && ehPlano(q) && !img.classList.contains('hidden');
    if(lado){
      if(img.parentElement !== pp) pp.insertBefore(img, card);   // figura vira a coluna da esquerda
    } else if(img.parentElement !== card){
      card.insertBefore(img, txt && txt.parentElement === card ? txt : card.firstChild);   // volta ao lugar de sempre
    }
    pp.classList.toggle('tr-lado', lado);
  }
  const render0 = app.renderPlayerQuestion;
  app.renderPlayerQuestion = function(q){
    const r = render0.apply(this, arguments);
    try{ arrumar(q); }catch(e){}
    return r;
  };
  const reav = () => { try{ arrumar(app.player && app.player.currentQuestion); }catch(e){} };
  if(LARGA.addEventListener) LARGA.addEventListener('change', reav); else if(LARGA.addListener) LARGA.addListener(reav);   // girou a tela
  estado.arrumarFigura = arrumar;
})();
