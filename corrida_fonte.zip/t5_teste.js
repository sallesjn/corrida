
/* =========================================================================
   TESTE — rode testarTrilha() no console (padrão: 3000 por degrau e nível)
   Confere: 4 alternativas distintas, nenhuma errada igual/equivalente à certa,
   índice e texto da certa, resposta recalculada por outro caminho (conferir),
   erro típico em toda alternativa errada, figura válida, sem NaN/undefined.
   Depois simula alunos para testar o motor (domínio, trava, diagnóstico).
========================================================================= */
function valorNum(s){
  const t = String(s).replace(/R\$\s*/, '').replace(/\s*(cm|°)$/, '').replace(/−/g, '-').trim();
  if(/^-?\d+(\.\d{3})*(,\d+)?$/.test(t)) return +t.replace(/\./g, '').replace(',', '.');
  if(/^-?\d+\/\d+$/.test(t)){ const [a, b] = t.split('/').map(Number); return a / b; }
  if(/^\d{1,2}:\d{2}$/.test(t)){ const [h, m] = t.split(':').map(Number); return h * 60 + m; }
  return null;
}
function problemaDa(q, id){
  if(!q || !Array.isArray(q.options)) return 'sem alternativas';
  if(q.options.length !== 4) return `tem ${q.options.length} alternativas`;
  if(q.correct < 0 || q.correct > 3) return 'índice da correta inválido';
  const norm = q.options.map(o => String(o).toLowerCase().replace(/−/g, '-').replace(/\s+/g, ' ').trim());
  if(new Set(norm).size !== 4) return 'alternativas repetidas';
  const nums = q.options.map(valorNum);
  if(nums.every(v => v !== null) && new Set(nums.map(v => v.toFixed(6))).size !== 4) return 'alternativa equivalente à certa';
  if(/NaN|undefined|Infinity|null|\[object/.test(q.text + ' ' + q.options.join(' ') + ' ' + (q.fala || ''))) return 'NaN/undefined no texto';
  if(q.image && !/^data:image\/svg\+xml/.test(q.image)) return 'imagem inválida';
  if(q.optImgs && (q.optImgs.length !== 4 || q.optImgs.some(u => !/^data:image\/svg\+xml/.test(u)))) return 'imagens das alternativas inválidas';
  if(!POR_ID[id].prov){
    if(q.options[q.correct] !== q.answer) return 'alternativa certa ≠ resposta';
    const conf = C[id](q.meta);
    if(conf !== q.answer) return `recalculo deu ${conf}, gerador deu ${q.answer}`;
    if(!Array.isArray(q.erros) || q.erros.length !== 4) return 'sem erros típicos';
    if(q.erros[q.correct] !== null) return 'certa marcada com erro';
    if(q.erros.some((e, i) => i !== q.correct && !e)) return 'errada sem erro típico';
  }
  return null;
}
function testarTrilha(qtd = 3000, soProprios = false){
  const tabela = [], exemplos = [];
  FALHAS.n = 0;
  for(const d of CAT){
    if(soProprios && d.prov) continue;
    for(let n = 1; n <= 3; n++){
      let falhas = 0; const vistos = new Set();
      for(let i = 0; i < qtd; i++){
        let q, p;
        const f0 = FALHAS.n;
        try{ q = gerarQuestao(d.id, n); p = FALHAS.n > f0 ? 'sorteio falhou: ' + FALHAS.ult : problemaDa(q, d.id); }
        catch(e){ p = 'erro: ' + e.message; }
        if(q) vistos.add(q.text + '|' + q.chave);
        if(p){ falhas++; if(exemplos.length < 25) exemplos.push({ degrau: d.id, nivel: n, problema: p, q }); }
      }
      tabela.push({ degrau: d.id, ano: d.ano, nivel: n, testadas: qtd, falhas, diferentes: vistos.size });
    }
  }
  // ---- simulação do motor ----
  const sim = [];
  const simular = (nome, pAcerto, frac, cfg, max = 3000) => {
    const rec = novoRegistro(nome); iniciar(rec, cfg);
    let bonus = 0, travou = null, diagFim = null, n = 0;
    for(; n < max; n++){
      const f = escolherFonte(rec); const q = gerarQuestao(f.id, f.nivel);
      const ok = typeof pAcerto === 'function' ? pAcerto(f, rec) : Math.random() < pAcerto;
      const idx = ok ? q.correct : (q.correct + 1) % 4;
      const ev = registrar(rec, f, q, idx, ok, frac);
      if(ev.dominou) bonus += REGRA.bonusDominio;
      if(ev.travou && !travou) travou = { resp: n + 1, ...ev.travou };
      if(ev.diagFim !== undefined && diagFim === null) diagFim = { resp: n + 1, degrau: ev.diagFim };
      if(!rec.atual && rec.diag === 'feito' && n > 50) break;
    }
    return { rec, bonus, travou, diagFim, respostas: n };
  };
  const a1 = simular('Perfeito', 1, 0.3, { diag: 'inicio', ano: 1 }, 40 * CAT.length);
  sim.push({ caso: 'acerta tudo rápido, do início', respostas: a1.respostas, dominados: CAT.filter(d => a1.rec.deg[d.id] && a1.rec.deg[d.id].dom).length, bonus: a1.bonus, ok: !a1.rec.atual });
  const a2 = simular('Lento', 1, 0.8, { diag: 'inicio', ano: 1 }, 400);
  sim.push({ caso: 'acerta tudo, mas devagar (80% do tempo)', respostas: a2.respostas, dominados: CAT.filter(d => a2.rec.deg[d.id] && a2.rec.deg[d.id].dom).length, bonus: a2.bonus, ok: a2.bonus === 0 });
  const a3 = simular('Travado', 0.2, 0.5, { diag: 'inicio', ano: 1 }, 200);
  sim.push({ caso: 'acerta 20%: deve disparar alerta', respostas: a3.respostas, alerta: a3.travou ? `${a3.travou.resp}ª resposta — ${a3.travou.motivo}; ${a3.travou.erro}` : 'NÃO', ok: !!a3.travou });
  const alvoDiag = 7;   // sabe até o degrau 7 (índice 0..6)
  const a4 = simular('Diagnóstico', f => POR_ID[f.id].i < alvoDiag, 0.3, { diag: 'saltos', ano: 2 }, 40);
  sim.push({ caso: `diagnóstico: sabe os ${alvoDiag} primeiros`, respostas: a4.diagFim ? a4.diagFim.resp : '—', começa_em: a4.diagFim ? a4.diagFim.degrau : 'não terminou', ok: !!a4.diagFim && a4.diagFim.degrau === CAT[alvoDiag].id });
  const a5 = simular('Mistura', 0.85, 0.35, { diag: 'inicio', ano: 1 }, 600);
  const fontes = { atual: 0, atual2: 0, rev: 0, previa: 0 };
  for(let i = 0; i < 4000; i++){ const f = escolherFonte(a5.rec); if(fontes[f.tipo] !== undefined) fontes[f.tipo]++; }
  sim.push({ caso: 'proporção das fontes (aluno com degraus dominados)', ...Object.fromEntries(Object.entries(fontes).map(([k, v]) => [k, Math.round(v / 40) + '%'])), ok: true });

  if(typeof console.table === 'function'){ console.table(tabela); console.table(sim); }
  const totalFalhas = tabela.reduce((s, x) => s + x.falhas, 0);
  console.log(totalFalhas ? `❌ ${totalFalhas} falhas` : '✅ Nenhuma falha nos geradores.', exemplos.length ? exemplos : '');
  return { tabela, sim, exemplos, totalFalhas };
}

/* ---------------- instalação ---------------- */
if(typeof window !== 'undefined'){
  window.testarTrilha = testarTrilha;
  try{ instalar(); }catch(e){ console.error('[Trilha] falha ao instalar', e); }
}
return { CAT, POR_ID, LIMITE, dicaDe, fracEmPe, lacunas, G, C, REGRA, gerarQuestao, novoRegistro, iniciar, escolherFonte, registrar, resumo, estado, IMG, testarTrilha, alternativas };
})();
