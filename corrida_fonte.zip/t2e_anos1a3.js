
/* =========================================================================
   LOTE 4 — o que faltava do currículo SEDU 2026: 1º ao 3º ano
========================================================================= */
const letrasABCD = ['A', 'B', 'C', 'D'];
const nomeIc = (tipo, n) => plural(tipo, n);

/* ============================ 1º ANO ============================ */

/* Grupos iguais (EF01MA23): pratos com a mesma quantidade */
G.grupos1 = n => {
  const k = n === 1 ? rnd(2, 3) : n === 2 ? rnd(2, 4) : rnd(3, 5), q = n === 1 ? rnd(2, 3) : n === 2 ? rnd(2, 5) : rnd(3, 5);
  const tipo = pick(OBJETOS);
  let o = '';
  const pw = 150;
  for(let i = 0; i < k; i++){
    const x = 10 + i * (pw + 10);
    const g = grupoIcones(tipo, q, x + (pw - Math.min(q, 3) * 42) / 2, 34, 42, 3);
    o += `<ellipse cx="${x + pw / 2}" cy="${34 + g.h / 2}" rx="${pw / 2}" ry="${g.h / 2 + 22}" fill="#e0f2fe" stroke="#0369a1" stroke-width="3"/>` + g.svg;      // as figuras ficam DENTRO do prato
  }
  const tot = k * q;
  const erradas = [{ v: k + q, erro: 'somou pratos e figuras de um prato' }, { v: q, erro: 'contou só um prato' }, { v: tot - q, erro: 'esqueceu um prato' }, { v: tot + q, erro: 'contou um prato a mais' }, { v: tot + 1, erro: 'contou uma a mais' }];
  const a = alternativas(tot, erradas, String, { min: 1 });
  return { ...a, text: `${k} pratos com ${q} ${nomeIc(tipo, q)} em cada um. Quant${genero(tipo) === 'f' ? 'as' : 'os'} ${nomeIc(tipo, 2)} ao todo?`,
    image: svgURI(SVG(k * (pw + 10) + 10, 34 + Math.ceil(q / 3) * 42 + 34, o)), meta: { k, q }, chave: `gr${k}x${q}${tipo}` };
};
C.grupos1 = m => String(m.k * m.q);

/* Posição (EF01MA11): direita, esquerda, em cima, embaixo */
G.posicao1 = n => {
  const tipos = shuffle(['maca', 'estrela', 'bola', 'flor', 'peixe', 'balao', 'banana', 'uva']).slice(0, 4);
  const vertical = n === 3 && Math.random() < .5;
  let o = '', rel, alvoI, certa;
  if(!vertical){
    tipos.forEach((t, i) => { o += ICONES[t](60 + i * 110, 65, 90); });
    o += `<line x1="10" y1="118" x2="${tipos.length * 110 + 10}" y2="118" stroke="#78350f" stroke-width="6"/>`;
    const dir = Math.random() < .5;
    alvoI = dir ? rnd(0, tipos.length - 2) : rnd(1, tipos.length - 1);
    certa = tipos[dir ? alvoI + 1 : alvoI - 1];
    rel = dir ? 'à DIREITA' : 'à ESQUERDA';
    const erradas = tipos.filter(t => t !== certa).map((t, i) => ({ v: NOME_ICONE[t][0], erro: t === tipos[dir ? alvoI - 1 : alvoI + 1] ? 'trocou direita com esquerda' : t === tipos[alvoI] ? 'escolheu o próprio objeto' : 'olhou longe demais' }));
    const a = alternativas(NOME_ICONE[certa][0], erradas, String);
    return { ...a, text: `O que está logo ${rel} do(a) ${NOME_ICONE[tipos[alvoI]][0]}?`, image: svgURI(SVG(tipos.length * 110 + 20, 130, o)), meta: { tipos, alvoI, dir, modo: 'h' }, chave: 'ph' + tipos.join('') + alvoI + dir };
  }
  // prateleira: 4 objetos empilhados em 2 andares (2 em cima, 2 embaixo)
  const pos = [[0, 0], [1, 0], [0, 1], [1, 1]];   // [coluna, andar] andar 0 = de cima
  o += `<rect x="10" y="20" width="260" height="250" fill="#fef3c7" stroke="#78350f" stroke-width="5"/><line x1="10" y1="145" x2="270" y2="145" stroke="#78350f" stroke-width="6"/>`;
  tipos.forEach((t, i) => { o += ICONES[t](80 + pos[i][0] * 120, 88 + pos[i][1] * 125, 90); });
  alvoI = rnd(0, 3); const cima = pos[alvoI][1] === 1;       // pergunta o que está em cima (ou embaixo) dele
  const iC = pos.findIndex(p => p[0] === pos[alvoI][0] && p[1] !== pos[alvoI][1]);
  certa = tipos[iC];
  const erradas = tipos.filter(t => t !== certa).map((t, i) => ({ v: NOME_ICONE[t][0], erro: t === tipos[alvoI] ? 'escolheu o próprio objeto' : 'olhou para o lado, não para cima/baixo' }));
  const a = alternativas(NOME_ICONE[certa][0], erradas, String);
  return { ...a, text: `O que está ${cima ? 'EM CIMA' : 'EMBAIXO'} do(a) ${NOME_ICONE[tipos[alvoI]][0]}, na prateleira?`, image: svgURI(SVG(280, 280, o)), meta: { tipos, alvoI, modo: 'v' }, chave: 'pv' + tipos.join('') + alvoI };
};
C.posicao1 = m => {
  if(m.modo === 'h') return NOME_ICONE[m.tipos[m.dir ? m.alvoI + 1 : m.alvoI - 1]][0];
  return NOME_ICONE[m.tipos[m.alvoI ^ 2]][0];                   // 0↔2 e 1↔3: mesma coluna, outro andar
};

/* Comparar grandezas (EF01MA15): comprido, alto, pesado */
G.compara1 = n => {
  const modo = n === 1 ? 'comprido' : n === 2 ? pick(['comprido', 'alto']) : pick(['alto', 'pesado']);
  const mais = Math.random() < .6;
  if(modo === 'pesado'){
    const [t1, t2] = shuffle(['maca', 'melancia', 'bola', 'estrela']).slice(0, 2).map(t => t === 'melancia' ? 'laranja' : t);
    const pesado = Math.random() < .5 ? 0 : 1;                 // lado mais baixo = mais pesado
    const ang = pesado === 0 ? -12 : 12;
    let o = `<polygon points="200,200 185,240 215,240" fill="#475569"/><g transform="rotate(${ang} 200 120)"><line x1="60" y1="120" x2="340" y2="120" stroke="#111" stroke-width="7"/>` +
      `<line x1="80" y1="120" x2="80" y2="150" stroke="#111" stroke-width="3"/><line x1="320" y1="120" x2="320" y2="150" stroke="#111" stroke-width="3"/></g><line x1="200" y1="120" x2="200" y2="205" stroke="#111" stroke-width="6"/>`;
    const yE = 120 + Math.sin(ang * Math.PI / 180) * -120, yD = 120 + Math.sin(ang * Math.PI / 180) * 120;
    o += `<ellipse cx="${80 + (1 - Math.cos(ang * Math.PI / 180)) * 120}" cy="${yE + 32}" rx="55" ry="10" fill="#94a3b8" stroke="#111" stroke-width="2"/><ellipse cx="${320 - (1 - Math.cos(ang * Math.PI / 180)) * 120}" cy="${yD + 32}" rx="55" ry="10" fill="#94a3b8" stroke="#111" stroke-width="2"/>`;
    o += ICONES[t1](80, yE - 5, 70) + ICONES[t2](320, yD - 5, 70);
    const nomes = [NOME_ICONE[t1][0], NOME_ICONE[t2][0]];
    const certa = mais ? nomes[pesado] : nomes[1 - pesado];
    const a = alternativas(certa, [{ v: mais ? nomes[1 - pesado] : nomes[pesado], erro: 'achou que o lado que sobe é o mais pesado' }, { v: 'Os dois pesam igual', erro: 'não olhou a inclinação' }, { v: 'Não dá para saber', erro: 'achou que não dá para saber' }], String);
    return { ...a, text: `Na balança, qual é o MAIS ${mais ? 'PESADO' : 'LEVE'}?`, image: svgURI(SVG(400, 250, o)), meta: { nomes, pesado, mais, modo }, chave: `cp${t1}${t2}${pesado}${mais}` };
  }
  const tams = sortearAte(() => [0, 1, 2, 3].map(() => rnd(3, 10)), v => new Set(v).size === 4);
  let o = '';
  if(modo === 'comprido'){
    tams.forEach((t, i) => { const y = 14 + i * 50, w = t * 42; o += T(22, y + 26, letrasABCD[i], { fs: 22 }) + `<rect x="45" y="${y + 4}" width="${w}" height="26" fill="${['#f59e0b', '#22c55e', '#3b82f6', '#ec4899'][i]}" stroke="#111" stroke-width="2.5"/><polygon points="${45 + w},${y + 4} ${45 + w + 26},${y + 17} ${45 + w},${y + 30}" fill="#fde68a" stroke="#111" stroke-width="2.5"/>`; });
    o = SVG(520, 214, o);
  } else {
    tams.forEach((t, i) => { const h = t * 22, x = 20 + i * 100; o += `<rect x="${x}" y="${250 - h}" width="70" height="${h}" fill="${['#f59e0b', '#22c55e', '#3b82f6', '#ec4899'][i]}" stroke="#111" stroke-width="2.5"/>` + T(x + 35, 280, letrasABCD[i], { fs: 22 }); for(let j = 0; j < Math.floor(h / 30); j++) o += `<rect x="${x + 14}" y="${250 - h + 10 + j * 30}" width="16" height="14" fill="#fff"/><rect x="${x + 40}" y="${250 - h + 10 + j * 30}" width="16" height="14" fill="#fff"/>`; });
    o = SVG(420, 290, `<line x1="10" y1="250" x2="410" y2="250" stroke="#111" stroke-width="3"/>` + o);
  }
  const iC = tams.indexOf(mais ? Math.max(...tams) : Math.min(...tams)), iE = tams.indexOf(mais ? Math.min(...tams) : Math.max(...tams));
  const a = alternativas(letrasABCD[iC], letrasABCD.map((l, i) => i === iC ? null : { v: l, erro: i === iE ? 'trocou maior com menor' : 'comparou errado' }), String);
  const pal = modo === 'comprido' ? (mais ? 'MAIS COMPRIDO' : 'MAIS CURTO') : (mais ? 'MAIS ALTO' : 'MAIS BAIXO');
  return { ...a, text: `Qual ${modo === 'comprido' ? 'lápis' : 'prédio'} é o ${pal}?`, image: svgURI(o), meta: { tams, mais, modo }, chave: `cc${tams.join('')}${mais}${modo}` };
};
C.compara1 = m => {
  if(m.modo === 'pesado') return m.mais ? m.nomes[m.pesado] : m.nomes[1 - m.pesado];
  let b = 0; m.tams.forEach((t, i) => { if(m.mais ? t > m.tams[b] : t < m.tams[b]) b = i; }); return 'ABCD'[b];
};

/* Acaso (EF01MA20): certeza, talvez, impossível — escolher a sacola */
function sacolasSVG(conteudos){      // conteudos = [[cores...], ...]
  let o = '';
  conteudos.forEach((cs, i) => {
    const x = 10 + i * 150;
    o += `<path d="M${x + 20} 50 L${x + 120} 50 L${x + 135} 190 Q${x + 70} 205 ${x + 5} 190 Z" fill="#fde68a" stroke="#92400e" stroke-width="3"/><path d="M${x + 45} 50 Q${x + 70} 15 ${x + 95} 50" fill="none" stroke="#92400e" stroke-width="4"/>`;
    cs.forEach((c, j) => { o += `<circle cx="${x + 42 + (j % 3) * 28}" cy="${170 - Math.floor(j / 3) * 28}" r="12" fill="${c}" stroke="#111" stroke-width="1.8"/>`; });
    o += T(x + 70, 230, 'Sacola ' + letrasABCD[i], { fs: 20 });
  });
  return SVG(conteudos.length * 150 + 10, 245, o);
}
G.acaso1 = n => {
  const [cor, hx] = pick(CORES_BOLAS), outras = CORES_BOLAS.filter(c => c[0] !== cor).map(c => c[1]);
  const q = () => rnd(3, n === 1 ? 5 : 8);
  const sacolas = shuffle([
    { tipo: 'certeza', bolas: Array(q()).fill(hx) },
    { tipo: 'impossível', bolas: [...Array(q())].map(() => pick(outras)) },
    { tipo: 'talvez', bolas: (() => { const t = q(), a = rnd(1, t - 1); return shuffle([...Array(a).fill(hx), ...[...Array(t - a)].map(() => pick(outras))]); })() }]);
  const pede = pick(['certeza', 'impossível', 'talvez']);
  const frase = { certeza: `com CERTEZA sai bola ${cor}`, 'impossível': `é IMPOSSÍVEL sair bola ${cor}`, talvez: `TALVEZ saia bola ${cor} (pode sair ou não)` }[pede];
  const iC = sacolas.findIndex(s => s.tipo === pede);
  const erradas = sacolas.map((s, i) => i === iC ? null : { v: 'Sacola ' + letrasABCD[i], erro: `confundiu "${pede}" com "${s.tipo}"` }).concat([{ v: 'Nenhuma sacola', erro: 'achou que nenhuma serve' }]);
  const a = alternativas('Sacola ' + letrasABCD[iC], erradas, String);
  return { ...a, text: `Tirando uma bola sem olhar, em qual sacola ${frase}?`, image: svgURI(sacolasSVG(sacolas.map(s => s.bolas))), meta: { sac: sacolas.map(s => s.bolas.map(b => b === hx)), pede }, chave: 'ac' + pede + sacolas.map(s => s.bolas.length).join('') };
};
C.acaso1 = m => { const i = m.sac.findIndex(s => m.pede === 'certeza' ? s.every(Boolean) : m.pede === 'impossível' ? !s.some(Boolean) : s.some(Boolean) && !s.every(Boolean)); return 'Sacola ' + 'ABCD'[i]; };

/* Relógio digital → relógio de ponteiros (EF01MA25) */
function relogioDigital(h, m, x = 10, y = 10){
  return `<rect x="${x}" y="${y}" width="220" height="100" rx="16" fill="#111827" stroke="#475569" stroke-width="5"/>` + T(x + 110, y + 72, `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`, { fs: 58, cor: '#4ade80', extra: ' font-family="monospace"' });
}
G.relDigital = n => {
  const h = rnd(1, 11), m = n === 1 ? 0 : n === 2 ? pick([0, 30]) : pick([0, 30, 15, 45]);
  const hh = n === 3 && Math.random() < .5 ? h + 12 : h;          // difícil: 15:00 também é 3 horas
  const cands = [[h, m, null], [m === 0 ? 12 : m / 5, (h % 12) * 5, 'trocou os ponteiros'], [h % 12 + 1, m, 'leu a hora seguinte'], [(h + 10) % 12 + 1, m, 'leu a hora anterior'], [h, (m + 30) % 60, 'errou os minutos'], [h, (m + 15) % 60, 'errou os minutos']]
    .filter(c => Number.isInteger(c[0]) && c[0] >= 1 && c[0] <= 12);
  const chave = c => `${c[0]}:${c[1]}`;
  const vistos = new Set(), itens = [];
  for(const c of cands){ if(itens.length < 4 && !vistos.has(chave(c)) && !(c[2] && c[0] % 12 === h % 12 && c[1] === m)){ vistos.add(chave(c)); itens.push(c); } }
  const emb = shuffle(itens);
  return { options: emb.map(c => fmtH(c[0], c[1])), correct: emb.findIndex(c => c[2] === null), erros: emb.map(c => c[2]), answer: fmtH(h, m),
    optImgs: emb.map(c => svgURI(relogio(c[0], c[1]))), text: 'Qual relógio de ponteiros mostra a mesma hora?', image: svgURI(SVG(240, 120, relogioDigital(hh, m))), meta: { h, m }, chave: `rd${hh}:${m}` };
};
C.relDigital = m => fmtH(m.h, m.m);

/* Contar até 100 com montinhos de 10 (EF01MA04) */
function palitosSVG(d, u){
  let o = '', x = 10;
  for(let i = 0; i < d; i++){
    for(let k = 0; k < 10; k++) o += `<rect x="${x + k * 6}" y="14" width="4" height="84" rx="2" fill="#f59e0b" stroke="#92400e" stroke-width="1"/>`;
    o += `<rect x="${x - 3}" y="48" width="66" height="12" rx="4" fill="#dc2626"/>`;
    x += 80;
  }
  x += 10;
  for(let k = 0; k < u; k++) o += `<rect x="${x + k * 14}" y="14" width="5" height="84" rx="2" fill="#f59e0b" stroke="#92400e" stroke-width="1"/>`;
  return SVG(x + u * 14 + 20, 112, o);
}
G.contar100 = n => {
  const d = n === 1 ? rnd(1, 4) : n === 2 ? rnd(3, 7) : rnd(5, 9), u = rnd(n === 3 ? 0 : 1, 9);
  const t = d * 10 + u;
  const erradas = [{ v: d + u, erro: 'contou cada montinho como 1' }, { v: u * 10 + d, erro: 'trocou dezenas e unidades' }, { v: t + 10, erro: 'contou um montinho a mais' }, { v: t - 10, erro: 'contou um montinho a menos' }, { v: t + 1, erro: 'contou um palito a mais' }];
  const a = alternativas(t, erradas, String, { min: 1, max: 100 });
  return { ...a, text: 'Cada montinho amarrado tem 10 palitos. Quantos palitos ao todo?', image: svgURI(palitosSVG(d, u)), meta: { d, u }, chave: `ct${d}.${u}` };
};
C.contar100 = m => String(m.d * 10 + m.u);

/* ============================ 2º ANO ============================ */

/* Multiplicação por 2, 3, 4, 5 e 10 e repartição (EF02MA24) */
G.vezes2 = n => {
  const f = pick(n === 1 ? [2, 3] : n === 2 ? [2, 3, 4, 5] : [2, 3, 4, 5, 10]), k = rnd(2, n === 1 ? 4 : 5), tipo = pick(OBJETOS);
  const reparte = n === 3 && Math.random() < .5;
  let o = '', x = 10;
  for(let i = 0; i < k; i++){ const g = grupoIcones(tipo, f, x + 6, 16, 30, f === 10 ? 5 : Math.min(f, 3)); o += `<rect x="${x}" y="8" width="${g.w + 12}" height="${g.h + 16}" rx="10" fill="#f1f5f9" stroke="#64748b" stroke-width="2.5" stroke-dasharray="${reparte ? '6,4' : '0'}"/>` + g.svg; x += g.w + 24; }
  const tot = f * k;
  if(reparte){
    const erradas = [{ v: tot, erro: 'respondeu o total' }, { v: tot - k, erro: 'tirou em vez de repartir' }, { v: f + 1, erro: 'um a mais' }, { v: f - 1, erro: 'um a menos' }, { v: k, erro: 'respondeu o número de crianças' }];
    const a = alternativas(f, erradas, String, { min: 1 });
    return { ...a, text: `${tot} ${nomeIc(tipo, 2)} repartid${genero(tipo) === 'f' ? 'as' : 'os'} igualmente entre ${k} crianças. Quant${genero(tipo) === 'f' ? 'as' : 'os'} para cada uma?`, image: svgURI(SVG(x, Math.ceil(f / (f === 10 ? 5 : Math.min(f, 3))) * 30 + 30, o)), meta: { f, k, reparte }, chave: `v2r${tot}/${k}` };
  }
  const erradas = [{ v: f + k, erro: 'somou em vez de multiplicar' }, { v: tot + f, erro: 'contou um grupo a mais' }, { v: tot - f, erro: 'contou um grupo a menos' }, { v: tot + 1, erro: 'contou um a mais' }];
  const a = alternativas(tot, erradas, String, { min: 1 });
  return { ...a, text: `${k} × ${f} = ?  (${k} grupos de ${f})`, image: svgURI(SVG(x, Math.ceil(f / (f === 10 ? 5 : Math.min(f, 3))) * 30 + 30, o)), meta: { f, k, reparte }, chave: `v2${k}x${f}` };
};
C.vezes2 = m => String(m.reparte ? m.f : m.f * m.k);

/* Caminho na malha com setas (EF02MA12) */
G.setas2 = n => {
  const L = 6, passos = n === 1 ? 2 : n === 2 ? 3 : 4;
  const D = { '→': [1, 0], '←': [-1, 0], '↑': [0, -1], '↓': [0, 1] };
  let ini, mov, fim;
  for(let t = 0; t < 5000; t++){                  // sorteia até o caminho caber na malha (nunca sai dela)
    ini = [rnd(0, L - 1), rnd(0, L - 1)]; mov = [...Array(passos)].map(() => [pick(Object.keys(D)), rnd(1, 3)]);
    let p = [...ini], dentro = true; for(const [s, q] of mov){ p = [p[0] + D[s][0] * q, p[1] + D[s][1] * q]; if(p.some(v => v < 0 || v >= L)) dentro = false; }
    fim = p; if(dentro && (fim[0] !== ini[0] || fim[1] !== ini[1])) break;
  }
  // alternativas: células marcadas com letras (certa + erros típicos)
  const inv = { '→': '←', '←': '→', '↑': '↓', '↓': '↑' };
  const andar = (ms) => { let p = [...ini]; for(const [s, q] of ms){ p = [p[0] + D[s][0] * q, p[1] + D[s][1] * q]; } return p; };
  const cands = [[fim, null], [andar(mov.map(([s, q]) => [s === '→' || s === '←' ? inv[s] : s, q])), 'trocou direita com esquerda'], [andar(mov.map(([s, q]) => [s === '↑' || s === '↓' ? inv[s] : s, q])), 'trocou para cima com para baixo'],
    [andar(mov.map(([s, q], i) => [s, i === mov.length - 1 ? q + 1 : q])), 'andou uma casa a mais'], [andar(mov.map(([s, q], i) => [s, i === 0 ? q - 1 : q])), 'andou uma casa a menos'], [andar(mov.slice(0, -1)), 'esqueceu o último passo']];
  const ok = p => p.every(v => v >= 0 && v < L) && !(p[0] === ini[0] && p[1] === ini[1]);
  const vistos = new Set(), itens = [];
  cands.forEach(([p, e]) => { const k = p.join(','); if(itens.length < 4 && ok(p) && !vistos.has(k)){ vistos.add(k); itens.push([p, e]); } });
  for(let y = 0; itens.length < 4 && y < L; y++) for(let x = 0; itens.length < 4 && x < L; x++){ const k = x + ',' + y; if(!vistos.has(k) && !(x === ini[0] && y === ini[1])){ vistos.add(k); itens.push([[x, y], 'andou errado']); } }
  const emb = shuffle(itens);
  const s = 54, x0 = 20, y0 = 20;
  let o = '';
  for(let y = 0; y < L; y++) for(let x = 0; x < L; x++) o += `<rect x="${x0 + x * s}" y="${y0 + y * s}" width="${s}" height="${s}" fill="#fff" stroke="#94a3b8" stroke-width="1.5"/>`;
  o += `<circle cx="${x0 + ini[0] * s + s / 2}" cy="${y0 + ini[1] * s + s / 2}" r="${s * .36}" fill="#f59e0b" stroke="#111" stroke-width="2"/>` + T(x0 + ini[0] * s + s / 2, y0 + ini[1] * s + s / 2 + 8, '★', { fs: 24 });
  emb.forEach(([p], i) => { o += T(x0 + p[0] * s + s / 2, y0 + p[1] * s + s / 2 + 11, letrasABCD[i], { fs: 32, cor: '#1d4ed8' }); });
  const inst = mov.map(([sm, q]) => `${q} ${sm}`).join('  ');
  o += `<rect x="${x0 + L * s + 16}" y="${y0}" width="150" height="${L * s}" rx="10" fill="#f1f5f9" stroke="#64748b" stroke-width="2"/>`;
  mov.forEach(([sm, q], i) => { o += T(x0 + L * s + 91, y0 + 50 + i * 60, `${q} ${sm}`, { fs: 34 }); });
  return { options: emb.map((_, i) => letrasABCD[i]), correct: emb.findIndex(c => c[1] === null), erros: emb.map(c => c[1]), answer: letrasABCD[emb.findIndex(c => c[1] === null)],
    text: `Saindo da estrela ★ e seguindo as setas (${inst}), onde você chega?`, image: svgURI(SVG(x0 + L * s + 186, y0 + L * s + 20, o)), meta: { ini, mov, pts: emb.map(c => c[0]) }, chave: 'st' + ini.join(',') + inst };
};
C.setas2 = m => { const D = { '→': [1, 0], '←': [-1, 0], '↑': [0, -1], '↓': [0, 1] }; let p = [...m.ini]; m.mov.forEach(([s, q]) => { p = [p[0] + D[s][0] * q, p[1] + D[s][1] * q]; }); return 'ABCD'[m.pts.findIndex(x => x[0] === p[0] && x[1] === p[1])]; };

/* Unidade de medida certa (EF02MA17) */
const MEDIR = [
  ['o suco da jarra', 'litro'], ['a água do balde', 'litro'], ['o leite da caixa', 'litro'], ['a gasolina do carro', 'litro'],
  ['o peso de um saco de arroz', 'quilograma'], ['o peso de uma melancia', 'quilograma'], ['o peso de uma pessoa', 'quilograma'], ['o peso de um cachorro', 'quilograma'],
  ['o comprimento da sala', 'metro'], ['a altura da porta', 'metro'], ['o comprimento de uma corda', 'metro'], ['a altura de uma árvore', 'metro'],
  ['o tempo do recreio', 'minuto'], ['o tempo de escovar os dentes', 'minuto'], ['o tempo de uma música', 'minuto'],
];
G.medidas2 = n => {
  const [coisa, un] = pick(MEDIR);
  const unidades = n === 1 ? ['litro', 'quilograma', 'metro', 'minuto'] : n === 2 ? ['litro', 'quilograma', 'metro', 'minuto', 'centímetro', 'grama'] : ['litro', 'mililitro', 'quilograma', 'grama', 'metro', 'centímetro', 'minuto', 'hora'];
  const confunde = { litro: 'quilograma', quilograma: 'litro', metro: 'centímetro', minuto: 'hora' };
  const erradas = unidades.filter(u => u !== un).map(u => ({ v: u, erro: u === confunde[un] ? 'confundiu as grandezas' : 'escolheu uma grandeza que não serve' }));
  const esc = shuffle(erradas);
  esc.sort((a, b) => (b.erro === 'confundiu as grandezas') - (a.erro === 'confundiu as grandezas'));
  const a = alternativas(un, esc.slice(0, 3), String);
  return { ...a, text: `Qual unidade é a melhor para medir ${coisa}?`, meta: { coisa }, chave: 'md' + coisa + n };
};
C.medidas2 = m => MEDIR.find(x => x[0] === m.coisa)[1];

/* Calendário (EF02MA18) */
function calendarioSVG(mes, diaSemana1, dias, marcas){
  const s = 56, x0 = 10, y0 = 60;
  let o = `<rect x="${x0}" y="10" width="${7 * s}" height="44" fill="#1d4ed8"/>` + T(x0 + 3.5 * s, 42, MESES[mes].toUpperCase(), { fs: 24, cor: '#fff' });
  ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].forEach((d, i) => { o += T(x0 + i * s + s / 2, y0 + 20, d, { fs: 18, cor: i === 0 ? '#dc2626' : '#111' }); });
  for(let d = 1; d <= dias; d++){
    const pos = diaSemana1 + d - 1, c = pos % 7, l = Math.floor(pos / 7);
    const x = x0 + c * s, y = y0 + 30 + l * 46;
    o += `<rect x="${x}" y="${y}" width="${s}" height="46" fill="${marcas[d] || '#fff'}" stroke="#94a3b8" stroke-width="1.2"/>` + T(x + s / 2, y + 31, d, { fs: 20, cor: c === 0 ? '#dc2626' : '#111', fw: marcas[d] ? 'bold' : 'normal' });
  }
  const linhas = Math.ceil((diaSemana1 + dias) / 7);
  return SVG(7 * s + 20, y0 + 30 + linhas * 46 + 10, o);
}
G.calendario2 = n => {
  const mes = rnd(0, 11), dias = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mes], d1 = rnd(0, 6);
  const hoje = rnd(1, dias - 8);
  if(n === 1){
    const k = rnd(1, 7);
    const alvo = hoje + k; const ds = (d1 + alvo - 1) % 7;
    const erradas = [{ v: DIAS[(ds + 1) % 7], erro: 'contou um dia a mais' }, { v: DIAS[(ds + 6) % 7], erro: 'contou um dia a menos' }, { v: DIAS[(d1 + hoje - 1) % 7], erro: 'repetiu o dia de hoje' }, { v: DIAS[(ds + 2) % 7], erro: 'contou errado' }];
    const a = alternativas(DIAS[ds], erradas, String);
    return { ...a, text: `Que dia da semana será o dia ${alvo}?`, image: svgURI(calendarioSVG(mes, d1, dias, { [alvo]: '#fde68a' })), meta: { d1, alvo, modo: 'dia' }, chave: `ca${mes}.${d1}.${alvo}` };
  }
  const alvo = hoje + (n === 2 ? rnd(3, 9) : rnd(8, Math.min(20, dias - hoje)));
  const k = alvo - hoje;
  const erradas = [{ v: k + 1, erro: 'contou o dia de hoje também' }, { v: k - 1, erro: 'contou um dia a menos' }, { v: alvo, erro: 'respondeu o dia do mês' }, { v: k + 7, erro: 'contou uma semana a mais' }];
  const a = alternativas(k, erradas, String, { min: 1 });
  return { ...a, text: `Hoje é dia ${hoje} (em verde). A festa é no dia ${alvo} (em amarelo). Quantos dias faltam?`, image: svgURI(calendarioSVG(mes, d1, dias, { [hoje]: '#bbf7d0', [alvo]: '#fde68a' })), meta: { hoje, alvo, modo: 'falta' }, chave: `cf${mes}.${hoje}.${alvo}` };
};
C.calendario2 = m => m.modo === 'dia' ? DIAS[(m.d1 + m.alvo - 1) % 7] : String(m.alvo - m.hoje);

/* Roleta: muito provável, pouco provável, impossível, certeza (EF02MA21) */
function roletaSVG(cores){           // cores = lista de cores dos setores
  const cx = 150, cy = 150, R = 130, n = cores.length;
  let o = '';
  cores.forEach((c, i) => { const a0 = (-90 + 360 / n * i) * Math.PI / 180, a1 = (-90 + 360 / n * (i + 1)) * Math.PI / 180;
    o += n === 1 ? `<circle cx="${cx}" cy="${cy}" r="${R}" fill="${c}" stroke="#111" stroke-width="3"/>` : `<path d="M${cx} ${cy} L${(cx + R * Math.cos(a0)).toFixed(1)} ${(cy + R * Math.sin(a0)).toFixed(1)} A${R} ${R} 0 ${360 / n > 180 ? 1 : 0} 1 ${(cx + R * Math.cos(a1)).toFixed(1)} ${(cy + R * Math.sin(a1)).toFixed(1)} Z" fill="${c}" stroke="#111" stroke-width="3"/>`; });
  o += `<circle cx="${cx}" cy="${cy}" r="10" fill="#111"/><polygon points="${cx - 12},6 ${cx + 12},6 ${cx},34" fill="#111"/>`;
  return SVG(300, 300, o);
}
const COR_ROL = [['vermelho', '#ef4444'], ['azul', '#3b82f6'], ['verde', '#22c55e'], ['amarelo', '#facc15']];
G.provavel2 = n => {
  const tot = pick(n === 1 ? [4, 6] : [6, 8, 10]);
  const [cn, ch] = pick(COR_ROL), outras = COR_ROL.filter(c => c[0] !== cn);
  const tipo = pick(n === 1 ? ['muito provável', 'pouco provável', 'impossível', 'certeza'] : ['muito provável', 'pouco provável', 'impossível', 'muito provável', 'pouco provável', 'certeza']);
  const k = tipo === 'certeza' ? tot : tipo === 'impossível' ? 0 : tipo === 'muito provável' ? rnd(Math.floor(tot / 2) + 1, tot - 1) : rnd(1, Math.ceil(tot / 2) - 1);
  const setores = shuffle([...Array(k).fill(ch), ...[...Array(tot - k)].map(() => pick(outras)[1])]);
  const conf = { 'muito provável': 'certeza', 'pouco provável': 'impossível', 'impossível': 'pouco provável', certeza: 'muito provável' };
  const a = alternativas(tipo, ['muito provável', 'pouco provável', 'impossível', 'certeza'].filter(t => t !== tipo).map(t => ({ v: t, erro: t === conf[tipo] ? `confundiu "${tipo}" com "${t}"` : 'contou errado as partes' })), String);
  return { ...a, text: `Girando a roleta, sair ${cn.toUpperCase()} é:`, image: svgURI(roletaSVG(setores)), meta: { k, tot }, chave: `pv${cn}${setores.join('')}` };
};
C.provavel2 = m => m.k === 0 ? 'impossível' : m.k === m.tot ? 'certeza' : 2 * m.k > m.tot ? 'muito provável' : 'pouco provável';

/* Tabela de dupla entrada (EF02MA22) */
function tabelaSVG(cab, linhas, destaque){
  const cw = 130, rh = 46, W = cw * cab.length + 20;
  let o = '';
  cab.forEach((c, j) => { o += `<rect x="${10 + j * cw}" y="10" width="${cw}" height="${rh}" fill="#1e40af" stroke="#111" stroke-width="1.5"/>` + T(10 + j * cw + cw / 2, 10 + 30, c, { fs: 18, cor: '#fff' }); });
  linhas.forEach((l, i) => l.forEach((c, j) => { o += `<rect x="${10 + j * cw}" y="${10 + (i + 1) * rh}" width="${cw}" height="${rh}" fill="${j === 0 ? '#dbeafe' : '#fff'}" stroke="#111" stroke-width="1.5"/>` + T(10 + j * cw + cw / 2, 10 + (i + 1) * rh + 30, c, { fs: 20, fw: j === 0 ? 'bold' : 'normal' }); }));
  return SVG(W, rh * (linhas.length + 1) + 20, o);
}
G.tabelaDupla = n => {
  const frutas = shuffle(['Maçã', 'Banana', 'Uva', 'Laranja']).slice(0, 3), turmas = n === 1 ? ['2º A', '2º B'] : ['2º A', '2º B', '2º C'];
  const v = turmas.map(() => frutas.map(() => rnd(2, 12)));
  const linhas = turmas.map((t, i) => [t, ...v[i]]);
  if(n < 3){
    const i = rnd(0, turmas.length - 1), j = rnd(0, 2);
    if(n === 1 || Math.random() < .5){
      const erradas = [{ v: v[(i + 1) % turmas.length][j], erro: 'olhou a linha errada' }, { v: v[i][(j + 1) % 3], erro: 'olhou a coluna errada' }, { v: v[i][(j + 2) % 3], erro: 'olhou a coluna errada' }, { v: v[i][j] + 1, erro: 'um a mais' }];
      const a = alternativas(v[i][j], erradas, String, { min: 0 });
      return { ...a, text: `Quantos alunos do ${turmas[i]} preferem ${frutas[j].toLowerCase()}?`, image: svgURI(tabelaSVG(['Turma', ...frutas], linhas)), meta: { v, i, j, modo: 'cel' }, chave: 'td' + v.flat().join(',') + i + j };
    }
    const s = v[i].reduce((a, b) => a + b, 0);
    const erradas = [{ v: s - v[i][0], erro: 'esqueceu uma coluna' }, { v: v.reduce((a, l) => a + l[0], 0), erro: 'somou a coluna, não a linha' }, { v: s + 1, erro: 'errou a soma' }, { v: s - 1, erro: 'errou a soma' }];
    const a = alternativas(s, erradas, String, { min: 1 });
    return { ...a, text: `Quantos alunos do ${turmas[i]} responderam ao todo?`, image: svgURI(tabelaSVG(['Turma', ...frutas], linhas)), meta: { v, i, modo: 'lin' }, chave: 'tl' + v.flat().join(',') + i };
  }
  const j = rnd(0, 2), s = v.reduce((a, l) => a + l[j], 0);
  const erradas = [{ v: v[0].reduce((a, b) => a + b, 0), erro: 'somou a linha, não a coluna' }, { v: s - v[0][j], erro: 'esqueceu uma turma' }, { v: s + 1, erro: 'errou a soma' }, { v: Math.max(...v.map(l => l[j])), erro: 'respondeu só o maior valor' }];
  const a = alternativas(s, erradas, String, { min: 1 });
  return { ...a, text: `Somando as turmas, quantos alunos preferem ${frutas[j].toLowerCase()}?`, image: svgURI(tabelaSVG(['Turma', ...frutas], linhas)), meta: { v, j, modo: 'col' }, chave: 'tc' + v.flat().join(',') + j };
};
C.tabelaDupla = m => { if(m.modo === 'cel') return String(m.v[m.i][m.j]); if(m.modo === 'lin'){ let s = 0; m.v[m.i].forEach(x => s += x); return String(s); } let s = 0; m.v.forEach(l => s += l[m.j]); return String(s); };

/* ============================ 3º ANO ============================ */

/* Divisão com resto (EF03MA08) */
G.divResto = n => {
  const k = rnd(2, n === 1 ? 3 : n === 2 ? 5 : 6), q = rnd(1, n === 1 ? 4 : 5), r = rnd(1, k - 1), tot = k * q + r;
  const tipo = pick(['maca', 'laranja', 'bola', 'estrela', 'flor']);
  const pedeResto = n === 1 ? true : Math.random() < .5;
  const certa = pedeResto ? r : q;
  const erradas = pedeResto ? [{ v: q, erro: 'respondeu quantas ficam em cada prato' }, { v: 0, erro: 'achou que não sobra nada' }, { v: r + k, erro: 'não distribuiu tudo o que dava' }, { v: tot - k * q + 1, erro: 'contou errado' }]
    : [{ v: r, erro: 'respondeu o que sobra' }, { v: q + 1, erro: 'arredondou para cima' }, { v: tot, erro: 'respondeu o total' }, { v: q - 1, erro: 'um a menos' }];
  const a = alternativas(certa, erradas, String, { min: 0 });
  return { ...a, text: `${tot} ${nomeIc(tipo, 2)} repartid${genero(tipo) === 'f' ? 'as' : 'os'} igualmente em ${k} pratos. ${pedeResto ? 'Quant' + (genero(tipo) === 'f' ? 'as' : 'os') + ' SOBRAM?' : 'Quant' + (genero(tipo) === 'f' ? 'as' : 'os') + ' ficam em CADA prato?'}`,
    image: svgURI(pratosSVG(tot, k, tipo)), meta: { tot, k, pedeResto }, chave: `dr${tot}/${k}${pedeResto}` };
};
C.divResto = m => String(m.pedeResto ? m.tot % m.k : Math.floor(m.tot / m.k));

/* Troco (EF03MA24) */
const PRODUTOS = [['caderno', '#3b82f6', 'um caderno'], ['lápis de cor', '#f59e0b', 'uma caixa de lápis'], ['mochila', '#dc2626', 'uma mochila'], ['bola', '#22c55e', 'uma bola'], ['livro', '#a855f7', 'um livro'], ['estojo', '#ec4899', 'um estojo']];
function etiquetaPreco(x, y, nome, cor, preco){
  return `<rect x="${x}" y="${y}" width="170" height="120" rx="12" fill="${cor}" opacity=".2" stroke="${cor}" stroke-width="3"/>` + T(x + 85, y + 44, nome, { fs: 20 }) +
    `<rect x="${x + 25}" y="${y + 62}" width="120" height="44" rx="8" fill="#fef3c7" stroke="#92400e" stroke-width="2.5"/>` + T(x + 85, y + 93, 'R$ ' + preco, { fs: 24 });
}
G.troco3 = n => {
  const [nome, cor, art] = pick(PRODUTOS);
  const nota = n === 1 ? pick([10, 20]) : n === 2 ? pick([20, 50]) : pick([50, 100]);
  const preco = n === 3 ? rnd(12, nota - 3) : rnd(2, nota - 1);
  const tr = nota - preco;
  const erradas = [{ v: preco, erro: 'respondeu o preço' }, { v: nota + preco > 200 ? null : nota + preco, erro: 'somou em vez de subtrair' }, { v: tr + 1, erro: 'errou a conta' }, { v: tr - 1, erro: 'errou a conta' }, { v: tr + 10, erro: 'errou as dezenas' }];
  const a = alternativas(tr, erradas, v => 'R$ ' + v, { min: 1 });
  const k = { 10: 'n10', 20: 'n20', 50: 'n50', 100: 'n100' }[nota];
  const img = SVG(400, 140, etiquetaPreco(10, 10, nome, cor, preco) + `<image href="${IMG[k]}" x="200" y="20" width="190" height="100" preserveAspectRatio="xMidYMid meet"/>`);
  return { ...a, text: `Comprei ${art} e paguei com esta nota. Quanto recebo de troco?`, image: svgURI(img), meta: { nota, preco }, chave: `tr${nota}-${preco}` };
};
C.troco3 = m => 'R$ ' + (m.nota - m.preco);

/* Figuras planas (EF03MA15) */
G.figPlanas3 = n => {
  const pool = n === 1 ? ['triângulo', 'quadrado', 'retângulo', 'círculo'] : ['triângulo', 'quadrado', 'retângulo', 'trapézio', 'paralelogramo'];
  const alvo = pick(pool);
  const giro = n === 3 ? pick([0, 15, 30, -25]) : 0;
  let img;
  if(alvo === 'triângulo') img = SVG(260, 220, `<polygon points="${pick(['130,20 240,200 20,200', '40,30 230,200 30,200', '60,40 240,120 90,210'])}" fill="#c7d2fe" stroke="#111" stroke-width="3.5"/>`);
  else if(alvo === 'círculo') img = SVG(240, 240, `<circle cx="120" cy="120" r="${rnd(70, 105)}" fill="#c7d2fe" stroke="#111" stroke-width="3.5"/>`);
  else img = quadSVG(alvo === 'trapézio' ? 'trapézio' : alvo, giro);
  const conf = { quadrado: 'retângulo', 'retângulo': 'quadrado', 'trapézio': 'paralelogramo', paralelogramo: 'retângulo', 'triângulo': 'trapézio', 'círculo': 'quadrado' };
  const erradas = [...pool, 'círculo', 'trapézio'].filter((t, i, a) => t !== alvo && a.indexOf(t) === i).map(t => ({ v: t, erro: t === conf[alvo] ? `confundiu com ${t}` : 'não contou os lados' }));
  erradas.sort((a, b) => (b.erro.startsWith('confundiu')) - (a.erro.startsWith('confundiu')));
  const a = alternativas(alvo, [erradas[0], ...shuffle(erradas.slice(1))].slice(0, 3), String);
  return { ...a, text: 'Qual é o nome desta figura?', image: svgURI(img), meta: { alvo }, chave: 'fp' + alvo + giro };
};
C.figPlanas3 = m => m.alvo;

/* Igualdade (EF03MA11): 5 + 3 = 6 + ? na balança */
function balancaNumeros(esq, dir){
  return SVG(480, 230, `<polygon points="240,120 215,210 265,210" fill="#475569"/><line x1="30" y1="120" x2="450" y2="120" stroke="#111" stroke-width="8"/>` +
    `<line x1="120" y1="120" x2="120" y2="150" stroke="#111" stroke-width="3"/><line x1="360" y1="120" x2="360" y2="150" stroke="#111" stroke-width="3"/>` +
    `<rect x="30" y="40" width="180" height="70" rx="12" fill="#dbeafe" stroke="#1d4ed8" stroke-width="3"/>` + T(120, 88, esq, { fs: 34 }) +
    `<rect x="270" y="40" width="180" height="70" rx="12" fill="#fef3c7" stroke="#b45309" stroke-width="3"/>` + T(360, 88, dir, { fs: 34 }) +
    `<ellipse cx="120" cy="155" rx="80" ry="10" fill="#94a3b8"/><ellipse cx="360" cy="155" rx="80" ry="10" fill="#94a3b8"/>`);
}
G.igualdade3 = n => {
  const max = n === 1 ? 10 : n === 2 ? 20 : 50;
  const sub = n === 3 && Math.random() < .5;
  let a1, b1, a2, r, esq, dir;
  if(!sub){ a1 = rnd(1, max - 2); b1 = rnd(1, max - a1); a2 = sortearAte(() => rnd(1, a1 + b1 - 1), x => x !== a1 && x !== b1); r = a1 + b1 - a2; esq = `${a1} + ${b1}`; dir = `${a2} + ?`; }
  else { a1 = rnd(20, max); b1 = rnd(1, a1 - 5); a2 = sortearAte(() => rnd(a1 - b1 + 1, max + 10), x => x !== a1); r = a2 - (a1 - b1); esq = `${a1} − ${b1}`; dir = `${a2} − ?`; }
  const tot = sub ? a1 - b1 : a1 + b1;
  const erradas = [{ v: tot, erro: 'escreveu o resultado da esquerda' }, { v: sub ? b1 : b1, erro: 'repetiu o número de cima' }, { v: r + 1, erro: 'errou a conta' }, { v: r - 1, erro: 'errou a conta' }, { v: sub ? a2 + tot : tot + a2, erro: 'somou em vez de completar' }];
  const a = alternativas(r, erradas.filter(e => e.v !== r), String, { min: 0 });
  return { ...a, text: `A balança está equilibrada: ${esq} = ${dir}. Qual é o número que falta?`, image: svgURI(balancaNumeros(esq, dir)), meta: { a1, b1, a2, sub }, chave: `ig${esq}=${dir}` };
};
C.igualdade3 = m => String(m.sub ? m.a2 - (m.a1 - m.b1) : m.a1 + m.b1 - m.a2);

/* Planificação (EF03MA14) */
function planificacaoSVG(tipo){
  const st = 'fill="#bfdbfe" stroke="#111" stroke-width="3" stroke-linejoin="round"';
  const q = (x, y, w, h) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" ${st}/>`;
  const tri = pts => `<polygon points="${pts}" ${st}/>`;
  const s = 60;
  if(tipo === 'cubo') return SVG(250, 330, [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2], [1, 3]].map(([c, l]) => q(10 + c * 76, 10 + l * 76, 76, 76)).join(''));
  if(tipo === 'paralelepipedo') return SVG(470, 230, q(80, 10, 150, 50) + q(10, 60, 70, 100) + q(80, 60, 150, 100) + q(230, 60, 70, 100) + q(300, 60, 150, 100) + q(80, 160, 150, 50));
  if(tipo === 'cilindro') return SVG(320, 330, q(40, 100, 240, 130) + `<circle cx="160" cy="55" r="44" ${st}/><circle cx="160" cy="275" r="44" ${st}/>`);
  if(tipo === 'cone'){           // setor circular com centro no bico do cone (raio = geratriz) + círculo da base encostado no arco
    const ax = 160, ay = 12, R = 170, ang = 120, r = R * ang / 360, a0 = (90 - ang / 2) * Math.PI / 180, a1 = (90 + ang / 2) * Math.PI / 180;
    const p0 = [ax + R * Math.cos(a0), ay + R * Math.sin(a0)], p1 = [ax + R * Math.cos(a1), ay + R * Math.sin(a1)];
    return SVG(320, Math.ceil(ay + R + 2 * r + 10), `<path d="M${ax} ${ay} L${p0[0].toFixed(1)} ${p0[1].toFixed(1)} A${R} ${R} 0 0 1 ${p1[0].toFixed(1)} ${p1[1].toFixed(1)} Z" ${st}/><circle cx="${ax}" cy="${(ay + R + r).toFixed(1)}" r="${r.toFixed(1)}" ${st}/>`);
  }
  if(tipo === 'piramide') return SVG(330, 330, q(115, 115, 100, 100) + tri('115,115 215,115 165,20') + tri('215,115 215,215 310,165') + tri('115,215 215,215 165,310') + tri('115,115 115,215 20,165'));
  return SVG(420, 260, q(60, 80, 100, 100) + q(160, 80, 100, 100) + q(260, 80, 100, 100) + tri('160,80 260,80 210,10') + tri('160,180 260,180 210,250'));     // prisma triangular
}
G.planif3 = n => {
  const pool = n === 1 ? ['cubo', 'cilindro', 'cone'] : n === 2 ? ['cubo', 'cilindro', 'cone', 'piramide'] : ['cubo', 'paralelepipedo', 'cilindro', 'cone', 'piramide', 'prismaTri'];
  const alvo = pick(pool);
  const conf = { cubo: 'paralelepipedo', paralelepipedo: 'cubo', cilindro: 'cone', cone: 'cilindro', piramide: 'prismaTri', prismaTri: 'piramide' };
  const todos = ['cubo', 'paralelepipedo', 'cilindro', 'cone', 'piramide', 'prismaTri', 'esfera'];
  const erradas = todos.filter(t => t !== alvo).map(t => ({ v: SOLIDO_NOME[t], erro: t === conf[alvo] ? `confundiu com ${SOLIDO_NOME[t]}` : 'não imaginou o molde montado' }));
  erradas.sort((a, b) => b.erro.startsWith('confundiu') - a.erro.startsWith('confundiu'));
  const a = alternativas(SOLIDO_NOME[alvo], [erradas[0], ...shuffle(erradas.slice(1)).slice(0, 2)], String);
  return { ...a, text: 'Recortando e dobrando este molde, que sólido se forma?', image: svgURI(planificacaoSVG(alvo)), meta: { alvo }, chave: 'pl' + alvo };
};
C.planif3 = m => SOLIDO_NOME[m.alvo];

/* Régua com milímetros (EF03MA19) */
function reguaMm(ini, fim){        // em mm
  const u = 5, x0 = 24, max = 120, yR = 70;
  let o = `<rect x="${x0 + ini * u}" y="20" width="${(fim - ini) * u}" height="34" rx="3" fill="#22c55e" stroke="#111" stroke-width="2.5"/>`;      // só a fita, sem ponta
  o += `<rect x="${x0 - 14}" y="${yR}" width="${max * u + 28}" height="70" rx="6" fill="#fef3c7" stroke="#92400e" stroke-width="2.5"/>`;
  for(let i = 0; i <= max; i++){ const x = x0 + i * u, g = i % 10 === 0, m5 = i % 5 === 0; o += `<line x1="${x}" y1="${yR}" x2="${x}" y2="${yR + (g ? 28 : m5 ? 19 : 11)}" stroke="#111" stroke-width="${g ? 2.5 : 1}"/>`; if(g) o += T(x, yR + 52, i / 10, { fs: 18 }); }
  return SVG(max * u + 60, yR + 80, o);
}
G.reguaMm = n => {
  const ini = n === 3 ? rnd(1, 3) * 10 : 0;
  const L = n === 1 ? rnd(3, 9) * 10 + pick([0, 5]) : rnd(21, 80), fim = ini + L;
  const cm = Math.floor(L / 10), mm = L % 10;
  const fmt = v => n === 1 ? (v % 10 ? `${Math.floor(v / 10)} cm e ${v % 10} mm` : `${v / 10} cm`) : `${v} mm`;
  const erradas = [{ v: L + 1, erro: 'contou um tracinho a mais' }, { v: L - 1, erro: 'contou um tracinho a menos' }, { v: fim !== L ? fim : L + 10, erro: fim !== L ? 'não começou do zero' : 'contou um centímetro a mais' }, { v: cm * 10 + (10 - mm) % 10, erro: 'contou os milímetros de trás para frente' }, { v: cm + mm * 10, erro: 'trocou cm com mm' }];
  const a = alternativas(L, erradas.filter(e => e.v > 0 && e.v !== L), fmt, { min: 1, reserva: [L + 2, L - 2, L + 5] });
  return { ...a, text: n === 1 ? 'Quanto mede a fita verde?' : 'Quanto mede a fita verde, em milímetros? (1 cm = 10 mm)', image: svgURI(reguaMm(ini, fim)), meta: { ini, fim, n }, chave: `rm${ini}-${fim}` };
};
C.reguaMm = m => { const L = m.fim - m.ini; return m.n === 1 ? (L % 10 ? `${Math.floor(L / 10)} cm e ${L % 10} mm` : `${L / 10} cm`) : `${L} mm`; };

/* Balança com pesos de kg e g (EF03MA20) */
const PESOS = [[1000, '1 kg'], [500, '500 g'], [200, '200 g'], [100, '100 g'], [50, '50 g']];
G.balancaKg = n => {
  const pool = n === 1 ? [1000, 500] : n === 2 ? [1000, 500, 200, 100] : [1000, 500, 200, 100, 50];
  const pesos = sortearAte(() => [...Array(rnd(2, n === 1 ? 3 : 5))].map(() => pick(pool)), p => new Set(p).size > 1).sort((a, b) => b - a);
  const tot = pesos.reduce((a, b) => a + b, 0);
  const obj = pick(['saco de arroz', 'pacote de feijão', 'melão', 'queijo']);
  let o = `<polygon points="240,110 215,200 265,200" fill="#475569"/><line x1="30" y1="110" x2="450" y2="110" stroke="#111" stroke-width="8"/><ellipse cx="120" cy="112" rx="90" ry="10" fill="#94a3b8"/><ellipse cx="360" cy="112" rx="90" ry="10" fill="#94a3b8"/>`;
  o += `<rect x="60" y="40" width="120" height="66" rx="18" fill="#fde68a" stroke="#92400e" stroke-width="3"/>` + T(120, 80, obj, { fs: 15 });
  pesos.forEach((p, i) => { const x = 290 + (i % 3) * 50, y = 104 - Math.floor(i / 3) * 42 - 36, w = p >= 500 ? 46 : 40; o += `<path d="M${x} ${y + 36} L${x + 6} ${y} L${x + w - 6} ${y} L${x + w} ${y + 36} Z" fill="#64748b" stroke="#111" stroke-width="2"/>` + T(x + w / 2, y + 25, PESOS.find(q => q[0] === p)[1], { fs: 11, cor: '#fff' }); });
  const fmt = v => n === 1 ? (v % 1000 ? `${Math.floor(v / 1000) ? Math.floor(v / 1000) + ' kg e ' : ''}${v % 1000} g` : `${v / 1000} kg`) : `${v} g`;
  const erradas = [{ v: pesos.length * 100, erro: 'contou os pesos, não o valor' }, { v: tot - pesos[pesos.length - 1], erro: 'esqueceu um peso' }, { v: tot + 100, erro: 'errou a soma' }, { v: tot - 100 > 0 ? tot - 100 : null, erro: 'errou a soma' }, { v: pesos.filter(p => p === 1000).length * 1 + pesos.filter(p => p < 1000).reduce((a, b) => a + b, 0), erro: 'somou kg como se fosse 1 grama' }];
  const a = alternativas(tot, erradas.filter(e => e.v && e.v !== tot), fmt, { min: 1, passo: 50 });
  return { ...a, text: `A balança está equilibrada. Quanto pesa o ${obj}?${n > 1 ? ' (em gramas; 1 kg = 1000 g)' : ''}`, image: svgURI(SVG(480, 215, o)), meta: { pesos, n }, chave: 'bk' + pesos.join(',') + n };
};
C.balancaKg = m => { let t = 0; m.pesos.forEach(p => t += p); return m.n === 1 ? (t % 1000 ? `${Math.floor(t / 1000) ? Math.floor(t / 1000) + ' kg e ' : ''}${t % 1000} g` : `${t / 1000} kg`) : `${t} g`; };

/* Resultados possíveis (EF03MA25) */
G.resultados3 = n => {
  const modo = n === 1 ? 'roleta' : n === 2 ? pick(['roleta', 'dado']) : pick(['roleta', 'moedas']);
  if(modo === 'moedas'){
    const v = pick(['2m', '3m', 'md']);
    const tot = { '2m': 4, '3m': 8, md: 12 }[v];
    const erradas = v === '2m' ? [{ v: 3, erro: 'achou que cara-coroa e coroa-cara são iguais' }, { v: 2, erro: 'pensou numa moeda só' }, { v: 6, erro: 'contou errado' }]
      : v === '3m' ? [{ v: 6, erro: 'somou em vez de multiplicar' }, { v: 4, erro: 'pensou em duas moedas' }, { v: 3, erro: 'contou uma por moeda' }]
      : [{ v: 8, erro: 'somou 2 + 6' }, { v: 6, erro: 'pensou só no dado' }, { v: 2, erro: 'pensou só na moeda' }];
    const a = alternativas(tot, erradas, String);
    const img = v === 'md' ? `<image href="${IMG.m1}" x="10" y="10" width="110" height="110"/>` + dadoFace(150, 20, 90, 5)
      : `<image href="${IMG.m1}" x="10" y="10" width="110" height="110"/><image href="${IMG.m50}" x="130" y="10" width="110" height="110"/>` + (v === '3m' ? `<image href="${IMG.m25}" x="250" y="10" width="110" height="110"/>` : '');
    const txt = { '2m': 'Lançando duas moedas, quantos resultados diferentes podem sair? (cara ou coroa em cada uma)', '3m': 'Lançando três moedas, quantos resultados diferentes podem sair? (cara ou coroa em cada uma)', md: 'Lançando uma moeda e um dado juntos, quantos resultados diferentes podem sair?' }[v];
    return { ...a, text: txt, image: svgURI(SVG(v === '3m' ? 370 : 250, 130, img)), meta: { modo, v }, chave: 'rs-' + v };
  }
  if(modo === 'dado'){
    const par = Math.random() < .5, c = 3;
    const erradas = [{ v: 6, erro: 'contou todas as faces' }, { v: 2, erro: 'contou errado' }, { v: 4, erro: 'contou uma a mais' }, { v: 1, erro: 'achou que só sai um' }];
    const a = alternativas(c, erradas, String);
    let o = ''; for(let k = 1; k <= 6; k++) o += dadoFace(10 + (k - 1) * 82, 10, 70, k);
    return { ...a, text: `Lançando um dado, quantos resultados diferentes são número ${par ? 'PAR' : 'ÍMPAR'}?`, image: svgURI(SVG(502, 90, o)), meta: { modo, par }, chave: 'rs-dado' + par };
  }
  const k = n === 1 ? rnd(2, 4) : rnd(3, 5);
  const nomes = shuffle(COR_ROL).slice(0, Math.min(k, 4));
  const setores = sortearAte(() => [...Array(rnd(k + 1, 8))].map(() => pick(nomes)), s => new Set(s.map(x => x[0])).size === nomes.length);
  const dist = new Set(setores.map(x => x[0])).size;
  const erradas = [{ v: setores.length, erro: 'contou as partes, não as cores' }, { v: dist + 1, erro: 'contou uma a mais' }, { v: dist - 1, erro: 'esqueceu uma cor' }, { v: 4, erro: 'contou errado' }];
  const a = alternativas(dist, erradas.filter(e => e.v > 0), String, { min: 1 });
  return { ...a, text: 'Girando a roleta, quantas CORES diferentes podem sair?', image: svgURI(roletaSVG(setores.map(x => x[1]))), meta: { modo, cores: setores.map(x => x[0]) }, chave: 'rs' + setores.map(x => x[0][0]).join('') };
};
C.resultados3 = m => m.modo === 'moedas' ? String(m.v === '2m' ? 2 * 2 : m.v === '3m' ? 2 * 2 * 2 : 2 * 6) : m.modo === 'dado' ? String([1, 2, 3, 4, 5, 6].filter(x => (x % 2 === 0) === m.par).length) : String(new Set(m.cores).size);
