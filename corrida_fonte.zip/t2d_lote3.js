
/* =========================================================================
   LOTE 3 — mais 6º ano (Orientações Curriculares SEDU 2026) e números negativos (7º)
========================================================================= */
const menos = v => v < 0 ? '−' + Math.abs(v) : String(v);          // sinal de menos tipográfico
const fracSVGtxt = (x, y, a, b, fs = 30, cor = '#111') =>          // fração em pé dentro de um SVG
  T(x, y - 6, a, { fs, cor }) + `<line x1="${x - fs * .55}" y1="${y + 2}" x2="${x + fs * .55}" y2="${y + 2}" stroke="${cor}" stroke-width="3"/>` + T(x, y + fs + 2, b, { fs, cor });
const mdc2 = (a, b) => { a = Math.abs(a); b = Math.abs(b); while(b){ [a, b] = [b, a % b]; } return a; };

/* ============================ URNA (7º) — substitui a urna antiga ============================ */
G.urna7 = n => {
  const tot = n === 1 ? rnd(5, 12) : pick([4, 5, 10]);
  const cores = shuffle(CORES_BOLAS).slice(0, n === 1 ? 2 : 3);
  let qs;
  if(cores.length === 2){ const k = rnd(1, tot - 1); qs = [k, tot - k]; }
  else qs = sortearAte(() => { const a = rnd(1, tot - 2), b = rnd(1, tot - a - 1); return [a, b, tot - a - b]; }, v => v.every(x => x > 0));
  const i = rnd(0, cores.length - 1), k = qs[i], nao = n === 3 && Math.random() < .5;
  const bolas = shuffle(cores.flatMap(([, h], j) => Array(qs[j]).fill(h)));
  const img = svgURI(SVG(170, 222, poteSVG(10, '', bolas)));
  const evento = nao ? `NÃO sair bola ${cores[i][0]}` : `sair bola ${cores[i][0]}`;
  if(n === 1){
    const erradas = [{ v: `${k}/${tot - k}`, erro: 'comparou com as outras cores' }, { v: `${tot - k}/${tot}`, erro: 'contou as outras cores' }, { v: `${tot}/${k}`, erro: 'inverteu a fração' }, { v: `1/${tot}`, erro: 'contou uma bola só' }, { v: `${k}/${tot + 1}`, erro: 'contou o total errado' }];
    const o = altFrac(`${k}/${tot}`, erradas, tot);
    return { ...o, text: `Tirando uma bola sem olhar, qual a chance de ${evento}?`, image: img, meta: { qs, i, nao, tot, modo: 'frac' }, chave: 'u7' + qs.join(',') + i };
  }
  const fav = nao ? tot - k : k, p = fav * 100 / tot;
  const erradas = [{ v: fav, erro: 'usou o número de bolas como porcentagem' }, { v: 100 - p, erro: nao ? 'calculou a chance de sair a cor' : 'calculou a chance de não sair' }, { v: fav * 10, erro: 'multiplicou por 10' },
    { v: p + 100 / tot, erro: 'contou uma bola a mais' }, { v: p - 100 / tot, erro: 'contou uma bola a menos' }, { v: Math.round(100 / tot), erro: 'contou uma bola só' }];
  const o = alternativas(p, erradas.filter(e => Number.isInteger(e.v)), v => v + '%', { min: 0, max: 100, passo: 5 });
  return { ...o, text: `Tirando uma bola sem olhar, qual a chance de ${evento}? (em %)`, image: img, meta: { qs, i, nao, tot, modo: 'pct' }, chave: 'u7' + qs.join(',') + i + nao };
};
C.urna7 = m => { const t = m.qs.reduce((a, b) => a + b, 0), f = m.nao ? t - m.qs[m.i] : m.qs[m.i]; return m.modo === 'frac' ? `${f}/${t}` : (f / t * 100) + '%'; };

/* ============================ 6º ANO ============================ */

/* Primo ou composto (EF06MA05) */
const ehPrimo = x => { if(x < 2) return false; for(let d = 2; d * d <= x; d++) if(x % d === 0) return false; return true; };
G.primos = n => {
  const max = n === 1 ? 30 : n === 2 ? 60 : 100;
  const qual = n === 3 && Math.random() < .5 ? 'composto' : 'primo';
  const certa = sortearAte(() => rnd(2, max), x => qual === 'primo' ? ehPrimo(x) && x > 2 : !ehPrimo(x) && x > 3 && (n < 3 || x % 2));
  const armadilhas = qual === 'primo'
    ? [...Array(max).keys()].filter(x => x > 8 && x % 2 && !ehPrimo(x))              // ímpares que não são primos (9, 15, 21…)
    : [...Array(max).keys()].filter(x => ehPrimo(x) && x > 2);
  const erradas = shuffle(armadilhas).slice(0, 3).map(v => ({ v, erro: qual === 'primo' ? `achou que todo ímpar é primo (${v} = ${[...Array(v).keys()].find(d => d > 1 && v % d === 0)} × ${v / [...Array(v).keys()].find(d => d > 1 && v % d === 0)})` : 'escolheu um primo' }));
  if(qual === 'primo') erradas.push({ v: 1, erro: '1 não é primo nem composto' });
  const o = alternativas(certa, erradas, String, { min: 1, reserva: qual === 'primo' ? [4, 6, 8, 10, 12, 14] : [2, 3, 5, 7] });
  return { ...o, text: qual === 'primo' ? 'Qual destes números é PRIMO?' : 'Qual destes números é COMPOSTO?', meta: { qual, ops: o.options }, chave: 'pr' + certa + qual };
};
C.primos = m => m.ops.find(v => m.qual === 'primo' ? ehPrimo(+v) : +v > 1 && !ehPrimo(+v));

/* Arredondamento na reta (EF06MA12) */
G.arredonda = n => {
  const base = n === 1 ? 10 : n === 2 ? 100 : 1000;
  const nome = { 10: 'dezena', 100: 'centena', 1000: 'unidade de milhar' }[base];
  const lo = base * rnd(n === 1 ? 1 : 2, n === 1 ? 29 : 9), passo = base / 10;
  const x = lo + passo * rnd(1, 9);
  const certa = x - lo >= base / 2 ? lo + base : lo;
  const outra = certa === lo ? lo + base : lo;
  const erradas = [{ v: outra, erro: certa === lo ? 'arredondou para cima sem olhar o algarismo' : 'arredondou para baixo sem olhar o algarismo' },
    { v: certa === lo ? lo - base : lo + 2 * base, erro: 'pulou para o múltiplo errado' }, { v: certa + base, erro: 'passou da ordem certa' }, { v: x - (x % base), erro: 'só cortou os algarismos' }];
  const o = alternativas(certa, erradas.filter(e => e.v !== x), v => String(v), { min: 0, passo: base });
  const img = svgURI(retaFolga(svgReta(lo, lo + base, passo, base / 2, [[x, String(x)]])));
  return { ...o, text: `Arredonde ${x} para a ${nome} mais próxima.`, image: img, meta: { x, base }, chave: `ar${x}` };
};
C.arredonda = m => String(Math.floor(m.x / m.base + 0.5) * m.base);

/* Contagem: cardápio e cartões (EF06MA35/ES) */
function etiquetasSVG(grupos){      // [[titulo, [itens]], ...] em etiquetas coloridas
  let o = '', y = 10;
  const cores = ['#fde68a', '#bbf7d0', '#bfdbfe', '#fbcfe8', '#ddd6fe', '#fed7aa'];
  grupos.forEach(([tit, itens], g) => {
    o += T(10, y + 30, tit, { fs: 20, anc: 'start' });
    itens.forEach((t, i) => { const x = 130 + i * 118; o += `<rect x="${x}" y="${y + 6}" width="110" height="38" rx="10" fill="${cores[(g * 2 + i) % cores.length]}" stroke="#111" stroke-width="2"/>` + T(x + 55, y + 32, t, { fs: 17 }); });
    y += 52;
  });
  return SVG(130 + 4 * 118 + 10, y + 6, o);
}
const PAES = ['francês', 'de forma', 'integral', 'de milho'], RECHEIOS = ['queijo', 'frango', 'ovo', 'presunto'], SUCOS = ['laranja', 'uva', 'caju', 'goiaba'];
G.cardapio = n => {
  if(n < 3){
    const a = rnd(2, n === 1 ? 3 : 4), b = rnd(2, n === 1 ? 3 : 4), c = n === 2 ? rnd(2, 3) : 1;
    const grupos = [['Pão', shuffle(PAES).slice(0, a)], ['Recheio', shuffle(RECHEIOS).slice(0, b)], ...(c > 1 ? [['Suco', shuffle(SUCOS).slice(0, c)]] : [])];
    const tot = a * b * c;
    const erradas = [{ v: a + b + (c > 1 ? c : 0), erro: 'somou em vez de multiplicar' }, { v: c > 1 ? a * b : tot - 1, erro: c > 1 ? 'esqueceu o suco' : 'esqueceu uma combinação' }, { v: tot + a, erro: 'contou combinações repetidas' }, { v: 2 * tot, erro: 'contou cada lanche duas vezes' }];
    const o = alternativas(tot, erradas, String, { min: 1 });
    return { ...o, text: c > 1 ? 'Um lanche tem 1 pão, 1 recheio e 1 suco. Quantos lanches diferentes dá para montar?' : 'Um sanduíche tem 1 pão e 1 recheio. Quantos sanduíches diferentes dá para montar?',
      image: svgURI(etiquetasSVG(grupos)), meta: { f: [a, b, c], modo: 'prod' }, chave: `cd${a}${b}${c}` };
  }
  const k = rnd(3, 5), dig = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]).slice(0, k).sort(), L = k === 3 ? 3 : pick([2, 3]);
  let tot = 1; for(let i = 0; i < L; i++) tot *= (k - i);
  const erradas = [{ v: k ** L, erro: 'deixou repetir algarismo' }, { v: k * L, erro: 'multiplicou cartões pelo número de algarismos' }, { v: L === 2 ? tot / 2 : tot / 6, erro: 'achou que a ordem não importa' }, { v: k + (k - 1) + (L === 3 ? k - 2 : 0), erro: 'somou em vez de multiplicar' }];
  const o = alternativas(tot, erradas.filter(e => Number.isInteger(e.v)), String, { min: 1 });
  let img = ''; dig.forEach((d, i) => { img += `<rect x="${10 + i * 78}" y="10" width="66" height="86" rx="10" fill="#fff" stroke="#111" stroke-width="3"/>` + T(43 + i * 78, 70, d, { fs: 44 }); });
  return { ...o, text: `Usando estes cartões, sem repetir, quantos números de ${L} algarismos dá para formar?`, image: svgURI(SVG(k * 78 + 12, 106, img)), meta: { k, L, modo: 'cartoes' }, chave: `cc${dig.join('')}${L}` };
};
C.cardapio = m => {
  if(m.modo === 'prod'){ let q = 0; for(let i = 0; i < m.f[0]; i++) for(let j = 0; j < m.f[1]; j++) for(let k = 0; k < m.f[2]; k++) q++; return String(q); }
  let q = 0; const lim = 10 ** m.L;                                        // lista os números e conta
  for(let x = 10 ** (m.L - 1); x < lim; x++){ const s = String(x); if(new Set(s).size === m.L && [...s].every(c => +c >= 1 && +c <= m.k)) q++; }
  return String(q);                                                           // (cartões 1..k têm a mesma contagem de quaisquer k algarismos distintos)
};

/* Comparar frações com barras do mesmo tamanho (EF06MA07) */
function barrasFracoes(fs){          // fs = [[a,b], ...] barras iguais, com a fração em pé à esquerda
  let o = '';
  fs.forEach(([a, b], k) => {
    const y = 14 + k * 100;
    o += fracSVGtxt(40, y + 30, a, b, 26);
    for(let i = 0; i < b; i++) o += `<rect x="${(90 + i * 400 / b).toFixed(2)}" y="${y}" width="${(400 / b).toFixed(2)}" height="66" fill="${i < a ? ['#f59e0b', '#3b82f6', '#22c55e'][k] : '#fff'}" stroke="#111" stroke-width="3"/>`;
  });
  return SVG(500, fs.length * 100 + 10, o);
}
G.fracCompara = n => {
  let A, B, modo = n === 3 && Math.random() < .3 ? 'igual' : 'dif';
  if(n === 1){ const d = rnd(3, 10); const [a, b] = shuffle([...Array(d - 1).keys()].map(x => x + 1)).slice(0, 2); A = [a, d]; B = [b, d]; }
  else if(n === 2){ const a = rnd(1, 4); const [d1, d2] = shuffle([...Array(8).keys()].map(x => x + a + 1)).slice(0, 2); A = [a, d1]; B = [a, d2]; }
  else if(modo === 'igual'){ const [p, q] = pick([[1, 2], [1, 3], [2, 3], [1, 4], [3, 4], [2, 5]]); const [k1, k2] = shuffle([1, 2, 3]).slice(0, 2); A = [p * k1, q * k1]; B = [p * k2, q * k2]; }
  else { A = sortearAte(() => { const d = rnd(3, 10); return [rnd(1, d - 1), d]; }, () => true); B = sortearAte(() => { const d = rnd(3, 10); return [rnd(1, d - 1), d]; }, x => x[1] !== A[1] && x[0] !== A[0] && x[0] * A[1] !== A[0] * x[1] && Math.abs(x[0] / x[1] - A[0] / A[1]) < .25); }
  const mais = Math.random() < .6;
  const vA = A[0] / A[1], vB = B[0] / B[1], tA = `${A[0]}/${A[1]}`, tB = `${B[0]}/${B[1]}`;
  const certa = Math.abs(vA - vB) < 1e-9 ? 'As duas são iguais' : (mais ? (vA > vB ? tA : tB) : (vA < vB ? tA : tB));
  const outraF = certa === tA ? tB : tA;
  const erradas = [...(certa === 'As duas são iguais' ? [{ v: tA, erro: 'não viu que as frações são equivalentes' }, { v: tB, erro: 'não viu que as frações são equivalentes' }] : [{ v: outraF, erro: n === 2 ? 'achou que denominador maior dá fração maior' : 'comparou errado' }, { v: 'As duas são iguais', erro: 'achou que são iguais' }]),
    { v: 'Não dá para comparar', erro: 'achou que não dá para comparar' }];
  const o = alternativas(certa, erradas, String);
  return { ...o, text: `Qual fração é ${mais ? 'MAIOR' : 'MENOR'}?`, image: svgURI(barrasFracoes([A, B])), meta: { A, B, mais }, chave: `fc${tA}${tB}${mais}` };
};
C.fracCompara = m => { const x = m.A[0] * m.B[1], y = m.B[0] * m.A[1]; if(x === y) return 'As duas são iguais'; return (m.mais ? x > y : x < y) ? `${m.A[0]}/${m.A[1]}` : `${m.B[0]}/${m.B[1]}`; };

/* Fração de uma quantidade com figura (EF06MA09) */
G.fracQtd = n => {
  const b = n === 1 ? rnd(2, 4) : n === 2 ? rnd(3, 5) : rnd(4, 8), k = n === 1 ? rnd(2, 4) : rnd(2, n === 2 ? 5 : 6), a = n === 1 ? 1 : rnd(2, b - 1), N = b * k;
  const tipo = pick(['maca', 'estrela', 'flor', 'balao', 'bola']);
  let o = '', y = 10, larg = 0;
  for(let g = 0; g < b; g++){ const gi = grupoIcones(tipo, k, 10, y, 34, k); o += `<rect x="4" y="${y - 4}" width="${gi.w + 12}" height="${gi.h + 8}" rx="8" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6,4"/>` + gi.svg; y += gi.h + 14; larg = Math.max(larg, gi.w); }
  const erradas = [{ v: k, erro: 'só dividiu pelo denominador' }, { v: N - a * k, erro: 'calculou a parte que sobra' }, { v: N * a, erro: 'multiplicou pelo numerador sem dividir' }, { v: a * k + k, erro: 'pegou um grupo a mais' }, { v: a * k - k, erro: 'pegou um grupo a menos' }];
  const o2 = alternativas(a * k, erradas, String, { min: 1 });
  return { ...o2, text: `Quanto é ${a}/${b} de ${N}?`, image: svgURI(SVG(larg + 30, y, o)), meta: { a, b, N }, chave: `fq${a}/${b}de${N}` };
};
C.fracQtd = m => String(m.N / m.b * m.a);

/* Somar e subtrair frações com barra (EF06MA10/ES) */
G.somaFrac = n => {
  let d, a, b, k = 1, sub = false;
  if(n === 1){ d = rnd(4, 10); a = rnd(1, d - 2); b = rnd(1, d - 1 - a); }
  else if(n === 2){ d = rnd(4, 12); sub = Math.random() < .5; if(sub){ a = rnd(2, d - 1); b = rnd(1, a - 1); } else { a = rnd(1, d - 2); b = rnd(1, d - 1 - a); } }
  else { d = rnd(2, 5); k = pick([2, 3]); a = rnd(1, d - 1); b = rnd(1, d * k - a * k - 1); }
  const D = d * k, r = sub ? a * k - b : a * k + b;                 // resultado em D avos (sem simplificar)
  const certa = `${r}/${D}`;
  const erradas = sub
    ? [{ v: `${b}/${d}`, erro: 'respondeu a parte que tirou' }, { v: `${a + b}/${d}`, erro: 'somou em vez de subtrair' }, { v: `${a - b}/${2 * d}`, erro: 'somou os denominadores' }, { v: `${r + 1}/${D}`, erro: 'contou uma parte a mais' }, { v: `${r - 1}/${D}`, erro: 'contou uma parte a menos' }]
    : [{ v: `${a + b}/${d + D}`, erro: 'somou numeradores e denominadores' }, { v: `${a + b}/${D}`, erro: k > 1 ? 'não converteu para o mesmo denominador' : 'errou a conta' }, { v: `${r + 1}/${D}`, erro: 'contou uma parte a mais' }, { v: `${r - 1}/${D}`, erro: 'contou uma parte a menos' }, { v: `${a * b}/${D}`, erro: 'multiplicou os numeradores' }];
  const o = altFrac(certa, erradas, D);
  // figura: barra em D partes; parte verde = primeira fração, azul = a que soma (ou riscada = a que tira)
  let img = '';
  if(k > 1){ img += fracSVGtxt(40, 40, a, d, 24) + T(40, 110, '+', { fs: 30 }) + fracSVGtxt(40, 150, b, D, 24); }
  const x0 = k > 1 ? 90 : 10, w = k > 1 ? 400 : 480;
  if(k > 1){ for(let i = 0; i < d; i++) img += `<rect x="${(x0 + i * w / d).toFixed(2)}" y="14" width="${(w / d).toFixed(2)}" height="60" fill="${i < a ? '#22c55e' : '#fff'}" stroke="#111" stroke-width="3"/>`; }
  const y = k > 1 ? 124 : 14;
  for(let i = 0; i < D; i++){
    const verde = !sub && k === 1 && i < a, azul = !sub && (k === 1 ? i >= a && i < a + b : i < b), cheia = sub && i < a, risc = sub && i >= a - b && i < a;
    img += `<rect x="${(x0 + i * w / D).toFixed(2)}" y="${y}" width="${(w / D).toFixed(2)}" height="60" fill="${verde || cheia ? '#22c55e' : azul ? '#3b82f6' : '#fff'}" stroke="#111" stroke-width="3"/>`;
    if(risc){ const xx = x0 + i * w / D; img += `<line x1="${xx.toFixed(1)}" y1="${y}" x2="${(xx + w / D).toFixed(1)}" y2="${y + 60}" stroke="#b91c1c" stroke-width="4"/><line x1="${(xx + w / D).toFixed(1)}" y1="${y}" x2="${xx.toFixed(1)}" y2="${y + 60}" stroke="#b91c1c" stroke-width="4"/>`; }
  }
  const texto = k > 1 ? `${a}/${d} + ${b}/${D} = ?` : sub ? `${a}/${d} − ${b}/${d} = ?` : `${a}/${d} + ${b}/${d} = ?`;
  return { ...o, text: texto, image: svgURI(SVG(500, y + 74, img)), meta: { a, b, d, k, sub }, chave: 'sf' + texto };
};
C.somaFrac = m => { const D = m.d * m.k; return `${m.sub ? m.a * m.k - m.b : m.a * m.k + m.b}/${D}`; };

/* Classificar triângulos (EF06MA19) */
function trianguloSVG(L, ang, rotulos){       // L = [a,b,c] lados (a oposto a A...), vértices A,B,C
  const [a, b, c] = L;
  const B0 = [0, 0], C0 = [a, 0];
  const x = (a * a + c * c - b * b) / (2 * a), y = -Math.sqrt(Math.max(0, c * c - x * x));
  const A0 = [x, y];
  const xs = [0, a, x], ys = [0, 0, y], mx = Math.min(...xs), Mx = Math.max(...xs), my = Math.min(...ys);
  const esc = Math.min(300 / (Mx - mx), 170 / (0 - my));
  const P = p => [70 + (p[0] - mx) * esc, 205 + p[1] * esc];
  const [pA, pB, pC] = [P(A0), P(B0), P(C0)];
  let o = `<polygon points="${[pA, pB, pC].map(p => p.map(v => v.toFixed(1)).join(',')).join(' ')}" fill="#fde68a" stroke="#111" stroke-width="3.5" stroke-linejoin="round"/>`;
  const G0 = [(pA[0] + pB[0] + pC[0]) / 3, (pA[1] + pB[1] + pC[1]) / 3];
  const fora = (p, q, t) => { const m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], v = [m[0] - G0[0], m[1] - G0[1]], l = Math.hypot(...v) || 1; return T(m[0] + v[0] / l * 36, m[1] + v[1] / l * 36 + 7, t, { fs: 21 }); };
  const dentro = (p, t) => { const v = [G0[0] - p[0], G0[1] - p[1]], l = Math.hypot(...v) || 1; return T(p[0] + v[0] / l * 40, p[1] + v[1] / l * 40 + 7, t, { fs: 19, cor: '#b91c1c' }); };
  if(rotulos === 'lados'){ o += fora(pB, pC, a + ' cm') + fora(pA, pC, b + ' cm') + fora(pA, pB, c + ' cm'); }
  else { [[pA, ang[0]], [pB, ang[1]], [pC, ang[2]]].forEach(([p, g]) => { if(g !== null) o += dentro(p, g + '°'); }); }
  return SVG(440, 250, o);
}
G.triangulos = n => {
  const porLados = n === 1 || (n === 3 && Math.random() < .3);
  if(porLados){
    const tipo = pick(['equilátero', 'isósceles', 'escaleno']);
    const L = tipo === 'equilátero' ? Array(3).fill(rnd(4, 9)) : tipo === 'isósceles' ? (() => { const p = rnd(5, 9), q = sortearAte(() => rnd(3, 12), v => v !== p && v < 2 * p); return shuffle([p, p, q]); })()
      : sortearAte(() => [rnd(3, 12), rnd(3, 12), rnd(3, 12)], v => new Set(v).size === 3 && v[0] < v[1] + v[2] && v[1] < v[0] + v[2] && v[2] < v[0] + v[1] && Math.max(...v) < 1.8 * Math.min(...v) + 3);
    const erradas = ['equilátero', 'isósceles', 'escaleno'].filter(t => t !== tipo).map(t => ({ v: t, erro: 'contou os lados iguais errado' })).concat([{ v: 'retângulo', erro: 'confundiu classificação por lados com por ângulos' }]);
    const o = alternativas(tipo, erradas, String);
    return { ...o, text: 'Pelos LADOS, como se classifica este triângulo?', image: svgURI(trianguloSVG(L, null, 'lados')), meta: { L, modo: 'lados' }, chave: 'tl' + L.join(',') };
  }
  const tipo = pick(['acutângulo', 'retângulo', 'obtusângulo']);
  const ang = sortearAte(() => { const A = tipo === 'retângulo' ? 90 : tipo === 'obtusângulo' ? 5 * rnd(20, 27) : 5 * rnd(10, 17); const B = 5 * rnd(5, Math.floor((175 - A) / 5) - 4); return shuffle([A, B, 180 - A - B]); },
    v => v.every(x => x >= 25) && (tipo === 'acutângulo' ? v.every(x => x < 90) : true));
  const rad = x => x * Math.PI / 180, L = ang.map(x => +(Math.sin(rad(x)) * 10).toFixed(4));
  const esconde = n === 3 ? rnd(0, 2) : null;              // difícil: um ângulo não aparece (a soma é 180°)
  const erradas = ['acutângulo', 'retângulo', 'obtusângulo'].filter(t => t !== tipo).map(t => ({ v: t, erro: n === 3 ? 'não calculou o ângulo que falta' : 'olhou errado o maior ângulo' })).concat([{ v: 'isósceles', erro: 'confundiu classificação por ângulos com por lados' }]);
  const o = alternativas(tipo, erradas, String);
  return { ...o, text: n === 3 ? 'Pelos ÂNGULOS, como se classifica este triângulo? (um ângulo não foi escrito)' : 'Pelos ÂNGULOS, como se classifica este triângulo?',
    image: svgURI(trianguloSVG(L, ang.map((x, i) => i === esconde ? null : x), 'angulos')), meta: { ang, modo: 'angulos' }, chave: 'ta' + ang.join(',') };
};
C.triangulos = m => {
  if(m.modo === 'lados'){ const d = new Set(m.L).size; return d === 1 ? 'equilátero' : d === 2 ? 'isósceles' : 'escaleno'; }
  const M = Math.max(...m.ang); return M === 90 ? 'retângulo' : M > 90 ? 'obtusângulo' : 'acutângulo';
};

/* Quadriláteros (EF06MA20) */
function quadSVG(tipo, giro){
  const s = 1;
  let P;
  if(tipo === 'quadrado') P = [[0, 0], [140, 0], [140, 140], [0, 140]];
  else if(tipo === 'retângulo') P = [[0, 0], [220, 0], [220, 120], [0, 120]];
  else if(tipo === 'losango') P = [[110, 0], [190, 110], [110, 220], [30, 110]];
  else if(tipo === 'paralelogramo') P = [[60, 0], [260, 0], [200, 130], [0, 130]];
  else P = [[70, 0], [190, 0], [260, 130], [0, 130]];                          // trapézio
  const c = P.reduce((a, p) => [a[0] + p[0] / 4, a[1] + p[1] / 4], [0, 0]), g = giro * Math.PI / 180;
  P = P.map(([x, y]) => [c[0] + (x - c[0]) * Math.cos(g) - (y - c[1]) * Math.sin(g), c[1] + (x - c[0]) * Math.sin(g) + (y - c[1]) * Math.cos(g)]);
  const xs = P.map(p => p[0]), ys = P.map(p => p[1]), dx = 40 - Math.min(...xs), dy = 40 - Math.min(...ys);
  P = P.map(([x, y]) => [x + dx, y + dy]);
  const W = Math.max(...xs) - Math.min(...xs) + 80, H = Math.max(...ys) - Math.min(...ys) + 80;
  let o = `<polygon points="${P.map(p => p.map(v => v.toFixed(1)).join(',')).join(' ')}" fill="#c7d2fe" stroke="#111" stroke-width="3.5" stroke-linejoin="round"/>`;
  const lados = [0, 1, 2, 3].map(i => [P[i], P[(i + 1) % 4]]);
  const comp = ([p, q]) => Math.hypot(q[0] - p[0], q[1] - p[1]);
  // tracinhos nos lados iguais
  const grupos = []; lados.forEach((l, i) => { const L = comp(l); let g = grupos.findIndex(x => Math.abs(x - L) < 1); if(g < 0){ grupos.push(L); g = grupos.length - 1; } l.g = g; });
  lados.forEach(l => { if(lados.filter(x => x.g === l.g).length < 2) return; const [p, q] = l, m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], L = comp(l), u = [(q[0] - p[0]) / L, (q[1] - p[1]) / L], nrm = [-u[1], u[0]];
    for(let k = 0; k <= l.g; k++){ const cx = m[0] + u[0] * (k - l.g / 2) * 8; const cy = m[1] + u[1] * (k - l.g / 2) * 8; o += `<line x1="${(cx - nrm[0] * 10).toFixed(1)}" y1="${(cy - nrm[1] * 10).toFixed(1)}" x2="${(cx + nrm[0] * 10).toFixed(1)}" y2="${(cy + nrm[1] * 10).toFixed(1)}" stroke="#b91c1c" stroke-width="3"/>`; } });
  // marcas de ângulo reto
  P.forEach((p, i) => { const a = P[(i + 3) % 4], b = P[(i + 1) % 4], u = [a[0] - p[0], a[1] - p[1]], v = [b[0] - p[0], b[1] - p[1]], lu = Math.hypot(...u), lv = Math.hypot(...v);
    if(Math.abs(u[0] * v[0] + u[1] * v[1]) / (lu * lv) < 1e-3){ const k = 16, q1 = [p[0] + u[0] / lu * k, p[1] + u[1] / lu * k], q2 = [p[0] + v[0] / lv * k, p[1] + v[1] / lv * k], q3 = [q1[0] + v[0] / lv * k, q1[1] + v[1] / lv * k];
      o += `<polyline points="${[q1, q3, q2].map(q => q.map(x => x.toFixed(1)).join(',')).join(' ')}" fill="none" stroke="#111" stroke-width="2.5"/>`; } });
  // setinhas nos lados paralelos
  const par = [[0, 2], [1, 3]].filter(([i, j]) => { const [p, q] = lados[i], [r, s2] = lados[j]; const u = [q[0] - p[0], q[1] - p[1]], v = [s2[0] - r[0], s2[1] - r[1]]; return Math.abs(u[0] * v[1] - u[1] * v[0]) / (Math.hypot(...u) * Math.hypot(...v)) < 1e-3; });
  par.forEach(([i, j], pi) => [i, j].forEach(k => { const [p, q] = lados[k], m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2], L = comp(lados[k]); let u = [(q[0] - p[0]) / L, (q[1] - p[1]) / L]; if(k >= 2) u = [-u[0], -u[1]];
    const nrm = [-u[1], u[0]]; for(let t = 0; t <= pi; t++){ const b0 = [m[0] + u[0] * (22 + t * 9), m[1] + u[1] * (22 + t * 9)];
      o += `<polyline points="${(b0[0] - u[0] * 8 + nrm[0] * 6).toFixed(1)},${(b0[1] - u[1] * 8 + nrm[1] * 6).toFixed(1)} ${b0[0].toFixed(1)},${b0[1].toFixed(1)} ${(b0[0] - u[0] * 8 - nrm[0] * 6).toFixed(1)},${(b0[1] - u[1] * 8 - nrm[1] * 6).toFixed(1)}" fill="none" stroke="#1d4ed8" stroke-width="3"/>`; } }));
  return SVG(W, H, o);
}
G.quadrilateros = n => {
  const tipo = n === 1 ? pick(['quadrado', 'retângulo', 'trapézio']) : pick(['quadrado', 'retângulo', 'losango', 'paralelogramo', 'trapézio']);
  const giro = n === 3 ? pick([15, 30, 45, -20, -35]) : 0;
  const conf = { quadrado: ['losango', 'retângulo'], 'retângulo': ['quadrado', 'paralelogramo'], losango: ['quadrado', 'paralelogramo'], paralelogramo: ['retângulo', 'losango'], 'trapézio': ['paralelogramo', 'retângulo'] }[tipo];
  const erradas = ['quadrado', 'retângulo', 'losango', 'paralelogramo', 'trapézio'].filter(t => t !== tipo).map(t => ({ v: t, erro: conf.includes(t) ? (tipo === 'quadrado' && t === 'losango' && giro ? 'achou que quadrado girado vira losango' : `confundiu com ${t}`) : 'não olhou as marcas' }));
  const o = alternativas(tipo, [...erradas.filter(e => !e.erro.startsWith('não')), ...erradas.filter(e => e.erro.startsWith('não'))].slice(0, 3), String);
  return { ...o, text: 'Que quadrilátero é este? (tracinhos = lados iguais · setas = lados paralelos · quadradinho = ângulo reto)', image: svgURI(quadSVG(tipo, giro)), meta: { tipo }, chave: 'qd' + tipo + giro };
};
C.quadrilateros = m => m.tipo;

/* ============================ 7º ANO — NÚMEROS NEGATIVOS ============================ */
const CIDADES_FRIAS = ['Urupema', 'Gramado', 'Curitiba', 'São Joaquim', 'Moscou', 'Oslo', 'Toronto', 'Montreal'];
function termometrosSVG(temps, nomes, min, max){
  let o = '';
  temps.forEach((t, i) => { const inner = termometroSVG(min, max, 1, 5, t).replace(/^<svg[^>]*>/, `<svg x="${i * 170}" y="0" width="170" height="250" viewBox="60 0 230 380" preserveAspectRatio="xMidYMid meet">`); o += inner + T(i * 170 + 85, 272, nomes[i], { fs: 19 }) + T(i * 170 + 85, 300, menos(t) + ' °C', { fs: 22, cor: '#b91c1c' }); });
  return SVG(temps.length * 170, 312, o);
}
G.tempCidades = n => {
  const k = n === 1 ? 2 : n === 2 ? 3 : 4, nomes = shuffle(CIDADES_FRIAS).slice(0, k);
  const temps = sortearAte(() => [...Array(k)].map(() => n === 1 ? rnd(-9, 9) : rnd(-12, 6)), v => new Set(v).size === k && v.some(x => x < 0) && (n === 1 ? v.some(x => x > 0) : v.filter(x => x < 0).length >= 2));
  if(n === 3 && Math.random() < .5){
    const M = Math.max(...temps), m = Math.min(...temps), dif = M - m;
    const erradas = [{ v: Math.abs(Math.abs(M) - Math.abs(m)), erro: 'subtraiu sem olhar o sinal' }, { v: M + m < 0 ? -(M + m) : M + m, erro: 'somou as temperaturas' }, { v: dif + 1, erro: 'contou um grau a mais' }, { v: dif - 1, erro: 'contou um grau a menos' }];
    const o = alternativas(dif, erradas, v => v + ' °C', { min: 1 });
    return { ...o, text: 'Qual a diferença entre a temperatura MAIS ALTA e a MAIS BAIXA?', image: svgURI(termometrosSVG(temps, nomes, -15, 10)), meta: { temps, modo: 'dif' }, chave: 'tcd' + temps.join(',') };
  }
  const fria = Math.random() < .6, alvo = fria ? Math.min(...temps) : Math.max(...temps);
  const certa = nomes[temps.indexOf(alvo)];
  const negs = temps.filter(x => x < 0), engano = fria ? (negs.length ? negs.reduce((a, b) => Math.abs(a) < Math.abs(b) ? a : b) : null) : (negs.length ? negs.reduce((a, b) => Math.abs(a) > Math.abs(b) ? a : b) : null);
  const erradas = nomes.filter(x => x !== certa).map(x => ({ v: x, erro: temps[nomes.indexOf(x)] === engano ? (fria ? 'achou que −' + Math.abs(engano) + ' é mais frio que ' + menos(alvo) : 'achou que ' + menos(engano) + ' é maior por ter o número maior') : 'comparou errado' }));
  if(k === 2) erradas.push({ v: 'As duas têm a mesma temperatura', erro: 'comparou errado' });
  if(k < 4) erradas.push({ v: 'Não dá para saber', erro: 'achou que não dá para saber' });
  const o = alternativas(certa, erradas, String);
  return { ...o, text: `Qual cidade está mais ${fria ? 'FRIA' : 'QUENTE'}?`, image: svgURI(termometrosSVG(temps, nomes, -15, 10)), meta: { temps, nomes, fria, modo: 'qual' }, chave: 'tc' + temps.join(',') + fria };
};
C.tempCidades = m => m.modo === 'dif' ? (Math.max(...m.temps) - Math.min(...m.temps)) + ' °C' : m.nomes[m.temps.indexOf(m.fria ? Math.min(...m.temps) : Math.max(...m.temps))];

function retaInteirosSVG(pts){       // reta de −10 a 10 com pontos [[valor, rótulo]]
  const x = v => 30 + (v + 10) * 26, y = 70;
  let o = `<line x1="14" y1="${y}" x2="${x(10) + 18}" y2="${y}" stroke="#111" stroke-width="3"/><polygon points="${x(10) + 22},${y} ${x(10) + 10},${y - 7} ${x(10) + 10},${y + 7}" fill="#111"/>`;
  for(let v = -10; v <= 10; v++){ const g = v % 5 === 0; o += `<line x1="${x(v)}" y1="${y - (g ? 12 : 7)}" x2="${x(v)}" y2="${y + (g ? 12 : 7)}" stroke="#111" stroke-width="${g ? 3 : 1.8}"/>`; if(g) o += T(x(v), y + 38, menos(v), { fs: 20 }); }
  pts.forEach(([v, r], i) => { o += `<circle cx="${x(v)}" cy="${y}" r="8" fill="${['#dc2626', '#2563eb'][i]}"/>` + T(x(v), y - 22, r, { fs: 24, cor: ['#dc2626', '#2563eb'][i] }); });
  return SVG(x(10) + 40, 120, o);
}
G.opostoModulo = n => {
  const a = sortearAte(() => rnd(-9, 9), v => v !== 0 && v % 5 !== 0);
  if(n === 1){
    const erradas = [{ v: a, erro: 'repetiu o número' }, { v: a + (a < 0 ? 1 : -1), erro: 'contou um tracinho errado' }, { v: -a + (a < 0 ? 1 : -1), erro: 'errou a contagem' }, { v: 0, erro: 'achou que o oposto é zero' }];
    const o = alternativas(-a, erradas, menos, { negativo: true, min: -10, max: 10 });
    return { ...o, text: 'Qual é o OPOSTO (simétrico) do número A?', image: svgURI(retaInteirosSVG([[a, 'A']])), meta: { a, modo: 'op' }, chave: 'om' + a };
  }
  if(n === 2){
    const erradas = [{ v: a < 0 ? a : -a, erro: 'achou que o módulo pode ser negativo' }, { v: Math.abs(a) + 1, erro: 'contou um tracinho a mais' }, { v: Math.abs(a) - 1, erro: 'contou um tracinho a menos' }, { v: 0, erro: 'achou que o módulo é zero' }];
    const o = alternativas(Math.abs(a), erradas, menos, { negativo: true, min: -10, max: 10 });
    return { ...o, text: 'Qual é o MÓDULO do número A? (distância de A até o zero)', image: svgURI(retaInteirosSVG([[a, 'A']])), meta: { a, modo: 'mod' }, chave: 'mm' + a };
  }
  const p = sortearAte(() => [rnd(-9, -1), rnd(1, 9)], v => v[0] % 5 && v[1] % 5);
  const [A, B] = shuffle(p), d = Math.abs(A - B);
  const erradas = [{ v: Math.abs(Math.abs(A) - Math.abs(B)), erro: 'subtraiu sem olhar o sinal' }, { v: d + 1, erro: 'contou os tracinhos em vez dos espaços' }, { v: d - 1, erro: 'esqueceu um espaço' }, { v: Math.max(Math.abs(A), Math.abs(B)), erro: 'contou só até o zero' }];
  const o = alternativas(d, erradas, String, { min: 1 });
  return { ...o, text: 'Qual é a DISTÂNCIA entre os pontos A e B?', image: svgURI(retaInteirosSVG([[A, 'A'], [B, 'B']])), meta: { A, B, modo: 'dist' }, chave: 'md' + A + ',' + B };
};
C.opostoModulo = m => m.modo === 'op' ? menos(-m.a) : m.modo === 'mod' ? String(Math.abs(m.a)) : String(Math.abs(m.A - m.B));

G.variacaoTemp = n => {
  const cai = n === 3 && Math.random() < .5;
  let t0, t1;
  if(n === 1){ t0 = rnd(-6, -1); t1 = rnd(1, 7); }
  else if(n === 2){ t0 = rnd(-12, -1); t1 = sortearAte(() => rnd(-10, 9), v => v > t0 && v !== 0); }
  else { const a = rnd(-12, -1), b = rnd(1, 9); [t0, t1] = cai ? [b, a] : [a, b]; }
  const d = Math.abs(t1 - t0);
  const erradas = [{ v: Math.abs(Math.abs(t1) - Math.abs(t0)), erro: 'subtraiu sem olhar o sinal' }, { v: d + 1, erro: 'contou um grau a mais' }, { v: d - 1, erro: 'contou um grau a menos' }, { v: Math.abs(t1), erro: 'contou só a partir do zero' }];
  const o = alternativas(d, erradas.filter(e => e.v > 0), v => v + ' °C', { min: 1 });
  return { ...o, text: `A temperatura ${cai ? 'CAIU' : 'SUBIU'} de manhã para a noite. Quantos graus ${cai ? 'caiu' : 'subiu'}?`, image: svgURI(termometrosSVG([t0, t1], ['manhã', 'noite'], -15, 10)), meta: { t0, t1 }, chave: `vt${t0},${t1}` };
};
C.variacaoTemp = m => Math.abs(m.t1 - m.t0) + ' °C';

function predioSVG(atual){          // andares −3 a 8, térreo = 0
  const h = 30, top = 10, y = a => top + (8 - a) * h;
  let o = `<rect x="70" y="${y(8)}" width="160" height="${12 * h}" fill="#e2e8f0" stroke="#111" stroke-width="3"/><rect x="40" y="${y(-1)}" width="220" height="3" fill="#78350f"/>` + T(275, y(-1) + 2, 'chão', { fs: 15, anc: 'start', cor: '#78350f' });
  for(let a = 8; a >= -3; a--){
    o += `<line x1="70" y1="${y(a) + h}" x2="230" y2="${y(a) + h}" stroke="#94a3b8" stroke-width="1.5"/>` + T(58, y(a) + 21, a === 0 ? 'T (0)' : menos(a), { fs: 17, anc: 'end', cor: a < 0 ? '#b91c1c' : '#111' });
    if(a < 0) o += `<rect x="72" y="${y(a) + 2}" width="156" height="${h - 3}" fill="#cbd5e1" opacity=".6"/>`;
  }
  const ya = y(atual) + h / 2;
  o += `<circle cx="150" cy="${ya - 6}" r="6" fill="#f59e0b" stroke="#111" stroke-width="2"/><line x1="150" y1="${ya}" x2="150" y2="${ya + 10}" stroke="#111" stroke-width="3"/>` + `<rect x="120" y="${y(atual) + 2}" width="60" height="${h - 3}" fill="none" stroke="#dc2626" stroke-width="3"/>`;
  return SVG(330, 12 * h + 24, o);
}
G.elevador = n => {
  if(n < 3){
    const ini = n === 1 ? rnd(-3, 2) : rnd(-3, 8), sobe = n === 1 ? true : Math.random() < .5;
    const k = sortearAte(() => rnd(2, 8), v => { const f = sobe ? ini + v : ini - v; return f >= -3 && f <= 8 && (ini < 0 || f < 0); });
    const fim = sobe ? ini + k : ini - k;
    const erradas = [{ v: sobe ? ini - k : ini + k, erro: 'andou para o lado errado' }, { v: fim + (sobe ? 1 : -1), erro: (ini < 0) !== (fim < 0) ? 'pulou o térreo (0) na contagem' : 'contou um andar a mais' }, { v: -fim, erro: 'errou o sinal' }, { v: Math.abs(ini) + k, erro: 'ignorou o sinal do andar' }];
    const o = alternativas(fim, erradas.filter(e => e.v >= -3 && e.v <= 12), menos, { negativo: true, min: -10, max: 15 });
    return { ...o, text: `O elevador está no andar ${ini === 0 ? 'T (0)' : menos(ini)} e ${sobe ? 'SOBE' : 'DESCE'} ${k} andares. Em que andar ele para?`, image: svgURI(predioSVG(ini)), meta: { ini, k, sobe, modo: 'para' }, chave: `el${ini}${sobe ? '+' : '-'}${k}` };
  }
  const a = rnd(-3, -1), b = rnd(1, 8), [ini, fim] = Math.random() < .5 ? [a, b] : [b, a];
  const d = Math.abs(fim - ini);
  const erradas = [{ v: Math.abs(Math.abs(fim) - Math.abs(ini)), erro: 'subtraiu sem olhar o sinal' }, { v: d - 1, erro: 'esqueceu de contar o térreo (0)' }, { v: d + 1, erro: 'contou um andar a mais' }, { v: Math.abs(fim), erro: 'contou só a partir do térreo' }];
  const o = alternativas(d, erradas.filter(e => e.v > 0), String, { min: 1 });
  return { ...o, text: `O elevador saiu do andar ${menos(ini)} e foi até o andar ${menos(fim)}. Quantos andares ${fim > ini ? 'subiu' : 'desceu'}?`, image: svgURI(predioSVG(ini)), meta: { ini, fim, modo: 'quantos' }, chave: `eq${ini},${fim}` };
};
C.elevador = m => m.modo === 'para' ? menos(m.sobe ? m.ini + m.k : m.ini - m.k) : String(Math.abs(m.fim - m.ini));
