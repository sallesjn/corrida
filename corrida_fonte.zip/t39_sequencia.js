/* =========================================================================
   PEDRAS DE PROTEÇÃO DA SEQUÊNCIA (🔥 acertos seguidos)
   · Antes: 1 erro (ou tempo esgotado) zerava a sequência.
   · Agora o aluno começa a partida com 3 pedras 💎. Cada erro gasta 1 pedra e a
     sequência NÃO zera. Sem pedra, o erro zera a sequência como antes.
   · A cada 10 acertos seguidos DE VERDADE (sem erro no meio) uma pedra volta,
     até no máximo 3.
   · Pontos, nível, trilha e relatório não mudam: só o contador da sequência.
   Bloco novo: wrappers de app.localAnswer e app.localTimeout.
========================================================================= */
REGRA.pedrasMax = 3;             // pedras no começo da partida e no máximo
REGRA.pedraRegenera = 10;        // acertos seguidos (sem erro) para recuperar 1 pedra
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .pp-stats .streak .seq-pedras{margin-left:6px;font-size:.8em;letter-spacing:1px;white-space:nowrap}
  .pp-stats .streak .seq-pedras i{font-style:normal;filter:grayscale(1);opacity:.35}
  .pp-stats .streak.seq-risco b{color:#fca5a5}
  .seq-pedra-anim{animation:seqPedra .6s ease}
  @keyframes seqPedra{0%{transform:scale(1)}40%{transform:scale(1.5)}100%{transform:scale(1)}}`;
  document.head.appendChild(st);

  function pedrasDe(s){
    if(s.pedras == null){ s.pedras = REGRA.pedrasMax; s.acSeg = 0; }   // partida nova
    return s.pedras;
  }
  function marca(s, anima){
    const it = document.querySelector('#playerPlay .pp-stats .streak'); if(!it) return;
    let e = it.querySelector('.seq-pedras');
    if(!e){ e = document.createElement('span'); e.className = 'seq-pedras'; it.appendChild(e); }
    const p = pedrasDe(s), falta = REGRA.pedraRegenera - (s.acSeg || 0) % REGRA.pedraRegenera;
    e.innerHTML = '💎'.repeat(p) + '<i>💎</i>'.repeat(Math.max(0, REGRA.pedrasMax - p));
    e.title = `Pedras de proteção: cada erro gasta 1 e a sequência não zera.` + (p < REGRA.pedrasMax ? ` Faltam ${falta} acertos seguidos para recuperar 1.` : '');
    it.classList.toggle('seq-risco', p === 0 && s.curStreak > 0);
    if(anima){ e.classList.remove('seq-pedra-anim'); void e.offsetWidth; e.classList.add('seq-pedra-anim'); }
  }
  function aviso(txt){
    document.querySelectorAll('.tr-banner').forEach(x => x.remove());
    const b = document.createElement('div'); b.className = 'tr-banner'; b.innerHTML = txt;
    document.body.appendChild(b); setTimeout(() => b.remove(), 2200);
  }
  function embrulha(nome){
    const f0 = app[nome];
    app[nome] = function(){
      const s = this.player && this.player.stats;
      if(!s) return f0.apply(this, arguments);
      pedrasDe(s);
      const seqAntes = s.curStreak || 0, errAntes = (s.wrong || 0) + (s.timeouts || 0), okAntes = s.correct || 0;
      const r = f0.apply(this, arguments);
      try{
        const errou = (s.wrong || 0) + (s.timeouts || 0) > errAntes, acertou = (s.correct || 0) > okAntes;
        let anima = false;
        if(acertou){
          s.acSeg = (s.acSeg || 0) + 1;
          if(s.acSeg % REGRA.pedraRegenera === 0 && s.pedras < REGRA.pedrasMax){
            s.pedras++; anima = true;
            aviso(`💎 Pedra recuperada! (${REGRA.pedraRegenera} acertos seguidos)`);
          }
        } else if(errou){
          s.acSeg = 0;
          if(seqAntes > 0 && s.pedras > 0){
            s.pedras--; anima = true;
            s.curStreak = seqAntes;                                        // a pedra segura a sequência
            $('ppStreak').textContent = s.curStreak;
            aviso(s.pedras ? `💎 A pedra protegeu sua sequência! (🔥 ${seqAntes}) · restam ${s.pedras}` : `💎 Última pedra usada! (🔥 ${seqAntes}) · o próximo erro zera`);
          }
        }
        marca(s, anima);
      }catch(e){}
      return r;
    };
  }
  embrulha('localAnswer');
  embrulha('localTimeout');
  // mostra as 3 pedras já no começo da partida
  let ultS = null;
  setInterval(() => { try{ const s = app.player && app.player.stats; if(s && app.mode !== 'teacher' && (s !== ultS || !document.querySelector('#playerPlay .pp-stats .seq-pedras'))){ ultS = s; marca(s); } }catch(e){} }, 500);
})();
