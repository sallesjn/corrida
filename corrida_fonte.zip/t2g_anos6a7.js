
/* =========================================================================
   LOTE 4 — o que faltava do currículo SEDU 2026: 6º e 7º ano
========================================================================= */
const sDec = v => (v < 0 ? '−' : '') + fmtDec(Math.round(Math.abs(v) * 1000) / 1000);     // decimal com sinal
function opcoesSinal(v, erradas, f = sDec, passo = 0.1){       // alternativas numéricas com sinal (compara pelo valor)
  const itens = [{ v, erro: null }], vistos = new Set([f(v)]);
  shuffle(erradas).forEach(e => { if(itens.length < 4 && e && Number.isFinite(e.v) && !vistos.has(f(e.v)) && Math.abs(e.v - v) > 1e-9){ vistos.add(f(e.v)); itens.push(e); } });
  for(let k = 1; itens.length < 4; k++){ for(const s of [1, -1]){ const x = Math.round((v + s * (k + 1) * passo) * 1000) / 1000; if(itens.length < 4 && !vistos.has(f(x))){ vistos.add(f(x)); itens.push({ v: x, erro: 'outro valor' }); } } }
  const sh = shuffle(itens);
  return { options: sh.map(i => f(i.v)), correct: sh.findIndex(i => i.erro === null), erros: sh.map(i => i.erro), answer: f(v) };
}
const r3 = x => Math.round(x * 1000) / 1000;

/* ============================ 6º ANO ============================ */

/* Operações com decimais (EF06MA11) */
G.decOps6 = n => {
  if(n === 1){
    const sub = Math.random() < .5, casasA = rnd(1, 2), casasB = casasA === 1 ? 2 : 1;
    let A = rnd(11, 99) * (casasA === 1 ? 10 : 1), B = rnd(11, 99) * (casasB === 1 ? 10 : 1);      // em centésimos
    if(sub && B > A) [A, B] = [B, A];
    const v = (sub ? A - B : A + B) / 100;
    const semAlinhar = (sub ? Math.abs(A / (casasA === 1 ? 10 : 1) - B / (casasB === 1 ? 10 : 1)) : A / (casasA === 1 ? 10 : 1) + B / (casasB === 1 ? 10 : 1)) / 100;
    const erradas = [{ v: semAlinhar, erro: 'não alinhou as vírgulas' }, { v: r3(v + .1), erro: 'errou os décimos' }, { v: r3(v - .1), erro: 'errou os décimos' }, { v: r3(v * 10), erro: 'errou a vírgula' }, { v: r3(v + 1), erro: 'errou a parte inteira' }];
    const o = opcoesDecimaisTR(v, erradas.filter(e => e.v > 0), fmtDec);
    return { ...o, text: `${fmtDec(A / 100)} ${sub ? '−' : '+'} ${fmtDec(B / 100)} = ?`, meta: { A, B, sub, modo: 'as' }, chave: `do${A}${sub ? '-' : '+'}${B}` };
  }
  if(n === 2){
    const pot = Math.random() < .35;
    if(pot){ const A = rnd(11, 999), k = pick([10, 100]); const v = A * k / 100;
      const o = opcoesDecimaisTR(v, [{ v: A / 100 / k, erro: 'andou a vírgula para o lado errado' }, { v: A * (k === 10 ? 100 : 10) / 100, erro: 'andou casas demais' }, { v: A / 100 + k, erro: 'somou em vez de multiplicar' }, { v: r3(A / 100 * k / 10), erro: 'andou casas de menos' }].filter(e => e.v > 0), fmtDec);
      return { ...o, text: `${fmtDec(A / 100)} × ${k} = ?`, meta: { A, k, modo: 'x10' }, chave: `dx${A}x${k}` }; }
    const A = rnd(11, 99) * pick([1, 10]), k = rnd(2, 9), v = r3(A * k / 100);
    const erradas = [{ v: r3(A * k / 1000), erro: 'errou a vírgula' }, { v: r3(A * k / 10), erro: 'errou a vírgula' }, { v: Math.floor(A / 100) * k + (A % 100) / 100, erro: 'multiplicou só a parte inteira' }, { v: r3(v + k / 10), erro: 'errou a conta' }];
    const o = opcoesDecimaisTR(v, erradas.filter(e => e.v > 0), fmtDec);
    return { ...o, text: `${fmtDec(A / 100)} × ${k} = ?`, meta: { A, k, modo: 'xn' }, chave: `dm${A}x${k}` };
  }
  if(Math.random() < .4){
    const a = pick([1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12]), v = r3((a / 10) ** 2);
    const erradas = [{ v: r3(a * a / 10), erro: 'esqueceu que décimo × décimo dá centésimo' }, { v: r3(2 * a / 10), erro: 'multiplicou por 2 em vez de elevar ao quadrado' }, { v: r3(a * a / 1000), erro: 'errou a vírgula' }, { v: r3(a / 10), erro: 'não elevou' }];
    const o = opcoesDecimaisTR(v, erradas.filter(e => e.v > 0), fmtDec);
    return { ...o, text: `(${fmtDec(a / 10)})² = ?`, meta: { a, modo: 'pot' }, chave: `dp${a}` };
  }
  const k = rnd(2, 9), q = rnd(11, 99), A = q * k;             // A/10 ÷ k = q/10  (exato)
  const v = q / 10;
  const erradas = [{ v: q, erro: 'esqueceu a vírgula' }, { v: q / 100, erro: 'errou a vírgula' }, { v: r3(v + 1), erro: 'errou a parte inteira' }, { v: r3(A / 10 - k), erro: 'subtraiu em vez de dividir' }];
  const o = opcoesDecimaisTR(v, erradas.filter(e => e.v > 0), fmtDec);
  return { ...o, text: `${fmtDec(A / 10)} ÷ ${k} = ?`, meta: { A, k, modo: 'div' }, chave: `dd${A}/${k}` };
};
C.decOps6 = m => {
  if(m.modo === 'as') return fmtDec((m.sub ? m.A - m.B : m.A + m.B) / 100);
  if(m.modo === 'x10' || m.modo === 'xn') return fmtDec(r3(m.A * m.k / 100));
  if(m.modo === 'pot') return fmtDec(r3(m.a * m.a / 100));
  return fmtDec(r3(m.A / m.k / 10));
};

/* Números romanos (EF06MA02/ES) */
const ROM = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
const romano = v => { let s = ''; for(const [a, r] of ROM) while(v >= a){ s += r; v -= a; } return s; };
const somaSimbolos = s => [...s].reduce((t, c) => t + ({ I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 })[c], 0);   // erro típico: somar tudo
G.romanos6 = n => {
  const max = n === 1 ? 20 : n === 2 ? 100 : 2100;
  const v = sortearAte(() => rnd(n === 3 ? 40 : 4, max), x => /IV|IX|XL|XC|CD|CM/.test(romano(x)));      // sempre com um "menor antes do maior"
  const r = romano(v);
  if(n === 3 && Math.random() < .5){
    const aditivo = v.toString().split('').reverse().map((d, i) => { const u = ['I', 'X', 'C', 'M'][i], c = ['V', 'L', 'D', ''][i]; d = +d; return (d >= 5 ? c : '') + u.repeat(d % 5); }).reverse().join('');
    const troca = r.replace(/IV|IX|XL|XC|CD|CM/, t => t[1] + t[0]);
    const erradas = [{ v: aditivo, erro: 'repetiu o símbolo 4 vezes (não pode)' }, { v: troca, erro: 'trocou a ordem (menor antes do maior subtrai)' }, { v: romano(v + 10), erro: 'errou as dezenas' }, { v: romano(v - 1), erro: 'errou as unidades' }];
    const a = alternativas(r, erradas.filter(e => e.v && e.v !== r), String);
    return { ...a, text: `Como se escreve ${v} em algarismos romanos?`, meta: { v, modo: 'escrever' }, chave: 'ro' + v };
  }
  const erradas = [{ v: somaSimbolos(r), erro: 'somou tudo (o menor antes do maior subtrai)' }, { v: v + 1, erro: 'errou as unidades' }, { v: v - 1, erro: 'errou as unidades' }, { v: v + 10, erro: 'errou as dezenas' }];
  const a = alternativas(v, erradas.filter(e => e.v !== v), String, { min: 1 });
  return { ...a, text: `Qual número é ${r}?`, meta: { v, modo: 'ler' }, chave: 'rl' + v };
};
C.romanos6 = m => {
  if(m.modo === 'ler') return String(m.v);
  const U = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX'], D = ['', 'X', 'XX', 'XXX', 'XL', 'L', 'LX', 'LXX', 'LXXX', 'XC'], Ce = ['', 'C', 'CC', 'CCC', 'CD', 'D', 'DC', 'DCC', 'DCCC', 'CM'];
  return 'M'.repeat(Math.floor(m.v / 1000)) + Ce[Math.floor(m.v / 100) % 10] + D[Math.floor(m.v / 10) % 10] + U[m.v % 10];
};

/* Prismas e pirâmides pela base (EF06MA17) */
const BASE_NOME = { 3: 'triangular', 4: 'quadrangular', 5: 'pentagonal', 6: 'hexagonal', 8: 'octogonal' };
function solidoBaseSVG(tipo, nb){
  const cx = 170, R = 120, r = 38, yB = 240, yT = 70, off = Math.PI / nb / 2 + .15;
  const P = [...Array(nb).keys()].map(k => { const t = 2 * Math.PI * k / nb + off; return [cx + R * Math.cos(t), r * Math.sin(t), Math.sin(t)]; });
  const bas = P.map(([x, y, s]) => [x, yB + y, s]);
  let o = '';
  const seg = (a, b, tr) => `<line x1="${a[0].toFixed(1)}" y1="${a[1].toFixed(1)}" x2="${b[0].toFixed(1)}" y2="${b[1].toFixed(1)}" stroke="#111" stroke-width="${tr ? 2 : 3.5}" ${tr ? 'stroke-dasharray="7,6"' : ''}/>`;
  const xs = P.map(p => p[0]), xMin = Math.min(...xs), xMax = Math.max(...xs);
  const tras = (s, x) => s < -0.2 && (x === undefined || (x > xMin + 1 && x < xMax - 1));      // contorno (mais à esquerda/direita) nunca fica tracejado
  if(tipo === 'prisma'){
    const top = P.map(([x, y, s]) => [x, yT + y, s]);
    o += `<polygon points="${top.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ')}" fill="#bfdbfe" stroke="none"/>`;
    for(let i = 0; i < nb; i++){ const j = (i + 1) % nb; o += seg(bas[i], bas[j], (bas[i][2] + bas[j][2]) / 2 < -0.05) + seg(top[i], top[j], false) + seg(bas[i], top[i], tras(bas[i][2], bas[i][0])); }
  } else {
    const ap = [cx, yT - 20];
    for(let i = 0; i < nb; i++){ const j = (i + 1) % nb; o += seg(bas[i], bas[j], (bas[i][2] + bas[j][2]) / 2 < -0.05) + seg(bas[i], ap, tras(bas[i][2], bas[i][0])); }
  }
  return SVG(340, 290, o);
}
G.prismas6 = n => {
  const nb = pick(n === 1 ? [3, 4] : n === 2 ? [3, 4, 5, 6] : [5, 6, 8]), tipo = pick(['prisma', 'pirâmide']);
  const qual = pick(n === 1 ? ['faces', 'vértices'] : ['faces', 'vértices', 'arestas']);
  const F = tipo === 'prisma' ? nb + 2 : nb + 1, V = tipo === 'prisma' ? 2 * nb : nb + 1, A = tipo === 'prisma' ? 3 * nb : 2 * nb;
  const val = { faces: F, 'vértices': V, arestas: A }[qual];
  const outro = { faces: tipo === 'prisma' ? nb + 1 : nb + 2, 'vértices': tipo === 'prisma' ? nb + 1 : 2 * nb, arestas: tipo === 'prisma' ? 2 * nb : 3 * nb }[qual];
  const erradas = [{ v: outro, erro: tipo === 'prisma' ? 'usou a regra da pirâmide' : 'usou a regra do prisma' }, { v: nb, erro: 'contou só a base' }, { v: val - 1, erro: 'esqueceu um(a) escondido(a)' }, { v: val + 1, erro: 'contou um(a) a mais' }, { v: val - nb, erro: 'contou só o que aparece' }];
  const a = alternativas(val, erradas.filter(e => e.v > 0 && e.v !== val), String, { min: 1 });
  return { ...a, text: `Quantas ${qual} tem ${tipo === 'prisma' ? 'este prisma' : 'esta pirâmide'} de base ${BASE_NOME[nb]}?`, image: svgURI(solidoBaseSVG(tipo, nb)), meta: { tipo, nb, qual }, chave: `ps${tipo}${nb}${qual}` };
};
C.prismas6 = m => {           // monta a lista de vértices e arestas e conta; faces pela relação de Euler
  const n = m.nb, pr = m.tipo === 'prisma';
  const V = pr ? 2 * n : n + 1;
  const arestas = new Set(); for(let i = 0; i < n; i++){ arestas.add('b' + i); if(pr){ arestas.add('t' + i); arestas.add('v' + i); } else arestas.add('l' + i); }
  const A = arestas.size, F = 2 - V + A;
  return String({ faces: F, 'vértices': V, arestas: A }[m.qual]);
};

/* Paralelas, perpendiculares e concorrentes (EF06MA22) */
function retasSVG(d1, d2, p1, p2, malha, marca){
  const W = 360, H = 280; let o = '';
  if(malha){ for(let x = 0; x <= W; x += 30) o += `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="#e2e8f0" stroke-width="1.5"/>`; for(let y = 0; y <= H; y += 30) o += `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="#e2e8f0" stroke-width="1.5"/>`; }
  const reta = (d, p, cor, rot) => { const L = 600, l = Math.hypot(...d); const u = [d[0] / l, d[1] / l]; return `<line x1="${p[0] - u[0] * L}" y1="${p[1] - u[1] * L}" x2="${p[0] + u[0] * L}" y2="${p[1] + u[1] * L}" stroke="${cor}" stroke-width="4"/>` + T(p[0] + u[0] * 110 + 14, p[1] + u[1] * 110 - 8, rot, { fs: 24, cor }); };
  o += reta(d1, p1, '#1d4ed8', 'r') + reta(d2, p2, '#dc2626', 's');
  if(marca) o += marca;
  return SVG(W, H, o);
}
G.paralPerp6 = n => {
  const tipo = pick(['paralelas', 'perpendiculares', 'concorrentes']);
  let d1, d2, p1 = [180, 110], p2 = [180, 170], marca = '', malha = n === 3;
  if(n === 3){
    const base = pick([[1, 2], [2, 1], [1, 1], [3, 1], [1, 3], [2, 3]]);
    d1 = base; d2 = tipo === 'paralelas' ? base : tipo === 'perpendiculares' ? [-base[1], base[0]] : sortearAte(() => [rnd(1, 3), rnd(-3, 3)], v => v[0] * base[1] - v[1] * base[0] !== 0 && v[0] * base[0] + v[1] * base[1] !== 0);
    p1 = [150, 120]; p2 = tipo === 'paralelas' ? [210, 150] : [150, 120];
    if(tipo === 'paralelas'){ p2 = [150 + 60 * (-base[1]) / Math.hypot(...base) * 0 + 90, 120]; }
  } else {
    const g = n === 1 ? 0 : rnd(10, 60), rad = g * Math.PI / 180, ang = tipo === 'perpendiculares' ? 90 : tipo === 'concorrentes' ? pick([40, 55, 65, 120, 135]) : 0;
    d1 = [Math.cos(rad), Math.sin(rad)]; d2 = [Math.cos(rad + ang * Math.PI / 180), Math.sin(rad + ang * Math.PI / 180)];
    if(tipo === 'paralelas'){ p1 = [180, 100]; p2 = [180 - Math.sin(rad) * 0, 180]; }
    else { p1 = p2 = [180, 140]; const a1 = Math.atan2(d1[1], d1[0]), a2 = Math.atan2(d2[1], d2[0]);
      if(tipo === 'perpendiculares'){ const k = 18, q1 = [180 + d1[0] * k, 140 + d1[1] * k], q2 = [180 + d2[0] * k, 140 + d2[1] * k], q3 = [q1[0] + d2[0] * k, q1[1] + d2[1] * k];
        marca = `<polyline points="${[q1, q3, q2].map(q => q.map(v => v.toFixed(1)).join(',')).join(' ')}" fill="none" stroke="#111" stroke-width="2.5"/>`; }
      else { const R = 40, x1 = 180 + R * Math.cos(a1), y1 = 140 + R * Math.sin(a1), x2 = 180 + R * Math.cos(a2), y2 = 140 + R * Math.sin(a2), m = (a1 + a2) / 2;
        marca = `<path d="M${x1.toFixed(1)} ${y1.toFixed(1)} A${R} ${R} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}" fill="none" stroke="#111" stroke-width="2.5"/>` + T(180 + 66 * Math.cos(m), 140 + 66 * Math.sin(m) + 7, ang + '°', { fs: 20 }); } }
  }
  const nomes = { paralelas: 'paralelas', perpendiculares: 'perpendiculares', concorrentes: 'concorrentes, mas não perpendiculares' };
  const erradas = Object.keys(nomes).filter(t => t !== tipo).map(t => ({ v: nomes[t], erro: tipo === 'concorrentes' && t === 'perpendiculares' ? 'achou que todo cruzamento é de 90°' : 'confundiu os tipos de retas' })).concat([{ v: 'coincidentes (a mesma reta)', erro: 'confundiu com retas coincidentes' }]);
  const a = alternativas(nomes[tipo], erradas, String);
  return { ...a, text: malha ? 'Olhe a malha: as retas r e s são…' : 'As retas r e s são…', image: svgURI(retasSVG(d1, d2, p1, p2, malha, marca)), meta: { d1, d2, tipo }, chave: 'pp' + tipo + d1.map(v => v.toFixed(2)) + d2.map(v => v.toFixed(2)) };
};
C.paralPerp6 = m => { const cr = m.d1[0] * m.d2[1] - m.d1[1] * m.d2[0], dt = m.d1[0] * m.d2[0] + m.d1[1] * m.d2[1];
  return Math.abs(cr) < 1e-9 ? 'paralelas' : Math.abs(dt) < 1e-9 ? 'perpendiculares' : 'concorrentes, mas não perpendiculares'; };

/* Ângulo como giro e no relógio (EF06MA25 · EF06MA26) */
G.giro6 = n => {
  if(n === 1){
    const [a, b] = pick([[1, 4], [1, 2], [3, 4], [1, 1], [1, 8], [1, 3]]), g = 360 * a / b;
    const R = 110, cx = 140, cy = 140, t = g * Math.PI / 180;
    const setor = g >= 360 ? `<circle cx="${cx}" cy="${cy}" r="${R}" fill="#fde68a"/>` : `<path d="M${cx} ${cy} L${cx} ${cy - R} A${R} ${R} 0 ${g > 180 ? 1 : 0} 1 ${(cx + R * Math.sin(t)).toFixed(1)} ${(cy - R * Math.cos(t)).toFixed(1)} Z" fill="#fde68a"/>`;
    const img = SVG(280, 280, `<circle cx="${cx}" cy="${cy}" r="${R}" fill="#fff" stroke="#111" stroke-width="3"/>` + setor + `<line x1="${cx}" y1="${cy}" x2="${cx}" y2="${cy - R}" stroke="#111" stroke-width="4"/><circle cx="${cx}" cy="${cy}" r="6" fill="#111"/>`);
    const erradas = [{ v: 100 * a / b, erro: 'achou que a volta tem 100°' }, { v: 180 * a / b, erro: 'achou que a volta tem 180°' }, { v: 90 * a, erro: 'contou só os quartos' }, { v: 360 / b, erro: 'esqueceu o numerador' }, { v: g + 90, erro: 'contou um quarto a mais' }];
    const aa = alternativas(g, erradas.filter(e => Number.isInteger(e.v) && e.v !== g), v => v + '°', { min: 1 });
    return { ...aa, text: b === 1 ? 'Quantos graus tem uma volta inteira?' : `Quantos graus tem ${a}/${b} de volta?`, image: svgURI(img), meta: { a, b, modo: 'volta' }, chave: `gv${a}/${b}` };
  }
  const h = rnd(1, 11), m = n === 2 ? 0 : 30;
  const bruto = Math.abs(30 * h + m * 0.5 - 6 * m), ang = Math.min(bruto, 360 - bruto);
  const erradas = [{ v: 360 - ang, erro: 'mediu o ângulo maior' }, { v: m ? Math.abs(30 * h - 180) === ang ? null : Math.min(Math.abs(30 * h - 180), 360 - Math.abs(30 * h - 180)) : null, erro: 'esqueceu que o ponteiro das horas anda' }, { v: ang + 30, erro: 'contou uma hora a mais' }, { v: ang - 30 > 0 ? ang - 30 : null, erro: 'contou uma hora a menos' }, { v: h * 5, erro: 'contou minutos, não graus' }];
  const aa = alternativas(ang, erradas.filter(e => e.v && e.v !== ang), v => v + '°', { min: 1, passo: 15 });
  return { ...aa, text: `Qual o MENOR ângulo entre os ponteiros às ${fmtH(h, m)}? (cada hora = 30°)`, image: svgURI(relogio(h, m)), meta: { h, m, modo: 'relogio' }, chave: `gr${h}:${m}` };
};
C.giro6 = m => { if(m.modo === 'volta') return (360 * m.a / m.b) + '°'; const ph = (m.h % 12) * 30 + m.m / 2, pm = m.m * 6; let d = Math.abs(ph - pm); if(d > 180) d = 360 - d; return d + '°'; };

/* Planta baixa com escala (EF06MA28) */
G.escala6 = n => {
  const f = n === 1 ? 1 : pick([2, 3]), w = rnd(2, 5), h = rnd(2, 4), u = 44;
  const comodo = pick(['Sala', 'Quarto', 'Cozinha']);
  const outroW = rnd(2, 3);
  const X0 = 20, Y0 = 50;
  let o = T(10, 30, `Escala: 1 cm no desenho = ${f} m de verdade`, { fs: 19, anc: 'start', cor: '#1d4ed8' });
  o += `<rect x="${X0}" y="${Y0}" width="${(w + outroW) * u}" height="${h * u}" fill="#fff" stroke="#111" stroke-width="5"/><line x1="${X0 + w * u}" y1="${Y0}" x2="${X0 + w * u}" y2="${Y0 + h * u}" stroke="#111" stroke-width="4"/>`;
  o += `<rect x="${X0 + 2}" y="${Y0 + 2}" width="${w * u - 4}" height="${h * u - 4}" fill="#fef3c7"/>` + T(X0 + w * u / 2, Y0 + h * u / 2 + 8, comodo, { fs: 22 }) + T(X0 + (w + outroW / 2) * u, Y0 + h * u / 2 + 8, 'Banheiro', { fs: 16, fw: 'normal' });
  o += T(X0 + w * u / 2, Y0 + h * u + 30, w + ' cm', { fs: 20, cor: '#b91c1c' }) + T(X0 - 6 + (w + outroW) * u + 50, Y0 + h * u / 2 + 8, h + ' cm', { fs: 20, cor: '#b91c1c' });
  const img = svgURI(SVG(Math.max((w + outroW) * u + 110, 470), Y0 + h * u + 50, o));
  if(n < 3){
    const v = w * f;
    const erradas = [{ v: w, erro: 'esqueceu a escala' }, { v: w + f, erro: 'somou em vez de multiplicar' }, { v: h * f, erro: 'mediu o outro lado' }, { v: w * f * 10, erro: 'confundiu as unidades' }];
    const a = alternativas(v, erradas.filter(e => e.v !== v), x => x + ' m', { min: 1 });
    return { ...a, text: `Qual é o comprimento REAL da ${comodo.toLowerCase()} (o lado de ${w} cm)?`, image: img, meta: { w, h, f, modo: 'lado' }, chave: `es${w}x${h}f${f}` };
  }
  const A = w * f * h * f;
  const erradas = [{ v: w * h, erro: 'calculou com as medidas do desenho' }, { v: w * h * f, erro: 'aplicou a escala só uma vez' }, { v: 2 * (w + h) * f, erro: 'calculou o perímetro' }, { v: A + w * f, erro: 'errou a conta' }];
  const a = alternativas(A, erradas.filter(e => e.v !== A), x => x + ' m²', { min: 1 });
  return { ...a, text: `Qual é a ÁREA REAL da ${comodo.toLowerCase()}?`, image: img, meta: { w, h, f, modo: 'area' }, chave: `ea${w}x${h}f${f}` };
};
C.escala6 = m => m.modo === 'lado' ? (m.w * m.f) + ' m' : (m.w * m.f) * (m.h * m.f) + ' m²';

/* Vértices no plano cartesiano — 1º quadrante (EF06MA16/ES) */
function plano1QSVG(pts, max = 8){
  const s = 38, x0 = 40, y0 = 20 + max * s, X = v => x0 + v * s, Y = v => y0 - v * s;
  let o = '';
  for(let i = 0; i <= max; i++){ o += `<line x1="${X(i)}" y1="${Y(0)}" x2="${X(i)}" y2="${Y(max)}" stroke="#e2e8f0" stroke-width="1.5"/><line x1="${X(0)}" y1="${Y(i)}" x2="${X(max)}" y2="${Y(i)}" stroke="#e2e8f0" stroke-width="1.5"/>` + T(X(i), y0 + 24, i, { fs: 16, fw: 'normal' }) + (i ? T(x0 - 14, Y(i) + 6, i, { fs: 16, fw: 'normal' }) : ''); }
  o += `<line x1="${X(0)}" y1="${Y(0)}" x2="${X(max) + 12}" y2="${Y(0)}" stroke="#111" stroke-width="3"/><line x1="${X(0)}" y1="${Y(0)}" x2="${X(0)}" y2="${Y(max) - 12}" stroke="#111" stroke-width="3"/>` + T(X(max) + 20, Y(0) + 6, 'x', { fs: 18 }) + T(X(0), Y(max) - 18, 'y', { fs: 18 });
  pts.forEach((p, i) => { const q = pts[(i + 1) % pts.length]; if(pts.length > 1 && !p[3] && !q[3]) o += `<line x1="${X(p[0])}" y1="${Y(p[1])}" x2="${X(q[0])}" y2="${Y(q[1])}" stroke="#1d4ed8" stroke-width="3"/>`; });   // só os lados entre vértices que aparecem
  pts.forEach(([x, y, r, oculto]) => { if(!oculto) o += `<circle cx="${X(x)}" cy="${Y(y)}" r="7" fill="#dc2626"/>` + T(X(x) + 14, Y(y) - 10, r, { fs: 20, cor: '#dc2626' }); });
  return SVG(X(max) + 40, y0 + 40, o);
}
G.vertices6 = n => {
  const x1 = rnd(1, 4), y1 = rnd(1, 3), w = rnd(2, 4), h = rnd(2, 4);
  let V = [[x1, y1], [x1 + w, y1], [x1 + w, y1 + h], [x1, y1 + h]];
  if(n === 3){ const s = rnd(1, 2); V = [[x1, y1], [x1 + w, y1], [x1 + w + s, y1 + h], [x1 + s, y1 + h]]; }     // paralelogramo
  const falta = n === 1 ? 3 : rnd(0, 3), rot = ['A', 'B', 'C', 'D'];
  const pts = V.map((p, i) => [p[0], p[1], rot[i], i === falta]);
  const D = V[falta], fmt = p => `(${p[0]}, ${p[1]})`;
  const erradas = [{ v: fmt([D[1], D[0]]), erro: 'trocou x com y' }, { v: fmt(V[(falta + 2) % 4]), erro: 'deu as coordenadas de outro vértice' }, { v: fmt([D[0] + 1, D[1]]), erro: 'contou um quadradinho a mais' }, { v: fmt([D[0], D[1] + 1]), erro: 'contou um quadradinho a mais' }];
  const a = alternativas(fmt(D), erradas.filter(e => e.v !== fmt(D)), String);
  return { ...a, text: `A, B, C e D são os vértices de um ${n === 3 ? 'paralelogramo' : 'retângulo'}. Quais são as coordenadas do vértice ${rot[falta]} que falta?`, image: svgURI(plano1QSVG(pts)), meta: { V: V.filter((_, i) => i !== falta), falta }, chave: 'vx' + JSON.stringify(V) + falta };
};
C.vertices6 = m => {     // o vértice que falta: soma dos vizinhos menos o oposto (vale para retângulo e paralelogramo)
  const idx = [0, 1, 2, 3].filter(i => i !== m.falta), P = {}; idx.forEach((i, k) => P[i] = m.V[k]);
  const a = P[(m.falta + 1) % 4], b = P[(m.falta + 3) % 4], op = P[(m.falta + 2) % 4];
  return `(${a[0] + b[0] - op[0]}, ${a[1] + b[1] - op[1]})`;
};

/* O que acontece com perímetro e área do quadrado (EF06MA29) */
G.quadAmplia6 = n => {
  const k = n === 1 ? 2 : n === 2 ? pick([2, 3]) : pick([2, 3, 0.5]);
  const oq = n === 1 ? 'PERÍMETRO' : n === 2 ? 'ÁREA' : pick(['PERÍMETRO', 'ÁREA']);
  const fator = oq === 'ÁREA' ? k * k : k;
  const fmt = f => f === 1 ? 'não muda' : f > 1 ? `fica ${f} vezes maior` : `fica ${1 / f} vezes menor`;
  const erradas = [{ v: oq === 'ÁREA' ? k : k * k, erro: oq === 'ÁREA' ? 'achou que a área muda igual ao lado' : 'achou que o perímetro muda como a área' }, { v: 1, erro: 'achou que não muda' }, { v: k > 1 ? k + 2 : 1 / 3, erro: 'somou em vez de multiplicar' }, { v: k > 1 ? 2 * fator : fator * 2, erro: 'contou demais' }];
  const a = alternativas(fmt(fator), erradas.map(e => ({ v: fmt(e.v), erro: e.erro })).filter(e => e.v !== fmt(fator)), String, { reserva: ['fica 3 vezes maior', 'fica 8 vezes maior', 'fica 6 vezes maior', 'fica 2 vezes menor', 'fica 4 vezes menor'].filter(t => t !== fmt(fator)) });
  const l = 2, L = l * k, s = 26;
  const sq = (x, lado, cor) => { let o = `<rect x="${x}" y="${20 + (6 - lado) * s}" width="${lado * s}" height="${lado * s}" fill="${cor}" stroke="#111" stroke-width="3"/>`; for(let i = 1; i < lado; i++) o += `<line x1="${x + i * s}" y1="${20 + (6 - lado) * s}" x2="${x + i * s}" y2="${20 + 6 * s}" stroke="#111" stroke-width="1" opacity=".4"/><line x1="${x}" y1="${20 + (6 - lado + i) * s}" x2="${x + lado * s}" y2="${20 + (6 - lado + i) * s}" stroke="#111" stroke-width="1" opacity=".4"/>`; return o; };
  const [a1, a2] = k >= 1 ? [l, L] : [4, 2];
  const img = SVG(40 + (a1 + a2) * s + 80, 6 * s + 60, sq(20, a1, '#fde68a') + T(20 + a1 * s / 2, 6 * s + 50, 'antes', { fs: 18 }) + T(40 + a1 * s + 20, 20 + 3 * s, '→', { fs: 32 }) + sq(40 + a1 * s + 50, a2, '#bbf7d0') + T(40 + a1 * s + 50 + a2 * s / 2, 6 * s + 50, 'depois', { fs: 18 }));
  const verbo = k === 2 ? 'DOBROU' : k === 3 ? 'TRIPLICOU' : 'foi reduzido à METADE';
  return { ...a, text: `O lado do quadrado ${verbo}. O que acontece com o ${oq}?`, image: svgURI(img), meta: { k, oq }, chave: `qa${k}${oq}` };
};
C.quadAmplia6 = m => {
  const l0 = 6, l1 = l0 * m.k, v0 = m.oq === 'ÁREA' ? l0 * l0 : 4 * l0, v1 = m.oq === 'ÁREA' ? l1 * l1 : 4 * l1, f = v1 / v0;
  return f === 1 ? 'não muda' : f > 1 ? `fica ${f} vezes maior` : `fica ${1 / f} vezes menor`;
};

/* Partilha em partes proporcionais (EF06MA15) */
G.partilha6 = n => {
  const nomes = shuffle(['Ana', 'Beto', 'Caio', 'Duda', 'Lia', 'Téo']).slice(0, n === 3 ? 3 : 2);
  const razoes = n === 1 ? pick([[1, 2], [2, 3], [1, 3]]) : n === 2 ? pick([[2, 3], [3, 4], [2, 5], [3, 5]]) : pick([[1, 2, 3], [1, 2, 2], [2, 3, 5]]);
  const u = rnd(2, n === 3 ? 6 : 9), tot = razoes.reduce((a, b) => a + b, 0) * u, i = rnd(0, razoes.length - 1), certa = razoes[i] * u;
  const erradas = [{ v: tot / razoes.length, erro: 'dividiu em partes iguais' }, { v: razoes[i] * u + u, erro: 'contou uma parte a mais' }, { v: tot / razoes[i], erro: 'dividiu pelo número da razão' }, { v: razoes[(i + 1) % razoes.length] * u, erro: 'deu a parte de outra pessoa' }];
  const a = alternativas(certa, erradas.filter(e => Number.isInteger(e.v) && e.v !== certa), String, { min: 1 });
  const desc = razoes.length === 2 ? `a cada ${razoes[0]} de ${nomes[0]}, ${nomes[1]} recebe ${razoes[1]}` : `na razão ${razoes.join(' : ')} (${nomes.join(', ')})`;
  return { ...a, text: `${tot} reais foram divididos assim: ${desc}. Quanto recebe ${nomes[i]}?`, image: svgURI(barrasPartilha(nomes, razoes, tot)), meta: { razoes, tot, i }, chave: `p6${razoes.join(':')}${tot}${i}` };
};
C.partilha6 = m => { let s = 0; m.razoes.forEach(r => s += r); return String(m.tot / s * m.razoes[m.i]); };

/* ============================ 7º ANO ============================ */

/* Racionais negativos na reta (EF07MA10) */
function retaRacSVG(min, max, sub, v){
  const W = 560, x0 = 30, L = 500, y = 70, X = t => x0 + (t - min) / (max - min) * L;
  let o = `<line x1="${x0 - 12}" y1="${y}" x2="${x0 + L + 14}" y2="${y}" stroke="#111" stroke-width="3"/><polygon points="${x0 + L + 20},${y} ${x0 + L + 8},${y - 7} ${x0 + L + 8},${y + 7}" fill="#111"/>`;
  for(let i = 0; i <= (max - min) * sub; i++){ const t = min + i / sub, inteiro = i % sub === 0; o += `<line x1="${X(t)}" y1="${y - (inteiro ? 15 : 8)}" x2="${X(t)}" y2="${y + (inteiro ? 15 : 8)}" stroke="#111" stroke-width="${inteiro ? 3.2 : 1.8}"/>`; if(inteiro) o += T(X(t), y + 42, menos(Math.round(t)), { fs: 22 }); }
  o += `<circle cx="${X(v)}" cy="${y}" r="9" fill="#dc2626"/>` + T(X(v), y - 22, 'A', { fs: 26, cor: '#dc2626' });
  return SVG(W, 125, o);
}
G.racNeg7 = n => {
  const sub = n === 1 ? 2 : n === 2 ? 4 : 10, min = n === 3 ? -2 : -3, max = n === 3 ? 1 : 3;
  const v = sortearAte(() => min + rnd(1, (max - min) * sub - 1) / sub, t => t < 0 && Math.abs(t * sub % sub) > 1e-9);
  const passo = 1 / sub;
  const erradas = [{ v: -v, erro: 'errou o sinal' }, { v: r3(v + passo), erro: 'contou um tracinho a menos' }, { v: r3(v - passo), erro: 'contou um tracinho a mais' }, { v: r3(Math.ceil(v) - (v - Math.floor(v))), erro: 'contou a partir do inteiro errado' }];
  const o = opcoesSinal(r3(v), erradas, sDec, passo);
  return { ...o, text: 'Que número está no lugar da letra A?', image: svgURI(retaRacSVG(min, max, sub, v)), meta: { v: r3(v) }, chave: 'rn' + v };
};
C.racNeg7 = m => sDec(m.v);

/* Operações com racionais (EF07MA11 · EF07MA12) */
G.opsRac7 = n => {
  if(n < 3){
    let a, b, op, v;
    if(n === 1){ a = rnd(-40, -5) / 10; b = rnd(5, 40) / 10; if(Math.random() < .5) [a, b] = [b, a]; op = pick(['+', '−']); v = r3(op === '+' ? a + b : a - b); }
    else { a = (Math.random() < .5 ? -1 : 1) * rnd(2, 30) / 10; b = (Math.random() < .5 ? -1 : 1) * rnd(2, 5); op = pick(['×', '÷']); if(op === '÷'){ const q = a; a = r3(q * b); v = r3(q); } else v = r3(a * b); }
    const par = x => x < 0 ? `(${sDec(x)})` : sDec(x);
    const erradas = [{ v: -v, erro: 'errou o sinal' }, { v: op === '+' || op === '−' ? r3(op === '+' ? Math.abs(a) + Math.abs(b) : Math.abs(a) - Math.abs(b)) : r3(op === '×' ? a * b * 10 : v / 10), erro: op === '+' || op === '−' ? 'ignorou os sinais' : 'errou a vírgula' }, { v: r3(v + 1), erro: 'errou a parte inteira' }, { v: r3(v - .1), erro: 'errou os décimos' }];
    const o = opcoesSinal(v, erradas, sDec);
    return { ...o, text: `${par(a)} ${op} ${par(b)} = ?`, meta: { a, b, op }, chave: `or${a}${op}${b}` };
  }
  const d = pick([3, 4, 5, 6, 8]), a = sortearAte(() => rnd(-d * 2, d * 2), x => x !== 0 && x % d !== 0), b = sortearAte(() => rnd(-d * 2, d * 2), x => x !== 0 && x % d !== 0), s = a + b;
  if(s === 0 || (a > 0 && b > 0)) return G.opsRac7(n);          // sempre com pelo menos um negativo
  const fr = x => (x < 0 ? '−' : '') + `${Math.abs(x)}/${d}`;
  const val = x => x / d;
  const cands = [[s, null], [-s, 'errou o sinal'], [Math.abs(a) + Math.abs(b), 'ignorou os sinais'], [s + 1, 'errou a conta'], [s - 1, 'errou a conta'], [a - b, 'subtraiu em vez de somar']];
  const vistos = new Set(), itens = [];
  cands.forEach(([x, e]) => { if(itens.length < 4 && x !== 0 && !vistos.has(x) && !(e && x === s)){ vistos.add(x); itens.push([x, e]); } });
  const emb = shuffle(itens);
  const par = x => x < 0 ? `(${fr(x)})` : fr(x);
  return { options: emb.map(c => fr(c[0])), correct: emb.findIndex(c => c[1] === null), erros: emb.map(c => c[1]), answer: fr(s), text: `${par(a)} + ${par(b)} = ?`, meta: { a, b, d, fr: 1 }, chave: `of${a}+${b}/${d}` };
};
C.opsRac7 = m => {
  if(m.fr){ const s = m.a + m.b; return (s < 0 ? '−' : '') + `${Math.abs(s)}/${m.d}`; }
  const v = m.op === '+' ? m.a + m.b : m.op === '−' ? m.a - m.b : m.op === '×' ? m.a * m.b : m.a / m.b; return sDec(r3(v));
};

/* Transformações no plano (EF07MA19/ES) */
function plano4QSVG(pts, lim = 6){
  const s = 30, c = 20 + lim * s, X = v => c + v * s, Y = v => c - v * s;
  let o = '';
  for(let i = -lim; i <= lim; i++){ o += `<line x1="${X(i)}" y1="${Y(-lim)}" x2="${X(i)}" y2="${Y(lim)}" stroke="#e2e8f0" stroke-width="1.2"/><line x1="${X(-lim)}" y1="${Y(i)}" x2="${X(lim)}" y2="${Y(i)}" stroke="#e2e8f0" stroke-width="1.2"/>`; if(i && i % 2 === 0) o += T(X(i), c + 20, menos(i), { fs: 13, fw: 'normal' }) + T(c - 12, Y(i) + 5, menos(i), { fs: 13, fw: 'normal', anc: 'end' }); }
  o += `<line x1="${X(-lim)}" y1="${c}" x2="${X(lim)}" y2="${c}" stroke="#111" stroke-width="2.5"/><line x1="${c}" y1="${Y(-lim)}" x2="${c}" y2="${Y(lim)}" stroke="#111" stroke-width="2.5"/>` + T(X(lim) - 6, c - 8, 'x', { fs: 16 }) + T(c + 12, Y(lim) + 14, 'y', { fs: 16 });
  pts.forEach(([x, y, r]) => { o += `<circle cx="${X(x)}" cy="${Y(y)}" r="7" fill="#dc2626"/>` + T(X(x) + 13, Y(y) - 9, r, { fs: 20, cor: '#dc2626' }); });
  return SVG(2 * c, 2 * c, o);
}
G.transf7 = n => {
  const x = sortearAte(() => rnd(-5, 5), v => v !== 0), y = sortearAte(() => rnd(-5, 5), v => v !== 0 && Math.abs(v) !== Math.abs(x));
  const tipo = n === 1 ? pick(['tx', 'ty']) : n === 2 ? pick(['transl', 'tx', 'ty']) : pick(['orig', 'transl', 'mult']);
  let dx = 0, dy = 0, R, txt;
  if(tipo === 'tx'){ R = [x, -y]; txt = 'Qual é o simétrico de P em relação ao EIXO x (reflexão no eixo x)?'; }
  else if(tipo === 'ty'){ R = [-x, y]; txt = 'Qual é o simétrico de P em relação ao EIXO y (reflexão no eixo y)?'; }
  else if(tipo === 'orig'){ R = [-x, -y]; txt = 'Multiplicando as coordenadas de P por −1, qual ponto se obtém?'; }
  else if(tipo === 'mult'){ R = [2 * x, 2 * y]; txt = 'Multiplicando as coordenadas de P por 2, qual ponto se obtém?'; }
  else { dx = sortearAte(() => rnd(-4, 4), v => v !== 0); dy = sortearAte(() => rnd(-4, 4), v => v !== 0); R = [x + dx, y + dy]; txt = `Transladando P ${Math.abs(dx)} para a ${dx > 0 ? 'DIREITA' : 'ESQUERDA'} e ${Math.abs(dy)} para ${dy > 0 ? 'CIMA' : 'BAIXO'}, onde ele fica?`; }
  const f = p => `(${menos(p[0])}, ${menos(p[1])})`;
  const erradas = [{ v: f([-x, y]), erro: 'refletiu no eixo errado' }, { v: f([x, -y]), erro: 'refletiu no eixo errado' }, { v: f([-x, -y]), erro: 'trocou os dois sinais' }, { v: f([y, x]), erro: 'trocou x com y' }, { v: f([x - dx, y - dy]), erro: 'andou para o lado contrário' }, { v: f([x + dy, y + dx]), erro: 'trocou os deslocamentos' }];
  // (o sinal de menos conta: por isso compara o texto exato, sem normalizar)
  const itens = [{ v: f(R), erro: null }], vistos = new Set([f(R), f([x, y])]);
  shuffle(erradas).forEach(e => { if(itens.length < 4 && !vistos.has(e.v)){ vistos.add(e.v); itens.push(e); } });
  for(let t = 1; itens.length < 4; t++){ const e = { v: f([R[0] + t, R[1]]), erro: 'contou errado' }; if(!vistos.has(e.v)){ vistos.add(e.v); itens.push(e); } }
  const sh = shuffle(itens), a = { options: sh.map(i => i.v), correct: sh.findIndex(i => i.erro === null), erros: sh.map(i => i.erro), answer: f(R) };
  return { ...a, text: txt, image: svgURI(plano4QSVG([[x, y, 'P']])), meta: { x, y, tipo, dx, dy }, chave: `tf${x},${y}${tipo}${dx}${dy}` };
};
C.transf7 = m => { const M = { tx: [1, -1], ty: [-1, 1], orig: [-1, -1], mult: [2, 2], transl: [1, 1] }[m.tipo]; const p = [m.x * M[0] + m.dx, m.y * M[1] + m.dy]; return `(${menos(p[0])}, ${menos(p[1])})`; };

/* Razão com xícaras (EF07MA08 · EF07MA09) */
function xicarasSVG(a, b){
  const xc = (x, y, cor) => `<path d="M${x} ${y} L${x + 50} ${y} L${x + 44} ${y + 50} L${x + 6} ${y + 50} Z" fill="${cor}" stroke="#111" stroke-width="2.5"/><path d="M${x + 50} ${y + 12} Q${x + 66} ${y + 18} ${x + 48} ${y + 34}" fill="none" stroke="#111" stroke-width="3"/>`;
  let o = T(10, 44, 'Farinha', { fs: 18, anc: 'start' }) + T(10, 124, 'Leite', { fs: 18, anc: 'start' });
  for(let i = 0; i < a; i++) o += xc(100 + i * 72, 12, '#fde68a');
  for(let i = 0; i < b; i++) o += xc(100 + i * 72, 92, '#f8fafc');
  return SVG(100 + Math.max(a, b) * 72 + 10, 160, o);
}
G.razao7 = n => {
  const [a, b] = sortearAte(() => [rnd(1, 5), rnd(1, 5)], v => v[0] !== v[1] && mdc2(v[0], v[1]) === 1);
  if(n < 3){
    const pedeTotal = n === 2 && Math.random() < .5;
    const certa = pedeTotal ? `${a}/${a + b}` : `${a}/${b}`;
    const erradas = [{ v: `${b}/${a}`, erro: 'inverteu a ordem da razão' }, { v: pedeTotal ? `${a}/${b}` : `${a}/${a + b}`, erro: pedeTotal ? 'comparou com o leite, não com o total' : 'comparou com o total' }, { v: `${b}/${a + b}`, erro: 'usou o leite' }, { v: `${a + 1}/${b}`, erro: 'contou uma xícara a mais' }];
    const o = altFrac(certa, erradas, b);
    return { ...o, text: pedeTotal ? 'Que fração da mistura é FARINHA? (farinha : total)' : 'Qual é a razão entre FARINHA e LEITE?', image: svgURI(xicarasSVG(a, b)), meta: { a, b, pedeTotal, modo: 'razao' }, chave: `rz${a}:${b}${pedeTotal}` };
  }
  const k = rnd(2, 5), q = a * k, v = b * k;
  const erradas = [{ v: q, erro: 'repetiu a quantidade de farinha' }, { v: b + (q - a), erro: 'somou em vez de multiplicar' }, { v: v + b, erro: 'uma receita a mais' }, { v: a * k * b, erro: 'multiplicou errado' }];
  const aa = alternativas(v, erradas.filter(e => e.v !== v), x => x + ' xícaras', { min: 1 });
  return { ...aa, text: `A receita usa farinha e leite nesta razão. Com ${q} xícaras de farinha, quantas de leite?`, image: svgURI(xicarasSVG(a, b)), meta: { a, b, q, modo: 'escala' }, chave: `rs${a}:${b}x${k}` };
};
C.razao7 = m => m.modo === 'escala' ? (m.q / m.a * m.b) + ' xícaras' : (m.pedeTotal ? `${m.a}/${m.a + m.b}` : `${m.a}/${m.b}`);

/* Volume de bloco retangular e litros (EF07MA30) */
function caixaSVG(a, b, c, u){
  const s = 22, cx = Math.cos(Math.PI / 6) * s, sy = Math.sin(Math.PI / 6) * s, esc = Math.min(1, 10 / Math.max(a, b, c));
  const A = a * esc, B = b * esc, Cc = c * esc, ox = 20 + B * cx, oy = 20 + Cc * s;
  const P = (i, j, k) => [ox + (i - j) * cx, oy + (i + j) * sy - k * s], pts = q => q.map(p => p.map(v => v.toFixed(1)).join(',')).join(' ');
  let o = `<polygon points="${pts([P(0, 0, Cc), P(A, 0, Cc), P(A, B, Cc), P(0, B, Cc)])}" fill="#bfdbfe" stroke="#1e3a8a" stroke-width="3"/>` +
    `<polygon points="${pts([P(0, B, 0), P(A, B, 0), P(A, B, Cc), P(0, B, Cc)])}" fill="#60a5fa" stroke="#1e3a8a" stroke-width="3"/>` +
    `<polygon points="${pts([P(A, 0, 0), P(A, B, 0), P(A, B, Cc), P(A, 0, Cc)])}" fill="#3b82f6" stroke="#1e3a8a" stroke-width="3"/>`;
  const m1 = P(A / 2, B, 0), m2 = P(A, B / 2, 0), m3 = P(A, 0, Cc / 2);
  o += T(m1[0] - 14, m1[1] + 30, a + ' ' + u, { fs: 20, cor: '#b91c1c' }) + T(m2[0] + 30, m2[1] + 28, b + ' ' + u, { fs: 20, cor: '#b91c1c' }) + T(m3[0] + 16, m3[1], c + ' ' + u, { fs: 20, cor: '#b91c1c', anc: 'start' });
  const W = (A + B) * cx + 140, H = (A + B) * sy + Cc * s + 70;
  return SVG(W, H, o);
}
G.volume7 = n => {
  if(n === 1){
    const a = rnd(2, 9), b = rnd(2, 6), c = rnd(2, 6), V = a * b * c;
    const erradas = [{ v: a + b + c, erro: 'somou as medidas' }, { v: a * b, erro: 'calculou só a base' }, { v: 2 * (a * b + a * c + b * c), erro: 'calculou a área da superfície' }, { v: V + a * b, erro: 'errou a conta' }];
    const aa = alternativas(V, erradas.filter(e => e.v !== V), x => x + ' cm³', { min: 1 });
    return { ...aa, text: 'Qual é o VOLUME da caixa?', image: svgURI(caixaSVG(a, b, c, 'cm')), meta: { a, b, c, modo: 'cm3' }, chave: `vc${a}x${b}x${c}` };
  }
  if(n === 2){
    const a = rnd(2, 6), b = rnd(2, 5), c = rnd(2, 5), V = a * b * c;
    const erradas = [{ v: V * 1000, erro: 'converteu errado (1 dm³ = 1 L)' }, { v: a + b + c, erro: 'somou as medidas' }, { v: V / 10 === Math.floor(V / 10) ? V / 10 : V + 10, erro: 'converteu errado' }, { v: V + b * c, erro: 'errou a conta' }];
    const aa = alternativas(V, erradas.filter(e => e.v !== V), x => x + ' litros', { min: 1 });
    return { ...aa, text: 'Quantos LITROS cabem no aquário? (1 dm³ = 1 litro)', image: svgURI(caixaSVG(a, b, c, 'dm')), meta: { a, b, c, modo: 'dm3' }, chave: `vd${a}x${b}x${c}` };
  }
  const a = 10 * rnd(2, 6), b = 10 * rnd(1, 4), c = 10 * rnd(1, 4), V = a * b * c / 1000;
  const erradas = [{ v: a * b * c / 100, erro: 'dividiu por 100 em vez de 1000' }, { v: a * b * c / 10000, erro: 'dividiu por 10000' }, { v: (a + b + c) / 10, erro: 'somou as medidas' }, { v: V + 1, erro: 'errou a conta' }];
  const o = opcoesDecimaisTR(V, erradas.filter(e => e.v > 0), x => fmtDec(r3(x)) + ' L');
  return { ...o, text: 'Quantos LITROS cabem na caixa? (1000 cm³ = 1 litro)', image: svgURI(caixaSVG(a, b, c, 'cm')), meta: { a, b, c, modo: 'L' }, chave: `vl${a}x${b}x${c}` };
};
C.volume7 = m => { const V = m.a * m.b * m.c; return m.modo === 'cm3' ? V + ' cm³' : m.modo === 'dm3' ? V + ' litros' : fmtDec(r3(V / 1000)) + ' L'; };

/* Proporção inversa (EF07MA17) */
G.inversa7 = n => {
  const ctx = pick([['pedreiros', 'dias', 'constroem o muro'], ['torneiras', 'horas', 'enchem a piscina'], ['máquinas', 'horas', 'fazem o serviço']]);
  const k = pick(n === 1 ? [12, 24] : [12, 24, 36, 48, 60]);
  const divs = [...Array(k).keys()].map(x => x + 1).filter(x => k % x === 0 && x >= 2 && x <= 12 && k / x >= 2);
  const [p1, p2] = shuffle(divs).slice(0, 2), t1 = k / p1, t2 = k / p2;
  const direta = t1 * p2 / p1;
  const erradas = [{ v: Number.isInteger(direta) ? direta : null, erro: 'usou proporção direta' }, { v: t1 + (p1 - p2), erro: 'somou a diferença' }, { v: t1, erro: 'achou que não muda' }, { v: t2 + 1, erro: 'errou a conta' }];
  const a = alternativas(t2, erradas.filter(e => e.v && e.v !== t2 && e.v > 0), x => `${x} ${ctx[1]}`, { min: 1 });
  return { ...a, text: `${p1} ${ctx[0]} ${ctx[2]} em ${t1} ${ctx[1]}. Em quantos ${ctx[1]} ${p2} ${ctx[0]} fazem o mesmo (no mesmo ritmo)?`, meta: { p1, t1, p2, u: ctx[1] }, chave: `iv${p1}.${t1}.${p2}` };
};
C.inversa7 = m => `${m.p1 * m.t1 / m.p2} ${m.u}`;
