
/* =========================================================================
   PROBABILIDADE COM POTES E DADOS · PRINCÍPIO FUNDAMENTAL DA CONTAGEM
   (ideias de "slide probabilidade com potes" e "atividades lançamento de dados")
========================================================================= */

/* ---------- desenhos ---------- */
function poteSVG(x0, rotulo, bolas){            // pote de vidro com tampa; bolas = lista de cores
  const w = 150, porLinha = 5, r = 12, linhas = Math.max(1, Math.ceil(bolas.length / porLinha));
  const fundo = 175, topo = 40;
  let o = `<rect x="${x0 + 30}" y="${topo - 22}" width="${w - 60}" height="18" rx="5" fill="#94a3b8" stroke="#111" stroke-width="2.5"/>` +
    `<path d="M${x0 + 38} ${topo - 4} L${x0 + 38} ${topo + 8} Q${x0 + 8} ${topo + 18} ${x0 + 8} ${topo + 50} L${x0 + 8} ${fundo - 14} Q${x0 + 8} ${fundo} ${x0 + 22} ${fundo} L${x0 + w - 22} ${fundo} Q${x0 + w - 8} ${fundo} ${x0 + w - 8} ${fundo - 14} L${x0 + w - 8} ${topo + 50} Q${x0 + w - 8} ${topo + 18} ${x0 + w - 38} ${topo + 8} L${x0 + w - 38} ${topo - 4} Z" fill="#e0f2fe" fill-opacity=".55" stroke="#111" stroke-width="3"/>`;
  bolas.forEach((c, i) => {
    const lin = Math.floor(i / porLinha), col = i % porLinha, naLinha = Math.min(porLinha, bolas.length - lin * porLinha);
    const cx = x0 + w / 2 + (col - (naLinha - 1) / 2) * (2 * r + 2), cy = fundo - 17 - lin * (2 * r + 2);
    o += `<circle cx="${cx.toFixed(1)}" cy="${cy}" r="${r}" fill="${c}" stroke="#111" stroke-width="1.8"/><circle cx="${(cx - 3.5).toFixed(1)}" cy="${cy - 4}" r="3" fill="#fff" fill-opacity=".6"/>`;
  });
  return o + T(x0 + w / 2, fundo + 32, rotulo, { fs: 24 });
}
function dadoFace(x, y, s, n, cor = '#fff'){
  const P = { 1: [[.5, .5]], 2: [[.27, .27], [.73, .73]], 3: [[.25, .25], [.5, .5], [.75, .75]], 4: [[.27, .27], [.73, .27], [.27, .73], [.73, .73]],
    5: [[.25, .25], [.75, .25], [.5, .5], [.25, .75], [.75, .75]], 6: [[.27, .22], [.73, .22], [.27, .5], [.73, .5], [.27, .78], [.73, .78]] }[n];
  return `<rect x="${x}" y="${y}" width="${s}" height="${s}" rx="${s * .16}" fill="${cor}" stroke="#111" stroke-width="3"/>` +
    P.map(([a, b]) => `<circle cx="${(x + a * s).toFixed(1)}" cy="${(y + b * s).toFixed(1)}" r="${(s * .09).toFixed(1)}" fill="#111"/>`).join('');
}
function roupaSVG(tipo, x, y, cor){               // ícones de 70 px
  if(tipo === 'camiseta') return `<path d="M${x + 22} ${y + 6} L${x + 6} ${y + 16} L${x + 12} ${y + 32} L${x + 20} ${y + 28} L${x + 20} ${y + 66} L${x + 50} ${y + 66} L${x + 50} ${y + 28} L${x + 58} ${y + 32} L${x + 64} ${y + 16} L${x + 48} ${y + 6} Q${x + 35} ${y + 16} ${x + 22} ${y + 6} Z" fill="${cor}" stroke="#111" stroke-width="2.5" stroke-linejoin="round"/>`;
  if(tipo === 'bermuda') return `<path d="M${x + 12} ${y + 10} L${x + 58} ${y + 10} L${x + 64} ${y + 60} L${x + 40} ${y + 60} L${x + 35} ${y + 30} L${x + 30} ${y + 60} L${x + 6} ${y + 60} Z" fill="${cor}" stroke="#111" stroke-width="2.5" stroke-linejoin="round"/><line x1="${x + 12}" y1="${y + 17}" x2="${x + 58}" y2="${y + 17}" stroke="#111" stroke-width="2"/>`;
  return `<path d="M${x + 10} ${y + 46} Q${x + 10} ${y + 16} ${x + 35} ${y + 16} Q${x + 60} ${y + 16} ${x + 60} ${y + 46} Z" fill="${cor}" stroke="#111" stroke-width="2.5"/><path d="M${x + 36} ${y + 46} L${x + 68} ${y + 46} Q${x + 68} ${y + 54} ${x + 58} ${y + 54} L${x + 36} ${y + 54} Z" fill="${cor}" stroke="#111" stroke-width="2.5"/><circle cx="${x + 35}" cy="${y + 15}" r="4" fill="#111"/>`;   // boné
}
const CORES_ROUPA = ['#ef4444', '#3b82f6', '#22c55e', '#facc15', '#a855f7', '#f97316', '#ec4899', '#14b8a6'];

/* ============================ POTES (5º ano) ============================ */
const AZ = '#3b82f6', VM = '#ef4444', AM = '#facc15';
G.potes = n => {
  const k = n === 3 ? 3 : 2, nomes = ['Pote A', 'Pote B', 'Pote C'].slice(0, k);
  const mais = n === 1 ? true : Math.random() < .6;
  let potes;                                     // [azuis, total]
  if(n === 1){ const t = rnd(5, 9); const a1 = rnd(1, t - 1); let a2 = rnd(1, t - 2); if(a2 >= a1) a2++; potes = [[a1, t], [a2, t]]; }
  else if(n === 2){
    const modo = pick(['armadilha', 'armadilha', 'igual', 'normal']);
    const umPote = () => { const t = rnd(3, 12); return [rnd(1, Math.min(7, t - 1)), t]; };
    if(modo === 'igual'){                         // mesma fração com totais diferentes (ex.: 2 de 4 e 3 de 6)
      const [p, q] = pick([[1, 2], [1, 3], [2, 3], [1, 4], [3, 4]]), ks = shuffle([1, 2, 3]).slice(0, 2);
      potes = ks.map(k => [p * k, q * k]);
    } else potes = sortearAte(() => [umPote(), umPote()], p => p[0][1] !== p[1][1] && p[0][0] !== p[1][0] &&
      (modo === 'armadilha' ? (p[0][0] - p[1][0]) * (p[0][0] * p[1][1] - p[1][0] * p[0][1]) < 0 : p[0][0] * p[1][1] !== p[1][0] * p[0][1]));
  } else {
    potes = sortearAte(() => [0, 1, 2].map(() => { const t = rnd(3, 12); return [rnd(1, Math.min(6, t - 1)), t]; }), p => new Set(p.map(([a, t]) => a / t)).size === 3);
  }
  const fr = potes.map(([a, t]) => a / t), alvo = mais ? Math.max(...fr) : Math.min(...fr);
  const iguais = fr.every(v => Math.abs(v - fr[0]) < 1e-9);
  const certa = iguais ? 'Os potes têm a mesma chance' : nomes[fr.findIndex(v => Math.abs(v - alvo) < 1e-9)];
  const iMaisAz = potes.map(p => p[0]).indexOf(mais ? Math.max(...potes.map(p => p[0])) : Math.min(...potes.map(p => p[0])));
  const erradas = [...nomes.filter(x => x !== certa).map((x, i) => ({ v: x, erro: nomes.indexOf(x) === iMaisAz ? (mais ? 'escolheu o pote com mais bolas azuis, sem ver o total' : 'escolheu o pote com menos bolas azuis, sem ver o total') : 'comparou errado' })),
    iguais ? null : { v: 'Os potes têm a mesma chance', erro: 'achou que a chance é igual' }, { v: 'Não dá para saber', erro: 'achou que não dá para saber' }];
  const o = alternativas(certa, erradas, String);
  let img = '';
  potes.forEach(([a, t], i) => {
    const outras = n === 1 ? Array(t - a).fill(VM) : [...Array(t - a)].map((_, j) => j % 3 === 2 ? AM : VM);
    img += poteSVG(10 + i * 170, nomes[i], shuffle([...Array(a).fill(AZ), ...outras]));
  });
  return { ...o, text: `Tirando uma bola sem olhar, em qual pote a chance de sair bola AZUL é ${mais ? 'MAIOR' : 'MENOR'}?`,
    image: svgURI(SVG(k * 170 + 10, 222, img)), meta: { potes, mais }, chave: 'pt' + JSON.stringify(potes) + mais };
};
C.potes = m => {             // compara por produto cruzado (sem divisão)
  const p = m.potes, cmp = (x, y) => x[0] * y[1] - y[0] * x[1];
  if(p.every(x => cmp(x, p[0]) === 0)) return 'Os potes têm a mesma chance';
  let b = 0; p.forEach((x, i) => { if(m.mais ? cmp(x, p[b]) > 0 : cmp(x, p[b]) < 0) b = i; });
  return ['Pote A', 'Pote B', 'Pote C'][b];
};

/* ============================ DADO (6º ano) ============================ */
const EVENTOS_DADO = [
  // [texto, teste, nível mínimo]
  ...[1, 2, 3, 4, 5, 6].map(k => [`cair o número ${k}`, x => x === k, 1]),
  ['cair número par', x => x % 2 === 0, 1], ['cair número ímpar', x => x % 2 === 1, 1],
  ['cair número menor que 3', x => x < 3, 1], ['cair número maior que 4', x => x > 4, 1], ['cair número menor que 4', x => x < 4, 1], ['cair número maior que 2', x => x > 2, 1],
  ['cair número primo', x => [2, 3, 5].includes(x), 2], ['cair múltiplo de 3', x => x % 3 === 0, 2], ['cair divisor de 6', x => 6 % x === 0, 2],
  ['cair número entre 2 e 5 (incluindo 2 e 5)', x => x >= 2 && x <= 5, 2], ['cair número maior ou igual a 5', x => x >= 5, 2],
  ['NÃO cair o número 6', x => x !== 6, 2], ['NÃO cair número par', x => x % 2 !== 0, 2],
  ['NÃO cair número primo', x => ![2, 3, 5].includes(x), 3], ['NÃO cair múltiplo de 3', x => x % 3 !== 0, 3], ['cair número composto (4 ou 6)', x => x === 4 || x === 6, 3],
  ['cair o número 7', x => x === 7, 3], ['cair número menor que 7', x => x < 7, 3],
];
G.dado = n => {
  const ev = pick(EVENTOS_DADO.filter(e => e[2] <= n && (n === 1 || e[2] >= n - 1)));
  const c = [1, 2, 3, 4, 5, 6].filter(ev[1]).length;
  const certa = `${c}/6`, numFace = (ev[0].match(/número (\d)$/) || [])[1];
  const erradas = [{ v: `${6 - c}/6`, erro: 'contou os casos contrários' }, { v: `${c}/${6 - c}`, erro: 'comparou favoráveis com desfavoráveis' }, { v: `${c + 1}/6`, erro: 'contou uma face a mais' },
    { v: `${c - 1}/6`, erro: 'contou uma face a menos' }, { v: `6/${c}`, erro: 'inverteu a fração' }, numFace ? { v: `${numFace}/6`, erro: 'usou o número da face' } : null, { v: `1/${c + 1}`, erro: 'outro valor' }];
  const o = c === 0 || c === 6 ? alternativas(c === 0 ? '0 (impossível)' : '6/6 (certeza)', [{ v: '1/6', erro: 'achou que ainda tem uma chance' }, { v: c === 0 ? '6/6 (certeza)' : '0 (impossível)', erro: 'confundiu impossível com certeza' }, { v: '5/6', erro: 'outro valor' }, { v: '3/6', erro: 'outro valor' }], String)
    : altFrac(certa, erradas, 6);
  let img = '';
  for(let k = 1; k <= 6; k++) img += dadoFace(10 + (k - 1) * 82, 10, 70, k, [1, 2, 3, 4, 5, 6].filter(ev[1]).includes(k) && n === 1 ? '#fff' : '#fff');
  return { ...o, text: `Lançando um dado comum, qual é a chance de ${ev[0]}?`, image: svgURI(SVG(502, 90, img)), meta: { ev: ev[0] }, chave: 'dd' + ev[0] };
};
C.dado = m => {                // recalcula pelo texto do evento, lançando as 6 faces
  const e = EVENTOS_DADO.find(x => x[0] === m.ev); let c = 0; for(let f = 1; f <= 6; f++) if(e[1](f)) c++;
  return c === 0 ? '0 (impossível)' : c === 6 ? '6/6 (certeza)' : `${c}/6`;
};

/* ============================ DOIS DADOS (7º ano) ============================ */
G.doisDados = n => {
  const mostrarTabela = n < 3;
  const S = n === 1 ? pick([2, 3, 11, 12, 4, 10]) : rnd(2, 12);
  const modo = n === 3 ? pick(['soma', 'maior', 'iguais']) : 'soma';
  let c = 0, texto, val = null;
  if(modo === 'soma'){ for(let a = 1; a <= 6; a++) for(let b = 1; b <= 6; b++) if(a + b === S) c++; texto = `a soma ser ${S}`; val = S; }
  else if(modo === 'maior'){ val = rnd(7, 10); for(let a = 1; a <= 6; a++) for(let b = 1; b <= 6; b++) if(a + b > val) c++; texto = `a soma ser maior que ${val}`; }
  else { c = 6; texto = 'os dois dados mostrarem o mesmo número'; }
  const erradas = [{ v: `1/11`, erro: 'achou que as 11 somas têm a mesma chance' }, { v: `${c}/11`, erro: 'dividiu pelas 11 somas possíveis' }, { v: `1/36`, erro: 'contou só uma combinação' },
    { v: `${c + 1}/36`, erro: 'contou uma combinação a mais' }, { v: `${c - 1}/36`, erro: 'contou uma combinação a menos' }, { v: `${c}/12`, erro: 'somou 6 + 6 em vez de 6 × 6' }];
  const o = altFrac(`${c}/36`, erradas, 36);
  let img = '';
  if(mostrarTabela){
    const s = 38, x0 = 10, y0 = 10;
    img += `<rect x="${x0}" y="${y0}" width="${s}" height="${s}" fill="#e2e8f0" stroke="#111" stroke-width="1.5"/>` + T(x0 + s / 2, y0 + s / 2 + 8, '+', { fs: 24 });
    for(let k = 1; k <= 6; k++){ img += dadoFace(x0 + k * s + 3, y0 + 3, s - 6, k, '#fef3c7') + dadoFace(x0 + 3, y0 + k * s + 3, s - 6, k, '#dbeafe'); }
    for(let a = 1; a <= 6; a++) for(let b = 1; b <= 6; b++) img += `<rect x="${x0 + b * s}" y="${y0 + a * s}" width="${s}" height="${s}" fill="#fff" stroke="#94a3b8" stroke-width="1.5"/>` + T(x0 + b * s + s / 2, y0 + a * s + s / 2 + 7, a + b, { fs: 19, fw: 'normal' });
    img = SVG(7 * s + 20, 7 * s + 20, img);
  } else img = SVG(210, 110, [15, 115].map(x => `<rect x="${x}" y="15" width="80" height="80" rx="13" fill="#fff" stroke="#111" stroke-width="3"/>` + T(x + 40, 71, '?', { fs: 48, cor: '#64748b' })).join(''));
  return { ...o, text: `Lançando dois dados${mostrarTabela ? ' (a tabela mostra todas as somas)' : ''}, qual é a chance de ${texto}?`, image: svgURI(img), meta: { modo, val }, chave: `2d${modo}${val}${n}` };
};
C.doisDados = m => {           // conta por outro caminho: lista os 36 pares
  const pares = []; for(let a = 1; a <= 6; a++) for(let b = 1; b <= 6; b++) pares.push([a, b]);
  const c = pares.filter(([a, b]) => m.modo === 'soma' ? a + b === m.val : m.modo === 'maior' ? a + b > m.val : a === b).length;
  return `${c}/36`;
};

/* ============================ CONTAGEM (4º ano) ============================ */
G.contagem = n => {
  const tres = n === 3;
  const a = n === 1 ? rnd(2, 3) : rnd(2, 5), b = n === 1 ? rnd(2, 3) : rnd(2, 4), c = tres ? rnd(2, 3) : 1;
  if(n > 1 && a === b && !tres && Math.random() < .5) return G.contagem(n);
  const tot = a * b * c;
  const erradas = [{ v: a + b + (tres ? c : 0), erro: 'somou em vez de multiplicar' }, tres ? { v: a * b, erro: 'esqueceu o boné' } : { v: a * b - 1, erro: 'esqueceu uma combinação' },
    { v: tres ? a * b + c : Math.max(a, b), erro: tres ? 'multiplicou só dois grupos' : 'contou só um grupo' }, { v: tot + a, erro: 'contou combinações repetidas' }, { v: 2 * tot, erro: 'contou cada combinação duas vezes' }];
  const o = alternativas(tot, erradas, String, { min: 1 });
  const cores = shuffle(CORES_ROUPA);
  const grupos = [['camiseta', a], ['bermuda', b], ...(tres ? [['bone', c]] : [])];
  let img = '', y = 10, k = 0;
  const rot = { camiseta: 'Camisetas', bermuda: 'Bermudas', bone: 'Bonés' };
  grupos.forEach(([tipo, q]) => {
    img += T(10, y + 42, rot[tipo], { fs: 20, anc: 'start' });
    for(let i = 0; i < q; i++) img += roupaSVG(tipo, 120 + i * 80, y, cores[(k++) % cores.length]);
    y += 80;
  });
  const texto = tres ? 'Usando 1 camiseta, 1 bermuda e 1 boné, quantos jeitos diferentes de se vestir existem?' : 'Usando 1 camiseta e 1 bermuda, quantos jeitos diferentes de se vestir existem?';
  return { ...o, text: texto, image: svgURI(SVG(120 + 5 * 80 + 10, y + 5, img)), meta: { a, b, c }, chave: `ct${a}${b}${c}` };
};
C.contagem = m => {            // lista todas as roupas possíveis e conta
  let q = 0; for(let i = 0; i < m.a; i++) for(let j = 0; j < m.b; j++) for(let k = 0; k < m.c; k++) q++;
  return String(q);
};
