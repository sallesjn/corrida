
/* =========================================================================
   ACOMPANHAR ALUNOS + PLANO INDIVIDUAL + AJUDA PARA QUEM ERRA (acrescentado)
   Professor (treino):
   · "👁️ Acompanhar alunos": um cartão por aluno, quem precisa de atenção em
     cima — 🔴 errando muito · 🎲 chutando · 🟡 parado · 📡 offline · 🟢 ok.
     Toca um aviso quando alguém passa a precisar de atenção.
   · Clique no aluno: 📌 Plano deste aluno (só até um ano, ou só as
     atividades marcadas — com exemplo e imagem), ✏️ troca de nome, ✕ remover.
   Aluno (treino):
   · 2 erros seguidos na mesma atividade → "📘 Vamos ver juntos": a questão
     errada, a certa marcada e a explicação de como se faz.
   · 3 respostas erradas rápidas seguidas (< 3 s) → "🐢 Calma!": as
     alternativas só liberam depois de 5 s.
   Funções originais intactas: só embrulhos (onMessage, localAnswer,
   nextLocalQuestion, renderPlayerQuestion).
========================================================================= */
const ACOMP = { OFFLINE_MS: 45000, PARADO_MS: 120000, RAPIDO_S: 3, CHUTES: 3, ERROS_VER: 2, FREIO_S: 5 };
if(typeof window !== 'undefined') window.__ACOMP = ACOMP;          // (para os testes)

/* ---------------- professor: situação de cada aluno ---------------- */
function situacaoAluno(p){
  const agora = Date.now();
  const r = estado.turma.alunos[normNome(p.name)];
  const ult = (r && r.ultOk) || [];
  const n10 = ult.length, ac10 = ult.reduce((s, x) => s + x, 0);
  const visto = p._visto || p._entrou || agora, ultima = p._ultima || p._entrou || agora;
  const chute = !!(r && ((r.chuteSeq || 0) >= ACOMP.CHUTES || (r.tMed && r.tMed < ACOMP.RAPIDO_S && n10 >= 6 && ac10 / n10 < 0.4)));
  let st, txt, ordem;
  if(agora - visto > ACOMP.OFFLINE_MS){ st = 'off'; txt = '📡 offline'; ordem = 2; }
  else if(chute){ st = 'chute'; txt = '🎲 chutando'; ordem = 0; }
  else if(n10 >= 6 && ac10 / n10 < 0.4){ st = 'erro'; txt = '🔴 errando muito'; ordem = 0; }
  else if(agora - ultima > ACOMP.PARADO_MS){ st = 'parado'; txt = `🟡 parado há ${Math.floor((agora - ultima) / 60000)} min`; ordem = 1; }
  else { st = 'ok'; txt = '🟢 respondendo'; ordem = 3; }
  const at = r && r.atual ? POR_ID[r.atual] : null, d = at && r.deg[at.id];
  const plano = r && r.plano ? (r.plano.ids ? `📌 ${r.plano.ids.length} atividade${r.plano.ids.length === 1 ? '' : 's'}` : `📌 até o ${r.plano.ano}º ano`) : '';
  return { st, txt, ordem, n10, ac10, at, nivel: d ? ['', 'fácil', 'médio', 'difícil'][d.n] : '', plano, trav: !!(r && r.trav), apoio: !!(r && r.apoio) };
}
function acompanharHTML(){
  const lista = app.host.players.filter(p => !p.isBot).map(p => ({ p, s: situacaoAluno(p) }));
  // aviso sonoro quando alguém passa a precisar de atenção
  const ant = estado.statusAnt || (estado.statusAnt = {});
  let novo = false;
  lista.forEach(({ p, s }) => { if(['erro', 'chute', 'parado'].includes(s.st) && ant[p.id] !== s.st) novo = true; ant[p.id] = s.st; });
  if(novo) try{ beep(520, .18, 'sine', 0.08); setTimeout(() => beep(660, .18, 'sine', 0.08), 200); }catch(e){}
  lista.sort((a, b) => a.s.ordem - b.s.ordem || a.p.name.localeCompare(b.p.name, 'pt-BR'));
  const cont = k => lista.filter(x => x.s.st === k).length;
  const resumoTopo = [['erro', '🔴'], ['chute', '🎲'], ['parado', '🟡'], ['off', '📡'], ['ok', '🟢']].map(([k, e]) => `<span class="ac-cont ${k}">${e} ${cont(k)}</span>`).join('');
  return `<div class="ac-topo">${resumoTopo}<span class="ac-dica">Clique no aluno para adaptar as atividades, trocar o nome ou remover.</span></div>
    <div class="ac-grade">${lista.map(({ p, s }) => `<div class="ac-card ${s.st}" data-aluno="${esc(p.id)}">
      <div class="ac-nome">${esc(p.name)}${p._trocando ? ' ✏️…' : ''}${s.trav ? ' ⚠️' : ''}</div>
      <div class="ac-st">${s.txt}${s.apoio ? ' · 💪 apoio' : ''}</div>
      <div class="ac-at">${s.at ? `📚 ${esc(s.at.nome)}${s.nivel ? ' · ' + s.nivel : ''}` : '—'}</div>
      <div class="ac-num">últimas ${s.n10}: <b>${s.ac10}/${s.n10}</b> · ${(p.correct || 0) + (p.wrong || 0)} resp. · 🏅 ${estado.hoje[p.id] || 0}</div>
      ${s.plano ? `<div class="ac-plano">${s.plano}</div>` : ''}${typeof cartaoExtra === 'function' ? cartaoExtra(p) : ''}</div>`).join('') || '<div style="color:var(--muted);padding:12px">Ninguém na sala ainda.</div>'}</div>`;
}
function abrirMenuAluno(pid){
  const p = app.host.players.find(x => x.id === pid); if(!p) return;
  const s = situacaoAluno(p);
  let box = $('acMenu'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'acMenu'; box.className = 'ac-fundo';
  box.innerHTML = `<div class="ac-janela"><div class="ac-jt">${esc(p.name)}</div><div class="ac-st" style="margin-bottom:12px">${s.txt}${s.at ? ' · 📚 ' + esc(s.at.nome) : ''}${s.plano ? ' · ' + s.plano : ''}</div>
      <button class="primary" data-a="plano">📌 Plano deste aluno (adaptar atividades)</button>
      <button class="ghost" data-a="nome">✏️ Pedir para trocar o nome</button>
      <button class="ghost" data-a="ficha">👤 Ficha do aluno (o que ele sabe fazer)</button>
      <button class="ghost" data-a="rem" style="color:#fca5a5">✕ Remover da sala</button>
      <button class="ghost" data-a="x">Fechar</button></div>`;
  document.body.appendChild(box);
  box.onclick = e => {
    const b = e.target.closest('[data-a]'); if(!b && e.target !== box) return;
    box.remove();
    if(!b) return;
    if(b.dataset.a === 'plano') abrirPlano(pid);
    if(b.dataset.a === 'nome') pedirTrocaNome(pid);
    if(b.dataset.a === 'rem') app.kickPlayer(pid);
    if(b.dataset.a === 'ficha') abrirFicha(normNome(p.name));
  };
}

/* ---------------- professor: plano individual ---------------- */
function miniaturaDegrau(d){
  try{
    const q = gerarQuestao(d.id, 1);
    if(q.image) return `<img src="${q.image}" alt="">`;
    if(q.optImgs) return `<img src="${q.optImgs[q.correct]}" alt="">`;
    return `<div class="pl-txt">${fracHTML(esc(q.text))}</div>`;
  }catch(e){ return ''; }
}
function temImagem(d){ try{ const q = gerarQuestao(d.id, 1); return !!(q.image || q.optImgs); }catch(e){ return false; } }
function abrirPlano(pid){
  const p = app.host.players.find(x => x.id === pid); if(!p) return;
  const rec = registroDe(p.name); if(!rec) return;
  const pl = rec.plano || null;
  const est = { tipo: pl ? (pl.ids ? 'lista' : 'ano') : 'turma', ano: (pl && pl.ano) || 1, ids: new Set((pl && pl.ids) || []), aba: 1, soImg: false };
  if(est.ids.size){ const a = Math.min(...[...est.ids].map(id => POR_ID[id] ? POR_ID[id].ano : 7)); est.aba = a; }
  let box = $('plBox'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'plBox'; box.className = 'cat-fundo';
  document.body.appendChild(box);
  const desenhar = () => {
    const degs = CAT.filter(d => d.ano === est.aba && !d.retirada && (!est.soImg || temImagem(d)));
    box.innerHTML = `<div class="cat-topo"><h2>📌 Plano de ${esc(p.name)}</h2>
        <div class="dir"><button class="ab" data-salvar="1" style="background:#16a34a;border-color:#16a34a">✅ Salvar plano</button><button class="ab" data-fechar="1">✕ Cancelar</button></div></div>
      <div class="pl-ops">
        <label class="pl-op"><input type="radio" name="plTipo" value="turma" ${est.tipo === 'turma' ? 'checked' : ''}> <b>Sem adaptação</b> — segue a trilha da turma</label>
        <label class="pl-op"><input type="radio" name="plTipo" value="ano" ${est.tipo === 'ano' ? 'checked' : ''}> <b>Só até o</b>
          <select id="plAno">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<option value="${a}" ${a === est.ano ? 'selected' : ''}>${a}º ano</option>`).join('')}</select> (a trilha dele para aí)</label>
        <label class="pl-op"><input type="radio" name="plTipo" value="lista" ${est.tipo === 'lista' ? 'checked' : ''}> <b>Só as atividades que eu marcar</b> — ele treina só elas, alternando</label>
      </div>
      ${est.tipo === 'lista' ? `<div class="cat-topo" style="position:static;margin-top:10px">
          ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<button class="ab ${a === est.aba ? 'on' : ''}" data-aba="${a}">${a}º ano${[...est.ids].some(id => POR_ID[id] && POR_ID[id].ano === a) ? ' •' : ''}</button>`).join('')}
          <label style="margin-left:10px;font-weight:800;font-size:14px"><input type="checkbox" id="plImg" ${est.soImg ? 'checked' : ''}> só com imagem</label>
          <span style="margin-left:auto;font-weight:900;color:#fbbf24">${est.ids.size} marcada${est.ids.size === 1 ? '' : 's'}</span></div>
        <div class="pl-grade">${degs.map(d => `<label class="pl-item ${est.ids.has(d.id) ? 'on' : ''}"><input type="checkbox" data-id="${d.id}" ${est.ids.has(d.id) ? 'checked' : ''}>
          <div class="pl-min">${miniaturaDegrau(d)}</div><div class="pl-nome">${esc(d.nome)}</div></label>`).join('') || '<div style="color:var(--muted);padding:12px">Nenhuma atividade com imagem neste ano.</div>'}</div>` : ''}`;
  };
  desenhar();
  box.onchange = e => {
    if(e.target.name === 'plTipo'){ est.tipo = e.target.value; desenhar(); return; }
    if(e.target.id === 'plAno'){ est.ano = +e.target.value; est.tipo = 'ano'; desenhar(); return; }
    if(e.target.id === 'plImg'){ est.soImg = e.target.checked; desenhar(); return; }
    const id = e.target.dataset && e.target.dataset.id;
    if(id){ if(e.target.checked) est.ids.add(id); else est.ids.delete(id); e.target.closest('.pl-item').classList.toggle('on', e.target.checked);
      const n = box.querySelector('.cat-topo[style] span'); if(n) n.textContent = `${est.ids.size} marcada${est.ids.size === 1 ? '' : 's'}`; }
  };
  box.onclick = e => {
    if(e.target.closest('[data-fechar]')){ box.remove(); return; }
    const aba = e.target.closest('button[data-aba]'); if(aba){ est.aba = +aba.dataset.aba; desenhar(); return; }
    if(e.target.closest('[data-salvar]')){
      if(est.tipo === 'lista' && !est.ids.size){ alert('Marque pelo menos uma atividade.'); return; }
      aplicarPlano(p, est.tipo === 'turma' ? null : est.tipo === 'ano' ? { ano: est.ano } : { ids: CAT.filter(d => est.ids.has(d.id)).map(d => d.id) });
      box.remove();
    }
  };
}
function aplicarPlano(p, plano){
  const rec = registroDe(p.name); if(!rec) return;
  if(plano) rec.plano = plano; else delete rec.plano;
  rec.rev = (rec.rev || 0) + 10;
  rec.pausa = null;
  if(plano){
    if(!rec.diag || typeof rec.diag === 'object') rec.diag = 'feito';
    const livre = d => !(rec.deg[d.id] && rec.deg[d.id].dom);
    const cand = plano.ids ? CAT.filter(d => plano.ids.includes(d.id)) : CAT.filter(d => d.ano <= plano.ano && !d.retirada && !d.off);
    const at = rec.atual ? POR_ID[rec.atual] : null;
    if(!at || !cand.includes(at) || !livre(at)){ const prox = cand.find(livre); rec.atual = prox ? prox.id : null; if(prox) degDo(rec, prox.id); }
  } else if(!rec.atual){ const prox = proximoAtivo(rec, 0); rec.atual = prox ? prox.id : null; }
  salvarTurmaLocal();
  enviarTrilha(p);
  app.toast(plano ? `📌 Plano de <b>${esc(p.name)}</b>: ${plano.ids ? plano.ids.length + ' atividade(s)' : 'até o ' + plano.ano + 'º ano'}` : `📌 <b>${esc(p.name)}</b> voltou a seguir a turma`, 'success');
}

/* ---------------- aluno: "Vamos ver juntos" e freio no chute ---------------- */
const ajudaAluno = { ver: null, pend: null, freio: false };
function mostrarVerJuntos(v, continuar){
  const q = v.q;
  let box = $('vjBox'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'vjBox'; box.className = 'vj-fundo';
  const alt = (o, i) => `<div class="vj-alt ${i === q.correct ? 'certa' : i === v.idx ? 'errada' : ''}">${q.optImgs && q.optImgs[i] ? `<img src="${q.optImgs[i]}" alt="">` : fracHTML(esc(String(o)))}${i === q.correct ? '<span>✅ certa</span>' : i === v.idx ? '<span>❌ você marcou</span>' : ''}</div>`;
  box.innerHTML = `<div class="vj-card">
      <div class="vj-tt">📘 Vamos ver juntos</div>
      <div class="vj-enun">${/\d\/\d/.test(q.text || '') ? fracHTML(q.text) : renderMath(q.text || '')}</div>
      ${q.image ? `<img class="vj-fig" src="${q.image}" alt="">` : ''}
      <div class="vj-alts">${(q.options || []).map(alt).join('')}</div>
      <div class="vj-dica">💡 <b>Como fazer:</b> ${fracHTML(dicaDe(q) || 'Leia de novo com calma e confira cada alternativa.')}</div>
      <button class="primary vj-ok" disabled>Entendi! Próxima ➜</button></div>`;
  document.body.appendChild(box);
  const bt = box.querySelector('.vj-ok');
  setTimeout(() => { bt.disabled = false; }, 2000);                      // um instante para ler
  bt.onclick = () => { box.remove(); continuar(); };
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .ac-topo{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
  .ac-cont{font-weight:900;font-size:16px;background:var(--panel2);border:2px solid var(--line);border-radius:999px;padding:4px 12px}
  .ac-dica{color:var(--muted);font-size:13px;margin-left:auto}
  .ac-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px}
  .ac-card{background:var(--panel2);border:3px solid var(--line);border-radius:14px;padding:10px 12px;cursor:pointer;text-align:left}
  .ac-card:hover{filter:brightness(1.15)}
  .ac-card.erro,.ac-card.chute{border-color:#ef4444;background:rgba(239,68,68,.12)}
  .ac-card.parado{border-color:#f59e0b;background:rgba(245,158,11,.1)}
  .ac-card.off{opacity:.6}
  .ac-card.ok{border-color:#16a34a}
  .ac-nome{font-weight:900;font-size:18px}
  .ac-st{font-weight:800;font-size:14px;margin-top:2px}
  .ac-at{font-size:13px;color:#cbd5e1;margin-top:4px}
  .ac-num{font-size:13px;color:var(--muted);margin-top:2px}
  .ac-plano{font-size:13px;font-weight:900;color:#fbbf24;margin-top:3px}
  .ac-fundo{position:fixed;inset:0;z-index:560;background:rgba(2,6,23,.7);display:flex;align-items:center;justify-content:center;padding:16px}
  .ac-janela{background:var(--panel);border:2px solid var(--line);border-radius:18px;padding:18px;width:min(420px,94vw);display:flex;flex-direction:column;gap:8px}
  .ac-jt{font-size:22px;font-weight:900}
  .pl-ops{display:flex;flex-direction:column;gap:8px;margin:12px 4px}
  .pl-op{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:15px;background:var(--panel);border:2px solid var(--line);border-radius:12px;padding:10px 12px;margin:0}
  .pl-op select{width:auto;padding:4px 8px;font-weight:800}
  .pl-op input[type=radio]{width:22px;height:22px;margin:0;flex:0 0 auto;accent-color:#22c55e}
  #plImg{width:20px;height:20px;margin:0 4px 0 0;vertical-align:middle;accent-color:#22c55e}
  .pl-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-top:10px}
  .pl-item{display:flex;flex-direction:column;gap:6px;background:var(--panel);border:3px solid var(--line);border-radius:12px;padding:8px;cursor:pointer;margin:0;position:relative}
  .pl-item.on{border-color:#22c55e;background:rgba(34,197,94,.1)}
  .pl-item input{position:absolute;top:8px;left:8px;width:22px;height:22px;accent-color:#22c55e}
  .pl-min{background:#fff;border-radius:8px;height:110px;display:flex;align-items:center;justify-content:center;overflow:hidden}
  .pl-min img{max-width:100%;max-height:106px}
  .pl-txt{color:#0f172a;font-weight:900;font-size:14px;line-height:1.2;padding:6px;text-align:center;max-height:104px;overflow:hidden}
  .pl-nome{font-weight:800;font-size:14px}
  .vj-fundo{position:fixed;inset:0;z-index:590;background:rgba(2,6,23,.9);display:flex;align-items:center;justify-content:center;padding:12px}
  .vj-card{background:#f8fafc;color:#0f172a;border-radius:20px;padding:16px 18px;max-width:640px;width:100%;max-height:96vh;overflow:auto;text-align:center;border:4px solid #3b82f6}
  .vj-tt{font-size:clamp(22px,5vw,30px);font-weight:900;color:#1d4ed8}
  .vj-enun{font-size:clamp(18px,4.5vw,26px);font-weight:900;margin:8px 0}
  .vj-fig{max-width:100%;max-height:200px;border-radius:10px;background:#fff}
  .vj-alts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}
  .vj-alt{border:3px solid #cbd5e1;border-radius:12px;padding:8px;font-weight:900;font-size:20px;background:#fff}
  .vj-alt img{max-height:70px;max-width:100%}
  .vj-alt span{display:block;font-size:13px;margin-top:2px}
  .vj-alt.certa{border-color:#16a34a;background:#dcfce7;color:#14532d}
  .vj-alt.errada{border-color:#dc2626;background:#fee2e2;color:#7f1d1d;opacity:.8}
  .vj-dica{background:#fffbeb;border:2px solid #f59e0b;border-radius:12px;padding:10px 12px;font-size:clamp(16px,4vw,20px);font-weight:700;text-align:left;color:#422006}
  .vj-ok{margin-top:12px;width:100%;font-size:20px;padding:14px}
  .vj-ok:disabled{opacity:.5}
  .fr-aviso{position:relative;z-index:2;margin:8px auto 0;max-width:520px;background:#e0f2fe;color:#075985;border:3px solid #0ea5e9;border-radius:14px;padding:8px 12px;font-weight:900;font-size:clamp(16px,4vw,22px);text-align:center}`;
  document.head.appendChild(st);

  /* professor: quando cada aluno foi visto e quando respondeu */
  const onMessage0 = app.onMessage;
  app.onMessage = function(topic, msg){
    if(this.mode === 'teacher' && msg && msg.id && topic.endsWith('/tohost')){
      const p = this.host.players.find(x => x.id === msg.id);
      const agora = Date.now();
      const r = onMessage0.call(this, topic, msg);
      const q = p || this.host.players.find(x => x.id === msg.id);   // o "join" pode ter acabado de criar o aluno
      if(q){
        q._visto = agora; if(!q._entrou) q._entrou = agora;
        if((msg.type === 'batch' && ((msg.correct || 0) + (msg.wrong || 0) + (msg.timeouts || 0)) > 0) || msg.type === 'trilhaRec') q._ultima = agora;
      }
      return r;
    }
    return onMessage0.call(this, topic, msg);
  };

  /* aluno: mede o tempo de cada resposta, conta erros seguidos e chutes */
  const localAnswer0 = app.localAnswer;
  app.localAnswer = function(idx){
    const q = this.player.currentQuestion, bloq = this.player.questionBlocked;
    const seg = (performance.now() - this.player.questionStart) / 1000;
    const r = localAnswer0.apply(this, arguments);
    const pt = this.player.trilha;
    if(bloq || !q || !pt || !pt.rec) return r;
    const ok = idx === q.correct, rec = pt.rec;
    const ts = rec.tempos || (rec.tempos = []); ts.push(Math.round(seg * 10) / 10); if(ts.length > 10) ts.shift();
    rec.tMed = Math.round(ts.reduce((a, b) => a + b, 0) / ts.length * 10) / 10;
    rec.chuteSeq = (!ok && seg < ACOMP.RAPIDO_S) ? (rec.chuteSeq || 0) + 1 : 0;
    pt.sujo = true;
    if(!treinoAluno()) return r;                                // ajudas abaixo só no treino (a corrida fica como era)
    const id = q.type;
    const es = pt.errSeq || (pt.errSeq = {});
    es[id] = ok ? 0 : (es[id] || 0) + 1;
    if(!q._ajuda && es[id] >= ACOMP.ERROS_VER){ es[id] = 0; ajudaAluno.ver = { q, idx }; }
    pt.rapErr = (!ok && seg < ACOMP.RAPIDO_S) ? (pt.rapErr || 0) + 1 : 0;
    if(pt.rapErr >= ACOMP.CHUTES){ pt.rapErr = 0; ajudaAluno.freio = true; }
    return r;
  };
  const nextLocalQuestion0 = app.nextLocalQuestion;
  app.nextLocalQuestion = function(){
    if(ajudaAluno.ver && this.player.phase === 'playing'){
      const v = ajudaAluno.ver; ajudaAluno.ver = null;
      const self = this, args = arguments;
      mostrarVerJuntos(v, () => { if(self.player.phase === 'playing') nextLocalQuestion0.apply(self, args); });
      return;
    }
    return nextLocalQuestion0.apply(this, arguments);
  };
  const renderPlayerQuestion0 = app.renderPlayerQuestion;
  app.renderPlayerQuestion = function(q){
    const r = renderPlayerQuestion0.apply(this, arguments);
    const velho = $('frAviso'); if(velho) velho.remove();
    if(ajudaAluno.freio && treinoAluno()){
      ajudaAluno.freio = false;
      const bts = [...$('ppOptions').children]; bts.forEach(b => b.disabled = true);
      const av = document.createElement('div'); av.id = 'frAviso'; av.className = 'fr-aviso';
      $('ppQuestionCard').appendChild(av);
      let n = ACOMP.FREIO_S;
      const tick = () => {
        if(this.player.currentQuestion !== q){ av.remove(); return; }
        if(n <= 0){ av.remove(); bts.forEach(b => b.disabled = false); return; }
        av.textContent = `🐢 Calma! Leia a pergunta com atenção… ${n}`; n--; setTimeout(tick, 1000);
      };
      tick();
    }
    return r;
  };
})();
