
/* =========================================================================
   CHAMA DE EVOLUÇÃO (acrescentado) — tela do ALUNO
   · Some o contador de erros (❌) da barra e da tela final: só acertos.
   · No lugar de "fácil / médio / difícil", uma chama que cresce conforme o
     aluno sobe dentro do degrau (4 tamanhos) e o número de degraus já
     conquistados (🪜). Ao conquistar um degrau, a chama dá um clarão.
   · O professor continua vendo os níveis nos relatórios (não muda nada lá).
   Funções originais intactas: só embrulhos (extrasPergunta, aviso,
   finishPlayerMatch).
========================================================================= */
function estagioChama(rec, id){
  const d = rec && id && rec.deg[id];
  if(!d) return 1;
  if(d.n >= 3){ const u = d.h.filter(x => x[0] === 3).slice(-10); return u.length >= 4 && u.reduce((s, x) => s + x[1], 0) >= 5 ? 4 : 3; }
  return d.n === 2 ? 2 : 1;
}
function chamaSVG(est){
  const k = [0, .55, .72, .88, 1][est] || .55;
  const cores = [null, ['#f97316', '#fdba74'], ['#ea580c', '#fde047'], ['#dc2626', '#facc15'], ['#b91c1c', '#fef08a']][est];
  const W = 34, H = 44;
  return `<svg class="ch-svg ch-${est}" viewBox="0 0 34 44" width="${Math.round(W * (0.75 + k * 0.6))}" height="${Math.round(H * (0.75 + k * 0.6))}" aria-hidden="true">
    <defs><linearGradient id="chg${est}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="${cores[0]}"/><stop offset="1" stop-color="${cores[1]}"/></linearGradient></defs>
    <path d="M17 2 C21 11 30 15 30 27 C30 36 24 42 17 42 C10 42 4 36 4 27 C4 20 9 17 10 10 C13 14 14 17 15 19 C16 13 15 7 17 2 Z" fill="url(#chg${est})" stroke="#7c2d12" stroke-width="1.2"/>
    <path d="M17 20 C19 25 23 27 23 32 C23 37 20 40 17 40 C14 40 11 37 11 32 C11 28 14 26 17 20 Z" fill="${est >= 4 ? '#93c5fd' : '#fef3c7'}" opacity=".9"/></svg>`;
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  #playerPlay .pp-stats .item.wrong{display:none!important}
  .ch-box{display:inline-flex;align-items:center;gap:6px;margin-left:6px;vertical-align:middle}
  .ch-svg{filter:drop-shadow(0 0 6px rgba(251,146,60,.8));transform-origin:50% 100%;animation:chBalanca 1.6s ease-in-out infinite}
  .ch-svg.ch-4{filter:drop-shadow(0 0 10px rgba(250,204,21,.95))}
  .ch-degraus{font-weight:900;font-size:15px;color:#fde68a;background:rgba(0,0,0,.25);border-radius:999px;padding:2px 9px}
  .ch-cresceu .ch-svg{animation:chCresce .9s ease-out 1, chBalanca 1.6s ease-in-out .9s infinite}
  @keyframes chBalanca{0%,100%{transform:scale(1) rotate(-2deg)}50%{transform:scale(1.06) rotate(2deg)}}
  @keyframes chCresce{0%{transform:scale(.6)}60%{transform:scale(1.5)}100%{transform:scale(1)}}`;
  document.head.appendChild(st);

  let ultimo = { id: null, est: 0, dom: -1 };
  const extras0 = extrasPergunta;
  extrasPergunta = function(q){
    const r = extras0.apply(this, arguments);
    try{
      const info = $('ppTrilhaInfo'), pt = app.player && app.player.trilha, rec = pt && pt.rec;
      if(info && q && q.trilha && rec && !info.classList.contains('hidden')){
        // tira "· fácil / médio / difícil" e põe a chama
        info.innerHTML = info.innerHTML.replace(/ · (fácil|médio|difícil)/, '');
        const id = rec.atual || q.trilha.id, est = estagioChama(rec, id), dom = resumo(rec).dominados;
        const cresceu = ultimo.id === id ? est > ultimo.est : dom > ultimo.dom && ultimo.dom >= 0;
        const box = document.createElement('span'); box.className = 'ch-box' + (cresceu ? ' ch-cresceu' : '');
        box.title = 'Sua chama cresce a cada passo do degrau';
        box.innerHTML = chamaSVG(est) + `<span class="ch-degraus">🪜 ${dom}</span>`;
        const aj = $('ppAjudaBtn');
        if(aj && aj.parentNode === info) info.insertBefore(box, aj); else info.appendChild(box);
        ultimo = { id, est, dom };
      }
    }catch(e){ console.warn('[chama]', e); }
    return r;
  };
  const aviso0 = aviso;
  aviso = function(txt, ms){
    if(/⬆️ Nível/.test(txt)) txt = '🔥 Sua chama cresceu!';
    txt = String(txt).replace('perguntas mais fáceis', 'um passo de cada vez');
    return aviso0.call(this, txt, ms);
  };
  const fim0 = app.finishPlayerMatch;
  app.finishPlayerMatch = function(){
    const r = fim0.apply(this, arguments);
    try{
      const s = this.player.stats, rec = this.player.trilha && this.player.trilha.rec;
      $('pdStats').innerHTML = `✅ ${s.correct} acerto${s.correct === 1 ? '' : 's'} &nbsp;·&nbsp; 🔥 Melhor sequência: ${s.bestStreak}` + (rec ? `<br>🪜 ${resumo(rec).dominados} degraus conquistados na trilha` : '');
    }catch(e){}
    return r;
  };
})();
