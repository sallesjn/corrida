
/* =========================================================================
   HISTÓRICO DAS QUESTÕES (acrescentado)
   · O celular do aluno guarda as últimas 20 questões que ele respondeu
     (enunciado, figura, alternativas, a certa e a que ele marcou), também
     depois de recarregar a página.
   · Professor: clique no aluno (👥 Alunos ou Acompanhar) → "📜 Últimas
     questões": o celular manda as questões e elas aparecem como o aluno
     viu, com a certa em verde, a marcada em vermelho e o código da
     atividade (para pedir correção, ex.: area8-N2).
   Funções originais intactas: só embrulhos (localAnswer, onMessage,
   abrirMenuAluno).
========================================================================= */
const HIST = { max: 20, lista: null, dono: null, rec: {} };
const histKey = () => 'cgm_hist_' + normNome(app.playerName || '');     // um histórico por aluno (vários alunos usam o mesmo Chromebook)
function histLocal(){ if(HIST.dono !== histKey()){ HIST.lista = null; HIST.dono = histKey(); }
  if(!HIST.lista){ try{ HIST.lista = JSON.parse(localStorage.getItem(histKey()) || '[]'); }catch(e){ HIST.lista = []; } } return HIST.lista; }
function histGuardar(){ try{ localStorage.setItem(histKey(), JSON.stringify(HIST.lista)); }catch(e){ HIST.lista.splice(0, Math.max(1, HIST.lista.length - 8)); try{ localStorage.setItem(histKey(), JSON.stringify(HIST.lista)); }catch(e2){} } }
function histCard(h, i){
  const alt = (o, k) => `<div class="vj-alt ${k === h.c ? 'certa' : k === h.m ? 'errada' : ''}">${h.oi && h.oi[k] ? `<img src="${h.oi[k]}" alt="">` : fracHTML(esc(String(o)))}${k === h.c ? '<span>✅ certa</span>' : k === h.m ? '<span>❌ marcou</span>' : ''}</div>`;
  const hora = h.ts ? new Date(h.ts).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '';
  const nome = POR_ID[h.id] ? POR_ID[h.id].nome : (TYPE_LABELS[h.id] || h.id);
  return `<div class="hs-card ${h.m === h.c ? 'ok' : 'erro'}"><div class="hs-cab"><b>${i + 1}. ${h.m === h.c ? '✅ acertou' : h.m === -1 ? '⏰ sem resposta' : '❌ errou'}</b><span>${esc(hora)} · ${esc(nome)} · código <b>${esc(h.id)}${h.n ? '-N' + h.n : ''}</b></span></div>
    <div class="vj-enun">${fracHTML(esc(h.t || ''))}</div>${h.img ? `<img class="vj-fig" src="${h.img}" alt="">` : ''}
    <div class="vj-alts">${(h.o || []).map(alt).join('')}</div></div>`;
}
function abrirHistorico(p){
  let box = $('hsBox'); if(box) box.remove();
  box = document.createElement('div'); box.id = 'hsBox'; box.className = 'cat-fundo';
  const chave = normNome(p.name);
  HIST.rec[chave] = { itens: [], tot: null, nome: p.name };
  box.innerHTML = `<div class="cat-topo"><h2>📜 Últimas questões de ${esc(p.name)}</h2><div class="dir"><button class="ab" data-fechar="1">✕ Fechar</button></div></div>
    <div class="hs-txt">A mais recente aparece primeiro. Se achar um erro na questão, anote o <b>código</b> para pedir a correção.</div><div id="hsCorpo" class="hs-espera">⏳ Pedindo ao celular de ${esc(p.name)}… (ele precisa estar conectado)</div>`;
  document.body.appendChild(box);
  box.onclick = e => { if(e.target.closest('[data-fechar]')) box.remove(); };
  app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'histPede' });
  setTimeout(() => { const c = $('hsCorpo'); if(c && c.classList.contains('hs-espera')) c.innerHTML = '📡 O celular não respondeu. Veja se o aluno está conectado e tente de novo.'; }, 12000);
}
function desenharHistorico(chave){
  const r = HIST.rec[chave], c = $('hsCorpo'); if(!r || !c) return;
  c.classList.remove('hs-espera');
  if(r.tot === 0){ c.innerHTML = 'Este celular ainda não respondeu nenhuma questão.'; return; }
  const itens = r.itens.filter(Boolean);
  c.innerHTML = `<div style="color:var(--muted);margin:6px 0">${itens.length} de ${r.tot} recebidas</div><div class="hs-grade">${itens.map(histCard).join('')}</div>`;
}
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .hs-txt{color:var(--muted);margin:10px 4px}
  .hs-espera{padding:20px;font-weight:800;color:#93c5fd}
  .hs-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px}
  .hs-card{background:#f8fafc;color:#0f172a;border-radius:16px;padding:12px;border:4px solid #16a34a;text-align:center}
  .hs-card.erro{border-color:#dc2626}
  .hs-cab{display:flex;flex-direction:column;gap:2px;text-align:left;font-size:14px;margin-bottom:6px}
  .hs-cab span{color:#475569;font-size:12px}
  .hs-card .vj-enun{font-size:20px}
  .hs-card .vj-alt{font-size:17px}`;
  document.head.appendChild(st);

  /* aluno: guarda cada questão respondida */
  const localAnswer0 = app.localAnswer;
  app.localAnswer = function(idx){
    const q = this.player.currentQuestion, bloq = this.player.questionBlocked;
    const r = localAnswer0.apply(this, arguments);
    try{
      if(q && !bloq && this.mode !== 'teacher'){
        const l = histLocal();
        l.push({ t: q.text, o: q.options, oi: q.optImgs || null, img: q.image || null, c: q.correct, m: idx, id: q.type, n: q.trilha ? q.trilha.nivel : null, ts: Date.now() });
        while(l.length > HIST.max) l.shift();
        histGuardar();
      }
    }catch(e){}
    return r;
  };
  /* mensagens */
  const onMessage0 = app.onMessage;
  app.onMessage = function(topic, msg){
    if(this.mode !== 'teacher' && msg && msg.type === 'histPede' && topic.endsWith(`/to/${this.playerId}`)){
      const l = histLocal().slice().reverse(), tot = l.length;
      if(!tot) this.pub(`${BASE}/${this.room}/tohost`, { type: 'histItem', id: this.playerId, i: 0, tot: 0 });
      l.forEach((it, i) => setTimeout(() => this.pub(`${BASE}/${this.room}/tohost`, { type: 'histItem', id: this.playerId, i, tot, it }), i * 250));
      return;
    }
    if(this.mode === 'teacher' && msg && msg.type === 'histItem' && topic.endsWith('/tohost')){
      const p = this.host.players.find(x => x.id === msg.id), chave = p ? normNome(p.name) : null;
      if(chave && HIST.rec[chave]){ HIST.rec[chave].tot = msg.tot; if(msg.it) HIST.rec[chave].itens[msg.i] = msg.it; desenharHistorico(chave); }
      return;
    }
    return onMessage0.call(this, topic, msg);
  };
  /* professor: botão no menu do aluno */
  const abrirMenuAluno0 = abrirMenuAluno;
  abrirMenuAluno = function(pid){
    const r = abrirMenuAluno0.apply(this, arguments);
    const jan = document.querySelector('#acMenu .ac-janela'), p = app.host.players.find(x => x.id === pid);
    if(jan && p){
      const b = document.createElement('button'); b.className = 'ghost'; b.textContent = '📜 Últimas questões (ver dúvidas e erros)';
      b.onclick = e => { e.stopPropagation(); const m = $('acMenu'); if(m) m.remove(); abrirHistorico(p); };
      const ref = jan.querySelector('[data-a="ficha"]'); if(ref) ref.after(b); else jan.appendChild(b);
    }
    return r;
  };
})();
