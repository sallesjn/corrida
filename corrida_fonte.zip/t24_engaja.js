
/* =========================================================================
   ENGAJAMENTO (acrescentado)
   1. Acerto com festa: som de acerto em 2 notas, "+pontos" subindo e
      confete pequeno; sequência de 3, 5, 10, 15, 20… com aviso e fanfarra.
   2. Erro gentil: som suave (em vez do "buzz"), sem vermelho forte; a
      certa pisca em verde.
   3. Sons de degrau e de desafio; botão 🔊/🔇 no celular do aluno.
   4. Conquistas (🏅): medalhas que o aluno coleciona; estante no celular.
   5. Telão: "🏅 Ana conquistou o degrau …" e "🎖️ Beto ganhou: …".
   6. Pratos das figuras com visual novo (prato branco).
   Funções originais intactas: só embrulhos (beep, app.localAnswer,
   registrar, gerarQuestao) e CSS por cima.
========================================================================= */
const ENG = { mudoKey: 'cgm_som' };
const somMudo = () => { try{ return localStorage.getItem(ENG.mudoKey) === '0'; }catch(e){ return false; } };
const MEDALHAS = [
  ['seq5', '🔥', '5 seguidas', 'Acertar 5 questões seguidas'], ['seq10', '⚡', '10 seguidas', 'Acertar 10 questões seguidas'], ['seq20', '🌟', '20 seguidas', 'Acertar 20 questões seguidas'],
  ['ac50', '🎯', '50 acertos', 'Somar 50 acertos na trilha'], ['ac200', '🏹', '200 acertos', 'Somar 200 acertos na trilha'], ['ac500', '💎', '500 acertos', 'Somar 500 acertos na trilha'],
  ['deg1', '🪜', 'Primeiro degrau', 'Conquistar o primeiro degrau jogando'], ['deg10', '🧗', '10 degraus', 'Conquistar 10 degraus jogando'], ['deg25', '🏔️', '25 degraus', 'Conquistar 25 degraus jogando'],
  ['dia3', '📅', '3 degraus num dia', 'Conquistar 3 degraus no mesmo dia'], ['des1', '⭐', 'Primeiro desafio', 'Vencer o primeiro desafio'], ['des10', '🌠', '10 desafios', 'Vencer 10 desafios'],
  ['pers', '💪', 'Não desistiu', 'Acertar logo depois de errar 3 seguidas'],
];
const MED_POR = Object.fromEntries(MEDALHAS.map(m => [m[0], m]));
const degJogando = rec => Object.values(rec.deg || {}).filter(d => d.dom && d.domPor && d.domPor !== 'ano' && d.domPor !== 'diag').length;
function checarMedalhas(rec, s, ok){
  const md = rec.med || (rec.med = { ac: 0, errSeq: 0, dia: '', diaN: 0, deg: degJogando(rec), g: {} });
  const novas = [], ganha = id => { if(!md.g[id]){ md.g[id] = Date.now(); novas.push(id); } };
  if(ok){ md.ac++; if(md.errSeq >= 3) ganha('pers'); md.errSeq = 0; } else md.errSeq++;
  const st = s ? s.curStreak : 0;
  if(st >= 5) ganha('seq5'); if(st >= 10) ganha('seq10'); if(st >= 20) ganha('seq20');
  if(md.ac >= 50) ganha('ac50'); if(md.ac >= 200) ganha('ac200'); if(md.ac >= 500) ganha('ac500');
  const dj = degJogando(rec), hoje = new Date().toISOString().slice(0, 10);
  if(md.dia !== hoje){ md.dia = hoje; md.diaN = 0; }
  if(dj > md.deg){ md.diaN += dj - md.deg; }
  md.deg = dj;
  if(dj >= 1) ganha('deg1'); if(dj >= 10) ganha('deg10'); if(dj >= 25) ganha('deg25'); if(md.diaN >= 3) ganha('dia3');
  const dv = rec.desafios ? rec.desafios.ok : 0; if(dv >= 1) ganha('des1'); if(dv >= 10) ganha('des10');
  return novas;
}

if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .pp-opt.wrong{border-color:#94a3b8!important;background:rgba(148,163,184,.14)!important;opacity:.85}
  .pp-question.flash-wrong{--flash-color:rgba(148,163,184,.18)!important}
  .pp-opt.correct{animation:engCerta .9s ease-in-out 1}
  @keyframes engCerta{0%,100%{transform:scale(1)}30%{transform:scale(1.06);box-shadow:0 0 24px rgba(34,197,94,.7)}60%{transform:scale(.98)}}
  .eng-mais{position:fixed;z-index:560;font-weight:900;font-size:clamp(26px,7vw,40px);color:#4ade80;text-shadow:0 3px 0 rgba(0,0,0,.35);pointer-events:none;animation:engSobe 1s ease-out forwards}
  @keyframes engSobe{0%{transform:translate(-50%,0) scale(.6);opacity:0}20%{opacity:1;transform:translate(-50%,-10px) scale(1.15)}100%{transform:translate(-50%,-80px) scale(1);opacity:0}}
  .eng-conf{position:fixed;z-index:555;width:9px;height:9px;border-radius:2px;pointer-events:none;animation:engConf .9s ease-out forwards}
  @keyframes engConf{0%{transform:translate(0,0) rotate(0);opacity:1}100%{transform:translate(var(--dx),var(--dy)) rotate(540deg);opacity:0}}
  .eng-seq{position:fixed;left:50%;top:18%;z-index:565;transform:translate(-50%,0);background:linear-gradient(135deg,#f97316,#facc15);color:#1a0f00;font-weight:900;font-size:clamp(24px,7vw,40px);padding:12px 26px;border-radius:999px;border:4px solid #fff7ed;box-shadow:0 12px 40px rgba(0,0,0,.5);pointer-events:none;animation:engSeq 1.6s ease-out forwards;white-space:nowrap}
  @keyframes engSeq{0%{transform:translate(-50%,0) scale(.3);opacity:0}15%{transform:translate(-50%,0) scale(1.15);opacity:1}25%{transform:translate(-50%,0) scale(1)}80%{opacity:1}100%{transform:translate(-50%,-30px) scale(1);opacity:0}}
  .eng-med{position:fixed;left:50%;top:10px;z-index:590;transform:translateX(-50%);background:#0f172a;border:3px solid #fbbf24;border-radius:18px;padding:10px 18px;display:flex;align-items:center;gap:12px;box-shadow:0 12px 40px rgba(0,0,0,.6);animation:engMed 3.2s ease-out forwards;pointer-events:none}
  .eng-med .e{font-size:40px}.eng-med .t{font-weight:900;color:#fbbf24;font-size:14px}.eng-med .n{font-weight:900;font-size:20px;color:#fff}
  @keyframes engMed{0%{transform:translate(-50%,-120%)}12%{transform:translate(-50%,0)}85%{transform:translate(-50%,0);opacity:1}100%{transform:translate(-50%,-120%);opacity:0}}
  #engBts{position:fixed;left:10px;bottom:10px;z-index:450;display:flex;gap:8px}
  #engBts button{width:auto;padding:8px 12px;border-radius:12px;font-size:18px;font-weight:900;background:rgba(15,23,42,.9);border:2px solid #334155;color:#fff}
  .eng-estante{position:fixed;inset:0;z-index:600;background:rgba(2,6,23,.92);display:flex;align-items:center;justify-content:center;padding:14px}
  .eng-estante .cx{background:#0f172a;border:3px solid #fbbf24;border-radius:20px;padding:16px;max-width:560px;width:100%;max-height:92vh;overflow:auto}
  .eng-estante h3{margin:0 0 10px;color:#fbbf24;text-align:center}
  .eng-grade{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
  .eng-m{background:#1e293b;border:2px solid #334155;border-radius:14px;padding:10px;text-align:center}
  .eng-m .e{font-size:36px}.eng-m .n{font-weight:900}.eng-m .d{font-size:12px;color:#94a3b8}
  .eng-m.nao{opacity:.45;filter:grayscale(1)}
  .eng-tel{position:fixed;left:50%;bottom:24px;z-index:445;transform:translateX(-50%);background:linear-gradient(135deg,#1e3a8a,#7c3aed);color:#fff;font-weight:900;font-size:clamp(18px,2vw,26px);padding:12px 26px;border-radius:999px;border:3px solid #fbbf24;box-shadow:0 10px 40px rgba(0,0,0,.6);animation:engTel 4s ease-out forwards;white-space:nowrap;max-width:90vw;overflow:hidden;text-overflow:ellipsis}
  @keyframes engTel{0%{transform:translate(-50%,140%)}10%{transform:translate(-50%,0)}88%{transform:translate(-50%,0);opacity:1}100%{transform:translate(-50%,140%);opacity:0}}`;
  document.head.appendChild(st);

  /* ---------- sons ---------- */
  const beep0 = beep;
  const nota = (f, d, t = 'sine', v = .07, atraso = 0) => setTimeout(() => beep0(f, d, t, v), atraso);
  ENG.acerto = () => { nota(784, .09, 'sine', .07); nota(1047, .16, 'sine', .07, 75); };
  ENG.erro = () => { nota(330, .12, 'sine', .045); nota(262, .18, 'sine', .04, 90); };
  ENG.fanfarra = () => [523, 659, 784, 1047, 1319].forEach((f, i) => nota(f, .16, 'triangle', .08, i * 85));
  ENG.medalha = () => [880, 1175, 1568].forEach((f, i) => nota(f, .14, 'sine', .07, i * 110));
  beep = function(f, d, t, v){
    if(app.mode !== 'teacher'){
      if(somMudo()) return;
      if(f === 180 && t === 'sawtooth') return ENG.erro();          // erro: som suave
      if(f === 660 && t === 'triangle' && d === .1) return ENG.acerto();
    }
    return beep0.apply(this, arguments);
  };

  /* ---------- botões do aluno: som e conquistas ---------- */
  const bts = document.createElement('div'); bts.id = 'engBts'; bts.className = 'hidden';
  bts.innerHTML = `<button id="engSom" title="Som">🔊</button><button id="engMedBtn" title="Minhas conquistas">🏅 0</button>`;
  document.body.appendChild(bts);
  const atualizaBts = () => {
    $('engSom').textContent = somMudo() ? '🔇' : '🔊';
    const rec = app.player && app.player.trilha && app.player.trilha.rec;
    $('engMedBtn').textContent = '🏅 ' + (rec && rec.med ? Object.keys(rec.med.g).length : 0);
  };
  $('engSom').onclick = () => { try{ localStorage.setItem(ENG.mudoKey, somMudo() ? '1' : '0'); }catch(e){} atualizaBts(); };
  $('engMedBtn').onclick = () => {
    const rec = app.player && app.player.trilha && app.player.trilha.rec, g = rec && rec.med ? rec.med.g : {};
    const box = document.createElement('div'); box.className = 'eng-estante';
    box.innerHTML = `<div class="cx"><h3>🏅 Minhas conquistas (${Object.keys(g).length} de ${MEDALHAS.length})</h3><div class="eng-grade">${MEDALHAS.map(([id, e, n, d]) => `<div class="eng-m ${g[id] ? '' : 'nao'}"><div class="e">${g[id] ? e : '🔒'}</div><div class="n">${esc(n)}</div><div class="d">${esc(d)}</div></div>`).join('')}</div>
      <button class="primary" style="margin-top:12px;width:100%">Voltar</button></div>`;
    document.body.appendChild(box); box.onclick = e => { if(e.target === box || e.target.closest('button')) box.remove(); };
  };
  setInterval(() => { const vis = app.mode !== 'teacher' && $('playerPlay') && !$('playerPlay').classList.contains('hidden'); bts.classList.toggle('hidden', !vis); if(vis) atualizaBts(); }, 1000);

  /* ---------- efeitos ao responder ---------- */
  const confete = (x, y) => { const cores = ['#f59e0b', '#22c55e', '#3b82f6', '#ec4899', '#facc15', '#a855f7'];
    for(let i = 0; i < 16; i++){ const c = document.createElement('div'); c.className = 'eng-conf'; const a = Math.random() * Math.PI * 2, r = 60 + Math.random() * 90;
      c.style.cssText = `left:${x}px;top:${y}px;background:${cores[i % cores.length]};--dx:${Math.cos(a) * r}px;--dy:${Math.sin(a) * r - 40}px`; document.body.appendChild(c); setTimeout(() => c.remove(), 950); } };
  const SEQ = { 3: '🔥 3 seguidas!', 5: '🔥🔥 5 seguidas! Em chamas!', 10: '⚡ 10 seguidas! Imparável!', 15: '🌟 15 seguidas! Fera!', 20: '🚀 20 seguidas! Lenda!' };
  const mostraMedalha = id => { const m = MED_POR[id]; if(!m) return; const d = document.createElement('div'); d.className = 'eng-med'; d.innerHTML = `<div class="e">${m[1]}</div><div><div class="t">🏅 NOVA CONQUISTA</div><div class="n">${esc(m[2])}</div></div>`; document.body.appendChild(d); try{ if(!somMudo()) ENG.medalha(); }catch(e){} setTimeout(() => d.remove(), 3300); };
  const localAnswer0 = app.localAnswer;
  app.localAnswer = function(idx){
    const q = this.player.currentQuestion, bloq = this.player.questionBlocked, s = this.player.stats, sc0 = s ? s.score : 0;
    const r = localAnswer0.apply(this, arguments);
    if(bloq || !q || this.mode === 'teacher') return r;
    try{
      const ok = idx === q.correct, card = $('ppQuestionCard');
      if(ok && card){
        const rc = card.getBoundingClientRect(), x = rc.left + rc.width / 2, y = rc.top + Math.min(rc.height / 2, 160);
        const dl = s.score - sc0;
        if(dl > 0){ const m = document.createElement('div'); m.className = 'eng-mais'; m.textContent = '+' + dl; m.style.left = x + 'px'; m.style.top = y + 'px'; document.body.appendChild(m); setTimeout(() => m.remove(), 1050); }
        confete(x, y);
        const sq = s.curStreak; if(SEQ[sq] || (sq > 20 && sq % 10 === 0)){ const b = document.createElement('div'); b.className = 'eng-seq'; b.textContent = SEQ[sq] || `🚀 ${sq} seguidas!`; document.body.appendChild(b); setTimeout(() => b.remove(), 1650); if(!somMudo()) ENG.fanfarra(); }
      }
      const pt = this.player.trilha, rec = pt && pt.rec;
      if(rec){ const novas = checarMedalhas(rec, s, ok); if(novas.length){ pt.sujo = true; novas.forEach((id, i) => setTimeout(() => mostraMedalha(id), 900 + i * 3400)); } }
    }catch(e){ console.warn('[engaja]', e); }
    return r;
  };
  /* desafio vencido: fanfarra */
  const registrar1 = registrar;
  registrar = function(rec, fonte){
    const ev = registrar1.apply(this, arguments);
    try{ if(typeof document !== 'undefined' && app.mode !== 'teacher' && !somMudo() && ev && (ev.desafio === 'venceu')) ENG.fanfarra(); }catch(e){}
    return ev;
  };

  /* ---------- telão: degraus e medalhas da turma ---------- */
  const visto = {}, fila = [];
  let mostrando = false;
  const proxima = () => { if(mostrando || !fila.length) return; mostrando = true; const t = fila.shift(); const d = document.createElement('div'); d.className = 'eng-tel'; d.innerHTML = t; document.body.appendChild(d);
    try{ [784, 988, 1175].forEach((f, i) => setTimeout(() => beep0(f, .12, 'sine', .06), i * 100)); }catch(e){}
    setTimeout(() => { d.remove(); mostrando = false; proxima(); }, 4100); };
  setInterval(() => {
    if(app.mode !== 'teacher' || app.host.isDemo || !$('hostGame') || $('hostGame').classList.contains('hidden')) return;
    app.host.players.filter(p => !p.isBot).forEach(p => {
      const r = estado.turma.alunos[normNome(p.name)]; if(!r) return;
      const doms = new Set(Object.keys(r.deg || {}).filter(id => { const d = r.deg[id]; return d.dom && d.domPor && d.domPor !== 'ano' && d.domPor !== 'diag'; }));
      const meds = new Set(Object.keys((r.med && r.med.g) || {}));
      const v = visto[p.id];
      if(v){
        doms.forEach(id => { if(!v.doms.has(id) && POR_ID[id]) fila.push(`🏅 <b>${esc(p.name)}</b> conquistou o degrau: ${esc(POR_ID[id].nome)}!`); });
        meds.forEach(id => { if(!v.meds.has(id) && MED_POR[id]) fila.push(`${MED_POR[id][1]} <b>${esc(p.name)}</b> ganhou a conquista: ${esc(MED_POR[id][2])}`); });
      }
      visto[p.id] = { doms, meds };
    });
    while(fila.length > 6) fila.shift();
    proxima();
  }, 2000);

  /* ---------- pratos com visual novo ---------- */
  const gq0 = gerarQuestao;
  gerarQuestao = function(){
    const q = gq0.apply(this, arguments);
    try{
      if(q && q.image && q.image.includes('e0f2fe') && q.image.includes('0369a1')){
        const pre = 'data:image/svg+xml;charset=utf-8,';
        if(q.image.startsWith(pre)){
          let s = decodeURIComponent(q.image.slice(pre.length));
          s = s.split('fill="#e0f2fe" stroke="#0369a1" stroke-width="3"').join('fill="#ffffff" stroke="#cbd5e1" stroke-width="5"').split('fill="#bae6fd"').join('fill="#f1f5f9"');
          q.image = pre + encodeURIComponent(s);
        }
      }
    }catch(e){}
    return q;
  };
})();
