/* =========================================================================
   REVISÃO COERENTE + FOCO SUGERIDO
   · Revisão: deixa de cair em degrau bem abaixo do ano da turma que o aluno só
     "ganhou" pelo diagnóstico (ex.: 2º ano para um aluno do 7º). Continuam na
     revisão: o que ele dominou jogando, o que é até 2 anos abaixo do ano da turma
     e os degraus-base (tabuada, divisão, frações, decimais, %…).
     O modo apoio (perguntas de conforto) não muda.
   · Foco sugerido: no cartão "Aula de hoje", embaixo do 🎯 Foco, aparece
     "💡 Sugestão: <atividade> (N alunos com dificuldade)" com [usar].
   Bloco novo: wrapper do escolherFonte e um aviso no cartão.
========================================================================= */
REGRA.revAnosAbaixo = 2;
function revisaoServe(rec, id){
  const d = rec.deg[id], g = POR_ID[id]; if(!d || !g) return false;
  if(d.domPor === 'trilha' || d.domPor === 'treino') return true;
  if(typeof BASE_REV !== 'undefined' && BASE_REV.has(id)) return true;
  return g.ano >= anoDaTurma() - REGRA.revAnosAbaixo;
}
const escolherFonteSemFiltro = escolherFonte;
escolherFonte = function(rec, sorte){
  const f = escolherFonteSemFiltro.apply(this, arguments);
  try{
    if(!f || f.tipo !== 'rev' || !rec || estado.temaEmUso || revisaoServe(rec, f.id)) return f;   // trilha por tema: não mexe
    // troca por outra revisão que faça sentido (a mais atrasada); se não houver, segue no degrau atual
    const cands = CAT.filter(d => ativo(d) && rec.deg[d.id] && rec.deg[d.id].dom && revisaoServe(rec, d.id))
      .map(d => ({ d, atraso: rec.resp - (rec.deg[d.id].revUlt || 0) - (rec.deg[d.id].revInt || REGRA.revIntervaloIni) }))
      .sort((a, b) => b.atraso - a.atraso);
    if(cands.length && cands[0].atraso >= 0) return { tipo: 'rev', id: cands[0].d.id, nivel: REGRA.nivelRevisao };
    if(rec.atual && POR_ID[rec.atual]) return { tipo: 'atual', id: rec.atual, nivel: degDo(rec, rec.atual).n };
    if(cands.length) return { tipo: 'rev', id: cands[0].d.id, nivel: REGRA.nivelRevisao };
  }catch(e){}
  return f;
};

/* ---------- foco sugerido ---------- */
function focoSugerido(){
  if(typeof estado.classificar !== 'function') return [];
  const A = (estado.turma && estado.turma.alunos) || {}, nomes = estado.cfg.nomes || [];
  const ano = Math.min(estado.cfg.ano || 7, LIMITE.anoMax || 9);
  const conta = {};
  nomes.forEach(n => {
    const r = A[normNome(n)]; if(!r) return;
    CAT.forEach(d => {
      if(!ativo(d) || d.ano > ano || !r.deg[d.id]) return;
      const s = estado.classificar(r, d);
      const peso = s.st === 'dificuldade' ? 2 : (s.st === 'aprendendo' && s.agora < 60 && (s.tot || 0) >= 5) ? 1 : 0;
      if(peso){ const c = conta[d.id] || (conta[d.id] = { id: d.id, pts: 0, dif: 0, alunos: 0 }); c.pts += peso; c.alunos++; if(peso === 2) c.dif++; }
    });
  });
  return Object.values(conta).filter(c => c.alunos >= 2).sort((a, b) => b.pts - a.pts || POR_ID[b.id].ano - POR_ID[a.id].ano).slice(0, 3);
}
estado.focoSugerido = focoSugerido;
if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .mn-sug{grid-column:2;display:flex;align-items:center;gap:8px;font-size:13px;color:#fde68a;margin-top:-4px;min-width:0}
  .mn-sug span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .mn-sug button{width:auto!important;padding:4px 10px!important;font-size:12px!important;border-radius:8px;background:#422006;border:1px solid #fde68a;color:#fde68a;font-weight:900;cursor:pointer}`;
  document.head.appendChild(st);
  let cache = { t: 0, sug: [] };
  function desenhar(){
    const fb = $('trFocoBox'); if(!fb) return;
    if(Date.now() - cache.t > 5000){ cache = { t: Date.now(), sug: focoSugerido() }; }
    const atuais = (estado.cfg.foco && estado.cfg.foco.ids) || [];
    const s = cache.sug.find(x => !atuais.includes(x.id));
    let el = fb.querySelector('.mn-sug');
    if(!s){ if(el) el.remove(); return; }
    if(!el){ el = document.createElement('div'); el.className = 'mn-sug'; fb.appendChild(el); }
    const d = POR_ID[s.id];
    const txt = `💡 Sugestão: <b>${esc(d.nome)}</b> (${s.dif ? `${s.dif} com dificuldade` : `${s.alunos} com acerto baixo`})`;
    const tip = 'Atividades em que a turma mais precisa de ajuda:\n' + cache.sug.map(x => `• ${POR_ID[x.id].nome} (${POR_ID[x.id].ano}º ano): ${x.dif} com dificuldade, ${x.alunos - x.dif} com acerto baixo`).join('\n');
    const html = `<span title="${esc(tip)}">${txt}</span><button data-sugid="${esc(s.id)}">usar</button>`;
    if(el.dataset.h !== html){ el.innerHTML = html; el.dataset.h = html; }
  }
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-sugid]'); if(!b) return;
    const id = b.dataset.sugid; if(!POR_ID[id]) return;
    const freq = (estado.cfg.foco && estado.cfg.foco.freq) || 0.25;
    estado.cfg.foco = { ids: [id], freq, stamp: Date.now() };
    salvarCfg(); salvarTurmaLocal();
    try{ atualizarBotaoFoco(); }catch(err){}
    if(app.room && app.mode === 'teacher') try{ app.broadcastState(); }catch(err){}
    app.toast(`🎯 Foco da aula: <b>${esc(POR_ID[id].nome)}</b>`, 'success');
    cache.t = 0; desenhar();
  });
  const montarCartao0 = montarCartao;
  montarCartao = function(){ const r = montarCartao0.apply(this, arguments); cache.t = 0; try{ desenhar(); }catch(e){} return r; };
  setInterval(() => { try{ desenhar(); }catch(e){} }, 3000);
  try{ desenhar(); }catch(e){}
})();
