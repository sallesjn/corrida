/* =========================================================================
   EF06MA24 — degrau "Problemas com grandezas" no fim do 6º ano da trilha.
   Só acrescenta: entra no catálogo depois do último degrau do 6º ano
   (os índices são renumerados; o progresso dos alunos é por nome do degrau).
========================================================================= */
(function(){
  if(typeof G.grandezas6 !== 'function' || POR_ID.grandezas6) return;
  const d = { id: 'grandezas6', ano: 6, un: 'Grandezas e medidas', bncc: 'EF06MA24', nome: 'Problemas com grandezas (medidas e tempo)', t: 1.7 };
  let pos = -1; CAT.forEach((x, i) => { if(x.ano <= 6) pos = i; });
  CAT.splice(pos + 1, 0, d);
  CAT.forEach((x, i) => { x.i = i; x.ordem = i; });
  d.anoOrig = d.ano; d.prov = false;
  POR_ID[d.id] = d;
  TYPE_LABELS[d.id] = `${d.ano}º · ${d.nome}`; TYPE_TIME_FACTOR[d.id] = d.t;
  DICA.grandezas6 = m => ({
    div: 'Passe tudo para a mesma unidade (1 L = 1 000 mL · 1 kg = 1 000 g · 1 m = 100 cm) e veja quantas vezes a parte cabe no total.',
    chegada: 'Some as horas e os minutos separados. Se os minutos passarem de 60, transforme 60 min em 1 hora.',
    temp: 'Quanto subiu = máxima − mínima.',
    duracao: 'Conte do início até a hora cheia seguinte, depois as horas inteiras, depois os minutos que sobram.',
    festa: 'Calcule o total em mL, passe para litros e veja quantas garrafas de 2 L. Se sobrar um pouco, precisa de mais uma garrafa.',
    receita: 'Multiplique os gramas pelo número de receitas e divida por 1 000 para ter quilos.',
    cubos: 'Conte quantos cubinhos tem uma camada (fileiras × cubinhos) e multiplique pelo número de camadas.',
    corrida: 'Calcule quantos metros ela já correu (voltas × pista), passe a meta para metros (1 km = 1 000 m) e subtraia.',
    aulas: 'Some o tempo de todas as aulas e o intervalo, e conte a partir da hora em que começa.',
    lajotas: 'Veja quantas lajotas cabem em cada lado (1 m = 100 cm) e multiplique as duas quantidades.',
  })[m.k] || 'Passe tudo para a mesma unidade antes de fazer a conta.';
})();
