
/* =========================================================================
   LOTE 4 — o que faltava do currículo SEDU 2026: 4º e 5º ano
========================================================================= */

/* ============================ 4º ANO ============================ */

/* Décimos e centésimos (EF04MA10) */
function barra10SVG(k, cor = '#22c55e'){ let o = ''; for(let i = 0; i < 10; i++) o += `<rect x="${10 + i * 48}" y="10" width="48" height="80" fill="${i < k ? cor : '#fff'}" stroke="#111" stroke-width="3"/>`; return SVG(500, 100, o); }
G.decimos4 = n => {
  if(n === 1){
    const k = rnd(1, 9), v = k / 10;
    const erradas = [{ v: k, erro: 'esqueceu a vírgula' }, { v: k / 100, erro: 'confundiu décimo com centésimo' }, { v: (10 - k) / 10, erro: 'contou as partes sem pintar' }, { v: (k + 1) / 10, erro: 'contou uma parte a mais' }];
    const o = opcoesDecimaisTR(v, erradas, fmtDec);
    return { ...o, text: 'A barra inteira vale 1. Que número decimal representa a parte pintada?', image: svgURI(barra10SVG(k)), meta: { v }, chave: 'dc' + k };
  }
  const inteiro = n === 3 ? rnd(1, 2) : 0;
  const p = sortearAte(() => rnd(3, 97), x => x % 10 !== 0);
  const v = inteiro + p / 100;
  const erradas = [{ v: inteiro + p / 1000, erro: 'confundiu centésimo com milésimo' }, { v: inteiro + p / 10, erro: 'confundiu centésimo com décimo' }, { v: inteiro + (p % 10 * 10 + Math.floor(p / 10)) / 100, erro: 'inverteu os algarismos' }, { v: inteiro + (100 - p) / 100, erro: 'contou os quadradinhos sem pintar' }, { v: n === 3 ? p / 100 : p, erro: n === 3 ? 'esqueceu os quadrados inteiros' : 'esqueceu a vírgula' }];
  const o = opcoesDecimaisTR(v, erradas, fmtDec);
  let img;
  if(inteiro){ const g = [...Array(inteiro)].map(() => grade100SVG(100, '#22c55e')).concat([grade100SVG(p, '#22c55e')]); img = SVG(g.length * 230, 230, g.map((s, i) => s.replace(/^<svg[^>]*>/, `<svg x="${i * 230}" y="0" width="220" height="220" viewBox="0 0 ${s.match(/viewBox="0 0 (\d+) (\d+)"/)[1]} ${s.match(/viewBox="0 0 (\d+) (\d+)"/)[2]}">`)).join('')); }
  else img = grade100SVG(p, '#22c55e');
  return { ...o, text: inteiro ? 'Cada quadrado grande vale 1. Que número decimal está pintado ao todo?' : 'O quadrado inteiro vale 1. Que número decimal representa a parte pintada?', image: svgURI(img), meta: { v }, chave: 'dc' + v };
};
C.decimos4 = m => fmtDec(Math.round(m.v * 1000) / 1000);

/* Quantos ângulos retos tem a figura (EF04MA18) */
const POLIS_RETO = {
  quadrado: [[0, 0], [160, 0], [160, 160], [0, 160]], 'retângulo': [[0, 0], [240, 0], [240, 130], [0, 130]],
  'trapézio retângulo': [[0, 0], [150, 0], [230, 140], [0, 140]], 'triângulo retângulo': [[0, 0], [0, 150], [220, 150]],
  'triângulo': [[110, 0], [220, 170], [0, 170]], paralelogramo: [[60, 0], [260, 0], [200, 130], [0, 130]],
  'casinha': [[0, 80], [100, 0], [200, 80], [200, 200], [0, 200]], 'figura em L': [[0, 0], [90, 0], [90, 120], [200, 120], [200, 200], [0, 200]],
  'trapézio': [[70, 0], [190, 0], [260, 140], [0, 140]], 'pipa': [[100, 0], [180, 70], [100, 220], [20, 70]],
};
const angulosRetos = P => P.filter((p, i) => { const a = P[(i + P.length - 1) % P.length], b = P[(i + 1) % P.length]; const u = [a[0] - p[0], a[1] - p[1]], v = [b[0] - p[0], b[1] - p[1]];
  const dot = u[0] * v[0] + u[1] * v[1], crs = u[0] * v[1] - u[1] * v[0]; return Math.abs(dot) < 1e-6 * Math.hypot(...u) * Math.hypot(...v) && crs < 0 === (P.reduce((s, q, k) => s + (q[0] * P[(k + 1) % P.length][1] - P[(k + 1) % P.length][0] * q[1]), 0) > 0) === false || (Math.abs(dot) < 1e-6 * Math.hypot(...u) * Math.hypot(...v) && interno90(P, i)); }).length;
function interno90(P, i){       // o ângulo interno é 90° (e não 270°)? usa o sinal da área e do produto vetorial
  const n = P.length, a = P[(i + n - 1) % n], p = P[i], b = P[(i + 1) % n];
  const area = P.reduce((s, q, k) => s + (q[0] * P[(k + 1) % n][1] - P[(k + 1) % n][0] * q[1]), 0);
  const crs = (p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0]);
  return Math.sign(crs) === Math.sign(area);            // vira para o mesmo lado da figura = canto convexo
}
const retosDe = P => P.filter((p, i) => { const n = P.length, a = P[(i + n - 1) % n], b = P[(i + 1) % n]; const u = [a[0] - p[0], a[1] - p[1]], v = [b[0] - p[0], b[1] - p[1]]; return Math.abs(u[0] * v[0] + u[1] * v[1]) < 1e-6 * Math.hypot(...u) * Math.hypot(...v) && interno90(P, i); }).length;
function poliSVG(P, giro, cor = '#fde68a'){
  const c = P.reduce((a, p) => [a[0] + p[0] / P.length, a[1] + p[1] / P.length], [0, 0]), g = giro * Math.PI / 180;
  let Q = P.map(([x, y]) => [c[0] + (x - c[0]) * Math.cos(g) - (y - c[1]) * Math.sin(g), c[1] + (x - c[0]) * Math.sin(g) + (y - c[1]) * Math.cos(g)]);
  const mx = Math.min(...Q.map(p => p[0])), my = Math.min(...Q.map(p => p[1]));
  Q = Q.map(([x, y]) => [x - mx + 30, y - my + 30]);
  const W = Math.max(...Q.map(p => p[0])) + 30, H = Math.max(...Q.map(p => p[1])) + 30;
  return SVG(W, H, `<polygon points="${Q.map(p => p.map(v => v.toFixed(1)).join(',')).join(' ')}" fill="${cor}" stroke="#111" stroke-width="4" stroke-linejoin="round"/>`);
}
G.anguloReto4 = n => {
  const pool = n === 1 ? ['quadrado', 'retângulo', 'triângulo retângulo', 'triângulo', 'paralelogramo'] : Object.keys(POLIS_RETO);
  const nome = pick(pool), P = POLIS_RETO[nome], giro = n === 3 ? pick([20, 35, -25, 45]) : 0;
  const r = retosDe(P);
  const erradas = [{ v: P.length, erro: 'contou todos os cantos' }, { v: r + 1, erro: 'contou um ângulo a mais' }, { v: r - 1, erro: 'esqueceu um ângulo reto' }, { v: nome === 'figura em L' ? 6 : 4, erro: 'achou que todo canto é reto' }, { v: 0, erro: 'não achou nenhum ângulo reto' }];
  const a = alternativas(r, erradas, String, { min: 0, max: 6 });
  return { ...a, text: 'Quantos ÂNGULOS RETOS (cantos de 90°, como o do esquadro) tem esta figura?', image: svgURI(poliSVG(P, giro)), meta: { P }, chave: 'ar' + nome + giro };
};
C.anguloReto4 = m => {       // confere medindo cada ângulo interno pelo arco-cosseno
  const P = m.P, n = P.length; let q = 0;
  const area = P.reduce((s, p, k) => s + (p[0] * P[(k + 1) % n][1] - P[(k + 1) % n][0] * p[1]), 0);
  for(let i = 0; i < n; i++){ const a = P[(i + n - 1) % n], p = P[i], b = P[(i + 1) % n];
    const ang = Math.acos(((a[0] - p[0]) * (b[0] - p[0]) + (a[1] - p[1]) * (b[1] - p[1])) / (Math.hypot(a[0] - p[0], a[1] - p[1]) * Math.hypot(b[0] - p[0], b[1] - p[1]))) * 180 / Math.PI;
    const convexo = Math.sign((p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0])) === Math.sign(area);
    if(convexo && Math.abs(ang - 90) < 0.01) q++; }
  return String(q);
};

/* Desconto e troco (EF04MA25) */
function etiquetaDesc(x, y, nome, cor, preco, desc){
  return `<rect x="${x}" y="${y}" width="200" height="140" rx="12" fill="${cor}" opacity=".18" stroke="${cor}" stroke-width="3"/>` + T(x + 100, y + 36, nome, { fs: 20 }) +
    `<rect x="${x + 30}" y="${y + 50}" width="140" height="44" rx="8" fill="#fef3c7" stroke="#92400e" stroke-width="2.5"/>` + T(x + 100, y + 81, 'R$ ' + preco, { fs: 24 }) +
    (desc ? `<rect x="${x + 20}" y="${y + 100}" width="160" height="32" rx="16" fill="#dc2626"/>` + T(x + 100, y + 123, `DESCONTO R$ ${desc}`, { fs: 16, cor: '#fff' }) : '');
}
G.trocoDesc4 = n => {
  const [nome, cor] = pick(PRODUTOS);
  const preco = rnd(n === 1 ? 10 : 15, n === 1 ? 40 : 90), desc = n === 2 ? 0 : 5 * rnd(1, Math.min(6, Math.floor((preco - 5) / 5)));
  const pagar = preco - desc;
  if(n === 1){
    const erradas = [{ v: preco + desc, erro: 'somou o desconto' }, { v: preco, erro: 'esqueceu o desconto' }, { v: desc, erro: 'respondeu o desconto' }, { v: pagar + 1, erro: 'errou a conta' }];
    const a = alternativas(pagar, erradas, v => 'R$ ' + v, { min: 1 });
    return { ...a, text: 'Quanto vou pagar, já com o desconto?', image: svgURI(SVG(220, 160, etiquetaDesc(10, 10, nome, cor, preco, desc))), meta: { preco, desc, nota: 0 }, chave: `td${preco}-${desc}` };
  }
  let nota = [20, 50, 100].find(x => x > pagar) || 100;
  const tr = nota - pagar;
  const erradas = [{ v: nota - preco >= 0 ? nota - preco : null, erro: 'esqueceu o desconto' }, { v: nota - preco - desc >= 0 ? nota - preco - desc : null, erro: 'tirou o desconto do troco' }, { v: pagar, erro: 'respondeu o valor a pagar' }, { v: tr + 1, erro: 'errou a conta' }, { v: tr + 10, erro: 'errou as dezenas' }];
  const a = alternativas(tr, erradas.filter(e => e.v !== null && e.v !== tr), v => 'R$ ' + v, { min: 0 });
  const k = { 20: 'n20', 50: 'n50', 100: 'n100' }[nota];
  return { ...a, text: `Paguei com esta nota. Quanto recebo de troco${desc ? ' (já com o desconto)' : ''}?`, image: svgURI(SVG(430, 160, etiquetaDesc(10, 10, nome, cor, preco, desc) + `<image href="${IMG[k]}" x="225" y="30" width="195" height="100" preserveAspectRatio="xMidYMid meet"/>`)), meta: { preco, desc, nota }, chave: `td${preco}-${desc}-${nota}` };
};
C.trocoDesc4 = m => 'R$ ' + (m.nota ? m.nota - (m.preco - m.desc) : m.preco - m.desc);

/* Fração na reta (EF04MA09) */
function retaFracSVG(d, max, k){
  const W = 520, x0 = 30, L = 460, y = 70, X = v => x0 + v / max * L;
  let o = `<line x1="${x0 - 10}" y1="${y}" x2="${x0 + L + 16}" y2="${y}" stroke="#111" stroke-width="3"/><polygon points="${x0 + L + 22},${y} ${x0 + L + 10},${y - 7} ${x0 + L + 10},${y + 7}" fill="#111"/>`;
  for(let i = 0; i <= d * max; i++){ const inteiro = i % d === 0, x = X(i / d); o += `<line x1="${x}" y1="${y - (inteiro ? 16 : 9)}" x2="${x}" y2="${y + (inteiro ? 16 : 9)}" stroke="#111" stroke-width="${inteiro ? 3.5 : 2}"/>`; if(inteiro) o += T(x, y + 44, i / d, { fs: 24 }); }
  o += `<circle cx="${X(k / d)}" cy="${y}" r="9" fill="#dc2626"/>` + T(X(k / d), y - 24, 'A', { fs: 26, cor: '#dc2626' });
  return SVG(W, 130, o);
}
G.fracReta4 = n => {
  const d = pick(n === 1 ? [2, 4] : n === 2 ? [3, 4, 5, 8, 10] : [2, 3, 4, 5]), max = n === 3 ? 2 : 1;
  const k = sortearAte(() => rnd(1, d * max - 1), x => x % d !== 0);
  const erradas = [{ v: `${k}/${d + 1}`, erro: 'contou os tracinhos em vez das partes' }, { v: `${k + 1}/${d}`, erro: 'contou uma parte a mais' }, { v: `${k - 1}/${d}`, erro: 'contou uma parte a menos' }, { v: `${d}/${k}`, erro: 'inverteu a fração' }, { v: max === 1 ? `${d - k}/${d}` : `${k - d}/${d}`, erro: max === 1 ? 'contou de trás para frente' : 'esqueceu o primeiro inteiro' }];
  const o = altFrac(`${k}/${d}`, erradas, d);
  return { ...o, text: 'Que fração está no lugar da letra A?', image: svgURI(retaFracSVG(d, max, k)), meta: { k, d }, chave: `fr${k}/${d}` };
};
C.fracReta4 = m => `${m.k}/${m.d}`;

/* Roleta com fatias de tamanhos diferentes (EF04MA26) */
function roletaAngSVG(fatias){       // [[cor, graus], ...]
  const cx = 150, cy = 150, R = 130; let a0 = -90, o = '';
  fatias.forEach(([c, g]) => { const a1 = a0 + g, r0 = a0 * Math.PI / 180, r1 = a1 * Math.PI / 180;
    o += `<path d="M${cx} ${cy} L${(cx + R * Math.cos(r0)).toFixed(1)} ${(cy + R * Math.sin(r0)).toFixed(1)} A${R} ${R} 0 ${g > 180 ? 1 : 0} 1 ${(cx + R * Math.cos(r1)).toFixed(1)} ${(cy + R * Math.sin(r1)).toFixed(1)} Z" fill="${c}" stroke="#111" stroke-width="3"/>`; a0 = a1; });
  return SVG(300, 300, o + `<circle cx="${cx}" cy="${cy}" r="10" fill="#111"/><polygon points="${cx - 12},6 ${cx + 12},6 ${cx},34" fill="#111"/>`);
}
G.roleta4 = n => {
  const cores = shuffle(COR_ROL).slice(0, 3), mais = Math.random() < .6;
  let fatias, area;
  if(n < 3){
    const qs = sortearAte(() => cores.map(() => rnd(1, n === 1 ? 5 : 4)), v => new Set(v).size === 3);
    const lista = shuffle(cores.flatMap(([nm, h], i) => Array(qs[i]).fill([nm, h])));
    fatias = lista.map(([nm, h]) => [h, 360 / lista.length, nm]);
  } else {                     // armadilha: a cor com MAIS fatias tem MENOS espaço
    const [A, B, Cc] = cores;
    fatias = shuffle([[A[1], 180, A[0]], [B[1], 40, B[0]], [B[1], 40, B[0]], [B[1], 40, B[0]], [Cc[1], 60, Cc[0]]]);
  }
  area = cores.map(([nm]) => fatias.filter(f => f[2] === nm).reduce((s, f) => s + f[1], 0));
  const alvo = mais ? Math.max(...area) : Math.min(...area), iC = area.indexOf(alvo);
  const nFat = cores.map(([nm]) => fatias.filter(f => f[2] === nm).length), iArm = nFat.indexOf(mais ? Math.max(...nFat) : Math.min(...nFat));
  const erradas = cores.map(([nm], i) => i === iC ? null : { v: nm, erro: i === iArm ? 'contou as fatias, não o tamanho delas' : 'comparou errado' }).concat([{ v: 'Todas têm a mesma chance', erro: 'achou que é igual' }]);
  const a = alternativas(cores[iC][0], erradas, String);
  return { ...a, text: `Girando a roleta, qual cor tem ${mais ? 'MAIS' : 'MENOS'} chance de sair?`, image: svgURI(roletaAngSVG(fatias)), meta: { fatias: fatias.map(f => [f[2], f[1]]), mais }, chave: 'rl' + fatias.map(f => f[2][0] + f[1]).join('') + mais };
};
C.roleta4 = m => { const t = {}; m.fatias.forEach(([c, g]) => t[c] = (t[c] || 0) + g); const ks = Object.keys(t); let b = ks[0]; ks.forEach(k => { if(m.mais ? t[k] > t[b] : t[k] < t[b]) b = k; }); return b; };

/* Horas, minutos e segundos no relógio digital (EF04MA22) */
G.horasDig4 = n => {
  if(n === 3){
    const mi = rnd(1, 4), se = rnd(5, 55), tot = mi * 60 + se;
    const erradas = [{ v: mi * 100 + se, erro: 'achou que 1 minuto tem 100 segundos' }, { v: mi + se, erro: 'somou minutos e segundos' }, { v: tot + 60, erro: 'contou um minuto a mais' }, { v: tot - 60, erro: 'contou um minuto a menos' }];
    const a = alternativas(tot, erradas, v => v + ' s', { min: 1 });
    return { ...a, text: `O cronômetro marca ${mi} minuto${mi > 1 ? 's' : ''} e ${se} segundos. Quantos segundos são? (1 min = 60 s)`, image: svgURI(SVG(300, 120, `<rect x="10" y="10" width="280" height="100" rx="16" fill="#111827" stroke="#475569" stroke-width="5"/>` + T(150, 82, `${String(mi).padStart(2, '0')}:${String(se).padStart(2, '0')}`, { fs: 58, cor: '#4ade80', extra: ' font-family="monospace"' }))), meta: { tot }, chave: `hs${mi}:${se}` };
  }
  const h0 = rnd(7, 15), m0 = n === 1 ? pick([0, 30]) : 5 * rnd(0, 11), dur = n === 1 ? 30 * rnd(2, 6) : 5 * rnd(8, 40);
  const fimMin = h0 * 60 + m0 + dur, h1 = Math.floor(fimMin / 60), m1 = fimMin % 60;
  const erradas = [{ v: dur + 40, erro: 'achou que 1 hora tem 100 minutos' }, { v: dur - 60 > 0 ? dur - 60 : null, erro: 'esqueceu uma hora' }, { v: dur + 60, erro: 'contou uma hora a mais' }, { v: dur - 5, erro: 'contou 5 minutos a menos' }, { v: dur + 10, erro: 'errou os minutos' }];
  const a = alternativas(dur, erradas.filter(e => e.v && e.v !== dur && e.v > 0), fmtDur, { min: 5, passo: 5 });
  const dig = (x, h, m, rot) => `<rect x="${x}" y="30" width="200" height="90" rx="14" fill="#111827" stroke="#475569" stroke-width="4"/>` + T(x + 100, 94, `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`, { fs: 50, cor: '#4ade80', extra: ' font-family="monospace"' }) + T(x + 100, 20, rot, { fs: 18 });
  return { ...a, text: 'Quanto tempo durou a aula de reforço?', image: svgURI(SVG(460, 130, dig(10, h0, m0, 'COMEÇOU') + dig(250, h1, m1, 'TERMINOU'))), meta: { dur }, chave: `hd${h0}:${m0}+${dur}` };
};
C.horasDig4 = m => m.tot !== undefined ? m.tot + ' s' : fmtDur(m.dur);

/* ============================ 5º ANO ============================ */

/* Nota fiscal da cantina (EF05MA07 · EF05MA08) */
const CANTINA = [['Suco', 250], ['Pão de queijo', 175], ['Bolo', 325], ['Pipoca', 150], ['Salgado', 400], ['Picolé', 225], ['Água', 125], ['Fruta', 100]];
function notaSVG(itens, pago){
  const W = 420, lin = 38, H = 150 + itens.length * lin + (pago ? 40 : 0);
  let o = `<rect x="10" y="10" width="${W - 20}" height="${H - 20}" fill="#fffbeb" stroke="#92400e" stroke-width="2" stroke-dasharray="8,4"/>` + T(W / 2, 44, 'CANTINA DA ESCOLA', { fs: 22 }) +
    T(30, 76, 'Item', { fs: 16, anc: 'start', cor: '#475569' }) + T(250, 76, 'Qtd', { fs: 16, cor: '#475569' }) + T(W - 30, 76, 'Preço un.', { fs: 16, anc: 'end', cor: '#475569' });
  itens.forEach(([nm, q, p], i) => { const y = 108 + i * lin; o += T(30, y, nm, { fs: 20, anc: 'start', fw: 'normal' }) + T(250, y, q, { fs: 20, fw: 'normal' }) + T(W - 30, y, fmtR(p), { fs: 20, anc: 'end', fw: 'normal' }); });
  const yT = 108 + itens.length * lin;
  o += `<line x1="30" y1="${yT - 22}" x2="${W - 30}" y2="${yT - 22}" stroke="#111" stroke-width="1.5"/>` + T(30, yT + 6, 'TOTAL', { fs: 20, anc: 'start' }) + T(W - 30, yT + 6, 'R$ ?', { fs: 22, anc: 'end', cor: '#dc2626' });
  if(pago) o += T(30, yT + 42, 'Pago com', { fs: 18, anc: 'start', fw: 'normal' }) + T(W - 30, yT + 42, fmtR(pago), { fs: 20, anc: 'end' });
  return SVG(W, H, o);
}
G.notaFiscal5 = n => {
  const k = n === 1 ? 2 : 3;
  const itens = shuffle(CANTINA).slice(0, k).map(([nm, p]) => [nm, n === 1 ? 1 : rnd(1, 3), p]);
  const tot = itens.reduce((s, [, q, p]) => s + q * p, 0);
  if(n < 3){
    const semQtd = itens.reduce((s, [, , p]) => s + p, 0);
    const erradas = [{ v: semQtd !== tot ? semQtd : null, erro: 'esqueceu de multiplicar pela quantidade' }, { v: tot - itens[0][2] * itens[0][1], erro: 'esqueceu um item' }, { v: tot + 100, erro: 'errou os reais' }, { v: tot - 10, erro: 'errou os centavos' }, { v: tot * 10, erro: 'errou a vírgula' }];
    const a = alternativas(tot, erradas.filter(e => e.v && e.v !== tot), fmtR, { min: 5, passo: 25 });
    return { ...a, text: 'Qual é o TOTAL da nota?', image: svgURI(notaSVG(itens, 0)), meta: { itens, pago: 0 }, chave: 'nf' + JSON.stringify(itens) };
  }
  const pago = [1000, 2000, 5000].find(x => x > tot);
  const tr = pago - tot;
  const erradas = [{ v: tot, erro: 'respondeu o total' }, { v: tr + 100, erro: 'errou os reais do troco' }, { v: tr - 10 > 0 ? tr - 10 : null, erro: 'errou os centavos do troco' }, { v: pago - itens.reduce((s, [, , p]) => s + p, 0), erro: 'esqueceu as quantidades' }];
  const a = alternativas(tr, erradas.filter(e => e.v && e.v !== tr && e.v > 0), fmtR, { min: 5, passo: 25 });
  return { ...a, text: 'Quanto é o TROCO?', image: svgURI(notaSVG(itens, pago)), meta: { itens, pago }, chave: 'nt' + JSON.stringify(itens) };
};
C.notaFiscal5 = m => { let t = 0; m.itens.forEach(([, q, p]) => { for(let i = 0; i < q; i++) t += p; }); return fmtR(m.pago ? m.pago - t : t); };

/* Tabela de proporção (EF05MA12) */
G.propTabela5 = n => {
  const prod = pick([['cadernos', 'Preço (R$)'], ['pacotes de figurinha', 'Preço (R$)'], ['canetas', 'Preço (R$)']]);
  const unit = n === 3 ? pick([150, 250, 350, 450]) : rnd(2, 9) * 100;       // em centavos
  const qs = n === 1 ? [1, 2, 3, 4] : [1, 2, 5, 10], iF = n === 1 ? 3 : rnd(1, 3);
  const reverso = n === 3 && Math.random() < .5 && iF > 1;
  const f = v => fmtR(v).replace('R$ ', '');
  const linhas = qs.map((q, i) => i === iF ? (reverso ? ['?', f(q * unit)] : [String(q), '?']) : [String(q), f(q * unit)]);
  let a;
  if(reverso){
    const q = qs[iF];
    const erradas = [{ v: q + 1, erro: 'errou a conta' }, { v: q - 1, erro: 'errou a conta' }, { v: q * 2, erro: 'dobrou a quantidade' }, { v: Math.round(q * unit / 100), erro: 'confundiu preço com quantidade' }];
    a = alternativas(q, erradas.filter(e => e.v !== q), String, { min: 1 });
  } else {
    const v = qs[iF] * unit;
    const erradas = [{ v: v + unit, erro: 'contou uma unidade a mais' }, { v: qs[iF - 1] * unit + unit, erro: 'somou só o preço de 1 à linha anterior' }, { v: v - unit, erro: 'contou uma unidade a menos' }, { v: v * 10, erro: 'errou a vírgula' }];
    a = alternativas(v, erradas.filter(e => e.v !== v && e.v > 0), fmtR, { min: 5, passo: 50 });
  }
  return { ...a, text: reverso ? `A tabela mostra o preço de ${prod[0]}. Qual quantidade custa R$ ${f(qs[iF] * unit)}?` : `A tabela mostra o preço de ${prod[0]}. Qual é o valor que falta?`,
    image: svgURI(tabelaSVG(['Quantidade', prod[1]], linhas)), meta: { qs, unit, iF, reverso }, chave: `pt${unit}${iF}${reverso}` };
};
C.propTabela5 = m => m.reverso ? String(m.qs[m.iF]) : fmtR(m.qs[m.iF] * m.unit);

/* Frações maiores que o inteiro: pizzas (EF05MA03) */
G.fracMista5 = n => {
  const d = pick(n === 1 ? [2, 4] : [3, 4, 6, 8]), w = rnd(1, n === 1 ? 2 : 3), k = rnd(1, d - 1);
  const pizzas = [...Array(w)].map(() => pizzaSVG(d, [...Array(d).keys()])).concat([pizzaSVG(d, [...Array(k).keys()])]);
  const img = SVG(pizzas.length * 200, 200, pizzas.map((s, i) => s.replace(/^<svg[^>]*>/, `<svg x="${i * 200}" y="0" width="195" height="195" viewBox="0 0 260 260">`)).join(''));
  const nomeD = { 2: 'meios (metades)', 3: 'terços', 4: 'quartos', 6: 'sextos', 8: 'oitavos' }[d];
  if(n < 3){
    const num = w * d + k;
    const erradas = [{ v: `${k}/${d}`, erro: 'contou só a pizza incompleta' }, { v: `${w + k}/${d}`, erro: 'contou cada pizza inteira como 1 pedaço' }, { v: `${num}/${d * (w + 1)}`, erro: 'contou todos os pedaços das pizzas como o inteiro' }, { v: `${num + 1}/${d}`, erro: 'contou um pedaço a mais' }, { v: `${d}/${num}`, erro: 'inverteu a fração' }];
    const o = altFrac(`${num}/${d}`, erradas, d);
    return { ...o, text: `Cada pizza foi cortada em ${d} pedaços. Quantos ${nomeD} de pizza há ao todo? (escreva em fração)`, image: svgURI(img), meta: { w, k, d, modo: 'impropria' }, chave: `fm${w}.${k}/${d}` };
  }
  // difícil: número misto
  const val = w + k / d, mix = (a, b) => `${a} ${b}/${d}`;
  const cands = [[mix(w, k), val, null], [mix(w + 1, k), w + 1 + k / d, 'contou a pizza incompleta como inteira'], [mix(w, d - k), w + (d - k) / d, 'contou os pedaços que faltam'], [mix(w - 1 >= 1 ? w - 1 : w + 2, k), (w - 1 >= 1 ? w - 1 : w + 2) + k / d, 'contou errado as pizzas inteiras'], [`${k} ${w}/${d}`, k + w / d, 'trocou inteiros com pedaços']];
  const vistos = new Set(), itens = [];
  cands.forEach(c => { const key = c[1].toFixed(6); if(itens.length < 4 && !vistos.has(key) && !(c[2] && Math.abs(c[1] - val) < 1e-9) && !/ 0\//.test(c[0])){ vistos.add(key); itens.push(c); } });
  for(let t = 1; itens.length < 4; t++){ const c = [mix(w + t + 1, k), w + t + 1 + k / d, 'outro valor']; if(!vistos.has(c[1].toFixed(6))){ vistos.add(c[1].toFixed(6)); itens.push(c); } }
  const emb = shuffle(itens);
  return { options: emb.map(c => c[0]), correct: emb.findIndex(c => c[2] === null), erros: emb.map(c => c[2]), answer: mix(w, k), text: 'Quantas pizzas há? (escreva como número misto: inteiros e fração)', image: svgURI(img), meta: { w, k, d, modo: 'misto' }, chave: `fx${w}.${k}/${d}` };
};
C.fracMista5 = m => m.modo === 'impropria' ? `${m.w * m.d + m.k}/${m.d}` : `${m.w} ${m.k}/${m.d}`;

/* Perímetro e área: mesmo perímetro, áreas diferentes (EF05MA20) */
function duasFigurasMalha(A, B){        // A, B = listas de células [lin, col]; desenhadas lado a lado na mesma malha
  const s = 30, alt = Math.max(...A.map(c => c[0]), ...B.map(c => c[0])) + 3, larA = Math.max(...A.map(c => c[1])) + 1, larB = Math.max(...B.map(c => c[1])) + 1;
  const C0 = larA + 3, W = C0 + larB + 1;
  const cel = [...A.map(([r, c]) => [r + 1, c + 1, 'A']), ...B.map(([r, c]) => [r + 1, c + C0, 'B'])];
  let o = '';
  for(let r = 0; r < alt; r++) for(let c = 0; c < W; c++) o += `<rect x="${10 + c * s}" y="${10 + r * s}" width="${s}" height="${s}" fill="#fff" stroke="#cbd5e1" stroke-width="1.2"/>`;
  const set = new Set(cel.map(([r, c]) => r + ',' + c));
  cel.forEach(([r, c, f]) => { o += `<rect x="${10 + c * s}" y="${10 + r * s}" width="${s}" height="${s}" fill="${f === 'A' ? '#fbbf24' : '#60a5fa'}" stroke="#94a3b8" stroke-width="1"/>`; });
  cel.forEach(([r, c]) => { const x = 10 + c * s, y = 10 + r * s; [[-1, 0, x, y, x + s, y], [1, 0, x, y + s, x + s, y + s], [0, -1, x, y, x, y + s], [0, 1, x + s, y, x + s, y + s]].forEach(([dr, dc, x1, y1, x2, y2]) => { if(!set.has((r + dr) + ',' + (c + dc))) o += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#111" stroke-width="3.5"/>`; }); });
  o += T(10 + (1 + larA / 2) * s, 10 + (alt - .2) * s, 'A', { fs: 26 }) + T(10 + (C0 + larB / 2) * s, 10 + (alt - .2) * s, 'B', { fs: 26 });
  return SVG(W * s + 20, alt * s + 20, o);
}
const retCel = (w, h) => { const c = []; for(let r = 0; r < h; r++) for(let k = 0; k < w; k++) c.push([r, k]); return c; };
G.perimArea5 = n => {
  let A, B, pede;
  if(n === 1){ const P = pick([10, 12, 14, 16]); const [w1, w2] = sortearAte(() => shuffle([...Array(P / 2 - 1).keys()].map(x => x + 1)).slice(0, 2), v => v[1] !== P / 2 - v[0] && Math.max(v[0], P / 2 - v[0], v[1], P / 2 - v[1]) <= 8); A = retCel(w1, P / 2 - w1); B = retCel(w2, P / 2 - w2); pede = 'area'; }
  else if(n === 2){ const Ar = pick([6, 8, 12, 16, 18]); const divs = [...Array(Ar).keys()].map(x => x + 1).filter(x => Ar % x === 0 && x <= Ar / x && Ar / x <= 9); const [a, b] = shuffle(divs).slice(0, 2); A = retCel(a, Ar / a); B = retCel(Ar / b, b); pede = 'perim'; }
  else { const w = rnd(3, 4), h = rnd(3, 4); A = retCel(w, h).filter(([r, c]) => !(r === 0 && c === w - 1)); const Ar = w * h - 1; const div = [...Array(Ar).keys()].map(x => x + 1).filter(x => Ar % x === 0 && Ar / x <= 9 && x <= 9); const b = pick(div); B = retCel(b, Ar / b); pede = 'perim'; }
  if(Math.random() < .5) [A, B] = [B, A];
  const med = cel => pede === 'area' ? cel.length : perimetroCel(cel);
  const mA = med(A), mB = med(B), mais = Math.random() < .6;
  const certa = mA === mB ? 'As duas são iguais' : (mais ? mA > mB : mA < mB) ? 'Figura A' : 'Figura B';
  const outra = certa === 'Figura A' ? 'Figura B' : 'Figura A';
  const erradas = certa === 'As duas são iguais' ? [{ v: 'Figura A', erro: 'não contou com cuidado' }, { v: 'Figura B', erro: 'não contou com cuidado' }] : [{ v: outra, erro: 'trocou maior com menor' }, { v: 'As duas são iguais', erro: pede === 'area' ? 'achou que mesmo perímetro dá mesma área' : 'achou que mesma área dá mesmo perímetro' }];
  const a = alternativas(certa, [...erradas, { v: 'Não dá para saber', erro: 'achou que não dá para saber' }], String);
  const txt = pede === 'area' ? `As figuras têm o MESMO PERÍMETRO. Qual tem ${mais ? 'MAIOR' : 'MENOR'} ÁREA?` : `As figuras têm a MESMA ÁREA. Qual tem ${mais ? 'MAIOR' : 'MENOR'} PERÍMETRO?`;
  return { ...a, text: txt, image: svgURI(duasFigurasMalha(A, B)), meta: { A, B, pede, mais }, chave: 'pa' + JSON.stringify([A.length, B.length, perimetroCel(A), perimetroCel(B)]) + pede + mais };
};
C.perimArea5 = m => {
  const per = cel => { let p = 0; const has = (r, c) => cel.some(x => x[0] === r && x[1] === c); cel.forEach(([r, c]) => { if(!has(r - 1, c)) p++; if(!has(r + 1, c)) p++; if(!has(r, c - 1)) p++; if(!has(r, c + 1)) p++; }); return p; };
  const a = m.pede === 'area' ? m.A.length : per(m.A), b = m.pede === 'area' ? m.B.length : per(m.B);
  return a === b ? 'As duas são iguais' : (m.mais ? a > b : a < b) ? 'Figura A' : 'Figura B';
};

/* Gráfico de linhas (EF05MA24) */
function graficoLinhaSVG(rotulos, vals, maxV, passo, titulo, unid){
  const W = 520, H = 320, x0 = 60, y0 = 270, w = 430, h = 220, X = i => x0 + 20 + i * (w - 40) / (vals.length - 1), Y = v => y0 - v / maxV * h;
  let o = T(W / 2, 26, titulo, { fs: 18 });
  for(let v = 0; v <= maxV; v += passo){ const rot = v % (passo * (maxV / passo > 10 ? 2 : 1)) === 0; o += `<line x1="${x0}" y1="${Y(v)}" x2="${x0 + w}" y2="${Y(v)}" stroke="${rot ? '#cbd5e1' : '#eef2f7'}" stroke-width="1.5"/>` + (rot ? T(x0 - 8, Y(v) + 6, v, { fs: 15, anc: 'end', fw: 'normal' }) : ''); }
  o += `<line x1="${x0}" y1="${y0}" x2="${x0 + w}" y2="${y0}" stroke="#111" stroke-width="2.5"/><line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y0 - h - 10}" stroke="#111" stroke-width="2.5"/>` + T(x0 - 44, y0 - h - 18, unid, { fs: 14, anc: 'start', cor: '#475569' });
  o += `<polyline points="${vals.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' ')}" fill="none" stroke="#dc2626" stroke-width="4" stroke-linejoin="round"/>`;
  vals.forEach((v, i) => { o += `<circle cx="${X(i)}" cy="${Y(v)}" r="6" fill="#dc2626" stroke="#fff" stroke-width="2"/>` + T(X(i), y0 + 24, rotulos[i], { fs: 15 }); });
  return SVG(W, H, o);
}
G.graficoLinha5 = n => {
  const dias = ['SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB', 'DOM'].slice(0, n === 1 ? 5 : 7), passo = n === 1 ? 5 : 2;
  const vals = sortearAte(() => dias.map(() => passo * rnd(n === 1 ? 3 : 8, n === 1 ? 7 : 16)), v => new Set(v).size >= v.length - 1 && v.filter(x => x === Math.max(...v)).length === 1 && v.filter(x => x === Math.min(...v)).length === 1);
  const maxV = Math.ceil(Math.max(...vals) / 10) * 10 + 5 - (Math.ceil(Math.max(...vals) / 10) * 10 + 5) % passo;
  const img = svgURI(graficoLinhaSVG(dias, vals, maxV, passo, 'Temperatura ao meio-dia', '°C'));
  const DIAN = { SEG: 'segunda', TER: 'terça', QUA: 'quarta', QUI: 'quinta', SEX: 'sexta', 'SÁB': 'sábado', DOM: 'domingo' };
  const tipo = n === 1 ? pick(['maior', 'valor']) : n === 2 ? pick(['valor', 'menor', 'subida']) : pick(['subida', 'dif']);
  if(tipo === 'maior' || tipo === 'menor'){
    const v = tipo === 'maior' ? Math.max(...vals) : Math.min(...vals), i = vals.indexOf(v), j = vals.indexOf(tipo === 'maior' ? Math.min(...vals) : Math.max(...vals));
    const a = alternativas(DIAN[dias[i]], dias.filter((d, k) => k !== i).map((d, k) => ({ v: DIAN[d], erro: d === dias[j] ? 'trocou maior com menor' : 'leu errado o gráfico' })), String);
    return { ...a, text: `Em que dia a temperatura foi ${tipo === 'maior' ? 'MAIS ALTA' : 'MAIS BAIXA'}?`, image: img, meta: { vals, dias, tipo }, chave: 'gl' + vals.join(',') + tipo };
  }
  if(tipo === 'valor'){
    const i = rnd(0, dias.length - 1), v = vals[i];
    const a = alternativas(v, [{ v: vals[(i + 1) % vals.length], erro: 'olhou o dia vizinho' }, { v: v + passo, erro: 'leu a linha de cima' }, { v: v - passo, erro: 'leu a linha de baixo' }, { v: v + 1, erro: 'errou a escala' }], x => x + ' °C', { min: 0, passo });
    return { ...a, text: `Qual foi a temperatura na ${DIAN[dias[i]]}?`, image: img, meta: { vals, i, tipo }, chave: 'gv' + vals.join(',') + i };
  }
  if(tipo === 'subida'){
    const difs = vals.slice(1).map((v, i) => v - vals[i]), best = Math.max(...difs);
    if(best <= 0 || difs.filter(d => d === best).length > 1) return G.graficoLinha5(n);
    const i = difs.indexOf(best);
    const certa = `de ${DIAN[dias[i]]} para ${DIAN[dias[i + 1]]}`;
    const erradas = difs.map((d, k) => k === i ? null : { v: `de ${DIAN[dias[k]]} para ${DIAN[dias[k + 1]]}`, erro: d < 0 ? 'confundiu subida com descida' : 'comparou errado as subidas' }).filter(Boolean);
    const a = alternativas(certa, erradas, String);
    return { ...a, text: 'Entre quais dias a temperatura MAIS SUBIU?', image: img, meta: { vals, dias, tipo }, chave: 'gs' + vals.join(',') };
  }
  const i = rnd(0, dias.length - 2), j = rnd(i + 1, dias.length - 1), d = Math.abs(vals[j] - vals[i]);
  if(d === 0) return G.graficoLinha5(n);
  const a = alternativas(d, [{ v: vals[j], erro: 'respondeu só um dos valores' }, { v: d + passo, erro: 'leu uma linha a mais' }, { v: vals[i] + vals[j], erro: 'somou as temperaturas' }, { v: Math.abs(d - passo) || null, erro: 'leu uma linha a menos' }].filter(e => e.v), x => x + ' °C', { min: 1, passo });
  return { ...a, text: `Qual a diferença de temperatura entre ${DIAN[dias[i]]} e ${DIAN[dias[j]]}?`, image: img, meta: { vals, i, j, tipo }, chave: 'gd' + vals.join(',') + i + j };
};
C.graficoLinha5 = m => {
  const DIAN = { SEG: 'segunda', TER: 'terça', QUA: 'quarta', QUI: 'quinta', SEX: 'sexta', 'SÁB': 'sábado', DOM: 'domingo' };
  if(m.tipo === 'maior' || m.tipo === 'menor'){ let b = 0; m.vals.forEach((v, k) => { if(m.tipo === 'maior' ? v > m.vals[b] : v < m.vals[b]) b = k; }); return DIAN[m.dias[b]]; }
  if(m.tipo === 'valor') return m.vals[m.i] + ' °C';
  if(m.tipo === 'subida'){ let b = 1; for(let k = 1; k < m.vals.length; k++) if(m.vals[k] - m.vals[k - 1] > m.vals[b] - m.vals[b - 1]) b = k; return `de ${DIAN[m.dias[b - 1]]} para ${DIAN[m.dias[b]]}`; }
  return Math.abs(m.vals[m.j] - m.vals[m.i]) + ' °C';
};

/* Partilha em partes desiguais com barras (EF05MA13 · EF06MA15) */
function barrasPartilha(nomes, partes, total, extra){   // partes = nº de pedaços iguais de cada um; extra = pedaço a mais do 1º
  const u = 60, x0 = 90; let o = '', y = 16;
  nomes.forEach((nm, i) => {
    o += T(x0 - 12, y + 30, nm, { fs: 20, anc: 'end' });
    for(let k = 0; k < partes[i]; k++) o += `<rect x="${x0 + k * u}" y="${y}" width="${u}" height="44" fill="${['#fbbf24', '#60a5fa', '#34d399'][i]}" stroke="#111" stroke-width="2.5"/>`;
    if(extra && i === 0) o += `<rect x="${x0 + partes[i] * u}" y="${y}" width="${u * .9}" height="44" fill="#fca5a5" stroke="#111" stroke-width="2.5"/>` + T(x0 + partes[i] * u + u * .45, y + 30, '+' + extra, { fs: 18 });
    y += 60;
  });
  const larg = Math.max(...partes) * u + (extra ? u : 0);
  o += `<path d="M${x0 + larg + 16} 16 Q${x0 + larg + 36} 16 ${x0 + larg + 36} ${16 + (y - 30) / 2} Q${x0 + larg + 36} ${y - 16} ${x0 + larg + 16} ${y - 16}" fill="none" stroke="#111" stroke-width="3"/>` + T(x0 + larg + 46, 22 + (y - 30) / 2, 'total ' + total, { fs: 20, anc: 'start' });
  return SVG(x0 + larg + 170, y + 6, o);
}
G.partilha5 = n => {
  const nomes = shuffle(['Ana', 'Beto', 'Caio', 'Duda', 'Lia', 'Téo']).slice(0, 2);
  if(n < 3){
    const f = n === 1 ? 2 : 3, u = rnd(3, n === 1 ? 12 : 15), total = u * (f + 1), maior = Math.random() < .5;
    const certa = maior ? u * f : u;
    const erradas = [{ v: maior ? u : u * f, erro: 'respondeu a parte do outro' }, { v: total / 2, erro: 'dividiu ao meio' }, { v: total / f, erro: `dividiu o total por ${f}` }, { v: total - u, erro: 'errou a partilha' }];
    const a = alternativas(certa, erradas.filter(e => Number.isInteger(e.v)), String, { min: 1 });
    return { ...a, text: `${nomes[0]} e ${nomes[1]} dividiram ${total} figurinhas. ${nomes[1]} ficou com o ${f === 2 ? 'DOBRO' : 'TRIPLO'} de ${nomes[0]}. Quantas ficaram com ${maior ? nomes[1] : nomes[0]}?`,
      image: svgURI(barrasPartilha(nomes, [1, f], total)), meta: { f, total, maior, modo: 'vezes' }, chave: `pa${f}.${total}${maior}` };
  }
  const menor = rnd(4, 15), dif = rnd(2, 9), total = 2 * menor + dif, pedeMaior = Math.random() < .5;
  const erradas = [{ v: pedeMaior ? menor : menor + dif, erro: 'respondeu a parte do outro' }, { v: Math.floor(total / 2), erro: 'dividiu ao meio' }, { v: (total - dif) / 2 + dif * 2, erro: 'somou a diferença duas vezes' }, { v: total - dif, erro: 'só tirou a diferença do total' }];
  const certa = pedeMaior ? menor + dif : menor;
  const a = alternativas(certa, erradas.filter(e => e.v !== certa), String, { min: 1 });
  return { ...a, text: `${nomes[0]} e ${nomes[1]} têm ${total} figurinhas juntos. ${nomes[0]} tem ${dif} a MAIS que ${nomes[1]}. Quantas tem ${pedeMaior ? nomes[0] : nomes[1]}?`,
    image: svgURI(barrasPartilha(nomes, [1, 1], total, dif)), meta: { total, dif, pedeMaior, modo: 'mais' }, chave: `pm${total}.${dif}${pedeMaior}` };
};
C.partilha5 = m => m.modo === 'vezes' ? String(m.maior ? m.total / (m.f + 1) * m.f : m.total / (m.f + 1)) : String(m.pedeMaior ? (m.total - m.dif) / 2 + m.dif : (m.total - m.dif) / 2);
