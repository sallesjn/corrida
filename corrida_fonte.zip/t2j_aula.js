
/* =========================================================================
   LOTE 7 — Tipos de ângulos (agudo, reto, obtuso, raso) — EF06MA25 / EF06MA27
========================================================================= */
const TIPOS_ANG = ['agudo', 'reto', 'obtuso', 'raso'];
const classeAng = g => g < 90 ? 'agudo' : g === 90 ? 'reto' : g < 180 ? 'obtuso' : 'raso';
/* desenho do ângulo: vértice, dois lados e a marca (arco, ou quadradinho no reto) */
function anguloSVG(g, rot, mostrar){
  const R = 150, cx = 0, cy = 0;
  const pt = (a, r) => [cx + r * Math.cos(a * Math.PI / 180), cy - r * Math.sin(a * Math.PI / 180)];
  const [x1, y1] = pt(rot, R), [x2, y2] = pt(rot + g, R);
  let o = `<line x1="${cx}" y1="${cy}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="#1d4ed8" stroke-width="7" stroke-linecap="round"/>` +
          `<line x1="${cx}" y1="${cy}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="#1d4ed8" stroke-width="7" stroke-linecap="round"/>`;
  if(g === 90){
    const k = 30, [a1, b1] = pt(rot, k), [a2, b2] = pt(rot + 90, k), a3 = a1 + (a2 - cx), b3 = b1 + (b2 - cy);
    o += `<polyline points="${a1.toFixed(1)},${b1.toFixed(1)} ${a3.toFixed(1)},${b3.toFixed(1)} ${a2.toFixed(1)},${b2.toFixed(1)}" fill="none" stroke="#dc2626" stroke-width="4"/>`;
  } else {
    const r = 48, [a1, b1] = pt(rot, r), [a2, b2] = pt(rot + g, r);
    o += `<path d="M${a1.toFixed(1)} ${b1.toFixed(1)} A${r} ${r} 0 0 0 ${a2.toFixed(1)} ${b2.toFixed(1)}" fill="none" stroke="#dc2626" stroke-width="4"/>`;
  }
  const pts = [[cx, cy], [x1, y1], [x2, y2]];
  if(mostrar){ const [tx, ty] = pt(rot + g / 2, 84); o += T(tx, ty + 9, g + '°', { fs: 28, cor: '#dc2626' }); pts.push([tx - 30, ty - 20], [tx + 30, ty + 20]); }
  if(g >= 180){ pts.push(pt(rot + 90, 60)); }
  o += `<circle cx="${cx}" cy="${cy}" r="8" fill="#111"/>`;
  // enquadra o desenho (sem sobrar espaço vazio de um lado)
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), pad = 22;
  let x0 = Math.min(...xs) - pad, y0 = Math.min(...ys) - pad, w = Math.max(...xs) - x0 + pad, h = Math.max(...ys) - y0 + pad;
  if(w < 260){ x0 -= (260 - w) / 2; w = 260; } if(h < 170){ y0 -= (170 - h) / 2; h = 170; }
  return SVG(Math.round(w), Math.round(h), `<g transform="translate(${(-x0).toFixed(1)},${(-y0).toFixed(1)})">${o}</g>`);
}
const ERRO_ANG = {
  agudo: { reto: 'achou que parecia 90°', obtuso: 'confundiu agudo (menor que 90°) com obtuso (maior)', raso: 'confundiu com o ângulo de 180°' },
  reto: { agudo: 'não reconheceu o quadradinho do ângulo reto', obtuso: 'não reconheceu o quadradinho do ângulo reto', raso: 'confundiu 90° com 180°' },
  obtuso: { agudo: 'confundiu obtuso (maior que 90°) com agudo', reto: 'achou que parecia 90°', raso: 'confundiu com o ângulo de 180°' },
  raso: { agudo: 'não percebeu que os lados formam uma reta', reto: 'confundiu 180° com 90°', obtuso: 'não percebeu que os lados formam uma reta (180°)' },
};
const altTipos = certa => alternativas(certa, TIPOS_ANG.filter(t => t !== certa).map(t => ({ v: t, erro: ERRO_ANG[certa][t] })), String);
G.tiposAng6 = n => {
  if(n === 3 && Math.random() < 0.5){
    // "Qual destes ângulos é ___?" com 4 medidas
    const alvo = pick(['agudo', 'obtuso', 'reto', 'raso']);
    const gera = c => c === 'reto' ? 90 : c === 'raso' ? 180 : c === 'agudo' ? 5 * rnd(2, 17) : 5 * rnd(19, 35);
    const certo = gera(alvo);
    const outros = shuffle(TIPOS_ANG.filter(t => t !== alvo)).map(t => ({ v: gera(t), erro: `esse ângulo é ${t}` }));
    const a = alternativas(certo, outros, v => v + '°', { min: 1, max: 180 });
    return { ...a, text: `Qual destes ângulos é ${alvo.toUpperCase()}?`, fala: `Qual destes ângulos é ${alvo}?`, meta: { tipo: 'medida', alvo, vals: a.options.map(o => parseInt(o, 10)) }, chave: 'tam' + alvo + certo };
  }
  if(n === 3){
    // ângulo entre os ponteiros do relógio (hora exata)
    const h = pick([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);
    const g = Math.min(h, 12 - h) * 30, certa = classeAng(g);
    const a = altTipos(certa);
    return { ...a, text: `Às ${h} horas, os ponteiros formam um ângulo…`, fala: `Às ${h} horas em ponto, que tipo de ângulo os ponteiros formam?`, image: svgURI(relogio(h, 0)), meta: { tipo: 'relogio', h, g }, chave: 'tar' + h };
  }
  // desenho do ângulo (N1: bem típico, sem girar; N2: perto de 90°, girado e às vezes com a medida)
  const certa = pick(TIPOS_ANG);
  const g = certa === 'reto' ? 90 : certa === 'raso' ? 180 : certa === 'agudo' ? (n === 1 ? 5 * rnd(6, 12) : 5 * rnd(14, 17)) : (n === 1 ? 5 * rnd(24, 32) : 5 * rnd(19, 22));
  const rot = n === 1 ? 0 : 5 * rnd(0, 12) * (Math.random() < .5 ? 1 : -1);
  const mostrar = n === 2 && certa !== 'reto' && certa !== 'raso' && Math.random() < 0.5;
  const a = altTipos(certa);
  return { ...a, text: 'Este ângulo é…', fala: 'Que tipo de ângulo é este?', image: svgURI(anguloSVG(g, rot, mostrar)), meta: { tipo: 'desenho', g, rot, mostrar }, chave: `tad${g}.${rot}.${mostrar}` };
};
C.tiposAng6 = m => {
  if(m.tipo === 'medida'){ const ok = m.vals.filter(v => (v < 90 ? 'agudo' : v === 90 ? 'reto' : v < 180 ? 'obtuso' : 'raso') === m.alvo); return ok.length === 1 ? ok[0] + '°' : 'ambíguo'; }   // só uma alternativa pode ser da classe pedida
  if(m.tipo === 'relogio'){ const d = Math.abs(m.h * 30 - 0) % 360, g = Math.min(d, 360 - d); return g < 90 ? 'agudo' : g === 90 ? 'reto' : g < 180 ? 'obtuso' : 'raso'; }
  return m.g < 90 ? 'agudo' : m.g === 90 ? 'reto' : m.g < 180 ? 'obtuso' : 'raso';
};

/* =========================================================================
   Retas: pedaços que NÃO se encontram no desenho, mas se encontram se forem
   prolongados (concorrentes) — ou que nunca se encontram (paralelas).
   Acrescentado aos níveis médio e difícil de paralPerp6 (4 em cada 10).
========================================================================= */
function trechosRetasSVG(a1, a2, X, off){
  // r e s passam pelo ponto X (fora do desenho, à direita) — ou são paralelas separadas por "off"
  const W = 360, H = 260, xa = 30, xb = 250;
  const seg = (a, P, cor, rot) => {
    const d = [Math.cos(a), -Math.sin(a)];
    const t1 = (xa - P[0]) / d[0], t2 = (xb - P[0]) / d[0];
    const A = [P[0] + d[0] * t1, P[1] + d[1] * t1], B = [P[0] + d[0] * t2, P[1] + d[1] * t2];
    return `<line x1="${A[0].toFixed(1)}" y1="${A[1].toFixed(1)}" x2="${B[0].toFixed(1)}" y2="${B[1].toFixed(1)}" stroke="${cor}" stroke-width="5" stroke-linecap="round"/>` + T(B[0] + 18, B[1] + 8, rot, { fs: 24, cor });
  };
  return SVG(W, H, seg(a1, off ? [X[0], X[1] - off / 2] : X, '#1d4ed8', 'r') + seg(a2, off ? [X[0], X[1] + off / 2] : X, '#dc2626', 's'));
}
const paralPerp6Original = G.paralPerp6;
G.paralPerp6 = n => {
  if(n === 1 || Math.random() >= 0.4) return paralPerp6Original(n);
  const tipo = pick(['paralelas', 'concorrentes']);
  const base = (rnd(-12, 12)) * Math.PI / 180;                          // inclinação da reta r
  const delta = (n === 3 ? rnd(8, 14) : rnd(14, 22)) * Math.PI / 180 * (Math.random() < .5 ? 1 : -1);
  const X = [rnd(420, 560), 130 + rnd(-10, 10)];                         // onde se encontrariam (fora do desenho)
  const a1 = base, a2 = tipo === 'paralelas' ? base : base + delta;
  const img = trechosRetasSVG(a1, a2, X, tipo === 'paralelas' ? rnd(70, 110) : 0);
  const d1 = [Math.cos(a1), -Math.sin(a1)], d2 = [Math.cos(a2), -Math.sin(a2)];
  const nomes = { paralelas: 'paralelas', perpendiculares: 'perpendiculares', concorrentes: 'concorrentes, mas não perpendiculares' };
  const erradas = tipo === 'concorrentes'
    ? [{ v: 'paralelas', erro: 'não imaginou as retas continuando: elas se encontram lá na frente' }, { v: 'perpendiculares', erro: 'achou que todo cruzamento é de 90°' }, { v: 'coincidentes (a mesma reta)', erro: 'confundiu com retas coincidentes' }]
    : [{ v: 'concorrentes, mas não perpendiculares', erro: 'achou que iam se encontrar' }, { v: 'perpendiculares', erro: 'confundiu os tipos de retas' }, { v: 'coincidentes (a mesma reta)', erro: 'confundiu com retas coincidentes' }];
  const a = alternativas(nomes[tipo], erradas, String);
  return { ...a, text: 'O desenho mostra só um pedaço das retas r e s (elas continuam). Elas são…', fala: 'As retas continuam dos dois lados. Elas são paralelas ou concorrentes?',
    image: svgURI(img), meta: { d1, d2, tipo, trecho: 1 }, chave: 'ppt' + tipo + a1.toFixed(3) + a2.toFixed(3) + X.join(',') };
};

/* =========================================================================
   ABRA O ÂNGULO (interativo): o aluno arrasta um dos lados a partir do 0°.
   As 4 alternativas continuam existindo por baixo (tipos ou medidas): quem
   joga no celular vê a peça de arrastar; a conferência escolhe a alternativa
   certa ou uma errada conforme o ângulo que ele abriu.
   N1: abra um ângulo agudo/reto/obtuso/raso — com a medida aparecendo
   N2: o mesmo, sem a medida
   N3: abra um ângulo de X° usando o transferidor
========================================================================= */
const ABRE_TOL = 4;
/* desenho da peça de abrir: lado azul fixo (0°) e lado vermelho girando até "g" */
function abreSVG(g, iv, certo){
  const T2 = iv.transferidor, W = 460, H = T2 ? 250 : 240, cx = 230, cy = T2 ? 230 : 205, R = T2 ? 200 : 185;
  let o = '';
  if(T2){
    o += `<path d="M${cx - R} ${cy} A${R} ${R} 0 0 1 ${cx + R} ${cy} Z" fill="#fef9c3" stroke="#a16207" stroke-width="3"/>`;
    for(let k = 0; k <= 180; k += 5){
      const t = k * Math.PI / 180, L = k % 10 === 0 ? 18 : 10;
      o += `<line x1="${(cx + R * Math.cos(t)).toFixed(1)}" y1="${(cy - R * Math.sin(t)).toFixed(1)}" x2="${(cx + (R - L) * Math.cos(t)).toFixed(1)}" y2="${(cy - (R - L) * Math.sin(t)).toFixed(1)}" stroke="#713f12" stroke-width="${k % 10 ? 1.2 : 2.2}"/>`;
      if(k % 10 === 0) o += T(cx + (R - 36) * Math.cos(t), cy - (R - 36) * Math.sin(t) + 6, k, { fs: 14 });
    }
  } else o += `<line x1="${cx - R}" y1="${cy}" x2="${cx + R}" y2="${cy}" stroke="#e2e8f0" stroke-width="2" stroke-dasharray="6,6"/>`;
  const t = g * Math.PI / 180, r = 46;
  if(g > 0) o += `<path d="M${cx} ${cy} L${cx + r} ${cy} A${r} ${r} 0 0 0 ${(cx + r * Math.cos(t)).toFixed(1)} ${(cy - r * Math.sin(t)).toFixed(1)} Z" fill="rgba(37,99,235,.18)" stroke="#2563eb" stroke-width="3"/>`;
  if(certo !== undefined && certo !== null){ const c = certo * Math.PI / 180; o += `<line x1="${cx}" y1="${cy}" x2="${(cx + (R + 12) * Math.cos(c)).toFixed(1)}" y2="${(cy - (R + 12) * Math.sin(c)).toFixed(1)}" stroke="#16a34a" stroke-width="6" stroke-dasharray="12,8"/>`; }
  o += `<line x1="${cx}" y1="${cy}" x2="${cx + R + 12}" y2="${cy}" stroke="#1d4ed8" stroke-width="7" stroke-linecap="round"/>`;
  const px = cx + (R + 12) * Math.cos(t), py = cy - (R + 12) * Math.sin(t);
  o += `<line x1="${cx}" y1="${cy}" x2="${px.toFixed(1)}" y2="${py.toFixed(1)}" stroke="#dc2626" stroke-width="7" stroke-linecap="round"/>`;
  o += `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="16" fill="#dc2626" stroke="#fff" stroke-width="4"/>`;
  if(iv.medida) o += T(cx + 78 * Math.cos(t / 2), cy - 78 * Math.sin(t / 2) + 8, Math.round(g) + '°', { fs: 26, cor: '#1d4ed8' });
  o += `<circle cx="${cx}" cy="${cy}" r="8" fill="#111"/>`;
  return SVG(W, H, o);
}
function confereAbertura(meta, g){
  if(meta.graus) return Math.abs(g - meta.graus) <= ABRE_TOL;
  if(meta.alvo === 'reto') return Math.abs(g - 90) <= ABRE_TOL;
  if(meta.alvo === 'raso') return g >= 180 - ABRE_TOL;
  if(meta.alvo === 'agudo') return g >= 5 && g < 90 - ABRE_TOL;
  return g > 90 + ABRE_TOL && g < 180 - ABRE_TOL;                                   // obtuso
}
G.abreAng6 = n => {
  if(n === 3){
    const graus = 5 * rnd(3, 33);
    const erradas = [{ v: 180 - graus, erro: 'usou a escala de fora do transferidor' }, { v: graus + 10, erro: 'passou um tracinho grande' }, { v: graus - 10, erro: 'faltou um tracinho grande' }, { v: 90, erro: 'abriu um ângulo reto' }].filter(e => e.v !== graus && e.v > 0 && e.v <= 180);
    const a = alternativas(graus, erradas, v => v + '°', { min: 5, max: 180, passo: 5 });
    return { ...a, text: `Abra um ângulo de ${graus}°`, fala: `Arraste o lado vermelho e abra um ângulo de ${graus} graus. Use o transferidor.`,
      meta: { graus }, interativo: { tipo: 'abrir', graus, medida: false, transferidor: true }, image: svgURI(abreSVG(0, { transferidor: true })), chave: 'ab' + graus };
  }
  const alvo = pick(TIPOS_ANG);
  const a = altTipos(alvo);
  return { ...a, text: `Abra um ângulo ${alvo.toUpperCase()}`, fala: `Arraste o lado vermelho e abra um ângulo ${alvo}.`,
    meta: { alvo }, interativo: { tipo: 'abrir', alvo, medida: n === 1, transferidor: false }, image: svgURI(abreSVG(0, { transferidor: false })), chave: 'ab' + alvo + n };
};
C.abreAng6 = m => m.graus ? m.graus + '°' : m.alvo;
