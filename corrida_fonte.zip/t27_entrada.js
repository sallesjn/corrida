/* =========================================================================
   ENTRADA DA TURMA: código fixo → toca no nome (anônimo: "Ana C.") → apelido opcional
   · Na rede (servidor público) só circula o rótulo "Ana C." e o apelido.
     O nome completo fica só no computador do professor e na nuvem dele.
   · O progresso fica preso ao rótulo; o apelido é só o que aparece na tela.
   · O apelido fica guardado na turma e vem pronto no próximo jogo.
   Bloco novo: só wrappers.
========================================================================= */
(function(){
  const PART = new Set(['de', 'da', 'do', 'das', 'dos', 'e', 'di', 'du']);
  const cap = w => w ? w.charAt(0).toUpperCase() + w.slice(1).toLowerCase() : '';
  const VELHO = 20 * 60 * 1000;           // mensagem retida mais velha que isso é da aula anterior

  /* ---------- rótulos (professor) ---------- */
  function candidatos(full){
    const ws = String(full).trim().split(/\s+/).filter(Boolean);
    const resto = ws.slice(1).filter(w => !PART.has(w.toLowerCase()));
    const a = cap(resto[0] || ''), z = cap(resto[resto.length - 1] || '');
    const pri = cap(ws[0] || '').slice(0, resto.length > 1 ? 9 : 12);          // rótulo cabe em 18 letras
    if(!resto.length) return [pri];
    const c = [`${pri} ${a[0]}.`, `${pri} ${a.slice(0, 2)}.`];
    if(resto.length > 1) c.push(`${pri} ${a[0]}. ${z[0]}.`, `${pri} ${a[0]}. ${z.slice(0, 2)}.`, `${pri} ${a[0]}. ${z.slice(0, 3)}.`);
    c.push(`${pri} ${a.slice(0, 3)}.`);
    return [...new Set(c)];
  }
  function normalizarNomes(){
    const T = estado.turma; if(!T || app.mode !== 'teacher') return false;
    const reais = T.reais || (T.reais = {});
    const lista = estado.cfg.nomes || [];
    const rotPorN = {}, porReal = {};
    Object.keys(reais).forEach(r => { rotPorN[normNome(r)] = r; porReal[normNome(reais[r])] = r; });
    const out = [], novos = [];
    lista.forEach(e => {
      const n = normNome(e); if(!n) return;
      if(rotPorN[n] !== undefined) out.push(rotPorN[n]);
      else if(porReal[n] !== undefined) out.push(porReal[n]);
      else if(!novos.some(x => normNome(x) === n)) novos.push(String(e).trim());
    });
    // tira rótulos sem dono (nome apagado da lista, sem progresso nem apelido): evita que um nome digitado pela metade "segure" um rótulo
    const fica = new Set(out);
    Object.keys(reais).forEach(r => { const k = normNome(r); if(!fica.has(r) && !(T.alunos || {})[k] && !(T.apelidos || {})[k]) delete reais[r]; });
    Object.keys(rotPorN).forEach(k => { if(reais[rotPorN[k]] === undefined) delete rotPorN[k]; });
    if(novos.length){
      const usados = new Set(Object.keys(rotPorN));
      const cs = novos.map(candidatos), nivel = novos.map(() => 0);
      const rot = i => cs[i][Math.min(nivel[i], cs[i].length - 1)];
      for(let volta = 0; volta < 12; volta++){
        const cont = {}; novos.forEach((_, i) => { const k = normNome(rot(i)); cont[k] = (cont[k] || 0) + 1; });
        let mudou = false;
        novos.forEach((_, i) => { const k = normNome(rot(i)); if((cont[k] > 1 || usados.has(k)) && nivel[i] < cs[i].length - 1){ nivel[i]++; mudou = true; } });
        if(!mudou) break;
      }
      // ainda igual (nomes idênticos): numera ("Ana C. 2")
      const finais = [];
      novos.forEach((_, i) => {
        let R = rot(i), n = 2;
        while(usados.has(normNome(R)) || finais.some(x => normNome(x) === normNome(R))) R = `${cs[i][0]} ${n++}`;
        finais.push(R);
      });
      novos.forEach((F, i) => {
        const R = finais[i], kF = normNome(F), kR = normNome(R);
        reais[R] = F; out.push(R);
        const A = T.alunos || {};
        if(kF !== kR && A[kF] && !A[kR]){ A[kR] = A[kF]; A[kR].nome = R; A[kR].chave = kR; delete A[kF]; }   // progresso antigo (nome completo) passa para o rótulo
      });
    }
    const final = [...new Set(out)].sort((a, b) => a.localeCompare(b, 'pt-BR'));
    const mudou = JSON.stringify(final) !== JSON.stringify(lista);
    if(mudou || novos.length){
      estado.cfg.nomes = final; salvarCfg(); salvarTurmaLocal();
      const ta = $('trNomes'); if(ta && document.activeElement !== ta) ta.value = textoReais();
    }
    return mudou;
  }
  const textoReais = () => (estado.cfg.nomes || []).map(r => ((estado.turma.reais || {})[r]) || r).join('\n');
  const nomeReal = nome => ((estado.turma && estado.turma.reais) || {})[nome] || '';
  estado.normalizarNomes = normalizarNomes;
  window.__ent = { normalizarNomes, candidatos, est: () => estado };   // para testes

  /* ---------- apelidos (professor) ---------- */
  const apelidos = () => estado.turma.apelidos || (estado.turma.apelidos = {});
  function validarApelido(a, p){
    if(!a) return '';
    if(a.length > 15) return 'O apelido pode ter no máximo 15 letras.';
    const ck = checkName(a); if(!ck.ok) return ck.reason;
    const n = normNome(a), meu = normNome(p.name);
    if((estado.cfg.nomes || []).some(r => normNome(r) === n && normNome(r) !== meu)) return 'Esse apelido é o nome de um colega. Escolha outro.';
    if(Object.entries(apelidos()).some(([k, x]) => k !== meu && normNome(x) === n)) return 'Um colega já usa esse apelido. Escolha outro.';
    if(app.host.players.some(x => x.id !== p.id && (normNome(x.name) === n || normNome(x.apelido || '') === n))) return 'Esse nome já está em uso na sala.';
    return '';
  }
  function avisarAluno(p, a, motivo){ app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'apelido', a: a || '', motivo: motivo || '' }); }
  function redesenhar(){
    try{ if(app.host.phase === 'lobby') app.renderLobby(); else { app.renderRaceTrack(); app.renderRankLive(); } }catch(e){}
    try{ app.broadcastState(); }catch(e){}
    try{ publicarNomes(); }catch(e){}
  }
  function definirApelido(p, a){
    const k = normNome(p.name), A = apelidos();
    if(a === undefined){                                  // entrou sem escolher (voltou depois de recarregar): usa o guardado
      if(p.apelido === undefined){ p.apelido = A[k] || ''; if(p.apelido) redesenhar(); }
      return;
    }
    a = String(a || '').trim().replace(/\s+/g, ' ');
    if(a === (p.apelido || '') && p.apelido !== undefined) return;
    if(a && p._vetado && normNome(a) === p._vetado){ p.apelido = ''; avisarAluno(p, '', 'O professor removeu esse apelido.'); redesenhar(); return; }
    const motivo = validarApelido(a, p);
    if(motivo){ p.apelido = ''; avisarAluno(p, '', motivo); redesenhar(); return; }
    p.apelido = a;
    if(a) A[k] = a; else delete A[k];
    salvarTurmaLocal(); redesenhar();
  }
  function apagarApelido(p){
    const A = apelidos(), k = normNome(p.name);
    p._vetado = normNome(p.apelido || ''); p.apelido = ''; delete A[k];
    salvarTurmaLocal(); avisarAluno(p, '', 'O professor removeu seu apelido.'); redesenhar();
    app.toast(`🧽 Apelido de <b>${esc(p.name)}</b> apagado`, 'info');
  }

  /* ---------- wrappers do professor ---------- */
  const publicarNomes0 = publicarNomes;
  publicarNomes = function(){ try{ normalizarNomes(); }catch(e){} return publicarNomes0.apply(this, arguments); };

  const hostPlayerJoin0 = app.hostPlayerJoin;
  app.hostPlayerJoin = function(msg){
    try{ if(estado.cfg.lista) normalizarNomes(); }catch(e){}
    const r = hostPlayerJoin0.apply(this, arguments);
    if(msg && !this.host.isDemo){ const p = this.host.players.find(x => x.id === msg.id); if(p && !p.isBot) definirApelido(p, msg.apelido); }
    return r;
  };

  /* código fixo: a sala da turma da nuvem usa sempre o mesmo código */
  let salaRoom = app.room, forcarSala = null;
  Object.defineProperty(app, 'room', { configurable: true, enumerable: true,
    get(){ return salaRoom; },
    set(v){ if(forcarSala && typeof v === 'string' && v.length === 4) v = forcarSala; salaRoom = v; } });
  const createRoom0 = app.createRoom;
  app.createRoom = function(isDemo){
    if(!estado.cfg.lista){ estado.cfg.lista = true; salvarCfg(); }        // sempre entra tocando no nome
    const cod = !isDemo && estado.nuvemAtiva && estado.nuvemAtiva() && estado.turma.codigo;
    forcarSala = cod || null;
    let r;
    try{ r = createRoom0.apply(this, arguments); } finally { forcarSala = null; }
    try{ normalizarNomes(); }catch(e){}
    return r;
  };

  /* na tela aparece o apelido (a identidade continua sendo o rótulo) */
  const comApelido = fn => function(){
    const ps = (this && this.host && this.host.players) || [], tr = [];
    ps.forEach(p => { if(p.apelido && !p.isBot){ tr.push([p, p.name]); p.name = p.apelido; } });
    try{ return fn.apply(this, arguments); } finally { tr.forEach(([p, n]) => { p.name = n; }); }
  };
  ['renderLobby', 'renderRaceTrack', 'renderRankLive', 'renderFinalRanking', 'broadcastState'].forEach(m => { if(typeof app[m] === 'function') app[m] = comApelido(app[m]); });

  /* gaveta: "Apelido (Ana C.)"; tocar no nome de quem tem apelido = apagar o apelido */
  const gavetaHTML0 = gavetaHTML;
  gavetaHTML = function(){
    let h = gavetaHTML0.apply(this, arguments);
    app.host.players.forEach(p => {
      if(p.isBot) return;
      const de = `data-troca="${esc(p.id)}" title="Pedir para trocar o nome">${esc(p.name)}`;
      const real = nomeReal(p.name);
      const para = p.apelido ? `data-troca="${esc(p.id)}" title="${esc(real || p.name)} · toque para apagar o apelido">${esc(p.apelido)} <small style="opacity:.7">(${esc(p.name)})</small>`
        : `data-troca="${esc(p.id)}" title="${real ? esc(real) + ' · ' : ''}Pedir para trocar o nome">${esc(p.name)}`;
      h = h.split(de).join(para);
    });
    return h;
  };
  const pedirTrocaNome0 = pedirTrocaNome;
  pedirTrocaNome = function(pid){
    const p = app.host.players.find(x => x.id === pid);
    if(p && p.apelido){ if(confirm(`Apagar o apelido "${p.apelido}" de ${p.name}?\nEle volta a aparecer como ${p.name}.`)) apagarApelido(p); return; }
    return pedirTrocaNome0.apply(this, arguments);
  };

  /* cartão: a caixa mostra os nomes completos; a rede só vê os rótulos */
  const montarCartao0 = montarCartao;
  montarCartao = function(){
    const r = montarCartao0.apply(this, arguments);
    // sempre pela lista da turma: some a opção "Aluno entra tocando no nome"
    if(!estado.cfg.lista){ estado.cfg.lista = true; salvarCfg(); }
    const sg = $('trLista');
    if(sg){
      const lab = sg.previousElementSibling;
      if(lab && lab.tagName === 'LABEL') lab.textContent = '👥 Alunos da turma';
      sg.style.display = 'none';
    }
    const ta = $('trNomes');
    if(ta) ta.placeholder = 'Nome completo de cada aluno, um por linha (pode colar da lista de chamada)';
    if(ta && !ta.dataset.ent){
      ta.dataset.ent = '1';
      try{ normalizarNomes(); }catch(e){}
      ta.value = textoReais();
      ta.oninput = () => { estado.cfg.nomes = nomesDaCaixa(); salvarCfg(); };        // enquanto digita, só guarda
      ta.onblur = () => { estado.cfg.nomes = nomesDaCaixa(); try{ normalizarNomes(); }catch(e){} ta.value = textoReais(); };
      const d = document.createElement('div');
      d.style.cssText = 'color:var(--muted);font-size:12px;margin-top:4px';
      d.innerHTML = '🔒 Escreva o nome completo. Na tela dos alunos aparece só o primeiro nome + inicial (ex.: <b>Ana C.</b>), e cada um pode pôr um apelido.';
      ta.after(d);
    }
    return r;
  };
  (() => { const ta = $('trNomes'); if(ta && !ta.dataset.ent){ const c = $('trilhaCard'); if(c){ c.remove(); montarCartao(); } } })();

  /* rede: carimbo de hora (o aluno ignora mensagem retida da aula anterior) + apelidos na lista */
  setTimeout(() => {                       // instala por último (por fora do envio para os servidores reserva)
  const pub0 = app.pub;
  app.pub = function(topic, obj, retain){
    if(obj && typeof obj === 'object'){
      if(this.mode === 'teacher'){
        if(obj.type === 'state' && /\/tostate$/.test(topic)) obj = Object.assign({}, obj, { ts: Date.now() });
        else if(obj.type === 'nomes'){
          const A = apelidos(), ap = {};
          (obj.nomes || []).forEach(r => { const a = A[normNome(r)]; if(a) ap[r] = a; });
          obj = Object.assign({}, obj, { ap, ts: Date.now(), fixo: !!(estado.turma.codigo && estado.turma.codigo === this.room) });
        }
      } else if(obj.type === 'join' && app.apelidoEsc !== undefined) obj = Object.assign({}, obj, { apelido: app.apelidoEsc });
    }
    return pub0.call(this, topic, obj, retain);
  };
  }, 0);
  /* sala de código fixo: mantém o estado retido sempre fresco (aluno sabe que o professor está lá) */
  setInterval(() => {
    try{ if(app.mode === 'teacher' && app.room && !app.host.isDemo && app.mqtt && app.mqtt.connected && estado.turma.codigo === app.room) app.broadcastState(); }catch(e){}
  }, 60000);

  /* ---------- aluno ---------- */
  const ent = { salaFixa: {}, ultTs: 0, ignorado: 0 }; window.__ent2 = ent;
  const st = document.createElement('style');
  st.textContent = `
  .ap-box{text-align:center;padding:6px 2px}
  .ap-box .ap-eu{font-size:22px;font-weight:900;margin-bottom:4px}
  .ap-box .ap-eu b{color:#93c5fd}
  .ap-box .ap-tx{color:var(--muted);font-weight:700;font-size:14px;margin:6px 0}
  .ap-box input{width:100%;font-size:22px;font-weight:800;text-align:center;box-sizing:border-box}
  .ap-box .ap-er{color:#fecaca;font-weight:800;font-size:13px;min-height:18px;margin:4px 0}
  .ap-box .ap-bts{display:flex;flex-direction:column;gap:8px;margin-top:6px}
  .ap-box .ap-bts button{font-size:18px;padding:12px}
  .ap-box .ap-volta{background:transparent;border:none;color:var(--muted);text-decoration:underline;font-weight:700;cursor:pointer;font-size:14px}`;
  document.head.appendChild(st);

  function telaApelido(box, R, m){
    const atual = (m.ap && m.ap[R]) || '';
    const outros = new Set([...(m.nomes || []).filter(x => x !== R).map(normNome), ...Object.entries(m.ap || {}).filter(([r]) => r !== R).map(([, a]) => normNome(a))]);
    box.innerHTML = `<div class="ap-box">
      <div class="ap-eu">Você é <b>${esc(R)}</b></div>
      <div class="ap-tx">${atual ? 'Seu apelido no jogo:' : 'Quer um apelido no jogo? (não precisa)'}</div>
      <input id="apNome" maxlength="15" autocomplete="off" spellcheck="false" placeholder="apelido (opcional)" value="${esc(atual)}">
      <div class="ap-er" id="apErro"></div>
      <div class="ap-bts"><button class="primary big" id="apEntrar">▶ Entrar</button>
        ${atual ? '<button class="ghost" id="apSem">Entrar sem apelido</button>' : ''}
        <button class="ap-volta" id="apVolta">↩ não sou ${esc(R)}</button></div></div>`;
    const entrar = a => {
      a = String(a || '').trim().replace(/\s+/g, ' ');
      if(a){
        const ck = checkName(a);
        const er = !ck.ok ? ck.reason : outros.has(normNome(a)) ? 'Esse apelido já é de um colega. Escolha outro.' : '';
        if(er){ $('apErro').textContent = '⚠️ ' + er; return; }
      }
      app.apelidoEsc = a;
      $('joinName').value = R;
      pararNomes();
      app.playerJoin();
    };
    box.onclick = e => {
      if(e.target.id === 'apEntrar') entrar($('apNome').value);
      else if(e.target.id === 'apSem') entrar('');
      else if(e.target.id === 'apVolta'){ box.innerHTML = ''; desenharNomes(ent.ultMsg || m); }
    };
    $('apNome').onkeydown = e => { if(e.key === 'Enter') entrar(e.target.value); };
    setTimeout(() => { const i = $('apNome'); if(i){ i.focus(); i.select(); } }, 50);
  }
  const desenharNomes0 = desenharNomes;
  desenharNomes = function(m){
    if(m && m.ts){                       // lista retida da aula anterior: ninguém está "em uso" ainda
      const velho = Date.now() - m.ts > VELHO, ant = ent.ultTs;
      ent.ultTs = Math.max(ent.ultTs, m.ts);
      if(velho && (!ant || m.ts <= ant)) m = Object.assign({}, m, { usados: [] });
    }
    if(m && m.fixo && listaNomes.sala) ent.salaFixa[listaNomes.sala] = true;
    const box0 = $('trNomesAluno');
    if(box0 && box0.querySelector('.ap-box')){ ent.ultMsg = m; return; }   // já está escolhendo o apelido: não apaga
    ent.ultMsg = m;
    const r = desenharNomes0.call(this, m);
    const box = $('trNomesAluno');
    if(box){
      box.onclick = e => { const b = e.target.closest('button[data-n]'); if(!b || b.disabled) return; telaApelido(box, b.dataset.n, ent.ultMsg || m); };
    }
    return r;
  };

  /* aluno: o professor apagou/recusou o apelido */
  const onMessage0 = app.onMessage;
  app.onMessage = function(topic, msg){
    if(this.mode !== 'teacher' && msg && msg.type === 'apelido' && topic.endsWith(`/to/${this.playerId}`)){
      app.apelidoEsc = msg.a || '';
      if(msg.motivo) try{ aviso(`🏷️ ${esc(msg.motivo)}<br>Você aparece como <b>${esc(app.playerName || '')}</b>.`, 3200); }catch(e){}
      return;
    }
    if(this.mode !== 'teacher' && msg && msg.type === 'state' && /\/tostate$/.test(topic) && msg.ts){
      // estado retido da aula anterior: ignora até chegar um mais novo (o professor abrindo a sala)
      if(!ent.stOk){
        const velho = Date.now() - msg.ts > VELHO;
        if(velho && (!ent.stTs || msg.ts <= ent.stTs)){ ent.stTs = Math.max(ent.stTs || 0, msg.ts); return; }
        ent.stOk = true;
      }
    }
    return onMessage0.apply(this, arguments);
  };

  /* aluno: sala de código fixo e professor ainda não abriu → "Aguardando o professor…" (sem "sala não encontrada") */
  const playerJoin0 = app.playerJoin;
  app.playerJoin = function(){
    const r = playerJoin0.apply(this, arguments);
    const sala = this.room;
    ent.stOk = false; ent.stTs = 0;
    if(sala && ent.salaFixa[sala]){
      clearInterval(ent.espT);
      let n = 0;
      ent.espT = setInterval(() => {
        if(app.room !== sala){ clearInterval(ent.espT); return; }
        if(app.player.gotState){                          // o professor abriu: avisa na hora que está aqui
          clearInterval(ent.espT);
          if(n >= 1) app.pub(`${BASE}/${sala}/tohost`, { type: 'join', id: app.playerId, name: app.playerName });
          return;
        }
        n++;
        if(n === 1){
          clearTimeout(app.player.joinTimeout);
          if($('pWaitTitle')) $('pWaitTitle').textContent = 'Aguardando o professor abrir a sala…';
          if($('pWaitSub')) $('pWaitSub').textContent = 'Pode esperar aqui: você entra sozinho quando ele abrir.';
        }
        clearTimeout(app.player.joinTimeout);
        if(n % 2 === 0) app.pub(`${BASE}/${sala}/tohost`, { type: 'join', id: app.playerId, name: app.playerName });
      }, 2000);
    }
    return r;
  };
})();
