/* =========================================================================
   VERIFICAÇÃO DOS PRESUMIDOS (C* → C ou NC)
   · O diagnóstico pula degraus quando o aluno acerta coisa mais avançada: eles
     ficam "consolidados presumidos" (C*). De vez em quando (1 em cada 10
     perguntas) o jogo traz uma pergunta de VERIFICAÇÃO de um C* do ano da turma
     ou do ano anterior, no nível médio:
       acertou ............................ vira C (confirmado no jogo)
       errou 1ª vez ....................... volta a perguntar mais tarde
       errou 2 vezes ...................... vira NC e o degrau volta para a trilha
   · Não entra no diagnóstico, no modo apoio, na pausa, no plano individual nem na
     trilha por tema. Para o aluno é uma pergunta comum.
   Bloco novo: wrappers de escolherFonte, registrar e classificar.
========================================================================= */
REGRA.pVerif = 0.20;          // chance de trocar a pergunta por uma verificação (na prática ~8% das perguntas, e some quando não há C*)
REGRA.verifAnos = 1;          // ano da turma e o anterior
function presumidosParaVerificar(rec){
  const ano = anoDaTurma();
  return CAT.filter(d => {
    const x = rec.deg[d.id];
    return ativo(d) && x && x.dom && (x.domPor === 'diag' || x.domPor === 'ano') && d.ano >= ano - REGRA.verifAnos && d.ano <= ano;
  });
}
const escolherFonteSemVerif = escolherFonte;
escolherFonte = function(rec, sorte){
  const f = escolherFonteSemVerif.apply(this, arguments);
  try{
    if(!rec || !f || f.tipo === 'diag' || (rec.diag && typeof rec.diag === 'object') || rec.apoio || rec.pausa || rec.plano || estado.temaEmUso) return f;
    if(f.tipo === 'foco' || f.tipo === 'desafio') return f;
    if(Math.random() >= REGRA.pVerif) return f;
    const ult = (rec.ultIds || []).slice(-1)[0];
    if(rec.verifUlt && rec.resp - rec.verifUlt < 3) return f;                    // nunca duas seguidas
    const cands = presumidosParaVerificar(rec).filter(d => d.id !== ult);
    if(!cands.length) return f;
    // quem errou 1 vez tem prioridade; depois, do mais avançado para o mais básico
    cands.sort((a, b) => ((rec.deg[b.id].verifErr || 0) - (rec.deg[a.id].verifErr || 0)) || (b.i - a.i));
    const d = Math.random() < 0.6 ? cands[0] : cands[Math.floor(Math.random() * cands.length)];
    return { tipo: 'verif', id: d.id, nivel: 2 };
  }catch(e){ return f; }
};
const registrarSemVerif = registrar;
registrar = function(rec, fonte, q, idx, ok, frac){
  if(!fonte || fonte.tipo !== 'verif') return registrarSemVerif.apply(this, arguments);
  const ev = registrarSemVerif.call(this, rec, Object.assign({}, fonte, { tipo: 'previa' }), q, idx, ok, frac) || {};
  try{
    rec.verifUlt = rec.resp;
    const d = rec.deg[fonte.id]; if(!d || !d.dom) return ev;
    if(q && q._ajuda) return ev;                                                  // com ajuda não confirma nem derruba
    if(ok){
      d.domPor = 'verif'; d.verifEm = new Date().toISOString(); d.verifErr = 0;
      ev.verificou = fonte.id;
    } else if((d.verifErr || 0) >= 1){
      d.dom = 0; d.domPor = ''; d.n = 2; d.cnt = 0; d.h = []; d.seqErr = 0; d.verifErr = 0; d.verifFalhou = 1;
      ev.verifFalhou = fonte.id;
      if(!rec.atual || (POR_ID[rec.atual] && POR_ID[fonte.id].i < POR_ID[rec.atual].i)) rec.atual = fonte.id;   // volta a treinar esse degrau
    } else {
      d.verifErr = 1;
    }
  }catch(e){}
  return ev;
};
/* ficha e relatório: "verif" = confirmado no jogo */
const classificarSemVerif = classificar;
classificar = function(r, d){
  const x = r && r.deg && r.deg[d.id];
  if(x && x.dom && x.domPor === 'verif'){
    const s = classificarSemVerif.apply(this, arguments);
    return Object.assign(s, { st: 'sabia', txt: 'confirmado no jogo (verificação)' + (x.verifEm ? ' · ' + new Date(x.verifEm).toLocaleDateString('pt-BR') : '') });
  }
  if(x && !x.dom && x.verifFalhou && !(x.h || []).length){
    const s = classificarSemVerif.apply(this, arguments);
    return Object.assign(s, { st: 'dificuldade', txt: 'o diagnóstico tinha dado como sabido, mas errou a verificação 2 vezes' });
  }
  return classificarSemVerif.apply(this, arguments);
};
estado.classificar = classificar;
estado.presumidosParaVerificar = presumidosParaVerificar;
