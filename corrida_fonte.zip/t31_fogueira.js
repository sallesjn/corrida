/* =========================================================================
   FOGUEIRA (nível do aluno) + ACERTOS NO TOTAL — tela do ALUNO
   · A fogueira é um NÍVEL (Nv 1, 2, 3…) que só sobe, nunca zera. Ela cresce com
     a experiência (XP), que junta tudo:
       acerto ............................ +2  (com ajuda: +1)
       acerto rápido na corrida (<35% do tempo) +1
       degrau conquistado ................ +20
       desafio vencido ................... +5
     Do nível N para o N+1 precisa de 40 + 20×(N−1) XP (cada nível pede um pouco mais).
     O aluno vê só o nível, o tamanho da fogueira e uma barrinha até o próximo.
   · ✅ Acertos no total: separado, soma todas as aulas (não zera).
   · O passo dentro do degrau atual vira bolinhas (●●○○) em vez de uma 2ª chama.
   · Ao voltar para a aula: "Bem-vindo de volta! 🔥 Nv 5 · ✅ 348 · 🪜 12".
   Bloco novo: wrappers (registrar, extrasPergunta, aviso, finishPlayerMatch).
========================================================================= */
const XP = { acerto: 2, ajuda: 1, rapido: 1, rapidoFrac: 0.35, degrau: 20, desafio: 5, base: 40, passo: 20 };
function xpInicial(rec){                         // alunos que já jogavam: calcula pelo que já fizeram
  let ac = 0, dom = 0;
  Object.values(rec.deg || {}).forEach(d => { ac += d.ac || 0; if(d.dom && (d.domPor === 'trilha' || d.domPor === 'treino')) dom++; });
  return ac * XP.acerto + dom * XP.degrau + ((rec.desafios && rec.desafios.ok) || 0) * XP.desafio;
}
function xpDe(rec){ if(rec && typeof rec.xp !== 'number') rec.xp = xpInicial(rec); return (rec && rec.xp) || 0; }
function nivelDe(xp){
  let n = 1, falta = xp, preciso = XP.base;
  while(falta >= preciso){ falta -= preciso; n++; preciso = XP.base + XP.passo * (n - 1); }
  return { n, dentro: falta, preciso, pct: Math.round(falta / preciso * 100) };
}
function acertosTotal(rec){ return Object.values((rec && rec.deg) || {}).reduce((s, d) => s + (d.ac || 0), 0); }
const tamanhoFogueira = n => n >= 15 ? 4 : n >= 10 ? 3 : n >= 5 ? 2 : 1;   // 4 tamanhos de chama (o 15+ ganha brilho azul)

/* XP sobe a cada resposta (no Chromebook do aluno; vai para o professor junto com o progresso) */
const registrarSemXp = registrar;
registrar = function(rec, fonte, q, idx, ok, frac){
  if(rec && typeof rec.xp !== 'number') rec.xp = xpInicial(rec);
  const ev = registrarSemXp.apply(this, arguments);
  try{
    if(rec && ok){
      let g = q && q._ajuda ? XP.ajuda : XP.acerto;
      if(!(q && q._ajuda) && +frac > 0 && +frac < XP.rapidoFrac) g += XP.rapido;      // treino manda frac 0: não conta rapidez
      rec.xp += g;
    }
    if(rec && ev && ev.dominou) rec.xp += XP.degrau;
    if(rec && ev && ev.desafio === 'venceu') rec.xp += XP.desafio;
  }catch(e){}
  return ev;
};

if(typeof window !== 'undefined') (() => {
  const st = document.createElement('style');
  st.textContent = `
  .fg-box{display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap;vertical-align:middle}
  .fg-nv{font-weight:900;font-size:15px;color:#fed7aa}
  .fg-bar{display:inline-block;width:46px;height:7px;border-radius:9px;background:rgba(0,0,0,.35);overflow:hidden;vertical-align:middle}
  .fg-bar i{display:block;height:100%;background:linear-gradient(90deg,#f97316,#facc15);border-radius:9px}
  .fg-passos{letter-spacing:1px;font-size:11px;color:#fde68a;opacity:.9}
  .fg-chip{font-weight:900;font-size:14px;color:#bbf7d0;background:rgba(0,0,0,.25);border-radius:999px;padding:2px 9px}
  .fg-subiu .ch-svg{animation:chCresce 1.1s ease-out 1, chBalanca 1.6s ease-in-out 1.1s infinite}
  .fg-volta{margin:14px auto 0;max-width:420px;background:rgba(249,115,22,.12);border:2px solid #f97316;border-radius:16px;padding:10px 14px;font-weight:900;color:#fed7aa;text-align:center}
  .fg-volta b{color:#fff}`;
  document.head.appendChild(st);

  const recDoAluno = () => { try{ const pt = app.player && app.player.trilha; return pt && pt.rec; }catch(e){ return null; } };
  let ultNivel = 0;
  function caixaHTML(rec, idDegrau){
    const xp = xpDe(rec), nv = nivelDe(xp), est = idDegrau ? estagioChama(rec, idDegrau) : 1;
    const passos = '●'.repeat(est) + '○'.repeat(Math.max(0, 4 - est));
    return { nv, html: chamaSVG(tamanhoFogueira(nv.n)) +
      `<span class="fg-nv" title="Nível da fogueira: sobe com acertos, rapidez, degraus e desafios">Nv ${nv.n}</span>` +
      `<span class="fg-bar" title="Falta pouco para o nível ${nv.n + 1}"><i style="width:${nv.pct}%"></i></span>` +
      `<span class="fg-passos" title="Passos no degrau de agora">${passos}</span>` +
      `<span class="ch-degraus" title="Degraus conquistados">🪜 ${resumo(rec).dominados}</span>` +
      `<span class="fg-chip" title="Acertos no total (todas as aulas)">✅ ${acertosTotal(rec)}</span>` };
  }
  /* troca a chama do degrau pela fogueira (nível) */
  const extras0 = extrasPergunta;
  extrasPergunta = function(q){
    const r = extras0.apply(this, arguments);
    try{
      const rec = recDoAluno(), box = document.querySelector('#ppTrilhaInfo .ch-box');
      if(rec && box){
        const c = caixaHTML(rec, rec.atual || (q && q.trilha && q.trilha.id));
        box.classList.add('fg-box'); box.classList.remove('ch-cresceu');
        box.title = '';
        box.innerHTML = c.html;
        if(ultNivel && c.nv.n > ultNivel){
          box.classList.add('fg-subiu');
          setTimeout(() => { try{ aviso(`🔥 Sua fogueira subiu para o <b>nível ${c.nv.n}</b>!`, 2400); if(typeof ENG !== 'undefined' && ENG.fanfarra) ENG.fanfarra(); }catch(e){} }, 300);
        }
        ultNivel = c.nv.n;
      }
    }catch(e){ console.warn('[fogueira]', e); }
    return r;
  };
  /* o aviso de subir de nível dentro do degrau não fala mais em "chama" */
  const aviso0 = aviso;
  aviso = function(txt, ms){
    if(/Sua chama cresceu/.test(String(txt))) txt = '🪜 Mais um passo no degrau!';
    return aviso0.call(this, txt, ms);
  };
  /* tela final: nível e total */
  const fim0 = app.finishPlayerMatch;
  app.finishPlayerMatch = function(){
    const r = fim0.apply(this, arguments);
    try{
      const rec = recDoAluno(), el = $('pdStats');
      if(rec && el){ const nv = nivelDe(xpDe(rec)); el.insertAdjacentHTML('beforeend', `<br>🔥 Fogueira <b>nível ${nv.n}</b> · ✅ ${acertosTotal(rec)} acertos no total`); }
    }catch(e){}
    return r;
  };
  /* tela de espera: "Bem-vindo de volta" */
  setInterval(() => {
    try{
      if(app.mode === 'teacher') return;
      const w = $('playerWait'), rec = recDoAluno();
      if(!w || !rec || !(rec.resp > 0) || w.classList.contains('hidden') || !w.offsetParent){ return; }
      let b = $('fgVolta');
      if(!b){ b = document.createElement('div'); b.id = 'fgVolta'; b.className = 'fg-volta'; w.appendChild(b); }
      const nv = nivelDe(xpDe(rec)), nome = app.apelidoEsc || app.playerName || '';
      const txt = `Bem-vindo de volta${nome ? ', <b>' + esc(nome) + '</b>' : ''}!<br>🔥 Nv ${nv.n} · ✅ ${acertosTotal(rec)} acertos · 🪜 ${resumo(rec).dominados} degraus`;
      if(b.innerHTML !== txt) b.innerHTML = txt;
    }catch(e){}
  }, 1000);
})();
