/* =========================================================================
   TELA DO PROFESSOR MAIS ENXUTA + EDITOR DA TURMA
   · Fica à vista: turmas na nuvem, tipo de sala, foco, tema, desafios, duração.
   · O resto vai para "⚙️ Mais ajustes" (recolhido). Nada é apagado: os mesmos
     controles, só mudam de lugar.
   · ✏️ Editar turma: nome, ano, código e alunos (incluir um, tirar um, colar
     lista, importar arquivo .txt/.csv, corrigir nome, apagar apelido).
   Bloco novo: só wrappers.
========================================================================= */
(function(){
  const st = document.createElement('style');
  st.textContent = `
  .mx-det{margin:0 0 14px;border:1px solid var(--line);border-radius:14px;background:rgba(15,23,42,.35)}
  .mx-det>summary{cursor:pointer;padding:12px 14px;font-weight:900;color:var(--muted);list-style:none;user-select:none}
  .mx-det>summary::-webkit-details-marker{display:none}
  .mx-det>summary:before{content:'▸ ';display:inline-block;transition:transform .15s}
  .mx-det[open]>summary:before{transform:rotate(90deg)}
  .mx-det>.mx-in{padding:4px 12px 12px}
  .mx-det .card{margin-bottom:10px}
  .te-fundo{position:fixed;inset:0;z-index:600;background:rgba(2,6,23,.88);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:20px 12px}
  .te-card{background:var(--panel);border:2px solid #38bdf8;border-radius:18px;padding:18px;max-width:640px;width:100%;color:var(--text)}
  .te-topo{display:flex;align-items:center;gap:10px;margin-bottom:12px}
  .te-topo h2{margin:0;font-size:22px;flex:1}
  .te-topo button{width:auto;padding:8px 14px}
  .te-lin{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
  .te-lin label{margin:0;min-width:110px}
  .te-lin input,.te-lin select{flex:1;min-width:140px;width:auto}
  .te-cod{font-size:22px;letter-spacing:3px;font-weight:900;color:#fde68a;background:#082f49;border-radius:8px;padding:2px 12px}
  .te-sec{margin-top:16px;border-top:1px solid var(--line);padding-top:12px}
  .te-sec h3{margin:0 0 8px;font-size:16px}
  .te-add{display:flex;gap:8px}
  .te-add input{flex:1}
  .te-add button{width:auto;padding:8px 14px}
  .te-bts{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}
  .te-bts button{width:auto;padding:7px 12px;font-size:14px}
  .te-cola{width:100%;min-height:120px;box-sizing:border-box;margin-top:6px}
  .te-lista{display:flex;flex-direction:column;gap:4px;max-height:46vh;overflow:auto;margin-top:8px}
  .te-al{display:flex;align-items:center;gap:8px;background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:6px 10px}
  .te-al .nm{flex:1;font-weight:800}
  .te-al .nm small{display:block;font-weight:600;color:var(--muted);font-size:12px}
  .te-al button{width:auto;background:transparent;border:none;cursor:pointer;font-size:16px;padding:2px 6px;color:var(--muted)}
  .te-al button.rm{color:#fca5a5}
  .te-msg{min-height:18px;font-size:13px;font-weight:800;color:#86efac;margin-top:6px}
  .te-msg.er{color:#fca5a5}
  .nv-edita{width:100%;margin:2px 0 8px;border-radius:10px;padding:9px;font-weight:900;border:2px solid #fde68a;background:#422006;color:#fde68a;cursor:pointer;font-size:15px}`;
  document.head.appendChild(st);

  /* ---------- reorganiza a tela (move, não apaga) ---------- */
  function organizar(){
    const card = $('trilhaCard'); if(!card) return;
    const setup = card.closest('section') || card.parentElement;
    let anc = $('mxAncora');
    if(!anc){ anc = document.createElement('div'); anc.id = 'mxAncora'; card.before(anc); }
    if(card.previousElementSibling !== anc) anc.after(card);
    // caixa recolhida "Mais ajustes"
    let det = $('mxDet');
    if(!det){
      det = document.createElement('details'); det.id = 'mxDet'; det.className = 'mx-det';
      det.innerHTML = '<summary>⚙️ Mais ajustes (trilha, arquivos, tempo, equipes…)</summary><div class="mx-in"></div>';
    }
    const dentro = det.querySelector('.mx-in');
    // cartões originais da partida: fica à vista só "Duração da partida"
    let duracao = null;
    [...setup.querySelectorAll(':scope > .card')].forEach(c => {
      if(c === card) return;
      const lab = (c.querySelector('label') || {}).textContent || '';
      if(/Duração da partida/.test(lab)){ duracao = c; return; }
      dentro.appendChild(c);
    });
    if(duracao){ card.after(duracao); duracao.after(det); } else card.after(det);
    // dentro do cartão da Trilha
    let bl = $('mxTrilha');
    if(!bl){ bl = document.createElement('div'); bl.id = 'mxTrilha'; bl.className = 'card'; }
    bl.innerHTML = '<label>🧗 Trilha (ajustes)</label>';          // o cartão foi refeito: tira os controles velhos
    dentro.prepend(bl);
    const mover = el => { if(el && el.parentElement !== bl) bl.appendChild(el); };
    const desc = [...card.children].find(e => e.tagName === 'DIV' && /Cada aluno sobe degrau/.test(e.textContent) && !e.id);
    mover(desc); mover($('trOn')); mover($('trCatalogo'));
    const op = $('trOpts');
    if(op){
      const rowDe = id => { const e = $(id); return e && e.closest('#trOpts > *'); };
      const anoMaxRow = rowDe('trAnoMax');
      const nota = anoMaxRow && anoMaxRow.nextElementSibling && !anoMaxRow.nextElementSibling.querySelector('select,button,input') ? anoMaxRow.nextElementSibling : null;
      [anoMaxRow, nota, rowDe('trAno'), rowDe('trDiag'), rowDe('trRev'), rowDe('trNomes'), rowDe('trTurmaNome'), op.querySelector(':scope > .config-actions'), $('trStatus'), $('trMapa')].forEach(mover);
    }
    // linha "Alunos" à vista (abre o editor)
    let la = $('mxAlunos');
    if(!la){ la = document.createElement('button'); la.id = 'mxAlunos'; la.className = 'nv-edita'; la.onclick = () => abrirEditor(); }
    la.textContent = `✏️ Editar turma · 👥 ${(estado.cfg.nomes || []).length} aluno${(estado.cfg.nomes || []).length === 1 ? '' : 's'}`;
    const nvb = $('nvBox');
    if(nvb) nvb.after(la); else { const l = card.querySelector('label'); if(l) l.after(la); }
  }
  const montarCartao0 = montarCartao;
  montarCartao = function(){
    // cartão vai ser refeito: tira antes os controles velhos que foram movidos (senão os ids ficam repetidos)
    if(!$('trilhaCard')){ const bl = $('mxTrilha'); if(bl) bl.innerHTML = ''; const la = $('mxAlunos'); if(la) la.remove(); }
    const r = montarCartao0.apply(this, arguments); try{ organizar(); }catch(e){ console.error(e); } return r; };
  try{ organizar(); }catch(e){ console.error(e); }

  /* ---------- editor da turma ---------- */
  const reais = () => estado.turma.reais || (estado.turma.reais = {});
  const apel = () => estado.turma.apelidos || (estado.turma.apelidos = {});
  const nomeCompleto = r => reais()[r] || r;
  function limparLinha(l){
    let s = String(l || '').replace(/﻿/g, '').trim();
    if(!s) return '';
    const campos = s.split(/[\t;,]/).map(x => x.trim().replace(/^"|"$/g, '')).filter(Boolean);
    if(campos.some(x => /^(nome|nomes|aluno|alunos|estudante|estudantes)\b/i.test(x)) && campos.length > 1) return '';   // cabeçalho do CSV
    if(campos.length > 1) s = campos.filter(x => /[a-zA-ZÀ-ÿ]{2,}/.test(x) && !/\d{3,}/.test(x)).sort((a, b) => b.length - a.length)[0] || '';
    s = s.replace(/^\s*\d+\s*[-.)–:]?\s*/, '').replace(/\s+/g, ' ').trim();
    if(/^(nome|nomes|aluno|alunos|estudante|estudantes|nome do aluno|nome completo)$/i.test(s)) return '';
    if(!/[a-zA-ZÀ-ÿ]{2,}/.test(s)) return '';
    return s.slice(0, 60);
  }
  function jaTem(full){
    const n = normNome(full);
    return (estado.cfg.nomes || []).some(r => normNome(r) === n || normNome(nomeCompleto(r)) === n);
  }
  function aplicar(){
    try{ estado.normalizarNomes && estado.normalizarNomes(); }catch(e){}
    salvarCfg(); salvarTurmaLocal();
    const ta = $('trNomes'); if(ta) ta.value = (estado.cfg.nomes || []).map(nomeCompleto).join('\n');
    try{ if(app.room && app.mode === 'teacher') publicarNomes(); }catch(e){}
  }
  function incluir(lista){
    let n = 0, rep = 0;
    lista.map(limparLinha).filter(Boolean).forEach(f => { if(jaTem(f)){ rep++; return; } estado.cfg.nomes = [...(estado.cfg.nomes || []), f]; n++; });
    if(n) aplicar();
    return { n, rep };
  }
  function abrirEditor(){
    let box = $('teBox'); if(box) box.remove();
    box = document.createElement('div'); box.id = 'teBox'; box.className = 'te-fundo';
    document.body.appendChild(box);
    const antes = JSON.stringify([estado.turma.nome, estado.cfg.ano]);
    const fechar = () => {
      box.remove();
      const mudou = JSON.stringify([estado.turma.nome, estado.cfg.ano]) !== antes;
      const c = $('trilhaCard'); if(c){ c.remove(); montarCartao(); }
      if(mudou) try{ atualizarStatus(); }catch(e){}
    };
    const msg = (t, er) => { const m = $('teMsg'); if(m){ m.textContent = t; m.className = 'te-msg' + (er ? ' er' : ''); } };
    const desenha = () => {
      const T = estado.turma, rs = (estado.cfg.nomes || []).slice().sort((a, b) => nomeCompleto(a).localeCompare(nomeCompleto(b), 'pt-BR'));
      const nuvem = estado.nuvemAtiva && estado.nuvemAtiva();
      const lista = rs.map(r => {
        const k = normNome(r), rec = (T.alunos || {})[k], ap = apel()[k];
        const dom = rec ? CAT.filter(d => rec.deg && rec.deg[d.id] && rec.deg[d.id].dom).length : 0;
        return `<div class="te-al"><div class="nm">${esc(nomeCompleto(r))}<small>aparece como <b>${esc(r)}</b>${ap ? ` · apelido <b>${esc(ap)}</b>` : ''}${rec ? ` · ${dom} degrau${dom === 1 ? '' : 's'}` : ' · ainda não jogou'}</small></div>
          ${ap ? `<button data-tap="${esc(r)}" title="Apagar o apelido">🧽</button>` : ''}
          <button data-tren="${esc(r)}" title="Corrigir o nome">✏️</button>
          <button class="rm" data-trm="${esc(r)}" title="Tirar da turma">✕</button></div>`;
      }).join('');
      box.innerHTML = `<div class="te-card">
        <div class="te-topo"><h2>✏️ Turma</h2><button class="primary" data-tfecha="1">✓ Pronto</button></div>
        <div class="te-lin"><label>Nome</label><input id="teNome" maxlength="40" value="${esc(T.nome || '')}" placeholder="Ex.: 7º M01"></div>
        <div class="te-lin"><label>Ano</label><select id="teAno">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(a => `<option value="${a}" ${a === estado.cfg.ano ? 'selected' : ''}>${a}º ano</option>`).join('')}</select></div>
        ${nuvem ? `<div class="te-lin"><label>Código</label><span class="te-cod">${esc(T.codigo || '----')}</span><span style="color:var(--muted);font-size:12px">os alunos digitam este código (trocar: no quadro da nuvem)</span></div>` : ''}
        <div class="te-sec"><h3>👥 Alunos (${rs.length})</h3>
          <div class="te-add"><input id="teNovo" maxlength="60" placeholder="Nome completo do aluno" autocomplete="off"><button class="primary" id="teIncluir">➕ Incluir</button></div>
          <div class="te-bts"><button class="ghost" id="teColarBt">📋 Colar vários nomes</button><button class="ghost" id="teArqBt">📂 Importar arquivo (.txt ou .csv)</button><input type="file" id="teArq" accept=".txt,.csv,text/plain,text/csv" style="display:none"></div>
          <div id="teColarBox" style="display:none"><textarea class="te-cola" id="teCola" placeholder="Cole aqui a lista (um nome por linha). Pode colar a coluna de nomes da lista de chamada."></textarea>
            <div class="te-bts"><button class="primary" id="teColarOk">➕ Incluir todos</button></div></div>
          <div class="te-msg" id="teMsg"></div>
          <div class="te-lista">${lista || '<div style="color:var(--muted);padding:8px">Nenhum aluno ainda. Inclua um por um, cole a lista ou importe um arquivo.</div>'}</div>
          <div style="color:var(--muted);font-size:12px;margin-top:8px">🔒 Na tela dos alunos aparece só o primeiro nome + inicial. ✕ tira o aluno da turma e apaga o progresso dele.</div>
        </div></div>`;
      setTimeout(() => { const i = $('teNovo'); if(i) i.focus(); }, 30);
    };
    box.onclick = e => {
      const t = e.target;
      if(t === box || t.closest('[data-tfecha]')){ fechar(); return; }
      if(t.id === 'teIncluir'){
        const v = $('teNovo').value; if(!limparLinha(v)) return;
        if(jaTem(v)){ msg('Esse nome já está na turma.', true); return; }
        incluir([v]); desenha(); msg(`➕ ${limparLinha(v)} incluído`); return;
      }
      if(t.id === 'teColarBt'){ const c = $('teColarBox'); c.style.display = c.style.display === 'none' ? '' : 'none'; if(c.style.display === '') $('teCola').focus(); return; }
      if(t.id === 'teColarOk'){ const r = incluir($('teCola').value.split(/\r?\n/)); desenha(); msg(`➕ ${r.n} aluno${r.n === 1 ? '' : 's'} incluído${r.n === 1 ? '' : 's'}${r.rep ? ` · ${r.rep} já estava${r.rep === 1 ? '' : 'm'} na turma` : ''}`); return; }
      if(t.id === 'teArqBt'){ $('teArq').click(); return; }
      const rm = t.closest('[data-trm]');
      if(rm){
        const r = rm.dataset.trm, k = normNome(r);
        const naSala = app.host && app.host.players && app.host.players.some(p => normNome(p.name) === k);
        if(!confirm(`Tirar ${nomeCompleto(r)} da turma?\nO progresso e o apelido dele também são apagados.${naSala ? '\n(Ele está na sala agora: continua até sair.)' : ''}`)) return;
        estado.cfg.nomes = (estado.cfg.nomes || []).filter(x => x !== r);
        delete reais()[r]; delete apel()[k]; if(estado.turma.alunos) delete estado.turma.alunos[k];
        aplicar(); desenha(); msg(`✕ ${nomeCompleto(r) || r} saiu da turma`); return;
      }
      const rn = t.closest('[data-tren]');
      if(rn){
        const r = rn.dataset.tren;
        const novo = limparLinha(prompt(`Corrigir o nome completo de ${r}:\n(o progresso continua o mesmo; na tela dos alunos continua "${r}")`, nomeCompleto(r)) || '');
        if(!novo || novo === nomeCompleto(r)) return;
        if(jaTem(novo) && normNome(novo) !== normNome(nomeCompleto(r))){ msg('Esse nome já está na turma.', true); return; }
        reais()[r] = novo; aplicar(); desenha(); msg('✏️ Nome corrigido'); return;
      }
      const ap = t.closest('[data-tap]');
      if(ap){
        const r = ap.dataset.tap, k = normNome(r);
        if(!confirm(`Apagar o apelido "${apel()[k]}" de ${r}?`)) return;
        delete apel()[k];
        const p = app.host && app.host.players && app.host.players.find(x => normNome(x.name) === k);
        if(p && typeof pedirTrocaNome === 'function' && p.apelido){ p.apelido = ''; try{ app.pub(`${BASE}/${app.room}/to/${p.id}`, { type: 'apelido', a: '', motivo: 'O professor removeu seu apelido.' }); app.broadcastState(); }catch(err){} }
        aplicar(); desenha(); msg('🧽 Apelido apagado'); return;
      }
    };
    box.onchange = e => {
      const t = e.target;
      if(t.id === 'teNome'){ estado.turma.nome = t.value.trim(); if($('trTurmaNome')) $('trTurmaNome').value = estado.turma.nome; salvarTurmaLocal(); msg('✓ Nome da turma salvo'); }
      if(t.id === 'teAno'){ const a = +t.value; estado.cfg.ano = a; if((estado.cfg.anoMax || 9) < a) estado.cfg.anoMax = a; salvarCfg(); salvarTurmaLocal(); msg(`✓ Turma do ${a}º ano`); }
      if(t.id === 'teArq'){
        const f = t.files && t.files[0]; if(!f) return;
        const ler = enc => new Promise(ok => { const rd = new FileReader(); rd.onload = () => ok(String(rd.result || '')); rd.readAsText(f, enc); });
        (async () => {
          let txt = await ler('UTF-8');
          if(/�/.test(txt)) txt = await ler('windows-1252');          // CSV salvo pelo Excel
          const r = incluir(txt.split(/\r?\n/));
          desenha(); msg(`📂 ${r.n} aluno${r.n === 1 ? '' : 's'} incluído${r.n === 1 ? '' : 's'} do arquivo${r.rep ? ` · ${r.rep} já estava${r.rep === 1 ? '' : 'm'} na turma` : ''}`, !r.n && !r.rep);
        })();
        t.value = '';
      }
    };
    box.onkeydown = e => { if(e.key === 'Enter' && e.target.id === 'teNovo') $('teIncluir').click(); if(e.key === 'Escape') fechar(); };
    desenha();
  }
  estado.abrirEditorTurma = abrirEditor;
  window.__te = { abrirEditor, limparLinha };   // para testes
})();
